﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Parser;

namespace ICSharpCode.NRefactory
{
	public interface IParser : IDisposable
	{
		void Parse();

		BlockStatement ParseBlock();

		Expression ParseExpression();

		List<INode> ParseTypeMembers();

		TypeReference ParseTypeReference();

		CompilationUnit CompilationUnit
		{
			get;
		}

		Errors Errors
		{
			get;
		}

		ILexer Lexer
		{
			get;
		}

		bool ParseMethodBodies
		{
			get;
			set;
		}
	}
}
