﻿using System;

namespace ICSharpCode.NRefactory
{
	public enum SupportedLanguage
	{
		CSharp,
		VBNet
	}
}
