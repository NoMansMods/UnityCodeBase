﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class CollectionInitializerExpression : Expression
	{
		public CollectionInitializerExpression()
		{
			this.createExpressions = new List<Expression>();
		}

		public CollectionInitializerExpression(List<Expression> createExpressions)
		{
			this.CreateExpressions = createExpressions;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitCollectionInitializerExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[CollectionInitializerExpression CreateExpressions={0}]", AbstractNode.GetCollectionString(this.CreateExpressions));
		}

		public List<Expression> CreateExpressions
		{
			get
			{
				return this.createExpressions;
			}
			set
			{
				this.createExpressions = (value ?? new List<Expression>());
			}
		}

		public new static CollectionInitializerExpression Null
		{
			get
			{
				return NullCollectionInitializerExpression.Instance;
			}
		}

		private List<Expression> createExpressions;
	}
}
