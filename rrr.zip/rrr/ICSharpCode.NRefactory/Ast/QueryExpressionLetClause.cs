﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionLetClause : QueryExpressionClause
	{
		public QueryExpressionLetClause()
		{
			this.identifier = "?";
			this.expression = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionLetClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionLetClause Identifier={0} Expression={1}]", this.Identifier, this.Expression);
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
				if (!this.expression.IsNull)
				{
					this.expression.Parent = this;
				}
			}
		}

		public string Identifier
		{
			get
			{
				return this.identifier;
			}
			set
			{
				this.identifier = (string.IsNullOrEmpty(value) ? "?" : value);
			}
		}

		private Expression expression;

		private string identifier;
	}
}
