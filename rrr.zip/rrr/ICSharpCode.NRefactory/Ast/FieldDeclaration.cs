﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class FieldDeclaration : AttributedNode
	{
		public FieldDeclaration(List<AttributeSection> attributes)
		{
			base.Attributes = attributes;
			this.typeReference = TypeReference.Null;
			this.fields = new List<VariableDeclaration>();
		}

		public FieldDeclaration(List<AttributeSection> attributes, TypeReference typeReference, Modifiers modifier)
		{
			base.Attributes = attributes;
			this.TypeReference = typeReference;
			base.Modifier = modifier;
			this.fields = new List<VariableDeclaration>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitFieldDeclaration(this, data);
		}

		public TypeReference GetTypeForField(int fieldIndex)
		{
			if (!this.typeReference.IsNull)
			{
				return this.typeReference;
			}
			return this.Fields[fieldIndex].TypeReference;
		}

		public VariableDeclaration GetVariableDeclaration(string variableName)
		{
			foreach (VariableDeclaration current in this.Fields)
			{
				if (current.Name == variableName)
				{
					return current;
				}
			}
			return null;
		}

		public override string ToString()
		{
			return string.Format("[FieldDeclaration TypeReference={0} Fields={1} Attributes={2} Modifier={3}]", new object[]
			{
				this.TypeReference,
				AbstractNode.GetCollectionString(this.Fields),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public List<VariableDeclaration> Fields
		{
			get
			{
				return this.fields;
			}
			set
			{
				this.fields = (value ?? new List<VariableDeclaration>());
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		private List<VariableDeclaration> fields;

		private TypeReference typeReference;
	}
}
