﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullTypeReference : TypeReference
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override TypeReference Clone()
		{
			return this;
		}

		public override string ToString()
		{
			return string.Format("[NullTypeReference]", new object[0]);
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		public static readonly NullTypeReference Instance = new NullTypeReference();
	}
}
