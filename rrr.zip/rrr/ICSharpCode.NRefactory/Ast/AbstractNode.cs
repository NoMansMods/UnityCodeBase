﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class AbstractNode : INode
	{
		public virtual object AcceptChildren(IAstVisitor visitor, object data)
		{
			foreach (INode current in this.children)
			{
				current.AcceptVisitor(visitor, data);
			}
			return data;
		}

		public abstract object AcceptVisitor(IAstVisitor visitor, object data);

		public virtual void AddChild(INode childNode)
		{
			this.children.Add(childNode);
		}

		public static string GetCollectionString(ICollection collection)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append('{');
			if (collection != null)
			{
				IEnumerator enumerator = collection.GetEnumerator();
				bool flag = true;
				while (enumerator.MoveNext())
				{
					if (!flag)
					{
						stringBuilder.Append(", ");
					}
					else
					{
						flag = false;
					}
					stringBuilder.Append((enumerator.Current == null) ? "<null>" : enumerator.Current.ToString());
				}
				stringBuilder.Append('}');
				return stringBuilder.ToString();
			}
			return "null";
		}

		public List<INode> Children
		{
			get
			{
				return this.children;
			}
			set
			{
				this.children = value;
			}
		}

		public Location EndLocation
		{
			get;
			set;
		}

		public INode Parent
		{
			get;
			set;
		}

		public Location StartLocation
		{
			get;
			set;
		}

		public object UserData
		{
			get;
			set;
		}

		private List<INode> children = new List<INode>();
	}
}
