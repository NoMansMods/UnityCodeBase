﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionJoinClause : QueryExpressionFromOrJoinClause
	{
		public QueryExpressionJoinClause()
		{
			this.onExpression = Expression.Null;
			this.equalsExpression = Expression.Null;
			this.intoIdentifier = "";
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionJoinClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionJoinClause OnExpression={0} EqualsExpression={1} IntoIdentifier={2} Type={3} Identifier={4} InExpression={5}]", new object[]
			{
				this.OnExpression,
				this.EqualsExpression,
				this.IntoIdentifier,
				base.Type,
				base.Identifier,
				base.InExpression
			});
		}

		public Expression EqualsExpression
		{
			get
			{
				return this.equalsExpression;
			}
			set
			{
				this.equalsExpression = (value ?? Expression.Null);
				if (!this.equalsExpression.IsNull)
				{
					this.equalsExpression.Parent = this;
				}
			}
		}

		public string IntoIdentifier
		{
			get
			{
				return this.intoIdentifier;
			}
			set
			{
				this.intoIdentifier = (value ?? "");
			}
		}

		public Expression OnExpression
		{
			get
			{
				return this.onExpression;
			}
			set
			{
				this.onExpression = (value ?? Expression.Null);
				if (!this.onExpression.IsNull)
				{
					this.onExpression.Parent = this;
				}
			}
		}

		private Expression equalsExpression;

		private string intoIdentifier;

		private Expression onExpression;
	}
}
