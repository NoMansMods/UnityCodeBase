﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class DestructorDeclaration : AttributedNode
	{
		public DestructorDeclaration(string name, Modifiers modifier, List<AttributeSection> attributes)
		{
			this.Name = name;
			base.Modifier = modifier;
			base.Attributes = attributes;
			this.body = BlockStatement.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitDestructorDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[DestructorDeclaration Name={0} Body={1} Attributes={2} Modifier={3}]", new object[]
			{
				this.Name,
				this.Body,
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public BlockStatement Body
		{
			get
			{
				return this.body;
			}
			set
			{
				this.body = (value ?? BlockStatement.Null);
				if (!this.body.IsNull)
				{
					this.body.Parent = this;
				}
			}
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (value ?? "");
			}
		}

		private BlockStatement body;

		private string name;
	}
}
