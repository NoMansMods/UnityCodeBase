﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullQueryExpressionFromClause : QueryExpressionFromClause
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullQueryExpressionFromClause]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullQueryExpressionFromClause Instance = new NullQueryExpressionFromClause();
	}
}
