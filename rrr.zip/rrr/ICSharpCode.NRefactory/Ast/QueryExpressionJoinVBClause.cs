﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionJoinVBClause : QueryExpressionClause
	{
		public QueryExpressionJoinVBClause()
		{
			this.joinVariable = QueryExpressionFromClause.Null;
			this.subJoin = QueryExpressionJoinVBClause.Null;
			this.conditions = new List<QueryExpressionJoinConditionVB>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionJoinVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionJoinVBClause JoinVariable={0} SubJoin={1} Conditions={2}]", this.JoinVariable, this.SubJoin, AbstractNode.GetCollectionString(this.Conditions));
		}

		public List<QueryExpressionJoinConditionVB> Conditions
		{
			get
			{
				return this.conditions;
			}
			set
			{
				this.conditions = (value ?? new List<QueryExpressionJoinConditionVB>());
			}
		}

		public QueryExpressionFromClause JoinVariable
		{
			get
			{
				return this.joinVariable;
			}
			set
			{
				this.joinVariable = (value ?? QueryExpressionFromClause.Null);
				if (!this.joinVariable.IsNull)
				{
					this.joinVariable.Parent = this;
				}
			}
		}

		public new static QueryExpressionJoinVBClause Null
		{
			get
			{
				return NullQueryExpressionJoinVBClause.Instance;
			}
		}

		public QueryExpressionJoinVBClause SubJoin
		{
			get
			{
				return this.subJoin;
			}
			set
			{
				this.subJoin = (value ?? QueryExpressionJoinVBClause.Null);
				if (!this.subJoin.IsNull)
				{
					this.subJoin.Parent = this;
				}
			}
		}

		private List<QueryExpressionJoinConditionVB> conditions;

		private QueryExpressionFromClause joinVariable;

		private QueryExpressionJoinVBClause subJoin;
	}
}
