﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class QueryExpressionFromOrJoinClause : QueryExpressionClause
	{
		protected QueryExpressionFromOrJoinClause()
		{
			this.type = TypeReference.Null;
			this.identifier = "?";
			this.inExpression = Expression.Null;
		}

		public string Identifier
		{
			get
			{
				return this.identifier;
			}
			set
			{
				this.identifier = (string.IsNullOrEmpty(value) ? "?" : value);
			}
		}

		public Expression InExpression
		{
			get
			{
				return this.inExpression;
			}
			set
			{
				this.inExpression = (value ?? Expression.Null);
				if (!this.inExpression.IsNull)
				{
					this.inExpression.Parent = this;
				}
			}
		}

		public TypeReference Type
		{
			get
			{
				return this.type;
			}
			set
			{
				this.type = (value ?? TypeReference.Null);
				if (!this.type.IsNull)
				{
					this.type.Parent = this;
				}
			}
		}

		private string identifier;

		private Expression inExpression;

		private TypeReference type;
	}
}
