﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionGroupJoinVBClause : QueryExpressionClause
	{
		public QueryExpressionGroupJoinVBClause()
		{
			this.joinClause = QueryExpressionJoinVBClause.Null;
			this.intoVariables = new List<ExpressionRangeVariable>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionGroupJoinVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionGroupJoinVBClause JoinClause={0} IntoVariables={1}]", this.JoinClause, AbstractNode.GetCollectionString(this.IntoVariables));
		}

		public List<ExpressionRangeVariable> IntoVariables
		{
			get
			{
				return this.intoVariables;
			}
			set
			{
				this.intoVariables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		public QueryExpressionJoinVBClause JoinClause
		{
			get
			{
				return this.joinClause;
			}
			set
			{
				this.joinClause = (value ?? QueryExpressionJoinVBClause.Null);
				if (!this.joinClause.IsNull)
				{
					this.joinClause.Parent = this;
				}
			}
		}

		private List<ExpressionRangeVariable> intoVariables;

		private QueryExpressionJoinVBClause joinClause;
	}
}
