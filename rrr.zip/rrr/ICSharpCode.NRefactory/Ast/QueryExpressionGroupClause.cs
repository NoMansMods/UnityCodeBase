﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionGroupClause : QueryExpressionClause
	{
		public QueryExpressionGroupClause()
		{
			this.projection = Expression.Null;
			this.groupBy = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionGroupClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionGroupClause Projection={0} GroupBy={1}]", this.Projection, this.GroupBy);
		}

		public Expression GroupBy
		{
			get
			{
				return this.groupBy;
			}
			set
			{
				this.groupBy = (value ?? Expression.Null);
				if (!this.groupBy.IsNull)
				{
					this.groupBy.Parent = this;
				}
			}
		}

		public Expression Projection
		{
			get
			{
				return this.projection;
			}
			set
			{
				this.projection = (value ?? Expression.Null);
				if (!this.projection.IsNull)
				{
					this.projection.Parent = this;
				}
			}
		}

		private Expression groupBy;

		private Expression projection;
	}
}
