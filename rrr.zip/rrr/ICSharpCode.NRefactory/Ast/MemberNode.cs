﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class MemberNode : ParametrizedNode
	{
		protected MemberNode()
		{
			this.interfaceImplementations = new List<InterfaceImplementation>();
			this.typeReference = TypeReference.Null;
		}

		protected MemberNode(Modifiers modifier, List<AttributeSection> attributes, string name, List<ParameterDeclarationExpression> parameters)
		{
			base.Modifier = modifier;
			base.Attributes = attributes;
			base.Name = name;
			base.Parameters = parameters;
			this.interfaceImplementations = new List<InterfaceImplementation>();
			this.typeReference = TypeReference.Null;
		}

		public List<InterfaceImplementation> InterfaceImplementations
		{
			get
			{
				return this.interfaceImplementations;
			}
			set
			{
				this.interfaceImplementations = (value ?? new List<InterfaceImplementation>());
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		private List<InterfaceImplementation> interfaceImplementations;

		private TypeReference typeReference;
	}
}
