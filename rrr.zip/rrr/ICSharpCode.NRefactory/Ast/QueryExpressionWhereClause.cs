﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionWhereClause : QueryExpressionClause
	{
		public QueryExpressionWhereClause()
		{
			this.condition = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionWhereClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionWhereClause Condition={0}]", this.Condition);
		}

		public Expression Condition
		{
			get
			{
				return this.condition;
			}
			set
			{
				this.condition = (value ?? Expression.Null);
				if (!this.condition.IsNull)
				{
					this.condition.Parent = this;
				}
			}
		}

		private Expression condition;
	}
}
