﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class ReDimStatement : Statement
	{
		public ReDimStatement(bool isPreserve)
		{
			this.IsPreserve = isPreserve;
			this.reDimClauses = new List<InvocationExpression>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitReDimStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ReDimStatement ReDimClauses={0} IsPreserve={1}]", AbstractNode.GetCollectionString(this.ReDimClauses), this.IsPreserve);
		}

		public bool IsPreserve
		{
			get
			{
				return this.isPreserve;
			}
			set
			{
				this.isPreserve = value;
			}
		}

		public List<InvocationExpression> ReDimClauses
		{
			get
			{
				return this.reDimClauses;
			}
			set
			{
				this.reDimClauses = (value ?? new List<InvocationExpression>());
			}
		}

		private bool isPreserve;

		private List<InvocationExpression> reDimClauses;
	}
}
