﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public interface INode
	{
		object AcceptChildren(IAstVisitor visitor, object data);

		object AcceptVisitor(IAstVisitor visitor, object data);

		List<INode> Children
		{
			get;
		}

		Location EndLocation
		{
			get;
			set;
		}

		INode Parent
		{
			get;
			set;
		}

		Location StartLocation
		{
			get;
			set;
		}

		object UserData
		{
			get;
			set;
		}
	}
}
