﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum OverloadableOperatorType
	{
		None,
		Add,
		Subtract,
		Multiply,
		Divide,
		Modulus,
		Concat,
		UnaryPlus,
		UnaryMinus,
		Not,
		BitNot,
		BitwiseAnd,
		BitwiseOr,
		ExclusiveOr,
		ShiftLeft,
		ShiftRight,
		GreaterThan,
		GreaterThanOrEqual,
		Equality,
		InEquality,
		LessThan,
		LessThanOrEqual,
		Increment,
		Decrement,
		IsTrue,
		IsFalse,
		Like,
		Power,
		CType,
		DivideInteger
	}
}
