﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class TypeOfIsExpression : Expression
	{
		public TypeOfIsExpression(Expression expression, TypeReference typeReference)
		{
			this.Expression = expression;
			this.TypeReference = typeReference;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitTypeOfIsExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[TypeOfIsExpression Expression={0} TypeReference={1}]", this.Expression, this.TypeReference);
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
				if (!this.expression.IsNull)
				{
					this.expression.Parent = this;
				}
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		private Expression expression;

		private TypeReference typeReference;
	}
}
