﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionOrdering : AbstractNode
	{
		public QueryExpressionOrdering()
		{
			this.criteria = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionOrdering(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionOrdering Criteria={0} Direction={1}]", this.Criteria, this.Direction);
		}

		public Expression Criteria
		{
			get
			{
				return this.criteria;
			}
			set
			{
				this.criteria = (value ?? Expression.Null);
				if (!this.criteria.IsNull)
				{
					this.criteria.Parent = this;
				}
			}
		}

		public QueryExpressionOrderingDirection Direction
		{
			get
			{
				return this.direction;
			}
			set
			{
				this.direction = value;
			}
		}

		private Expression criteria;

		private QueryExpressionOrderingDirection direction;
	}
}
