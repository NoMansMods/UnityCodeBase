﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum FieldDirection
	{
		None,
		In,
		Out,
		Ref
	}
}
