﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullEventAddRegion : EventAddRegion
	{
		private NullEventAddRegion() : base(null)
		{
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullEventAddRegion]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullEventAddRegion Instance = new NullEventAddRegion();
	}
}
