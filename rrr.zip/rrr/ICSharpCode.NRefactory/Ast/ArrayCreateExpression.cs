﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class ArrayCreateExpression : Expression
	{
		public ArrayCreateExpression(TypeReference createType)
		{
			this.CreateType = createType;
			this.arguments = new List<Expression>();
			this.arrayInitializer = CollectionInitializerExpression.Null;
		}

		public ArrayCreateExpression(TypeReference createType, List<Expression> arguments)
		{
			this.CreateType = createType;
			this.Arguments = arguments;
			this.arrayInitializer = CollectionInitializerExpression.Null;
		}

		public ArrayCreateExpression(TypeReference createType, CollectionInitializerExpression arrayInitializer)
		{
			this.CreateType = createType;
			this.ArrayInitializer = arrayInitializer;
			this.arguments = new List<Expression>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitArrayCreateExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ArrayCreateExpression CreateType={0} Arguments={1} ArrayInitializer={2}]", this.CreateType, AbstractNode.GetCollectionString(this.Arguments), this.ArrayInitializer);
		}

		public List<Expression> Arguments
		{
			get
			{
				return this.arguments;
			}
			set
			{
				this.arguments = (value ?? new List<Expression>());
			}
		}

		public CollectionInitializerExpression ArrayInitializer
		{
			get
			{
				return this.arrayInitializer;
			}
			set
			{
				this.arrayInitializer = (value ?? CollectionInitializerExpression.Null);
				if (!this.arrayInitializer.IsNull)
				{
					this.arrayInitializer.Parent = this;
				}
			}
		}

		public TypeReference CreateType
		{
			get
			{
				return this.createType;
			}
			set
			{
				this.createType = (value ?? TypeReference.Null);
				if (!this.createType.IsNull)
				{
					this.createType.Parent = this;
				}
			}
		}

		public bool IsImplicitlyTyped
		{
			get
			{
				return this.createType.IsNull || string.IsNullOrEmpty(this.createType.Type);
			}
		}

		private List<Expression> arguments;

		private CollectionInitializerExpression arrayInitializer;

		private TypeReference createType;
	}
}
