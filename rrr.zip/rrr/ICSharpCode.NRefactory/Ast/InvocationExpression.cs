﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class InvocationExpression : Expression
	{
		public InvocationExpression(Expression targetObject)
		{
			this.TargetObject = targetObject;
			this.arguments = new List<Expression>();
		}

		public InvocationExpression(Expression targetObject, List<Expression> arguments)
		{
			this.TargetObject = targetObject;
			this.Arguments = arguments;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitInvocationExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[InvocationExpression TargetObject={0} Arguments={1}]", this.TargetObject, AbstractNode.GetCollectionString(this.Arguments));
		}

		public List<Expression> Arguments
		{
			get
			{
				return this.arguments;
			}
			set
			{
				this.arguments = (value ?? new List<Expression>());
			}
		}

		public Expression TargetObject
		{
			get
			{
				return this.targetObject;
			}
			set
			{
				this.targetObject = (value ?? Expression.Null);
				if (!this.targetObject.IsNull)
				{
					this.targetObject.Parent = this;
				}
			}
		}

		private List<Expression> arguments;

		private Expression targetObject;
	}
}
