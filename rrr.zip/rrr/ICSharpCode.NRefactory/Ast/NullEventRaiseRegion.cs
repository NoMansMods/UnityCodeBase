﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullEventRaiseRegion : EventRaiseRegion
	{
		private NullEventRaiseRegion() : base(null)
		{
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullEventRaiseRegion]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullEventRaiseRegion Instance = new NullEventRaiseRegion();
	}
}
