﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullQueryExpressionJoinVBClause : QueryExpressionJoinVBClause
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullQueryExpressionJoinVBClause]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullQueryExpressionJoinVBClause Instance = new NullQueryExpressionJoinVBClause();
	}
}
