﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class TemplateDefinition : AttributedNode
	{
		public TemplateDefinition(string name, List<AttributeSection> attributes)
		{
			this.Name = name;
			base.Attributes = attributes;
			this.bases = new List<TypeReference>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitTemplateDefinition(this, data);
		}

		public override string ToString()
		{
			return string.Format("[TemplateDefinition Name={0} Bases={1} Attributes={2} Modifier={3}]", new object[]
			{
				this.Name,
				AbstractNode.GetCollectionString(this.Bases),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public List<TypeReference> Bases
		{
			get
			{
				return this.bases;
			}
			set
			{
				this.bases = (value ?? new List<TypeReference>());
			}
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (string.IsNullOrEmpty(value) ? "?" : value);
			}
		}

		private List<TypeReference> bases;

		private string name;
	}
}
