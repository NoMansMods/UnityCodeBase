﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionJoinConditionVB : AbstractNode
	{
		public QueryExpressionJoinConditionVB()
		{
			this.leftSide = Expression.Null;
			this.rightSide = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionJoinConditionVB(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionJoinConditionVB LeftSide={0} RightSide={1}]", this.LeftSide, this.RightSide);
		}

		public Expression LeftSide
		{
			get
			{
				return this.leftSide;
			}
			set
			{
				this.leftSide = (value ?? Expression.Null);
				if (!this.leftSide.IsNull)
				{
					this.leftSide.Parent = this;
				}
			}
		}

		public Expression RightSide
		{
			get
			{
				return this.rightSide;
			}
			set
			{
				this.rightSide = (value ?? Expression.Null);
				if (!this.rightSide.IsNull)
				{
					this.rightSide.Parent = this;
				}
			}
		}

		private Expression leftSide;

		private Expression rightSide;
	}
}
