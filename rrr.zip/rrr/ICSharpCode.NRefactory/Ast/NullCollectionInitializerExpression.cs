﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullCollectionInitializerExpression : CollectionInitializerExpression
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullCollectionInitializerExpression]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullCollectionInitializerExpression Instance = new NullCollectionInitializerExpression();
	}
}
