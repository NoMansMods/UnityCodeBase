﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpression : Expression
	{
		public QueryExpression()
		{
			this.fromClause = QueryExpressionFromClause.Null;
			this.middleClauses = new List<QueryExpressionClause>();
			this.selectOrGroupClause = QueryExpressionClause.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpression FromClause={0} IsQueryContinuation={1} MiddleClauses={2} SelectOrGroupClause={3}]", new object[]
			{
				this.FromClause,
				this.IsQueryContinuation,
				AbstractNode.GetCollectionString(this.MiddleClauses),
				this.SelectOrGroupClause
			});
		}

		public QueryExpressionFromClause FromClause
		{
			get
			{
				return this.fromClause;
			}
			set
			{
				this.fromClause = (value ?? QueryExpressionFromClause.Null);
				if (!this.fromClause.IsNull)
				{
					this.fromClause.Parent = this;
				}
			}
		}

		public bool IsQueryContinuation
		{
			get
			{
				return this.isQueryContinuation;
			}
			set
			{
				this.isQueryContinuation = value;
			}
		}

		public List<QueryExpressionClause> MiddleClauses
		{
			get
			{
				return this.middleClauses;
			}
			set
			{
				this.middleClauses = (value ?? new List<QueryExpressionClause>());
			}
		}

		public new static QueryExpression Null
		{
			get
			{
				return NullQueryExpression.Instance;
			}
		}

		public QueryExpressionClause SelectOrGroupClause
		{
			get
			{
				return this.selectOrGroupClause;
			}
			set
			{
				this.selectOrGroupClause = (value ?? QueryExpressionClause.Null);
				if (!this.selectOrGroupClause.IsNull)
				{
					this.selectOrGroupClause.Parent = this;
				}
			}
		}

		private QueryExpressionFromClause fromClause;

		private bool isQueryContinuation;

		private List<QueryExpressionClause> middleClauses;

		private QueryExpressionClause selectOrGroupClause;
	}
}
