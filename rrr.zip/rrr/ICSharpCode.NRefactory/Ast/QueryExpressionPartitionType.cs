﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum QueryExpressionPartitionType
	{
		Take,
		TakeWhile,
		Skip,
		SkipWhile
	}
}
