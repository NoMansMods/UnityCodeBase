﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class EventAddRemoveRegion : AttributedNode, INullable
	{
		protected EventAddRemoveRegion(List<AttributeSection> attributes)
		{
			base.Attributes = attributes;
			this.block = BlockStatement.Null;
			this.parameters = new List<ParameterDeclarationExpression>();
		}

		public BlockStatement Block
		{
			get
			{
				return this.block;
			}
			set
			{
				this.block = (value ?? BlockStatement.Null);
				if (!this.block.IsNull)
				{
					this.block.Parent = this;
				}
			}
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public List<ParameterDeclarationExpression> Parameters
		{
			get
			{
				return this.parameters;
			}
			set
			{
				this.parameters = (value ?? new List<ParameterDeclarationExpression>());
			}
		}

		private BlockStatement block;

		private List<ParameterDeclarationExpression> parameters;
	}
}
