﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionFromClause : QueryExpressionFromOrJoinClause
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionFromClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionFromClause Type={0} Identifier={1} InExpression={2}]", base.Type, base.Identifier, base.InExpression);
		}

		public new static QueryExpressionFromClause Null
		{
			get
			{
				return NullQueryExpressionFromClause.Instance;
			}
		}
	}
}
