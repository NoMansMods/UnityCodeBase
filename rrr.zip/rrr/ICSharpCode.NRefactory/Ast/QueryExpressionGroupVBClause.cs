﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionGroupVBClause : QueryExpressionClause
	{
		public QueryExpressionGroupVBClause()
		{
			this.groupVariables = new List<ExpressionRangeVariable>();
			this.byVariables = new List<ExpressionRangeVariable>();
			this.intoVariables = new List<ExpressionRangeVariable>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionGroupVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionGroupVBClause GroupVariables={0} ByVariables={1} IntoVariables={2}]", AbstractNode.GetCollectionString(this.GroupVariables), AbstractNode.GetCollectionString(this.ByVariables), AbstractNode.GetCollectionString(this.IntoVariables));
		}

		public List<ExpressionRangeVariable> ByVariables
		{
			get
			{
				return this.byVariables;
			}
			set
			{
				this.byVariables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		public List<ExpressionRangeVariable> GroupVariables
		{
			get
			{
				return this.groupVariables;
			}
			set
			{
				this.groupVariables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		public List<ExpressionRangeVariable> IntoVariables
		{
			get
			{
				return this.intoVariables;
			}
			set
			{
				this.intoVariables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		private List<ExpressionRangeVariable> byVariables;

		private List<ExpressionRangeVariable> groupVariables;

		private List<ExpressionRangeVariable> intoVariables;
	}
}
