﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class PropertyDeclaration : MemberNode
	{
		public PropertyDeclaration(Modifiers modifier, List<AttributeSection> attributes, string name, List<ParameterDeclarationExpression> parameters)
		{
			base.Modifier = modifier;
			base.Attributes = attributes;
			base.Name = name;
			base.Parameters = parameters;
			this.bodyStart = Location.Empty;
			this.bodyEnd = Location.Empty;
			this.getRegion = PropertyGetRegion.Null;
			this.setRegion = PropertySetRegion.Null;
		}

		internal PropertyDeclaration(string name, TypeReference typeReference, Modifiers modifier, List<AttributeSection> attributes) : this(modifier, attributes, name, null)
		{
			base.TypeReference = typeReference;
			if ((modifier & Modifiers.ReadOnly) != Modifiers.ReadOnly)
			{
				this.SetRegion = new PropertySetRegion(null, null);
			}
			if ((modifier & Modifiers.WriteOnly) != Modifiers.WriteOnly)
			{
				this.GetRegion = new PropertyGetRegion(null, null);
			}
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitPropertyDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[PropertyDeclaration BodyStart={0} BodyEnd={1} GetRegion={2} SetRegion={3} InterfaceImplementations={4} TypeReference={5} Name={6} Parameters={7} Attributes={8} Modifier={9}]", new object[]
			{
				this.BodyStart,
				this.BodyEnd,
				this.GetRegion,
				this.SetRegion,
				AbstractNode.GetCollectionString(base.InterfaceImplementations),
				base.TypeReference,
				base.Name,
				AbstractNode.GetCollectionString(base.Parameters),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public Location BodyEnd
		{
			get
			{
				return this.bodyEnd;
			}
			set
			{
				this.bodyEnd = value;
			}
		}

		public Location BodyStart
		{
			get
			{
				return this.bodyStart;
			}
			set
			{
				this.bodyStart = value;
			}
		}

		public PropertyGetRegion GetRegion
		{
			get
			{
				return this.getRegion;
			}
			set
			{
				this.getRegion = (value ?? PropertyGetRegion.Null);
				if (!this.getRegion.IsNull)
				{
					this.getRegion.Parent = this;
				}
			}
		}

		public bool HasGetRegion
		{
			get
			{
				return !this.getRegion.IsNull;
			}
		}

		public bool HasSetRegion
		{
			get
			{
				return !this.setRegion.IsNull;
			}
		}

		public bool IsReadOnly
		{
			get
			{
				return this.HasGetRegion && !this.HasSetRegion;
			}
		}

		public bool IsWriteOnly
		{
			get
			{
				return !this.HasGetRegion && this.HasSetRegion;
			}
		}

		public PropertySetRegion SetRegion
		{
			get
			{
				return this.setRegion;
			}
			set
			{
				this.setRegion = (value ?? PropertySetRegion.Null);
				if (!this.setRegion.IsNull)
				{
					this.setRegion.Parent = this;
				}
			}
		}

		private Location bodyEnd;

		private Location bodyStart;

		private PropertyGetRegion getRegion;

		private PropertySetRegion setRegion;
	}
}
