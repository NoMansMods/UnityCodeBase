﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullQueryExpressionClause : QueryExpressionClause
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullQueryExpressionClause]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullQueryExpressionClause Instance = new NullQueryExpressionClause();
	}
}
