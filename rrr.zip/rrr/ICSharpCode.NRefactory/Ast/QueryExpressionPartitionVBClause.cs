﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionPartitionVBClause : QueryExpressionClause
	{
		public QueryExpressionPartitionVBClause()
		{
			this.expression = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionPartitionVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionPartitionVBClause Expression={0} PartitionType={1}]", this.Expression, this.PartitionType);
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
				if (!this.expression.IsNull)
				{
					this.expression.Parent = this;
				}
			}
		}

		public QueryExpressionPartitionType PartitionType
		{
			get
			{
				return this.partitionType;
			}
			set
			{
				this.partitionType = value;
			}
		}

		private Expression expression;

		private QueryExpressionPartitionType partitionType;
	}
}
