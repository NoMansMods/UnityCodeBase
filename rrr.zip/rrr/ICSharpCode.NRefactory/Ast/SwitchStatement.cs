﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class SwitchStatement : Statement
	{
		public SwitchStatement(Expression switchExpression, List<SwitchSection> switchSections)
		{
			this.SwitchExpression = switchExpression;
			this.SwitchSections = switchSections;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitSwitchStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[SwitchStatement SwitchExpression={0} SwitchSections={1}]", this.SwitchExpression, AbstractNode.GetCollectionString(this.SwitchSections));
		}

		public Expression SwitchExpression
		{
			get
			{
				return this.switchExpression;
			}
			set
			{
				this.switchExpression = (value ?? Expression.Null);
				if (!this.switchExpression.IsNull)
				{
					this.switchExpression.Parent = this;
				}
			}
		}

		public List<SwitchSection> SwitchSections
		{
			get
			{
				return this.switchSections;
			}
			set
			{
				this.switchSections = (value ?? new List<SwitchSection>());
			}
		}

		private Expression switchExpression;

		private List<SwitchSection> switchSections;
	}
}
