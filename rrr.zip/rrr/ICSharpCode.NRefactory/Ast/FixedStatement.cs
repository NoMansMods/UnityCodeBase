﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class FixedStatement : StatementWithEmbeddedStatement
	{
		public FixedStatement(Statement pointerDeclaration, Statement embeddedStatement)
		{
			this.PointerDeclaration = pointerDeclaration;
			base.EmbeddedStatement = embeddedStatement;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitFixedStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[FixedStatement PointerDeclaration={0} EmbeddedStatement={1}]", this.PointerDeclaration, base.EmbeddedStatement);
		}

		public Statement PointerDeclaration
		{
			get
			{
				return this.pointerDeclaration;
			}
			set
			{
				this.pointerDeclaration = (value ?? Statement.Null);
				if (!this.pointerDeclaration.IsNull)
				{
					this.pointerDeclaration.Parent = this;
				}
			}
		}

		private Statement pointerDeclaration;
	}
}
