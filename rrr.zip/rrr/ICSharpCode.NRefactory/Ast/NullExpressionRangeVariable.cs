﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullExpressionRangeVariable : ExpressionRangeVariable
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullExpressionRangeVariable]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullExpressionRangeVariable Instance = new NullExpressionRangeVariable();
	}
}
