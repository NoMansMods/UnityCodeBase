﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ConversionType
	{
		None,
		Implicit,
		Explicit
	}
}
