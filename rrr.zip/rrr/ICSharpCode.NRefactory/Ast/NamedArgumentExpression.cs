﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class NamedArgumentExpression : Expression
	{
		public NamedArgumentExpression()
		{
			this.name = "";
			this.expression = Expression.Null;
		}

		public NamedArgumentExpression(string name, Expression expression)
		{
			this.Name = name;
			this.Expression = expression;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitNamedArgumentExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[NamedArgumentExpression Name={0} Expression={1}]", this.Name, this.Expression);
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
				if (!this.expression.IsNull)
				{
					this.expression.Parent = this;
				}
			}
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (value ?? "");
			}
		}

		private Expression expression;

		private string name;
	}
}
