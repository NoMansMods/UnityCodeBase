﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class MethodDeclaration : MemberNode
	{
		public MethodDeclaration()
		{
			this.body = BlockStatement.Null;
			this.handlesClause = new List<string>();
			this.templates = new List<TemplateDefinition>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitMethodDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[MethodDeclaration Body={0} HandlesClause={1} Templates={2} IsExtensionMethod={3} InterfaceImplementations={4} TypeReference={5} Name={6} Parameters={7} Attributes={8} Modifier={9}]", new object[]
			{
				this.Body,
				AbstractNode.GetCollectionString(this.HandlesClause),
				AbstractNode.GetCollectionString(this.Templates),
				this.IsExtensionMethod,
				AbstractNode.GetCollectionString(base.InterfaceImplementations),
				base.TypeReference,
				base.Name,
				AbstractNode.GetCollectionString(base.Parameters),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public BlockStatement Body
		{
			get
			{
				return this.body;
			}
			set
			{
				this.body = (value ?? BlockStatement.Null);
				if (!this.body.IsNull)
				{
					this.body.Parent = this;
				}
			}
		}

		public List<string> HandlesClause
		{
			get
			{
				return this.handlesClause;
			}
			set
			{
				this.handlesClause = (value ?? new List<string>());
			}
		}

		public bool IsExtensionMethod
		{
			get
			{
				return this.isExtensionMethod;
			}
			set
			{
				this.isExtensionMethod = value;
			}
		}

		public List<TemplateDefinition> Templates
		{
			get
			{
				return this.templates;
			}
			set
			{
				this.templates = (value ?? new List<TemplateDefinition>());
			}
		}

		private BlockStatement body;

		private List<string> handlesClause;

		private bool isExtensionMethod;

		private List<TemplateDefinition> templates;
	}
}
