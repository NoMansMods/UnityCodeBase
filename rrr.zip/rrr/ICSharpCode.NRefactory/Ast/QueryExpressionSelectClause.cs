﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionSelectClause : QueryExpressionClause
	{
		public QueryExpressionSelectClause()
		{
			this.projection = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionSelectClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionSelectClause Projection={0}]", this.Projection);
		}

		public Expression Projection
		{
			get
			{
				return this.projection;
			}
			set
			{
				this.projection = (value ?? Expression.Null);
				if (!this.projection.IsNull)
				{
					this.projection.Parent = this;
				}
			}
		}

		private Expression projection;
	}
}
