﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ParentType
	{
		ClassOrStruct,
		InterfaceOrEnum,
		Namespace,
		Unknown
	}
}
