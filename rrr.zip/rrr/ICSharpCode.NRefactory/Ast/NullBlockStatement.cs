﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullBlockStatement : BlockStatement
	{
		public override object AcceptChildren(IAstVisitor visitor, object data)
		{
			return data;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return data;
		}

		public override void AddChild(INode childNode)
		{
			throw new InvalidOperationException();
		}

		public override string ToString()
		{
			return string.Format("[NullBlockStatement]", new object[0]);
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		public static readonly NullBlockStatement Instance = new NullBlockStatement();
	}
}
