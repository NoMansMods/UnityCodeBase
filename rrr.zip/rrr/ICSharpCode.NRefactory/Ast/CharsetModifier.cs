﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum CharsetModifier
	{
		None,
		Auto,
		Unicode,
		Ansi
	}
}
