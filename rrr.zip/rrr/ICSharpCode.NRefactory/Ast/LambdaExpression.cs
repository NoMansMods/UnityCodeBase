﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class LambdaExpression : Expression
	{
		public LambdaExpression()
		{
			this.parameters = new List<ParameterDeclarationExpression>();
			this.statementBody = BlockStatement.Null;
			this.expressionBody = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitLambdaExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[LambdaExpression Parameters={0} StatementBody={1} ExpressionBody={2}]", AbstractNode.GetCollectionString(this.Parameters), this.StatementBody, this.ExpressionBody);
		}

		public Expression ExpressionBody
		{
			get
			{
				return this.expressionBody;
			}
			set
			{
				this.expressionBody = (value ?? Expression.Null);
				if (!this.expressionBody.IsNull)
				{
					this.expressionBody.Parent = this;
				}
			}
		}

		public Location ExtendedEndLocation
		{
			get;
			set;
		}

		public List<ParameterDeclarationExpression> Parameters
		{
			get
			{
				return this.parameters;
			}
			set
			{
				this.parameters = (value ?? new List<ParameterDeclarationExpression>());
			}
		}

		public BlockStatement StatementBody
		{
			get
			{
				return this.statementBody;
			}
			set
			{
				this.statementBody = (value ?? BlockStatement.Null);
				if (!this.statementBody.IsNull)
				{
					this.statementBody.Parent = this;
				}
			}
		}

		private Expression expressionBody;

		private List<ParameterDeclarationExpression> parameters;

		private BlockStatement statementBody;
	}
}
