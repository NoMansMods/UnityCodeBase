﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ContinueType
	{
		None,
		Do,
		For,
		While
	}
}
