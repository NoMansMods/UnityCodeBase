﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class ConstructorInitializer : AbstractNode, INullable
	{
		public ConstructorInitializer()
		{
			this.arguments = new List<Expression>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitConstructorInitializer(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ConstructorInitializer ConstructorInitializerType={0} Arguments={1}]", this.ConstructorInitializerType, AbstractNode.GetCollectionString(this.Arguments));
		}

		public List<Expression> Arguments
		{
			get
			{
				return this.arguments;
			}
			set
			{
				this.arguments = (value ?? new List<Expression>());
			}
		}

		public ConstructorInitializerType ConstructorInitializerType
		{
			get
			{
				return this.constructorInitializerType;
			}
			set
			{
				this.constructorInitializerType = value;
			}
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static ConstructorInitializer Null
		{
			get
			{
				return NullConstructorInitializer.Instance;
			}
		}

		private List<Expression> arguments;

		private ConstructorInitializerType constructorInitializerType;
	}
}
