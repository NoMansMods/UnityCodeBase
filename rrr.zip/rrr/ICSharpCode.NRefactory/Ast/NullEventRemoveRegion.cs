﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullEventRemoveRegion : EventRemoveRegion
	{
		private NullEventRemoveRegion() : base(null)
		{
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullEventRemoveRegion]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullEventRemoveRegion Instance = new NullEventRemoveRegion();
	}
}
