﻿using System;
using ICSharpCode.NRefactory.Parser;
using ICSharpCode.NRefactory.PrettyPrinter;

namespace ICSharpCode.NRefactory.Ast
{
	public class PrimitiveExpression : Expression
	{
		public PrimitiveExpression(object val)
		{
			this.Value = val;
		}

		public PrimitiveExpression(object val, string stringValue)
		{
			this.Value = val;
			this.StringValue = stringValue;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitPrimitiveExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[PrimitiveExpression: Value={1}, ValueType={2}, StringValue={0}]", this.StringValue, this.Value, (this.Value == null) ? "null" : this.Value.GetType().FullName);
		}

		public LiteralFormat LiteralFormat
		{
			get;
			set;
		}

		public string StringValue
		{
			get
			{
				if (this.stringValue == null)
				{
					return CSharpOutputVisitor.ToCSharpString(this);
				}
				return this.stringValue;
			}
			set
			{
				this.stringValue = ((value == null) ? string.Empty : value);
			}
		}

		public object Value
		{
			get;
			set;
		}

		private string stringValue;
	}
}
