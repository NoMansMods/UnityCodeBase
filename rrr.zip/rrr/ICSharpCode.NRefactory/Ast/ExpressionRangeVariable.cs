﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class ExpressionRangeVariable : AbstractNode, INullable
	{
		public ExpressionRangeVariable()
		{
			this.identifier = "";
			this.expression = Expression.Null;
			this.type = TypeReference.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitExpressionRangeVariable(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ExpressionRangeVariable Identifier={0} Expression={1} Type={2}]", this.Identifier, this.Expression, this.Type);
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
				if (!this.expression.IsNull)
				{
					this.expression.Parent = this;
				}
			}
		}

		public string Identifier
		{
			get
			{
				return this.identifier;
			}
			set
			{
				this.identifier = (value ?? "");
			}
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static ExpressionRangeVariable Null
		{
			get
			{
				return NullExpressionRangeVariable.Instance;
			}
		}

		public TypeReference Type
		{
			get
			{
				return this.type;
			}
			set
			{
				this.type = (value ?? TypeReference.Null);
				if (!this.type.IsNull)
				{
					this.type.Parent = this;
				}
			}
		}

		private Expression expression;

		private string identifier;

		private TypeReference type;
	}
}
