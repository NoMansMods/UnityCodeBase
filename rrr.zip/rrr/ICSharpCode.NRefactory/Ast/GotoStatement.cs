﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class GotoStatement : Statement
	{
		public GotoStatement(string label)
		{
			this.Label = label;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitGotoStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[GotoStatement Label={0}]", this.Label);
		}

		public string Label
		{
			get
			{
				return this.label;
			}
			set
			{
				this.label = (value ?? "");
			}
		}

		private string label;
	}
}
