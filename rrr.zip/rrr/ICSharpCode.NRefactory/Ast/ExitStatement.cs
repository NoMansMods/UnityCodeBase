﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class ExitStatement : Statement
	{
		public ExitStatement(ExitType exitType)
		{
			this.ExitType = exitType;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitExitStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ExitStatement ExitType={0}]", this.ExitType);
		}

		public ExitType ExitType
		{
			get
			{
				return this.exitType;
			}
			set
			{
				this.exitType = value;
			}
		}

		private ExitType exitType;
	}
}
