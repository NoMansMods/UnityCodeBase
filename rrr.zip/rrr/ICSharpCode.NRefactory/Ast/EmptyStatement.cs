﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class EmptyStatement : Statement
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitEmptyStatement(this, data);
		}

		public override string ToString()
		{
			return "[EmptyStatement]";
		}
	}
}
