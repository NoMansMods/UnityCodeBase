﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullQueryExpression : QueryExpression
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullQueryExpression]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullQueryExpression Instance = new NullQueryExpression();
	}
}
