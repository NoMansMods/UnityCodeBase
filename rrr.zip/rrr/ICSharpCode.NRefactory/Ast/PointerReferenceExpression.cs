﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class PointerReferenceExpression : Expression
	{
		public PointerReferenceExpression(Expression targetObject, string memberName)
		{
			this.TargetObject = targetObject;
			this.MemberName = memberName;
			this.typeArguments = new List<TypeReference>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitPointerReferenceExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[PointerReferenceExpression TargetObject={0} MemberName={1} TypeArguments={2}]", this.TargetObject, this.MemberName, AbstractNode.GetCollectionString(this.TypeArguments));
		}

		[Obsolete]
		public string Identifier
		{
			get
			{
				return this.MemberName;
			}
			set
			{
				this.MemberName = value;
			}
		}

		public string MemberName
		{
			get
			{
				return this.memberName;
			}
			set
			{
				this.memberName = (value ?? "");
			}
		}

		public Expression TargetObject
		{
			get
			{
				return this.targetObject;
			}
			set
			{
				this.targetObject = (value ?? Expression.Null);
				if (!this.targetObject.IsNull)
				{
					this.targetObject.Parent = this;
				}
			}
		}

		public List<TypeReference> TypeArguments
		{
			get
			{
				return this.typeArguments;
			}
			set
			{
				this.typeArguments = (value ?? new List<TypeReference>());
			}
		}

		private string memberName;

		private Expression targetObject;

		private List<TypeReference> typeArguments;
	}
}
