﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class StatementWithEmbeddedStatement : Statement
	{
		public Statement EmbeddedStatement
		{
			get
			{
				return this.embeddedStatement;
			}
			set
			{
				this.embeddedStatement = Statement.CheckNull(value);
				if (value != null)
				{
					value.Parent = this;
				}
			}
		}

		private Statement embeddedStatement;
	}
}
