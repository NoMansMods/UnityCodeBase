﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullConstructorInitializer : ConstructorInitializer
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullConstructorInitializer]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullConstructorInitializer Instance = new NullConstructorInitializer();
	}
}
