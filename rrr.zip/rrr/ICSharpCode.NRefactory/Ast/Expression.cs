﻿using System;
using System.Globalization;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class Expression : AbstractNode, INullable
	{
		public static Expression AddInteger(Expression expr, int value)
		{
			PrimitiveExpression primitiveExpression = expr as PrimitiveExpression;
			if (primitiveExpression != null && primitiveExpression.Value is int)
			{
				int num = (int)primitiveExpression.Value + value;
				return new PrimitiveExpression(num, num.ToString(NumberFormatInfo.InvariantInfo));
			}
			BinaryOperatorExpression binaryOperatorExpression = expr as BinaryOperatorExpression;
			if (binaryOperatorExpression != null && binaryOperatorExpression.Op == BinaryOperatorType.Add)
			{
				binaryOperatorExpression = new BinaryOperatorExpression(binaryOperatorExpression.Left, binaryOperatorExpression.Op, binaryOperatorExpression.Right);
				binaryOperatorExpression.Right = Expression.AddInteger(binaryOperatorExpression.Right, value);
				if (binaryOperatorExpression.Right is PrimitiveExpression && ((PrimitiveExpression)binaryOperatorExpression.Right).Value is int)
				{
					int num2 = (int)((PrimitiveExpression)binaryOperatorExpression.Right).Value;
					if (num2 == 0)
					{
						return binaryOperatorExpression.Left;
					}
					if (num2 < 0)
					{
						((PrimitiveExpression)binaryOperatorExpression.Right).Value = -num2;
						binaryOperatorExpression.Op = BinaryOperatorType.Subtract;
					}
				}
				return binaryOperatorExpression;
			}
			if (binaryOperatorExpression != null && binaryOperatorExpression.Op == BinaryOperatorType.Subtract)
			{
				primitiveExpression = (binaryOperatorExpression.Right as PrimitiveExpression);
				if (primitiveExpression != null && primitiveExpression.Value is int)
				{
					int num3 = (int)primitiveExpression.Value - value;
					if (num3 == 0)
					{
						return binaryOperatorExpression.Left;
					}
					binaryOperatorExpression = new BinaryOperatorExpression(binaryOperatorExpression.Left, binaryOperatorExpression.Op, binaryOperatorExpression.Right);
					if (num3 < 0)
					{
						num3 = -num3;
						binaryOperatorExpression.Op = BinaryOperatorType.Add;
					}
					binaryOperatorExpression.Right = new PrimitiveExpression(num3, num3.ToString(NumberFormatInfo.InvariantInfo));
					return binaryOperatorExpression;
				}
			}
			BinaryOperatorType op = BinaryOperatorType.Add;
			if (value < 0)
			{
				value = -value;
				op = BinaryOperatorType.Subtract;
			}
			return new BinaryOperatorExpression(expr, op, new PrimitiveExpression(value, value.ToString(NumberFormatInfo.InvariantInfo)));
		}

		public static Expression CheckNull(Expression expression)
		{
			if (expression != null)
			{
				return expression;
			}
			return NullExpression.Instance;
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static Expression Null
		{
			get
			{
				return NullExpression.Instance;
			}
		}
	}
}
