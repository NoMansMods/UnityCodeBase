﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullExpression : Expression
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return string.Format("[NullExpression]", new object[0]);
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static readonly NullExpression Instance = new NullExpression();
	}
}
