﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICSharpCode.NRefactory.Ast
{
	public class TypeReference : AbstractNode, INullable, ICloneable
	{
		static TypeReference()
		{
			TypeReference.StructConstraint = new TypeReference("constraint: struct");
			TypeReference.ClassConstraint = new TypeReference("constraint: class");
			TypeReference.NewConstraint = new TypeReference("constraint: new");
			TypeReference.types = new Dictionary<string, string>();
			TypeReference.vbtypes = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
			TypeReference.typesReverse = new Dictionary<string, string>();
			TypeReference.vbtypesReverse = new Dictionary<string, string>();
			TypeReference.types.Add("bool", "System.Boolean");
			TypeReference.types.Add("byte", "System.Byte");
			TypeReference.types.Add("char", "System.Char");
			TypeReference.types.Add("decimal", "System.Decimal");
			TypeReference.types.Add("double", "System.Double");
			TypeReference.types.Add("float", "System.Single");
			TypeReference.types.Add("int", "System.Int32");
			TypeReference.types.Add("long", "System.Int64");
			TypeReference.types.Add("object", "System.Object");
			TypeReference.types.Add("sbyte", "System.SByte");
			TypeReference.types.Add("short", "System.Int16");
			TypeReference.types.Add("string", "System.String");
			TypeReference.types.Add("uint", "System.UInt32");
			TypeReference.types.Add("ulong", "System.UInt64");
			TypeReference.types.Add("ushort", "System.UInt16");
			TypeReference.types.Add("void", "System.Void");
			TypeReference.vbtypes.Add("Boolean", "System.Boolean");
			TypeReference.vbtypes.Add("Byte", "System.Byte");
			TypeReference.vbtypes.Add("SByte", "System.SByte");
			TypeReference.vbtypes.Add("Date", "System.DateTime");
			TypeReference.vbtypes.Add("Char", "System.Char");
			TypeReference.vbtypes.Add("Decimal", "System.Decimal");
			TypeReference.vbtypes.Add("Double", "System.Double");
			TypeReference.vbtypes.Add("Single", "System.Single");
			TypeReference.vbtypes.Add("Integer", "System.Int32");
			TypeReference.vbtypes.Add("Long", "System.Int64");
			TypeReference.vbtypes.Add("UInteger", "System.UInt32");
			TypeReference.vbtypes.Add("ULong", "System.UInt64");
			TypeReference.vbtypes.Add("Object", "System.Object");
			TypeReference.vbtypes.Add("Short", "System.Int16");
			TypeReference.vbtypes.Add("UShort", "System.UInt16");
			TypeReference.vbtypes.Add("String", "System.String");
			foreach (KeyValuePair<string, string> current in TypeReference.types)
			{
				TypeReference.typesReverse.Add(current.Value, current.Key);
			}
			foreach (KeyValuePair<string, string> current2 in TypeReference.vbtypes)
			{
				TypeReference.vbtypesReverse.Add(current2.Value, current2.Key);
			}
		}

		protected TypeReference()
		{
		}

		public TypeReference(string type)
		{
			this.Type = type;
		}

		[Obsolete("Type and SystemType are no longer distinguished - use the (string type, bool isKeyword) constructor instead!")]
		public TypeReference(string type, string systemType)
		{
			this.Type = systemType;
			this.IsKeyword = (type != systemType);
		}

		public TypeReference(string type, bool isKeyword)
		{
			this.Type = type;
			this.IsKeyword = isKeyword;
		}

		public TypeReference(string type, List<TypeReference> genericTypes) : this(type)
		{
			if (genericTypes != null)
			{
				this.genericTypes = genericTypes;
			}
		}

		public TypeReference(string type, int[] rankSpecifier) : this(type, 0, rankSpecifier)
		{
		}

		public TypeReference(string type, int pointerNestingLevel, int[] rankSpecifier) : this(type, pointerNestingLevel, rankSpecifier, null)
		{
		}

		public TypeReference(string type, int pointerNestingLevel, int[] rankSpecifier, List<TypeReference> genericTypes)
		{
			this.type = type;
			this.pointerNestingLevel = pointerNestingLevel;
			this.rankSpecifier = rankSpecifier;
			if (genericTypes != null)
			{
				this.genericTypes = genericTypes;
			}
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitTypeReference(this, data);
		}

		public static bool AreEqualReferences(TypeReference a, TypeReference b)
		{
			if (a == b)
			{
				return true;
			}
			if (a == null || b == null)
			{
				return false;
			}
			if (a is InnerClassTypeReference)
			{
				a = ((InnerClassTypeReference)a).CombineToNormalTypeReference();
			}
			if (b is InnerClassTypeReference)
			{
				b = ((InnerClassTypeReference)b).CombineToNormalTypeReference();
			}
			if (a.type != b.type)
			{
				return false;
			}
			if (a.IsKeyword != b.IsKeyword)
			{
				return false;
			}
			if (a.IsGlobal != b.IsGlobal)
			{
				return false;
			}
			if (a.pointerNestingLevel != b.pointerNestingLevel)
			{
				return false;
			}
			if (a.IsArrayType != b.IsArrayType)
			{
				return false;
			}
			if (a.IsArrayType)
			{
				if (a.rankSpecifier.Length != b.rankSpecifier.Length)
				{
					return false;
				}
				for (int i = 0; i < a.rankSpecifier.Length; i++)
				{
					if (a.rankSpecifier[i] != b.rankSpecifier[i])
					{
						return false;
					}
				}
			}
			if (a.genericTypes.Count != b.genericTypes.Count)
			{
				return false;
			}
			for (int j = 0; j < a.genericTypes.Count; j++)
			{
				if (!TypeReference.AreEqualReferences(a.genericTypes[j], b.genericTypes[j]))
				{
					return false;
				}
			}
			return true;
		}

		public static TypeReference CheckNull(TypeReference typeReference)
		{
			return typeReference ?? NullTypeReference.Instance;
		}

		public virtual TypeReference Clone()
		{
			TypeReference typeReference = new TypeReference(this.type);
			TypeReference.CopyFields(this, typeReference);
			return typeReference;
		}

		protected static void CopyFields(TypeReference from, TypeReference to)
		{
			to.pointerNestingLevel = from.pointerNestingLevel;
			if (from.rankSpecifier != null)
			{
				to.rankSpecifier = (int[])from.rankSpecifier.Clone();
			}
			foreach (TypeReference current in from.genericTypes)
			{
				to.genericTypes.Add(current.Clone());
			}
			to.IsGlobal = from.IsGlobal;
			to.IsKeyword = from.IsKeyword;
		}

		private static string GetSystemType(string type)
		{
			if (TypeReference.types == null)
			{
				return type;
			}
			string result;
			if (TypeReference.types.TryGetValue(type, out result))
			{
				return result;
			}
			if (TypeReference.vbtypes.TryGetValue(type, out result))
			{
				return result;
			}
			return type;
		}

		public static string StripLastIdentifierFromType(ref TypeReference tr)
		{
			if (tr is InnerClassTypeReference && ((InnerClassTypeReference)tr).Type.IndexOf('.') < 0)
			{
				string result = ((InnerClassTypeReference)tr).Type;
				tr = ((InnerClassTypeReference)tr).BaseType;
				return result;
			}
			int num = tr.Type.LastIndexOf('.');
			if (num < 0)
			{
				return tr.Type;
			}
			string result2 = tr.Type.Substring(num + 1);
			tr.Type = tr.Type.Substring(0, num);
			return result2;
		}

		object ICloneable.Clone()
		{
			return this.Clone();
		}

		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder(this.type);
			if (this.genericTypes != null && this.genericTypes.Count > 0)
			{
				stringBuilder.Append('<');
				for (int i = 0; i < this.genericTypes.Count; i++)
				{
					if (i > 0)
					{
						stringBuilder.Append(',');
					}
					stringBuilder.Append(this.genericTypes[i].ToString());
				}
				stringBuilder.Append('>');
			}
			if (this.pointerNestingLevel > 0)
			{
				stringBuilder.Append('*', this.pointerNestingLevel);
			}
			if (this.IsArrayType)
			{
				int[] array = this.rankSpecifier;
				for (int j = 0; j < array.Length; j++)
				{
					int num = array[j];
					stringBuilder.Append('[');
					if (num < 0)
					{
						stringBuilder.Append('`', -num);
					}
					else
					{
						stringBuilder.Append(',', num);
					}
					stringBuilder.Append(']');
				}
			}
			return stringBuilder.ToString();
		}

		public List<TypeReference> GenericTypes
		{
			get
			{
				return this.genericTypes;
			}
		}

		public bool IsArrayType
		{
			get
			{
				return this.rankSpecifier != null && this.rankSpecifier.Length > 0;
			}
		}

		public bool IsGlobal
		{
			get;
			set;
		}

		public bool IsKeyword
		{
			get;
			set;
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static TypeReference Null
		{
			get
			{
				return NullTypeReference.Instance;
			}
		}

		public int PointerNestingLevel
		{
			get
			{
				return this.pointerNestingLevel;
			}
			set
			{
				this.pointerNestingLevel = value;
			}
		}

		public static IDictionary<string, string> PrimitiveTypesCSharp
		{
			get
			{
				return TypeReference.types;
			}
		}

		public static IDictionary<string, string> PrimitiveTypesCSharpReverse
		{
			get
			{
				return TypeReference.typesReverse;
			}
		}

		public static IDictionary<string, string> PrimitiveTypesVB
		{
			get
			{
				return TypeReference.vbtypes;
			}
		}

		public static IDictionary<string, string> PrimitiveTypesVBReverse
		{
			get
			{
				return TypeReference.vbtypesReverse;
			}
		}

		public int[] RankSpecifier
		{
			get
			{
				return this.rankSpecifier;
			}
			set
			{
				this.rankSpecifier = value;
			}
		}

		[Obsolete("Use 'Type' instead - it now contains the SystemType for primitive types.")]
		public string SystemType
		{
			get
			{
				return this.Type;
			}
		}

		public string Type
		{
			get
			{
				return this.type;
			}
			set
			{
				this.type = (value ?? "?");
			}
		}

		public static readonly TypeReference ClassConstraint;

		private List<TypeReference> genericTypes = new List<TypeReference>();

		public static readonly TypeReference NewConstraint;

		private int pointerNestingLevel;

		private int[] rankSpecifier;

		public static readonly TypeReference StructConstraint;

		private string type = "";

		private static Dictionary<string, string> types;

		private static Dictionary<string, string> typesReverse;

		private static Dictionary<string, string> vbtypes;

		private static Dictionary<string, string> vbtypesReverse;
	}
}
