﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionAggregateClause : QueryExpressionClause
	{
		public QueryExpressionAggregateClause()
		{
			this.fromClause = QueryExpressionFromClause.Null;
			this.middleClauses = new List<QueryExpressionClause>();
			this.intoVariables = new List<ExpressionRangeVariable>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionAggregateClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionAggregateClause FromClause={0} MiddleClauses={1} IntoVariables={2}]", this.FromClause, AbstractNode.GetCollectionString(this.MiddleClauses), AbstractNode.GetCollectionString(this.IntoVariables));
		}

		public QueryExpressionFromClause FromClause
		{
			get
			{
				return this.fromClause;
			}
			set
			{
				this.fromClause = (value ?? QueryExpressionFromClause.Null);
				if (!this.fromClause.IsNull)
				{
					this.fromClause.Parent = this;
				}
			}
		}

		public List<ExpressionRangeVariable> IntoVariables
		{
			get
			{
				return this.intoVariables;
			}
			set
			{
				this.intoVariables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		public List<QueryExpressionClause> MiddleClauses
		{
			get
			{
				return this.middleClauses;
			}
			set
			{
				this.middleClauses = (value ?? new List<QueryExpressionClause>());
			}
		}

		private QueryExpressionFromClause fromClause;

		private List<ExpressionRangeVariable> intoVariables;

		private List<QueryExpressionClause> middleClauses;
	}
}
