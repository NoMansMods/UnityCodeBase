﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class BlockStatement : Statement
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitBlockStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[BlockStatement: Children={0}]", AbstractNode.GetCollectionString(base.Children));
		}

		public new static BlockStatement Null
		{
			get
			{
				return NullBlockStatement.Instance;
			}
		}
	}
}
