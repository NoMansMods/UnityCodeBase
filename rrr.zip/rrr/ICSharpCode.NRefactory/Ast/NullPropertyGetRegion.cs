﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullPropertyGetRegion : PropertyGetRegion
	{
		private NullPropertyGetRegion() : base(null, null)
		{
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullPropertyGetRegion]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullPropertyGetRegion Instance = new NullPropertyGetRegion();
	}
}
