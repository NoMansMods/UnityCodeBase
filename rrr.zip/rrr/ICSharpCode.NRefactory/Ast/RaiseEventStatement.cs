﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class RaiseEventStatement : Statement
	{
		public RaiseEventStatement(string eventName, List<Expression> arguments)
		{
			this.EventName = eventName;
			this.Arguments = arguments;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitRaiseEventStatement(this, data);
		}

		public override string ToString()
		{
			return string.Format("[RaiseEventStatement EventName={0} Arguments={1}]", this.EventName, AbstractNode.GetCollectionString(this.Arguments));
		}

		public List<Expression> Arguments
		{
			get
			{
				return this.arguments;
			}
			set
			{
				this.arguments = (value ?? new List<Expression>());
			}
		}

		public string EventName
		{
			get
			{
				return this.eventName;
			}
			set
			{
				this.eventName = (value ?? "");
			}
		}

		private List<Expression> arguments;

		private string eventName;
	}
}
