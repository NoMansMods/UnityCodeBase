﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class EventDeclaration : MemberNode
	{
		public EventDeclaration()
		{
			this.addRegion = EventAddRegion.Null;
			this.removeRegion = EventRemoveRegion.Null;
			this.raiseRegion = EventRaiseRegion.Null;
			this.bodyStart = Location.Empty;
			this.bodyEnd = Location.Empty;
			this.initializer = Expression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitEventDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[EventDeclaration AddRegion={0} RemoveRegion={1} RaiseRegion={2} BodyStart={3} BodyEnd={4} Initializer={5} InterfaceImplementations={6} TypeReference={7} Name={8} Parameters={9} Attributes={10} Modifier={11}]", new object[]
			{
				this.AddRegion,
				this.RemoveRegion,
				this.RaiseRegion,
				this.BodyStart,
				this.BodyEnd,
				this.Initializer,
				AbstractNode.GetCollectionString(base.InterfaceImplementations),
				base.TypeReference,
				base.Name,
				AbstractNode.GetCollectionString(base.Parameters),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public EventAddRegion AddRegion
		{
			get
			{
				return this.addRegion;
			}
			set
			{
				this.addRegion = (value ?? EventAddRegion.Null);
				if (!this.addRegion.IsNull)
				{
					this.addRegion.Parent = this;
				}
			}
		}

		public Location BodyEnd
		{
			get
			{
				return this.bodyEnd;
			}
			set
			{
				this.bodyEnd = value;
			}
		}

		public Location BodyStart
		{
			get
			{
				return this.bodyStart;
			}
			set
			{
				this.bodyStart = value;
			}
		}

		public bool HasAddRegion
		{
			get
			{
				return !this.addRegion.IsNull;
			}
		}

		public bool HasRaiseRegion
		{
			get
			{
				return !this.raiseRegion.IsNull;
			}
		}

		public bool HasRemoveRegion
		{
			get
			{
				return !this.removeRegion.IsNull;
			}
		}

		public Expression Initializer
		{
			get
			{
				return this.initializer;
			}
			set
			{
				this.initializer = (value ?? Expression.Null);
				if (!this.initializer.IsNull)
				{
					this.initializer.Parent = this;
				}
			}
		}

		public EventRaiseRegion RaiseRegion
		{
			get
			{
				return this.raiseRegion;
			}
			set
			{
				this.raiseRegion = (value ?? EventRaiseRegion.Null);
				if (!this.raiseRegion.IsNull)
				{
					this.raiseRegion.Parent = this;
				}
			}
		}

		public EventRemoveRegion RemoveRegion
		{
			get
			{
				return this.removeRegion;
			}
			set
			{
				this.removeRegion = (value ?? EventRemoveRegion.Null);
				if (!this.removeRegion.IsNull)
				{
					this.removeRegion.Parent = this;
				}
			}
		}

		private EventAddRegion addRegion;

		private Location bodyEnd;

		private Location bodyStart;

		private Expression initializer;

		private EventRaiseRegion raiseRegion;

		private EventRemoveRegion removeRegion;
	}
}
