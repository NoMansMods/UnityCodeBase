﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class ExternAliasDirective : AbstractNode
	{
		public ExternAliasDirective()
		{
			this.name = "";
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitExternAliasDirective(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ExternAliasDirective Name={0}]", this.Name);
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (value ?? "");
			}
		}

		private string name;
	}
}
