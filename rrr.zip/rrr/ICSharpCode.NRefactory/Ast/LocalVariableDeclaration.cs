﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class LocalVariableDeclaration : Statement
	{
		public LocalVariableDeclaration(VariableDeclaration declaration) : this(TypeReference.Null)
		{
			this.Variables.Add(declaration);
		}

		public LocalVariableDeclaration(TypeReference typeReference)
		{
			this.variables = new List<VariableDeclaration>();
			base..ctor();
			this.TypeReference = typeReference;
		}

		public LocalVariableDeclaration(Modifiers modifier)
		{
			this.variables = new List<VariableDeclaration>();
			base..ctor();
			this.typeReference = TypeReference.Null;
			this.modifier = modifier;
		}

		public LocalVariableDeclaration(TypeReference typeReference, Modifiers modifier)
		{
			this.variables = new List<VariableDeclaration>();
			base..ctor();
			this.TypeReference = typeReference;
			this.modifier = modifier;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitLocalVariableDeclaration(this, data);
		}

		public TypeReference GetTypeForVariable(int variableIndex)
		{
			if (!this.typeReference.IsNull)
			{
				return this.typeReference;
			}
			for (int i = variableIndex; i < this.Variables.Count; i++)
			{
				if (!this.Variables[i].TypeReference.IsNull)
				{
					return this.Variables[i].TypeReference;
				}
			}
			return null;
		}

		public VariableDeclaration GetVariableDeclaration(string variableName)
		{
			foreach (VariableDeclaration current in this.variables)
			{
				if (current.Name == variableName)
				{
					return current;
				}
			}
			return null;
		}

		public override string ToString()
		{
			return string.Format("[LocalVariableDeclaration: Type={0}, Modifier ={1} Variables={2}]", this.typeReference, this.modifier, AbstractNode.GetCollectionString(this.variables));
		}

		public Modifiers Modifier
		{
			get
			{
				return this.modifier;
			}
			set
			{
				this.modifier = value;
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = TypeReference.CheckNull(value);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		public List<VariableDeclaration> Variables
		{
			get
			{
				return this.variables;
			}
		}

		private Modifiers modifier;

		private TypeReference typeReference;

		private List<VariableDeclaration> variables;
	}
}
