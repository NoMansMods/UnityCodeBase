﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum QueryExpressionOrderingDirection
	{
		None,
		Ascending,
		Descending
	}
}
