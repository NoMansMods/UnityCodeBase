﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum UnaryOperatorType
	{
		None,
		Not,
		BitNot,
		Minus,
		Plus,
		Increment,
		Decrement,
		PostIncrement,
		PostDecrement,
		Dereference,
		AddressOf
	}
}
