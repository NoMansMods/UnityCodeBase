﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ExitType
	{
		None,
		Sub,
		Function,
		Property,
		Do,
		For,
		While,
		Select,
		Try
	}
}
