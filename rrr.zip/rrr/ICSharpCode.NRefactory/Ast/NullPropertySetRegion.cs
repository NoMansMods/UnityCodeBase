﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullPropertySetRegion : PropertySetRegion
	{
		private NullPropertySetRegion() : base(null, null)
		{
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return null;
		}

		public override string ToString()
		{
			return "[NullPropertySetRegion]";
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		internal static NullPropertySetRegion Instance = new NullPropertySetRegion();
	}
}
