﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class Attribute : AbstractNode
	{
		public Attribute()
		{
			this.name = "";
			this.positionalArguments = new List<Expression>();
			this.namedArguments = new List<NamedArgumentExpression>();
		}

		public Attribute(string name, List<Expression> positionalArguments, List<NamedArgumentExpression> namedArguments)
		{
			this.Name = name;
			this.PositionalArguments = positionalArguments;
			this.NamedArguments = namedArguments;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitAttribute(this, data);
		}

		public override string ToString()
		{
			return string.Format("[Attribute Name={0} PositionalArguments={1} NamedArguments={2}]", this.Name, AbstractNode.GetCollectionString(this.PositionalArguments), AbstractNode.GetCollectionString(this.NamedArguments));
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (value ?? "");
			}
		}

		public List<NamedArgumentExpression> NamedArguments
		{
			get
			{
				return this.namedArguments;
			}
			set
			{
				this.namedArguments = (value ?? new List<NamedArgumentExpression>());
			}
		}

		public List<Expression> PositionalArguments
		{
			get
			{
				return this.positionalArguments;
			}
			set
			{
				this.positionalArguments = (value ?? new List<Expression>());
			}
		}

		private string name;

		private List<NamedArgumentExpression> namedArguments;

		private List<Expression> positionalArguments;
	}
}
