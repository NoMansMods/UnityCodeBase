﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionOrderClause : QueryExpressionClause
	{
		public QueryExpressionOrderClause()
		{
			this.orderings = new List<QueryExpressionOrdering>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionOrderClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionOrderClause Orderings={0}]", AbstractNode.GetCollectionString(this.Orderings));
		}

		public List<QueryExpressionOrdering> Orderings
		{
			get
			{
				return this.orderings;
			}
			set
			{
				this.orderings = (value ?? new List<QueryExpressionOrdering>());
			}
		}

		private List<QueryExpressionOrdering> orderings;
	}
}
