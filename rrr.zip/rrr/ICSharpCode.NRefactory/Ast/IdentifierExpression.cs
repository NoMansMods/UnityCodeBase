﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class IdentifierExpression : Expression
	{
		public IdentifierExpression(string identifier)
		{
			this.Identifier = identifier;
			this.typeArguments = new List<TypeReference>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitIdentifierExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[IdentifierExpression Identifier={0} TypeArguments={1}]", this.Identifier, AbstractNode.GetCollectionString(this.TypeArguments));
		}

		public string Identifier
		{
			get
			{
				return this.identifier;
			}
			set
			{
				this.identifier = (value ?? "");
			}
		}

		public List<TypeReference> TypeArguments
		{
			get
			{
				return this.typeArguments;
			}
			set
			{
				this.typeArguments = (value ?? new List<TypeReference>());
			}
		}

		private string identifier;

		private List<TypeReference> typeArguments;
	}
}
