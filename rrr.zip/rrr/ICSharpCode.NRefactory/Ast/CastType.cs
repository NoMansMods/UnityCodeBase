﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum CastType
	{
		Cast,
		TryCast,
		Conversion,
		PrimitiveConversion
	}
}
