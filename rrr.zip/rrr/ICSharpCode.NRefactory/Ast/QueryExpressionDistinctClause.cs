﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionDistinctClause : QueryExpressionClause
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionDistinctClause(this, data);
		}

		public override string ToString()
		{
			return "[QueryExpressionDistinctClause]";
		}
	}
}
