﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class IndexerDeclaration : AttributedNode
	{
		public IndexerDeclaration(Modifiers modifier, List<ParameterDeclarationExpression> parameters, List<AttributeSection> attributes)
		{
			base.Modifier = modifier;
			this.Parameters = parameters;
			base.Attributes = attributes;
			this.interfaceImplementations = new List<InterfaceImplementation>();
			this.typeReference = TypeReference.Null;
			this.bodyStart = Location.Empty;
			this.bodyEnd = Location.Empty;
			this.getRegion = PropertyGetRegion.Null;
			this.setRegion = PropertySetRegion.Null;
		}

		public IndexerDeclaration(TypeReference typeReference, List<ParameterDeclarationExpression> parameters, Modifiers modifier, List<AttributeSection> attributes)
		{
			this.TypeReference = typeReference;
			this.Parameters = parameters;
			base.Modifier = modifier;
			base.Attributes = attributes;
			this.interfaceImplementations = new List<InterfaceImplementation>();
			this.bodyStart = Location.Empty;
			this.bodyEnd = Location.Empty;
			this.getRegion = PropertyGetRegion.Null;
			this.setRegion = PropertySetRegion.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitIndexerDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[IndexerDeclaration Parameters={0} InterfaceImplementations={1} TypeReference={2} BodyStart={3} BodyEnd={4} GetRegion={5} SetRegion={6} Attributes={7} Modifier={8}]", new object[]
			{
				AbstractNode.GetCollectionString(this.Parameters),
				AbstractNode.GetCollectionString(this.InterfaceImplementations),
				this.TypeReference,
				this.BodyStart,
				this.BodyEnd,
				this.GetRegion,
				this.SetRegion,
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public Location BodyEnd
		{
			get
			{
				return this.bodyEnd;
			}
			set
			{
				this.bodyEnd = value;
			}
		}

		public Location BodyStart
		{
			get
			{
				return this.bodyStart;
			}
			set
			{
				this.bodyStart = value;
			}
		}

		public PropertyGetRegion GetRegion
		{
			get
			{
				return this.getRegion;
			}
			set
			{
				this.getRegion = (value ?? PropertyGetRegion.Null);
				if (!this.getRegion.IsNull)
				{
					this.getRegion.Parent = this;
				}
			}
		}

		public bool HasGetRegion
		{
			get
			{
				return !this.getRegion.IsNull;
			}
		}

		public bool HasSetRegion
		{
			get
			{
				return !this.setRegion.IsNull;
			}
		}

		public List<InterfaceImplementation> InterfaceImplementations
		{
			get
			{
				return this.interfaceImplementations;
			}
			set
			{
				this.interfaceImplementations = (value ?? new List<InterfaceImplementation>());
			}
		}

		public bool IsReadOnly
		{
			get
			{
				return this.HasGetRegion && !this.HasSetRegion;
			}
		}

		public bool IsWriteOnly
		{
			get
			{
				return !this.HasGetRegion && this.HasSetRegion;
			}
		}

		public List<ParameterDeclarationExpression> Parameters
		{
			get
			{
				return this.parameters;
			}
			set
			{
				this.parameters = (value ?? new List<ParameterDeclarationExpression>());
			}
		}

		public PropertySetRegion SetRegion
		{
			get
			{
				return this.setRegion;
			}
			set
			{
				this.setRegion = (value ?? PropertySetRegion.Null);
				if (!this.setRegion.IsNull)
				{
					this.setRegion.Parent = this;
				}
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		private Location bodyEnd;

		private Location bodyStart;

		private PropertyGetRegion getRegion;

		private List<InterfaceImplementation> interfaceImplementations;

		private List<ParameterDeclarationExpression> parameters;

		private PropertySetRegion setRegion;

		private TypeReference typeReference;
	}
}
