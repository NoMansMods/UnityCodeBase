﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionLetVBClause : QueryExpressionClause
	{
		public QueryExpressionLetVBClause()
		{
			this.variables = new List<ExpressionRangeVariable>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionLetVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionLetVBClause Variables={0}]", AbstractNode.GetCollectionString(this.Variables));
		}

		public List<ExpressionRangeVariable> Variables
		{
			get
			{
				return this.variables;
			}
			set
			{
				this.variables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		private List<ExpressionRangeVariable> variables;
	}
}
