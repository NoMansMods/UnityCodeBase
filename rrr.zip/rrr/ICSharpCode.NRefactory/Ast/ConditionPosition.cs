﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ConditionPosition
	{
		None,
		Start,
		End
	}
}
