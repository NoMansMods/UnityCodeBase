﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ClassType
	{
		Class,
		Module,
		Interface,
		Struct,
		Enum
	}
}
