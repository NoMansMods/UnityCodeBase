﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class QueryExpressionClause : AbstractNode, INullable
	{
		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static QueryExpressionClause Null
		{
			get
			{
				return NullQueryExpressionClause.Instance;
			}
		}
	}
}
