﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class InnerClassTypeReference : TypeReference
	{
		public InnerClassTypeReference(TypeReference outerClass, string innerType, List<TypeReference> innerGenericTypes) : base(innerType, innerGenericTypes)
		{
			this.baseType = outerClass;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitInnerClassTypeReference(this, data);
		}

		public override TypeReference Clone()
		{
			InnerClassTypeReference innerClassTypeReference = new InnerClassTypeReference(this.baseType.Clone(), base.Type, new List<TypeReference>());
			TypeReference.CopyFields(this, innerClassTypeReference);
			return innerClassTypeReference;
		}

		public TypeReference CombineToNormalTypeReference()
		{
			TypeReference typeReference = (this.baseType is InnerClassTypeReference) ? ((InnerClassTypeReference)this.baseType).CombineToNormalTypeReference() : this.baseType.Clone();
			TypeReference.CopyFields(this, typeReference);
			TypeReference expr_33 = typeReference;
			expr_33.Type = expr_33.Type + "." + base.Type;
			return typeReference;
		}

		public override string ToString()
		{
			return this.baseType.ToString() + "+" + base.ToString();
		}

		public TypeReference BaseType
		{
			get
			{
				return this.baseType;
			}
			set
			{
				this.baseType = value;
			}
		}

		private TypeReference baseType;
	}
}
