﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class CatchClause : AbstractNode
	{
		public CatchClause(Statement statementBlock)
		{
			this.StatementBlock = statementBlock;
			this.typeReference = TypeReference.Null;
			this.variableName = "";
			this.condition = Expression.Null;
		}

		public CatchClause(TypeReference typeReference, string variableName, Statement statementBlock)
		{
			this.TypeReference = typeReference;
			this.VariableName = variableName;
			this.StatementBlock = statementBlock;
			this.condition = Expression.Null;
		}

		public CatchClause(TypeReference typeReference, string variableName, Statement statementBlock, Expression condition)
		{
			this.TypeReference = typeReference;
			this.VariableName = variableName;
			this.StatementBlock = statementBlock;
			this.Condition = condition;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitCatchClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[CatchClause TypeReference={0} VariableName={1} StatementBlock={2} Condition={3}]", new object[]
			{
				this.TypeReference,
				this.VariableName,
				this.StatementBlock,
				this.Condition
			});
		}

		public Expression Condition
		{
			get
			{
				return this.condition;
			}
			set
			{
				this.condition = (value ?? Expression.Null);
				if (!this.condition.IsNull)
				{
					this.condition.Parent = this;
				}
			}
		}

		public Statement StatementBlock
		{
			get
			{
				return this.statementBlock;
			}
			set
			{
				this.statementBlock = (value ?? Statement.Null);
				if (!this.statementBlock.IsNull)
				{
					this.statementBlock.Parent = this;
				}
			}
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		public string VariableName
		{
			get
			{
				return this.variableName;
			}
			set
			{
				this.variableName = (value ?? "");
			}
		}

		private Expression condition;

		private Statement statementBlock;

		private TypeReference typeReference;

		private string variableName;
	}
}
