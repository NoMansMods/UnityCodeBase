﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class AttributeSection : AbstractNode
	{
		public AttributeSection()
		{
			this.attributeTarget = "";
			this.attributes = new List<Attribute>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitAttributeSection(this, data);
		}

		public override string ToString()
		{
			return string.Format("[AttributeSection AttributeTarget={0} Attributes={1}]", this.AttributeTarget, AbstractNode.GetCollectionString(this.Attributes));
		}

		public List<Attribute> Attributes
		{
			get
			{
				return this.attributes;
			}
			set
			{
				this.attributes = (value ?? new List<Attribute>());
			}
		}

		public string AttributeTarget
		{
			get
			{
				return this.attributeTarget;
			}
			set
			{
				this.attributeTarget = (value ?? "");
			}
		}

		private List<Attribute> attributes;

		private string attributeTarget;
	}
}
