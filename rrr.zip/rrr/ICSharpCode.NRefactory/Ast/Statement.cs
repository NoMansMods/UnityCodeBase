﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class Statement : AbstractNode, INullable
	{
		public static Statement CheckNull(Statement statement)
		{
			return statement ?? NullStatement.Instance;
		}

		public virtual bool IsNull
		{
			get
			{
				return false;
			}
		}

		public static Statement Null
		{
			get
			{
				return NullStatement.Instance;
			}
		}
	}
}
