﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public class SizeOfExpression : Expression
	{
		public SizeOfExpression(TypeReference typeReference)
		{
			this.TypeReference = typeReference;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitSizeOfExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[SizeOfExpression TypeReference={0}]", this.TypeReference);
		}

		public TypeReference TypeReference
		{
			get
			{
				return this.typeReference;
			}
			set
			{
				this.typeReference = (value ?? TypeReference.Null);
				if (!this.typeReference.IsNull)
				{
					this.typeReference.Parent = this;
				}
			}
		}

		private TypeReference typeReference;
	}
}
