﻿using System;
using System.Collections;

namespace ICSharpCode.NRefactory.Ast
{
	public class CompilationUnit : AbstractNode
	{
		public CompilationUnit()
		{
			this.blockStack.Push(this);
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitCompilationUnit(this, data);
		}

		public override void AddChild(INode childNode)
		{
			if (childNode != null)
			{
				INode node = (INode)this.blockStack.Peek();
				node.Children.Add(childNode);
				childNode.Parent = node;
			}
		}

		public void BlockEnd()
		{
			this.blockStack.Pop();
		}

		public void BlockStart(INode block)
		{
			this.blockStack.Push(block);
		}

		public override string ToString()
		{
			return string.Format("[CompilationUnit]", new object[0]);
		}

		public INode CurrentBock
		{
			get
			{
				if (this.blockStack.Count <= 0)
				{
					return null;
				}
				return (INode)this.blockStack.Peek();
			}
		}

		private Stack blockStack = new Stack();
	}
}
