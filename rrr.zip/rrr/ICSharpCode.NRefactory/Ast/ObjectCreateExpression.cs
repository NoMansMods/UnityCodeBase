﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class ObjectCreateExpression : Expression
	{
		public ObjectCreateExpression(TypeReference createType, List<Expression> parameters)
		{
			this.CreateType = createType;
			this.Parameters = parameters;
			this.objectInitializer = CollectionInitializerExpression.Null;
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitObjectCreateExpression(this, data);
		}

		public override string ToString()
		{
			return string.Format("[ObjectCreateExpression CreateType={0} Parameters={1} ObjectInitializer={2}]", this.CreateType, AbstractNode.GetCollectionString(this.Parameters), this.ObjectInitializer);
		}

		public TypeReference CreateType
		{
			get
			{
				return this.createType;
			}
			set
			{
				this.createType = (value ?? TypeReference.Null);
				if (!this.createType.IsNull)
				{
					this.createType.Parent = this;
				}
			}
		}

		public bool IsAnonymousType
		{
			get
			{
				return this.createType.IsNull || string.IsNullOrEmpty(this.createType.Type);
			}
		}

		public CollectionInitializerExpression ObjectInitializer
		{
			get
			{
				return this.objectInitializer;
			}
			set
			{
				this.objectInitializer = (value ?? CollectionInitializerExpression.Null);
				if (!this.objectInitializer.IsNull)
				{
					this.objectInitializer.Parent = this;
				}
			}
		}

		public List<Expression> Parameters
		{
			get
			{
				return this.parameters;
			}
			set
			{
				this.parameters = (value ?? new List<Expression>());
			}
		}

		private TypeReference createType;

		private CollectionInitializerExpression objectInitializer;

		private List<Expression> parameters;
	}
}
