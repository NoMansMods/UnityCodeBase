﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public interface INullable
	{
		bool IsNull
		{
			get;
		}
	}
}
