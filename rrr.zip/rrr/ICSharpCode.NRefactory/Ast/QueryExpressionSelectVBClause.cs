﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class QueryExpressionSelectVBClause : QueryExpressionClause
	{
		public QueryExpressionSelectVBClause()
		{
			this.variables = new List<ExpressionRangeVariable>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitQueryExpressionSelectVBClause(this, data);
		}

		public override string ToString()
		{
			return string.Format("[QueryExpressionSelectVBClause Variables={0}]", AbstractNode.GetCollectionString(this.Variables));
		}

		public List<ExpressionRangeVariable> Variables
		{
			get
			{
				return this.variables;
			}
			set
			{
				this.variables = (value ?? new List<ExpressionRangeVariable>());
			}
		}

		private List<ExpressionRangeVariable> variables;
	}
}
