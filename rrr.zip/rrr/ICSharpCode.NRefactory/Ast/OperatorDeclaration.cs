﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public class OperatorDeclaration : MethodDeclaration
	{
		public OperatorDeclaration()
		{
			this.returnTypeAttributes = new List<AttributeSection>();
		}

		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return visitor.VisitOperatorDeclaration(this, data);
		}

		public override string ToString()
		{
			return string.Format("[OperatorDeclaration ConversionType={0} ReturnTypeAttributes={1} OverloadableOperator={2} Body={3} HandlesClause={4} Templates={5} IsExtensionMethod={6} InterfaceImplementations={7} TypeReference={8} Name={9} Parameters={10} Attributes={11} Modifier={12}]", new object[]
			{
				this.ConversionType,
				AbstractNode.GetCollectionString(this.ReturnTypeAttributes),
				this.OverloadableOperator,
				base.Body,
				AbstractNode.GetCollectionString(base.HandlesClause),
				AbstractNode.GetCollectionString(base.Templates),
				base.IsExtensionMethod,
				AbstractNode.GetCollectionString(base.InterfaceImplementations),
				base.TypeReference,
				base.Name,
				AbstractNode.GetCollectionString(base.Parameters),
				AbstractNode.GetCollectionString(base.Attributes),
				base.Modifier
			});
		}

		public ConversionType ConversionType
		{
			get
			{
				return this.conversionType;
			}
			set
			{
				this.conversionType = value;
			}
		}

		public bool IsConversionOperator
		{
			get
			{
				return this.conversionType != ConversionType.None;
			}
		}

		public OverloadableOperatorType OverloadableOperator
		{
			get
			{
				return this.overloadableOperator;
			}
			set
			{
				this.overloadableOperator = value;
			}
		}

		public List<AttributeSection> ReturnTypeAttributes
		{
			get
			{
				return this.returnTypeAttributes;
			}
			set
			{
				this.returnTypeAttributes = (value ?? new List<AttributeSection>());
			}
		}

		private ConversionType conversionType;

		private OverloadableOperatorType overloadableOperator;

		private List<AttributeSection> returnTypeAttributes;
	}
}
