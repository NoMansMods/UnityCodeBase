﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	internal sealed class NullStatement : Statement
	{
		public override object AcceptVisitor(IAstVisitor visitor, object data)
		{
			return data;
		}

		public override string ToString()
		{
			return string.Format("[NullStatement]", new object[0]);
		}

		public override bool IsNull
		{
			get
			{
				return true;
			}
		}

		public static readonly NullStatement Instance = new NullStatement();
	}
}
