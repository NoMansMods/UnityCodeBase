﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Ast
{
	public abstract class ParametrizedNode : AttributedNode
	{
		protected ParametrizedNode()
		{
			this.name = "";
			this.parameters = new List<ParameterDeclarationExpression>();
		}

		protected ParametrizedNode(Modifiers modifier, List<AttributeSection> attributes, string name, List<ParameterDeclarationExpression> parameters)
		{
			base.Modifier = modifier;
			base.Attributes = attributes;
			this.Name = name;
			this.Parameters = parameters;
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = (value ?? "");
			}
		}

		public List<ParameterDeclarationExpression> Parameters
		{
			get
			{
				return this.parameters;
			}
			set
			{
				this.parameters = (value ?? new List<ParameterDeclarationExpression>());
			}
		}

		private string name;

		private List<ParameterDeclarationExpression> parameters;
	}
}
