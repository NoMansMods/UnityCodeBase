﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum OptionType
	{
		None,
		Explicit,
		Strict,
		CompareBinary,
		CompareText,
		Infer
	}
}
