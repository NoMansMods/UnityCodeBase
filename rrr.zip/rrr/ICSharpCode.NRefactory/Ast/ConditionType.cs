﻿using System;

namespace ICSharpCode.NRefactory.Ast
{
	public enum ConditionType
	{
		None,
		Until,
		While,
		DoWhile
	}
}
