﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("3.2.1.6466")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyCompany("ic#code")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("2000-2010 AlphaSierraPapa")]
[assembly: AssemblyDescription("Parser and refactoring library for C# and VB.NET")]
[assembly: AssemblyProduct("SharpDevelop")]
[assembly: AssemblyTitle("NRefactory")]
[assembly: AssemblyTrademark("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: StringFreezing]
[assembly: ComVisible(false)]
