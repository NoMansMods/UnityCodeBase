﻿using System;

namespace ICSharpCode.NRefactory
{
	internal sealed class DummyEnvironmentInformationProvider : IEnvironmentInformationProvider
	{
		public bool HasField(string reflectionTypeName, int typeParameterCount, string fieldName)
		{
			return false;
		}

		internal static readonly IEnvironmentInformationProvider Instance = new DummyEnvironmentInformationProvider();
	}
}
