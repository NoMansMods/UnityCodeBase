﻿using System;
using System.IO;
using System.Text;
using ICSharpCode.NRefactory.Parser;
using ICSharpCode.NRefactory.Parser.CSharp;
using ICSharpCode.NRefactory.Parser.VB;

namespace ICSharpCode.NRefactory
{
	public static class ParserFactory
	{
		public static ILexer CreateLexer(SupportedLanguage language, TextReader textReader)
		{
			switch (language)
			{
			case SupportedLanguage.CSharp:
				return new ICSharpCode.NRefactory.Parser.CSharp.Lexer(textReader);
			case SupportedLanguage.VBNet:
				return new ICSharpCode.NRefactory.Parser.VB.Lexer(textReader);
			default:
				throw new NotSupportedException(language + " not supported.");
			}
		}

		public static IParser CreateParser(string fileName)
		{
			return ParserFactory.CreateParser(fileName, Encoding.UTF8);
		}

		public static IParser CreateParser(SupportedLanguage language, TextReader textReader)
		{
			ILexer lexer = ParserFactory.CreateLexer(language, textReader);
			switch (language)
			{
			case SupportedLanguage.CSharp:
				return new ICSharpCode.NRefactory.Parser.CSharp.Parser(lexer);
			case SupportedLanguage.VBNet:
				return new ICSharpCode.NRefactory.Parser.VB.Parser(lexer);
			default:
				throw new NotSupportedException(language + " not supported.");
			}
		}

		public static IParser CreateParser(string fileName, Encoding encoding)
		{
			string extension = Path.GetExtension(fileName);
			if (extension.Equals(".cs", StringComparison.OrdinalIgnoreCase))
			{
				return ParserFactory.CreateParser(SupportedLanguage.CSharp, new StreamReader(fileName, encoding));
			}
			if (extension.Equals(".vb", StringComparison.OrdinalIgnoreCase))
			{
				return ParserFactory.CreateParser(SupportedLanguage.VBNet, new StreamReader(fileName, encoding));
			}
			return null;
		}
	}
}
