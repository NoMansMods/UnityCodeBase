﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory
{
	public class PreprocessingDirective : AbstractSpecial
	{
		public PreprocessingDirective(string cmd, string arg, Location start, Location end) : base(start, end)
		{
			this.Cmd = cmd;
			this.Arg = arg;
		}

		public override object AcceptVisitor(ISpecialVisitor visitor, object data)
		{
			return visitor.Visit(this, data);
		}

		public static void CSharpToVB(List<ISpecial> list)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i] is PreprocessingDirective)
				{
					list[i] = PreprocessingDirective.CSharpToVB((PreprocessingDirective)list[i]);
				}
			}
		}

		public static PreprocessingDirective CSharpToVB(PreprocessingDirective dir)
		{
			string text = dir.Cmd;
			string text2 = dir.Arg;
			string a;
			if ((a = text) != null)
			{
				if (!(a == "#region"))
				{
					if (!(a == "#endregion"))
					{
						if (!(a == "#endif"))
						{
							if (a == "#if")
							{
								text2 += " Then";
							}
						}
						else
						{
							text = "#End";
							text2 = "If";
						}
					}
					else
					{
						text = "#End";
						text2 = "Region";
					}
				}
				else
				{
					text = "#Region";
					if (!text2.StartsWith("\""))
					{
						text2 = "\"" + text2.Trim() + "\"";
					}
				}
			}
			if (text.Length > 1)
			{
				text = text.Substring(0, 2).ToUpperInvariant() + text.Substring(2);
			}
			return new PreprocessingDirective(text, text2, dir.StartPosition, dir.EndPosition)
			{
				Expression = dir.Expression
			};
		}

		public override string ToString()
		{
			return string.Format("[PreProcessingDirective: Cmd = {0}, Arg = {1}]", this.Cmd, this.Arg);
		}

		public static void VBToCSharp(IList<ISpecial> list)
		{
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i] is PreprocessingDirective)
				{
					list[i] = PreprocessingDirective.VBToCSharp((PreprocessingDirective)list[i]);
				}
			}
		}

		public static PreprocessingDirective VBToCSharp(PreprocessingDirective dir)
		{
			string text = dir.Cmd;
			string text2 = dir.Arg;
			if (text.Equals("#End", StringComparison.InvariantCultureIgnoreCase))
			{
				if (text2.ToLowerInvariant().StartsWith("region"))
				{
					text = "#endregion";
					text2 = "";
				}
				else if ("if".Equals(text2, StringComparison.InvariantCultureIgnoreCase))
				{
					text = "#endif";
					text2 = "";
				}
			}
			else if (text.Equals("#Region", StringComparison.InvariantCultureIgnoreCase))
			{
				text = "#region";
			}
			else if (text.Equals("#If", StringComparison.InvariantCultureIgnoreCase))
			{
				text = "#if";
				if (text2.ToLowerInvariant().EndsWith(" then"))
				{
					text2 = text2.Substring(0, text2.Length - 5);
				}
			}
			else if (text.Equals("#Else", StringComparison.InvariantCultureIgnoreCase))
			{
				if (dir.Expression != null)
				{
					text = "#elif";
				}
				else
				{
					text = "#else";
				}
			}
			else if (text.Equals("#ElseIf", StringComparison.InvariantCultureIgnoreCase))
			{
				text = "#elif";
			}
			return new PreprocessingDirective(text, text2, dir.StartPosition, dir.EndPosition)
			{
				Expression = dir.Expression
			};
		}

		public string Arg
		{
			get
			{
				return this.arg;
			}
			set
			{
				this.arg = (value ?? string.Empty);
			}
		}

		public string Cmd
		{
			get
			{
				return this.cmd;
			}
			set
			{
				this.cmd = (value ?? string.Empty);
			}
		}

		public Expression Expression
		{
			get
			{
				return this.expression;
			}
			set
			{
				this.expression = (value ?? Expression.Null);
			}
		}

		public Location LastLineEnd
		{
			get;
			set;
		}

		private string arg;

		private string cmd;

		private Expression expression = Expression.Null;
	}
}
