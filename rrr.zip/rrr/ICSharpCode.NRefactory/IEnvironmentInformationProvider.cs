﻿using System;

namespace ICSharpCode.NRefactory
{
	public interface IEnvironmentInformationProvider
	{
		bool HasField(string reflectionTypeName, int typeParameterCount, string fieldName);
	}
}
