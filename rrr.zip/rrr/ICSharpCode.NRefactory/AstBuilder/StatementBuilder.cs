﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.AstBuilder
{
	public static class StatementBuilder
	{
		public static void AddStatement(this BlockStatement block, Statement statement)
		{
			if (block == null)
			{
				throw new ArgumentNullException("block");
			}
			if (statement == null)
			{
				throw new ArgumentNullException("statement");
			}
			block.AddChild(statement);
			statement.Parent = block;
		}

		public static void AddStatement(this BlockStatement block, Expression expressionStatement)
		{
			if (expressionStatement == null)
			{
				throw new ArgumentNullException("expressionStatement");
			}
			block.AddStatement(new ExpressionStatement(expressionStatement));
		}

		public static void Assign(this BlockStatement block, Expression left, Expression right)
		{
			if (left == null)
			{
				throw new ArgumentNullException("left");
			}
			if (right == null)
			{
				throw new ArgumentNullException("right");
			}
			block.AddStatement(new AssignmentExpression(left, AssignmentOperatorType.Assign, right));
		}

		public static void Return(this BlockStatement block, Expression expression)
		{
			if (expression == null)
			{
				throw new ArgumentNullException("expression");
			}
			block.AddStatement(new ReturnStatement(expression));
		}

		public static void Throw(this BlockStatement block, Expression expression)
		{
			if (expression == null)
			{
				throw new ArgumentNullException("expression");
			}
			block.AddStatement(new ThrowStatement(expression));
		}
	}
}
