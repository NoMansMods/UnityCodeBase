﻿using System;

namespace ICSharpCode.NRefactory
{
	public enum CommentType
	{
		Block,
		SingleLine,
		Documentation
	}
}
