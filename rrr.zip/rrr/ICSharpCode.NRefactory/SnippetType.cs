﻿using System;

namespace ICSharpCode.NRefactory
{
	public enum SnippetType
	{
		None,
		CompilationUnit,
		Expression,
		Statements,
		TypeMembers
	}
}
