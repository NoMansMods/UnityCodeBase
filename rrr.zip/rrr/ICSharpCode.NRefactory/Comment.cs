﻿using System;

namespace ICSharpCode.NRefactory
{
	public class Comment : AbstractSpecial
	{
		public Comment(CommentType commentType, string comment, bool commentStartsLine, Location startPosition, Location endPosition) : base(startPosition, endPosition)
		{
			this.commentType = commentType;
			this.comment = comment;
			this.CommentStartsLine = commentStartsLine;
		}

		public override object AcceptVisitor(ISpecialVisitor visitor, object data)
		{
			return visitor.Visit(this, data);
		}

		public override string ToString()
		{
			return string.Format("[{0}: Type = {1}, Text = {2}, Start = {3}, End = {4}]", new object[]
			{
				base.GetType().Name,
				this.CommentType,
				this.CommentText,
				base.StartPosition,
				base.EndPosition
			});
		}

		public bool CommentStartsLine
		{
			get;
			set;
		}

		public string CommentText
		{
			get
			{
				return this.comment;
			}
			set
			{
				this.comment = value;
			}
		}

		public CommentType CommentType
		{
			get
			{
				return this.commentType;
			}
			set
			{
				this.commentType = value;
			}
		}

		private string comment;

		private CommentType commentType;
	}
}
