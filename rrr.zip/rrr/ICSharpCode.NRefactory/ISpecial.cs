﻿using System;

namespace ICSharpCode.NRefactory
{
	public interface ISpecial
	{
		object AcceptVisitor(ISpecialVisitor visitor, object data);

		Location EndPosition
		{
			get;
		}

		Location StartPosition
		{
			get;
		}
	}
}
