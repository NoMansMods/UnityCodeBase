﻿using System;
using System.Collections;
using ICSharpCode.NRefactory.Parser.CSharp;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public sealed class CSharpOutputFormatter : AbstractOutputFormatter
	{
		public CSharpOutputFormatter(PrettyPrintOptions prettyPrintOptions) : base(prettyPrintOptions)
		{
			this.prettyPrintOptions = prettyPrintOptions;
		}

		public void BeginBrace(BraceStyle style, bool indent)
		{
			switch (style)
			{
			case BraceStyle.EndOfLine:
				if (!base.LastCharacterIsWhiteSpace)
				{
					base.Space();
				}
				this.PrintToken(16);
				this.NewLine();
				if (indent)
				{
					base.IndentationLevel++;
				}
				break;
			case BraceStyle.EndOfLineWithoutSpace:
				this.PrintToken(16);
				this.NewLine();
				if (indent)
				{
					base.IndentationLevel++;
				}
				break;
			case BraceStyle.NextLine:
				this.NewLine();
				base.Indent();
				this.PrintToken(16);
				this.NewLine();
				if (indent)
				{
					base.IndentationLevel++;
				}
				break;
			case BraceStyle.NextLineShifted:
				this.NewLine();
				if (indent)
				{
					base.IndentationLevel++;
				}
				base.Indent();
				this.PrintToken(16);
				this.NewLine();
				break;
			case BraceStyle.NextLineShifted2:
				this.NewLine();
				if (indent)
				{
					base.IndentationLevel++;
				}
				base.Indent();
				this.PrintToken(16);
				this.NewLine();
				base.IndentationLevel++;
				break;
			}
			this.braceStack.Push(style);
		}

		public void EndBrace(bool indent)
		{
			this.EndBrace(indent, true);
		}

		public void EndBrace(bool indent, bool emitNewLine)
		{
			switch ((BraceStyle)this.braceStack.Pop())
			{
			case BraceStyle.EndOfLine:
			case BraceStyle.EndOfLineWithoutSpace:
			case BraceStyle.NextLine:
				if (indent)
				{
					base.IndentationLevel--;
				}
				base.Indent();
				this.PrintToken(17);
				if (emitNewLine)
				{
					this.NewLine();
					return;
				}
				break;
			case BraceStyle.NextLineShifted:
				base.Indent();
				this.PrintToken(17);
				if (emitNewLine)
				{
					this.NewLine();
				}
				if (indent)
				{
					base.IndentationLevel--;
					return;
				}
				break;
			case BraceStyle.NextLineShifted2:
				if (indent)
				{
					base.IndentationLevel--;
				}
				base.Indent();
				this.PrintToken(17);
				if (emitNewLine)
				{
					this.NewLine();
				}
				base.IndentationLevel--;
				break;
			default:
				return;
			}
		}

		public override void PrintComment(Comment comment, bool forceWriteInPreviousBlock)
		{
			switch (comment.CommentType)
			{
			case CommentType.Block:
			{
				bool isIndented = this.isIndented;
				if (!isIndented)
				{
					base.Indent();
				}
				if (forceWriteInPreviousBlock)
				{
					base.WriteInPreviousLine("/*" + comment.CommentText + "*/", forceWriteInPreviousBlock);
				}
				else
				{
					base.PrintSpecialText("/*" + comment.CommentText + "*/");
				}
				if (isIndented)
				{
					base.Indent();
					return;
				}
				return;
			}
			case CommentType.Documentation:
				base.WriteLineInPreviousLine("///" + comment.CommentText, forceWriteInPreviousBlock);
				return;
			}
			base.WriteLineInPreviousLine("//" + comment.CommentText, forceWriteInPreviousBlock, comment.StartPosition.Column != 3);
		}

		public override void PrintIdentifier(string identifier)
		{
			if (Keywords.GetToken(identifier) >= 0)
			{
				base.PrintText("@");
			}
			base.PrintText(identifier);
		}

		public override void PrintToken(int token)
		{
			if (token == 11 && !this.EmitSemicolon)
			{
				return;
			}
			base.PrintText(Tokens.GetTokenString(token));
		}

		public bool EmitSemicolon
		{
			get
			{
				return this.emitSemicolon;
			}
			set
			{
				this.emitSemicolon = value;
			}
		}

		private Stack braceStack = new Stack();

		private bool emitSemicolon = true;

		private PrettyPrintOptions prettyPrintOptions;
	}
}
