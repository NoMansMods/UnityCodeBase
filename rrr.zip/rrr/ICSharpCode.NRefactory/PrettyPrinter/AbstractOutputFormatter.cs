﻿using System;
using System.Collections;
using System.Text;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public abstract class AbstractOutputFormatter : IOutputFormatter
	{
		protected AbstractOutputFormatter(AbstractPrettyPrintOptions prettyPrintOptions)
		{
			this.prettyPrintOptions = prettyPrintOptions;
		}

		public virtual void EndFile()
		{
		}

		public void Indent()
		{
			if (this.DoIndent)
			{
				int i = 0;
				while (i < this.prettyPrintOptions.IndentSize * this.indentationLevel)
				{
					char c = this.prettyPrintOptions.IndentationChar;
					if (c == '\t' && i + this.prettyPrintOptions.TabSize > this.prettyPrintOptions.IndentSize * this.indentationLevel)
					{
						c = ' ';
					}
					this.text.Append(c);
					if (c == '\t')
					{
						i += this.prettyPrintOptions.TabSize;
					}
					else
					{
						i++;
					}
				}
				this.isIndented = true;
			}
		}

		public virtual void NewLine()
		{
			if (this.DoNewLine)
			{
				if (!this.LastCharacterIsNewLine)
				{
					this.lineBeforeLastStart = this.lastLineStart;
				}
				this.text.AppendLine();
				this.lastLineStart = this.text.Length;
				this.isIndented = false;
			}
		}

		public void PrintBlankLine(bool forceWriteInPreviousBlock)
		{
			this.WriteInPreviousLine(Environment.NewLine, forceWriteInPreviousBlock);
		}

		public abstract void PrintComment(Comment comment, bool forceWriteInPreviousBlock);

		public abstract void PrintIdentifier(string identifier);

		public virtual void PrintPreprocessingDirective(PreprocessingDirective directive, bool forceWriteInPreviousBlock)
		{
			if (!directive.Expression.IsNull)
			{
				CSharpOutputVisitor cSharpOutputVisitor = new CSharpOutputVisitor();
				directive.Expression.AcceptVisitor(cSharpOutputVisitor, null);
				this.WriteLineInPreviousLine(directive.Cmd + " " + cSharpOutputVisitor.Text, forceWriteInPreviousBlock);
				return;
			}
			if (string.IsNullOrEmpty(directive.Arg))
			{
				this.WriteLineInPreviousLine(directive.Cmd, forceWriteInPreviousBlock);
				return;
			}
			this.WriteLineInPreviousLine(directive.Cmd + " " + directive.Arg, forceWriteInPreviousBlock);
		}

		protected void PrintSpecialText(string specialText)
		{
			this.lineBeforeLastStart = this.text.Length;
			this.text.Append(specialText);
			this.lastLineStart = this.text.Length;
			this.isIndented = false;
		}

		public void PrintText(string text)
		{
			this.text.Append(text);
			this.isIndented = false;
		}

		public abstract void PrintToken(int token);

		public void PrintTokenList(ArrayList tokenList)
		{
			foreach (int token in tokenList)
			{
				this.PrintToken(token);
				this.Space();
			}
		}

		public void Reset()
		{
			this.text.Length = 0;
			this.isIndented = false;
		}

		public void Space()
		{
			this.text.Append(' ');
			this.isIndented = false;
		}

		protected void WriteInPreviousLine(string txt, bool forceWriteInPreviousBlock)
		{
			this.WriteInPreviousLine(txt, forceWriteInPreviousBlock, true);
		}

		protected void WriteInPreviousLine(string txt, bool forceWriteInPreviousBlock, bool indent)
		{
			if (txt.Length == 0)
			{
				return;
			}
			bool lastCharacterIsNewLine = this.LastCharacterIsNewLine;
			if (lastCharacterIsNewLine)
			{
				if (!forceWriteInPreviousBlock)
				{
					if (indent && txt != Environment.NewLine)
					{
						this.Indent();
					}
					this.text.Append(txt);
					this.lineBeforeLastStart = this.lastLineStart;
					this.lastLineStart = this.text.Length;
					return;
				}
				this.lastLineStart = this.lineBeforeLastStart;
			}
			string value = this.text.ToString(this.lastLineStart, this.text.Length - this.lastLineStart);
			this.text.Remove(this.lastLineStart, this.text.Length - this.lastLineStart);
			if (indent && txt != Environment.NewLine)
			{
				if (forceWriteInPreviousBlock)
				{
					this.indentationLevel++;
				}
				this.Indent();
				if (forceWriteInPreviousBlock)
				{
					this.indentationLevel--;
				}
			}
			this.text.Append(txt);
			this.lineBeforeLastStart = this.lastLineStart;
			this.lastLineStart = this.text.Length;
			this.text.Append(value);
			if (lastCharacterIsNewLine)
			{
				this.lineBeforeLastStart = this.lastLineStart;
				this.lastLineStart = this.text.Length;
			}
			this.isIndented = false;
		}

		protected void WriteLineInPreviousLine(string txt, bool forceWriteInPreviousBlock)
		{
			this.WriteInPreviousLine(txt + Environment.NewLine, forceWriteInPreviousBlock);
		}

		protected void WriteLineInPreviousLine(string txt, bool forceWriteInPreviousBlock, bool indent)
		{
			this.WriteInPreviousLine(txt + Environment.NewLine, forceWriteInPreviousBlock, indent);
		}

		public bool DoIndent
		{
			get
			{
				return this.indent;
			}
			set
			{
				this.indent = value;
			}
		}

		public bool DoNewLine
		{
			get
			{
				return this.doNewLine;
			}
			set
			{
				this.doNewLine = value;
			}
		}

		public int IndentationLevel
		{
			get
			{
				return this.indentationLevel;
			}
			set
			{
				this.indentationLevel = value;
			}
		}

		public bool IsInMemberBody
		{
			get;
			set;
		}

		public bool LastCharacterIsNewLine
		{
			get
			{
				return this.text.Length == this.lastLineStart;
			}
		}

		public bool LastCharacterIsWhiteSpace
		{
			get
			{
				return this.text.Length == 0 || char.IsWhiteSpace(this.text[this.text.Length - 1]);
			}
		}

		public string Text
		{
			get
			{
				return this.text.ToString();
			}
		}

		public int TextLength
		{
			get
			{
				return this.text.Length;
			}
		}

		private bool doNewLine = true;

		private bool indent = true;

		private int indentationLevel;

		internal bool isIndented;

		internal int lastLineStart;

		internal int lineBeforeLastStart;

		private AbstractPrettyPrintOptions prettyPrintOptions;

		private StringBuilder text = new StringBuilder();
	}
}
