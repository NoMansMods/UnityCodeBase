﻿using System;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Parser;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public interface IOutputAstVisitor : IAstVisitor
	{
		Errors Errors
		{
			get;
		}

		AbstractPrettyPrintOptions Options
		{
			get;
		}

		IOutputFormatter OutputFormatter
		{
			get;
		}

		string Text
		{
			get;
		}

		event Action<INode> AfterNodeVisit;

		event Action<INode> BeforeNodeVisit;
	}
}
