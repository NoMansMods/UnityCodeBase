﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public enum BraceStyle
	{
		EndOfLine,
		EndOfLineWithoutSpace,
		NextLine,
		NextLineShifted,
		NextLineShifted2
	}
}
