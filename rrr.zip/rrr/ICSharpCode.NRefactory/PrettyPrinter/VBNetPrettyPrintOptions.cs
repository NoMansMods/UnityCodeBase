﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public class VBNetPrettyPrintOptions : AbstractPrettyPrintOptions
	{
		public bool OutputByValModifier
		{
			get;
			set;
		}
	}
}
