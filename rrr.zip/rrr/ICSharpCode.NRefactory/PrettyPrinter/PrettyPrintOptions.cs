﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public class PrettyPrintOptions : AbstractPrettyPrintOptions
	{
		public PrettyPrintOptions()
		{
			this.PlaceNonBlockElseOnNewLine = true;
		}

		public bool AllowEventAddBlockInline
		{
			get
			{
				return this.allowEventAddBlockInline;
			}
			set
			{
				this.allowEventAddBlockInline = value;
			}
		}

		public bool AllowEventRemoveBlockInline
		{
			get
			{
				return this.allowEventRemoveBlockInline;
			}
			set
			{
				this.allowEventRemoveBlockInline = value;
			}
		}

		public bool AllowPropertyGetBlockInline
		{
			get
			{
				return this.allowPropertyGetBlockInline;
			}
			set
			{
				this.allowPropertyGetBlockInline = value;
			}
		}

		public bool AllowPropertySetBlockInline
		{
			get
			{
				return this.allowPropertySetBlockInline;
			}
			set
			{
				this.allowPropertySetBlockInline = value;
			}
		}

		public BraceStyle AnonymousMethodBraceStyle
		{
			get
			{
				return this.anonymousMethodBraceStyle;
			}
			set
			{
				this.anonymousMethodBraceStyle = value;
			}
		}

		public bool AroundAdditiveOperatorParentheses
		{
			get
			{
				return this.aroundAdditiveOperatorParentheses;
			}
			set
			{
				this.aroundAdditiveOperatorParentheses = value;
			}
		}

		public bool AroundAssignmentParentheses
		{
			get
			{
				return this.aroundAssignmentParentheses;
			}
			set
			{
				this.aroundAssignmentParentheses = value;
			}
		}

		public bool AroundBitwiseOperatorParentheses
		{
			get
			{
				return this.aroundBitwiseOperatorParentheses;
			}
			set
			{
				this.aroundBitwiseOperatorParentheses = value;
			}
		}

		public bool AroundEqualityOperatorParentheses
		{
			get
			{
				return this.aroundEqualityOperatorParentheses;
			}
			set
			{
				this.aroundEqualityOperatorParentheses = value;
			}
		}

		public bool AroundLogicalOperatorParentheses
		{
			get
			{
				return this.aroundLogicalOperatorParentheses;
			}
			set
			{
				this.aroundLogicalOperatorParentheses = value;
			}
		}

		public bool AroundMultiplicativeOperatorParentheses
		{
			get
			{
				return this.aroundMultiplicativeOperatorParentheses;
			}
			set
			{
				this.aroundMultiplicativeOperatorParentheses = value;
			}
		}

		public bool AroundRelationalOperatorParentheses
		{
			get
			{
				return this.aroundRelationalOperatorParentheses;
			}
			set
			{
				this.aroundRelationalOperatorParentheses = value;
			}
		}

		public bool AroundShiftOperatorParentheses
		{
			get
			{
				return this.aroundShiftOperatorParentheses;
			}
			set
			{
				this.aroundShiftOperatorParentheses = value;
			}
		}

		public bool BeforeConstructorDeclarationParentheses
		{
			get
			{
				return this.beforeConstructorDeclarationParentheses;
			}
			set
			{
				this.beforeConstructorDeclarationParentheses = value;
			}
		}

		public bool BeforeDelegateDeclarationParentheses
		{
			get
			{
				return this.beforeDelegateDeclarationParentheses;
			}
			set
			{
				this.beforeDelegateDeclarationParentheses = value;
			}
		}

		public bool BeforeMethodCallParentheses
		{
			get
			{
				return this.beforeMethodCallParentheses;
			}
			set
			{
				this.beforeMethodCallParentheses = value;
			}
		}

		public bool BeforeMethodDeclarationParentheses
		{
			get
			{
				return this.beforeMethodDeclarationParentheses;
			}
			set
			{
				this.beforeMethodDeclarationParentheses = value;
			}
		}

		public bool CatchParentheses
		{
			get
			{
				return this.catchParentheses;
			}
			set
			{
				this.catchParentheses = value;
			}
		}

		public bool CheckedParentheses
		{
			get
			{
				return this.checkedParentheses;
			}
			set
			{
				this.checkedParentheses = value;
			}
		}

		public BraceStyle ClassBraceStyle
		{
			get
			{
				return this.classBraceStyle;
			}
			set
			{
				this.classBraceStyle = value;
			}
		}

		public bool ConditionalOperatorAfterConditionSpace
		{
			get
			{
				return this.conditionalOperatorAfterConditionSpace;
			}
			set
			{
				this.conditionalOperatorAfterConditionSpace = value;
			}
		}

		public bool ConditionalOperatorAfterSeparatorSpace
		{
			get
			{
				return this.conditionalOperatorAfterSeparatorSpace;
			}
			set
			{
				this.conditionalOperatorAfterSeparatorSpace = value;
			}
		}

		public bool ConditionalOperatorBeforeConditionSpace
		{
			get
			{
				return this.conditionalOperatorBeforeConditionSpace;
			}
			set
			{
				this.conditionalOperatorBeforeConditionSpace = value;
			}
		}

		public bool ConditionalOperatorBeforeSeparatorSpace
		{
			get
			{
				return this.conditionalOperatorBeforeSeparatorSpace;
			}
			set
			{
				this.conditionalOperatorBeforeSeparatorSpace = value;
			}
		}

		public BraceStyle ConstructorBraceStyle
		{
			get
			{
				return this.constructorBraceStyle;
			}
			set
			{
				this.constructorBraceStyle = value;
			}
		}

		public BraceStyle DestructorBraceStyle
		{
			get
			{
				return this.destructorBraceStyle;
			}
			set
			{
				this.destructorBraceStyle = value;
			}
		}

		public BraceStyle EnumBraceStyle
		{
			get
			{
				return this.enumBraceStyle;
			}
			set
			{
				this.enumBraceStyle = value;
			}
		}

		public BraceStyle EventAddBraceStyle
		{
			get
			{
				return this.eventAddBraceStyle;
			}
			set
			{
				this.eventAddBraceStyle = value;
			}
		}

		public BraceStyle EventBraceStyle
		{
			get
			{
				return this.eventBraceStyle;
			}
			set
			{
				this.eventBraceStyle = value;
			}
		}

		public BraceStyle EventRemoveBraceStyle
		{
			get
			{
				return this.eventRemoveBraceStyle;
			}
			set
			{
				this.eventRemoveBraceStyle = value;
			}
		}

		public BraceForcement FixedBraceForcement
		{
			get
			{
				return this.fixedBraceForcement;
			}
			set
			{
				this.fixedBraceForcement = value;
			}
		}

		public bool FixedParentheses
		{
			get
			{
				return this.fixedParentheses;
			}
			set
			{
				this.fixedParentheses = value;
			}
		}

		public BraceForcement ForBraceForcement
		{
			get
			{
				return this.forBraceForcement;
			}
			set
			{
				this.forBraceForcement = value;
			}
		}

		public BraceForcement ForEachBraceForcement
		{
			get
			{
				return this.foreachBraceForcement;
			}
			set
			{
				this.foreachBraceForcement = value;
			}
		}

		public bool ForeachParentheses
		{
			get
			{
				return this.foreachParentheses;
			}
			set
			{
				this.foreachParentheses = value;
			}
		}

		public bool ForParentheses
		{
			get
			{
				return this.forParentheses;
			}
			set
			{
				this.forParentheses = value;
			}
		}

		public BraceForcement IfElseBraceForcement
		{
			get
			{
				return this.ifElseBraceForcement;
			}
			set
			{
				this.ifElseBraceForcement = value;
			}
		}

		public bool IfParentheses
		{
			get
			{
				return this.ifParentheses;
			}
			set
			{
				this.ifParentheses = value;
			}
		}

		public bool IndentBlocks
		{
			get
			{
				return this.indentBlocks;
			}
			set
			{
				this.indentBlocks = value;
			}
		}

		public bool IndentBreakStatements
		{
			get
			{
				return this.indentBreakStatements;
			}
			set
			{
				this.indentBreakStatements = value;
			}
		}

		public bool IndentCaseBody
		{
			get
			{
				return this.indentCaseBody;
			}
			set
			{
				this.indentCaseBody = value;
			}
		}

		public bool IndentClassBody
		{
			get
			{
				return this.indentClassBody;
			}
			set
			{
				this.indentClassBody = value;
			}
		}

		public bool IndentEnumBody
		{
			get
			{
				return this.indentEnumBody;
			}
			set
			{
				this.indentEnumBody = value;
			}
		}

		public bool IndentEventBody
		{
			get
			{
				return this.indentEventBody;
			}
			set
			{
				this.indentEventBody = value;
			}
		}

		public bool IndentInterfaceBody
		{
			get
			{
				return this.indentInterfaceBody;
			}
			set
			{
				this.indentInterfaceBody = value;
			}
		}

		public bool IndentMethodBody
		{
			get
			{
				return this.indentMethodBody;
			}
			set
			{
				this.indentMethodBody = value;
			}
		}

		public bool IndentNamespaceBody
		{
			get
			{
				return this.indentNamespaceBody;
			}
			set
			{
				this.indentNamespaceBody = value;
			}
		}

		public bool IndentPropertyBody
		{
			get
			{
				return this.indentPropertyBody;
			}
			set
			{
				this.indentPropertyBody = value;
			}
		}

		public bool IndentStructBody
		{
			get
			{
				return this.indentStructBody;
			}
			set
			{
				this.indentStructBody = value;
			}
		}

		public bool IndentSwitchBody
		{
			get
			{
				return this.indentSwitchBody;
			}
			set
			{
				this.indentSwitchBody = value;
			}
		}

		public BraceStyle InterfaceBraceStyle
		{
			get
			{
				return this.interfaceBraceStyle;
			}
			set
			{
				this.interfaceBraceStyle = value;
			}
		}

		public bool LockParentheses
		{
			get
			{
				return this.lockParentheses;
			}
			set
			{
				this.lockParentheses = value;
			}
		}

		public BraceStyle MethodBraceStyle
		{
			get
			{
				return this.methodBraceStyle;
			}
			set
			{
				this.methodBraceStyle = value;
			}
		}

		public BraceStyle NamespaceBraceStyle
		{
			get
			{
				return this.namespaceBraceStyle;
			}
			set
			{
				this.namespaceBraceStyle = value;
			}
		}

		public bool NewParentheses
		{
			get
			{
				return this.newParentheses;
			}
			set
			{
				this.newParentheses = value;
			}
		}

		public bool PlaceCatchOnNewLine
		{
			get;
			set;
		}

		public bool PlaceElseOnNewLine
		{
			get;
			set;
		}

		public bool PlaceFinallyOnNewLine
		{
			get;
			set;
		}

		public bool PlaceNonBlockElseOnNewLine
		{
			get;
			set;
		}

		public bool PlaceWhileOnNewLine
		{
			get;
			set;
		}

		public BraceStyle PropertyBraceStyle
		{
			get
			{
				return this.propertyBraceStyle;
			}
			set
			{
				this.propertyBraceStyle = value;
			}
		}

		public BraceStyle PropertyGetBraceStyle
		{
			get
			{
				return this.propertyGetBraceStyle;
			}
			set
			{
				this.propertyGetBraceStyle = value;
			}
		}

		public BraceStyle PropertySetBraceStyle
		{
			get
			{
				return this.propertySetBraceStyle;
			}
			set
			{
				this.propertySetBraceStyle = value;
			}
		}

		public bool SizeOfParentheses
		{
			get
			{
				return this.sizeOfParentheses;
			}
			set
			{
				this.sizeOfParentheses = value;
			}
		}

		public bool SpacesAfterComma
		{
			get
			{
				return this.spacesAfterComma;
			}
			set
			{
				this.spacesAfterComma = value;
			}
		}

		public bool SpacesAfterSemicolon
		{
			get
			{
				return this.spacesAfterSemicolon;
			}
			set
			{
				this.spacesAfterSemicolon = value;
			}
		}

		public bool SpacesAfterTypecast
		{
			get
			{
				return this.spacesAfterTypecast;
			}
			set
			{
				this.spacesAfterTypecast = value;
			}
		}

		public bool SpacesBeforeComma
		{
			get
			{
				return this.spacesBeforeComma;
			}
			set
			{
				this.spacesBeforeComma = value;
			}
		}

		public bool SpacesWithinBrackets
		{
			get
			{
				return this.spacesWithinBrackets;
			}
			set
			{
				this.spacesWithinBrackets = value;
			}
		}

		public BraceStyle StatementBraceStyle
		{
			get
			{
				return this.statementBraceStyle;
			}
			set
			{
				this.statementBraceStyle = value;
			}
		}

		public BraceStyle StructBraceStyle
		{
			get
			{
				return this.structBraceStyle;
			}
			set
			{
				this.structBraceStyle = value;
			}
		}

		public bool SwitchParentheses
		{
			get
			{
				return this.switchParentheses;
			}
			set
			{
				this.switchParentheses = value;
			}
		}

		public bool TypeOfParentheses
		{
			get
			{
				return this.typeOfParentheses;
			}
			set
			{
				this.typeOfParentheses = value;
			}
		}

		public bool UncheckedParentheses
		{
			get
			{
				return this.uncheckedParentheses;
			}
			set
			{
				this.uncheckedParentheses = value;
			}
		}

		public BraceForcement UsingBraceForcement
		{
			get
			{
				return this.usingBraceForcement;
			}
			set
			{
				this.usingBraceForcement = value;
			}
		}

		public bool UsingParentheses
		{
			get
			{
				return this.usingParentheses;
			}
			set
			{
				this.usingParentheses = value;
			}
		}

		public BraceForcement WhileBraceForcement
		{
			get
			{
				return this.whileBraceForcement;
			}
			set
			{
				this.whileBraceForcement = value;
			}
		}

		public bool WhileParentheses
		{
			get
			{
				return this.whileParentheses;
			}
			set
			{
				this.whileParentheses = value;
			}
		}

		public bool WithinCastParentheses
		{
			get
			{
				return this.withinCastParentheses;
			}
			set
			{
				this.withinCastParentheses = value;
			}
		}

		public bool WithinCatchParentheses
		{
			get
			{
				return this.withinCatchParentheses;
			}
			set
			{
				this.withinCatchParentheses = value;
			}
		}

		public bool WithinCheckedExpressionParantheses
		{
			get
			{
				return this.withinCheckedExpressionParantheses;
			}
			set
			{
				this.withinCheckedExpressionParantheses = value;
			}
		}

		public bool WithinForEachParentheses
		{
			get
			{
				return this.withinForEachParentheses;
			}
			set
			{
				this.withinForEachParentheses = value;
			}
		}

		public bool WithinForParentheses
		{
			get
			{
				return this.withinForParentheses;
			}
			set
			{
				this.withinForParentheses = value;
			}
		}

		public bool WithinIfParentheses
		{
			get
			{
				return this.withinIfParentheses;
			}
			set
			{
				this.withinIfParentheses = value;
			}
		}

		public bool WithinLockParentheses
		{
			get
			{
				return this.withinLockParentheses;
			}
			set
			{
				this.withinLockParentheses = value;
			}
		}

		public bool WithinMethodCallParentheses
		{
			get
			{
				return this.withinMethodCallParentheses;
			}
			set
			{
				this.withinMethodCallParentheses = value;
			}
		}

		public bool WithinMethodDeclarationParentheses
		{
			get
			{
				return this.withinMethodDeclarationParentheses;
			}
			set
			{
				this.withinMethodDeclarationParentheses = value;
			}
		}

		public bool WithinParentheses
		{
			get
			{
				return this.withinParentheses;
			}
			set
			{
				this.withinParentheses = value;
			}
		}

		public bool WithinSizeOfParentheses
		{
			get
			{
				return this.withinSizeOfParentheses;
			}
			set
			{
				this.withinSizeOfParentheses = value;
			}
		}

		public bool WithinSwitchParentheses
		{
			get
			{
				return this.withinSwitchParentheses;
			}
			set
			{
				this.withinSwitchParentheses = value;
			}
		}

		public bool WithinTypeOfParentheses
		{
			get
			{
				return this.withinTypeOfParentheses;
			}
			set
			{
				this.withinTypeOfParentheses = value;
			}
		}

		public bool WithinUsingParentheses
		{
			get
			{
				return this.withinUsingParentheses;
			}
			set
			{
				this.withinUsingParentheses = value;
			}
		}

		public bool WithinWhileParentheses
		{
			get
			{
				return this.withinWhileParentheses;
			}
			set
			{
				this.withinWhileParentheses = value;
			}
		}

		private bool allowEventAddBlockInline = true;

		private bool allowEventRemoveBlockInline = true;

		private bool allowPropertyGetBlockInline = true;

		private bool allowPropertySetBlockInline = true;

		private BraceStyle anonymousMethodBraceStyle;

		private bool aroundAdditiveOperatorParentheses = true;

		private bool aroundAssignmentParentheses = true;

		private bool aroundBitwiseOperatorParentheses = true;

		private bool aroundEqualityOperatorParentheses = true;

		private bool aroundLogicalOperatorParentheses = true;

		private bool aroundMultiplicativeOperatorParentheses = true;

		private bool aroundRelationalOperatorParentheses = true;

		private bool aroundShiftOperatorParentheses = true;

		private bool beforeConstructorDeclarationParentheses;

		private bool beforeDelegateDeclarationParentheses;

		private bool beforeMethodCallParentheses;

		private bool beforeMethodDeclarationParentheses;

		private bool catchParentheses = true;

		private bool checkedParentheses;

		private BraceStyle classBraceStyle = BraceStyle.NextLine;

		private bool conditionalOperatorAfterConditionSpace = true;

		private bool conditionalOperatorAfterSeparatorSpace = true;

		private bool conditionalOperatorBeforeConditionSpace = true;

		private bool conditionalOperatorBeforeSeparatorSpace = true;

		private BraceStyle constructorBraceStyle = BraceStyle.NextLine;

		private BraceStyle destructorBraceStyle = BraceStyle.NextLine;

		private BraceStyle enumBraceStyle = BraceStyle.NextLine;

		private BraceStyle eventAddBraceStyle;

		private BraceStyle eventBraceStyle;

		private BraceStyle eventRemoveBraceStyle;

		private BraceForcement fixedBraceForcement;

		private bool fixedParentheses = true;

		private BraceForcement forBraceForcement;

		private BraceForcement foreachBraceForcement;

		private bool foreachParentheses = true;

		private bool forParentheses = true;

		private BraceForcement ifElseBraceForcement;

		private bool ifParentheses = true;

		private bool indentBlocks = true;

		private bool indentBreakStatements = true;

		private bool indentCaseBody = true;

		private bool indentClassBody = true;

		private bool indentEnumBody = true;

		private bool indentEventBody = true;

		private bool indentInterfaceBody = true;

		private bool indentMethodBody = true;

		private bool indentNamespaceBody = true;

		private bool indentPropertyBody = true;

		private bool indentStructBody = true;

		private bool indentSwitchBody = true;

		private BraceStyle interfaceBraceStyle = BraceStyle.NextLine;

		private bool lockParentheses = true;

		private BraceStyle methodBraceStyle = BraceStyle.NextLine;

		private BraceStyle namespaceBraceStyle = BraceStyle.NextLine;

		private bool newParentheses;

		private BraceStyle propertyBraceStyle;

		private BraceStyle propertyGetBraceStyle;

		private BraceStyle propertySetBraceStyle;

		private bool sizeOfParentheses;

		private bool spacesAfterComma = true;

		private bool spacesAfterSemicolon = true;

		private bool spacesAfterTypecast;

		private bool spacesBeforeComma;

		private bool spacesWithinBrackets;

		private BraceStyle statementBraceStyle;

		private BraceStyle structBraceStyle = BraceStyle.NextLine;

		private bool switchParentheses = true;

		private bool typeOfParentheses;

		private bool uncheckedParentheses;

		private BraceForcement usingBraceForcement;

		private bool usingParentheses = true;

		private BraceForcement whileBraceForcement;

		private bool whileParentheses = true;

		private bool withinCastParentheses;

		private bool withinCatchParentheses;

		private bool withinCheckedExpressionParantheses;

		private bool withinForEachParentheses;

		private bool withinForParentheses;

		private bool withinIfParentheses;

		private bool withinLockParentheses;

		private bool withinMethodCallParentheses;

		private bool withinMethodDeclarationParentheses;

		private bool withinParentheses;

		private bool withinSizeOfParentheses;

		private bool withinSwitchParentheses;

		private bool withinTypeOfParentheses;

		private bool withinUsingParentheses;

		private bool withinWhileParentheses;
	}
}
