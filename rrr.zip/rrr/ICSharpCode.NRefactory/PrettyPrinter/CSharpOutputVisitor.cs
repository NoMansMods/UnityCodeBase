﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Parser;
using ICSharpCode.NRefactory.Visitors;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public sealed class CSharpOutputVisitor : NodeTrackingAstVisitor, IOutputAstVisitor, IAstVisitor
	{
		public CSharpOutputVisitor()
		{
			this.outputFormatter = new CSharpOutputFormatter(this.prettyPrintOptions);
		}

		public void AppendCommaSeparatedList<T>(ICollection<T> list) where T : class, INode
		{
			this.AppendCommaSeparatedList<T>(list, false);
		}

		public void AppendCommaSeparatedList<T>(ICollection<T> list, bool alwaysBreakLine) where T : class, INode
		{
			if (list != null)
			{
				int num = 0;
				foreach (T current in list)
				{
					current.AcceptVisitor(this, null);
					if (num + 1 < list.Count)
					{
						if (alwaysBreakLine || (num + 1) % 10 == 0)
						{
							this.PrintFormattedCommaAndNewLine();
						}
						else
						{
							this.PrintFormattedComma();
						}
					}
					num++;
				}
			}
		}

		protected override void BeginVisit(INode node)
		{
			if (this.BeforeNodeVisit != null)
			{
				this.BeforeNodeVisit(node);
			}
			base.BeginVisit(node);
		}

		private static string ConvertChar(char ch)
		{
			char c = ch;
			switch (c)
			{
			case '\0':
				return "\\0";
			case '\u0001':
			case '\u0002':
			case '\u0003':
			case '\u0004':
			case '\u0005':
			case '\u0006':
				break;
			case '\a':
				return "\\a";
			case '\b':
				return "\\b";
			case '\t':
				return "\\t";
			case '\n':
				return "\\n";
			case '\v':
				return "\\v";
			case '\f':
				return "\\f";
			case '\r':
				return "\\r";
			default:
				if (c == '\\')
				{
					return "\\\\";
				}
				break;
			}
			if (char.IsControl(ch))
			{
				string arg_96_0 = "\\u";
				int num = (int)ch;
				return arg_96_0 + num.ToString("x4");
			}
			return ch.ToString();
		}

		private static string ConvertCharLiteral(char ch)
		{
			if (ch == '\'')
			{
				return "\\'";
			}
			return CSharpOutputVisitor.ConvertChar(ch);
		}

		private static string ConvertString(string str)
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < str.Length; i++)
			{
				char c = str[i];
				if (c == '"')
				{
					stringBuilder.Append("\\\"");
				}
				else
				{
					stringBuilder.Append(CSharpOutputVisitor.ConvertChar(c));
				}
			}
			return stringBuilder.ToString();
		}

		private static string ConvertTypeString(string typeString)
		{
			string result;
			if (TypeReference.PrimitiveTypesCSharpReverse.TryGetValue(typeString, out result))
			{
				return result;
			}
			return typeString;
		}

		protected override void EndVisit(INode node)
		{
			base.EndVisit(node);
			if (this.AfterNodeVisit != null)
			{
				this.AfterNodeVisit(node);
			}
		}

		private void Error(INode node, string message)
		{
			this.outputFormatter.PrintText(" // ERROR: " + message + Environment.NewLine);
			this.errors.Error(node.StartLocation.Line, node.StartLocation.Column, message);
		}

		private static bool IsNullLiteralExpression(Expression expr)
		{
			PrimitiveExpression primitiveExpression = expr as PrimitiveExpression;
			return primitiveExpression != null && primitiveExpression.Value == null;
		}

		private void NotSupported(INode node)
		{
			this.Error(node, "Not supported in C#: " + node.GetType().Name);
		}

		private void OutputBlock(BlockStatement blockStatement, BraceStyle braceStyle)
		{
			this.OutputBlock(blockStatement, braceStyle, true);
		}

		private void OutputBlock(BlockStatement blockStatement, BraceStyle braceStyle, bool emitEndingNewLine)
		{
			this.BeginVisit(blockStatement);
			if (blockStatement.IsNull)
			{
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.NewLine();
			}
			else
			{
				this.outputFormatter.BeginBrace(braceStyle, this.prettyPrintOptions.IndentBlocks);
				using (List<INode>.Enumerator enumerator = blockStatement.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Statement statement = (Statement)enumerator.Current;
						this.outputFormatter.Indent();
						if (statement is BlockStatement)
						{
							this.TrackVisit(statement, BraceStyle.EndOfLine);
						}
						else
						{
							this.TrackVisit(statement, null);
						}
						if (!this.outputFormatter.LastCharacterIsNewLine)
						{
							this.outputFormatter.NewLine();
						}
					}
				}
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentBlocks, emitEndingNewLine);
			}
			this.EndVisit(blockStatement);
		}

		private void OutputBlockAllowInline(BlockStatement blockStatement, BraceStyle braceStyle)
		{
			this.OutputBlockAllowInline(blockStatement, braceStyle, true);
		}

		private void OutputBlockAllowInline(BlockStatement blockStatement, BraceStyle braceStyle, bool useNewLine)
		{
			if (!blockStatement.IsNull && (blockStatement.Children.Count == 0 || (blockStatement.Children.Count == 1 && (blockStatement.Children[0] is ExpressionStatement || blockStatement.Children[0] is ReturnStatement))))
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(16);
				this.outputFormatter.Space();
				if (blockStatement.Children.Count != 0)
				{
					bool doIndent = this.outputFormatter.DoIndent;
					bool doNewLine = this.outputFormatter.DoNewLine;
					this.outputFormatter.DoIndent = false;
					this.outputFormatter.DoNewLine = false;
					this.TrackVisit(blockStatement.Children[0], null);
					this.outputFormatter.DoIndent = doIndent;
					this.outputFormatter.DoNewLine = doNewLine;
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(17);
				if (useNewLine)
				{
					this.outputFormatter.NewLine();
					return;
				}
			}
			else
			{
				this.OutputBlock(blockStatement, braceStyle, useNewLine);
			}
		}

		private void OutputEnumMembers(TypeDeclaration typeDeclaration, object data)
		{
			for (int i = 0; i < typeDeclaration.Children.Count; i++)
			{
				FieldDeclaration fieldDeclaration = typeDeclaration.Children[i] as FieldDeclaration;
				if (fieldDeclaration == null)
				{
					this.TrackVisit(typeDeclaration.Children[i], data);
				}
				else
				{
					this.BeginVisit(fieldDeclaration);
					VariableDeclaration variableDeclaration = fieldDeclaration.Fields[0];
					this.VisitAttributes(fieldDeclaration.Attributes, data);
					this.outputFormatter.Indent();
					this.outputFormatter.PrintIdentifier(variableDeclaration.Name);
					if (variableDeclaration.Initializer != null && !variableDeclaration.Initializer.IsNull)
					{
						if (this.prettyPrintOptions.AroundAssignmentParentheses)
						{
							this.outputFormatter.Space();
						}
						this.outputFormatter.PrintToken(3);
						if (this.prettyPrintOptions.AroundAssignmentParentheses)
						{
							this.outputFormatter.Space();
						}
						this.TrackVisit(variableDeclaration.Initializer, data);
					}
					if (i < typeDeclaration.Children.Count - 1)
					{
						this.outputFormatter.PrintToken(14);
					}
					this.outputFormatter.NewLine();
					this.EndVisit(fieldDeclaration);
				}
			}
		}

		private void OutputGetAndSetRegion(PropertyGetRegion getRegion, PropertySetRegion setRegion)
		{
			BraceStyle propertyBraceStyle = this.prettyPrintOptions.PropertyBraceStyle;
			if (getRegion.Block.IsNull && setRegion.Block.IsNull && getRegion.Attributes.Count == 0 && setRegion.Attributes.Count == 0 && (propertyBraceStyle == BraceStyle.EndOfLine || propertyBraceStyle == BraceStyle.EndOfLineWithoutSpace))
			{
				if (propertyBraceStyle == BraceStyle.EndOfLine)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(16);
				if (!getRegion.IsNull)
				{
					this.outputFormatter.Space();
					this.OutputModifier(getRegion.Modifier);
					this.outputFormatter.PrintText("get;");
				}
				if (!setRegion.IsNull)
				{
					this.outputFormatter.Space();
					this.OutputModifier(setRegion.Modifier);
					this.outputFormatter.PrintText("set;");
				}
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(17);
				this.outputFormatter.NewLine();
				return;
			}
			this.outputFormatter.BeginBrace(propertyBraceStyle, this.prettyPrintOptions.IndentPropertyBody);
			this.TrackVisit(getRegion, null);
			this.TrackVisit(setRegion, null);
			this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentPropertyBody);
		}

		private void OutputModifier(Modifiers modifier)
		{
			ArrayList arrayList = new ArrayList();
			if ((modifier & Modifiers.Unsafe) != Modifiers.None)
			{
				arrayList.Add(119);
			}
			if ((modifier & Modifiers.Public) != Modifiers.None)
			{
				arrayList.Add(98);
			}
			if ((modifier & Modifiers.Private) != Modifiers.None)
			{
				arrayList.Add(96);
			}
			if ((modifier & Modifiers.Protected) != Modifiers.None)
			{
				arrayList.Add(97);
			}
			if ((modifier & Modifiers.Static) != Modifiers.None)
			{
				arrayList.Add(107);
			}
			if ((modifier & Modifiers.Internal) != Modifiers.None)
			{
				arrayList.Add(84);
			}
			if ((modifier & Modifiers.Override) != Modifiers.None)
			{
				arrayList.Add(94);
			}
			if ((modifier & Modifiers.Dim) != Modifiers.None)
			{
				arrayList.Add(49);
			}
			if ((modifier & Modifiers.Virtual) != Modifiers.None)
			{
				arrayList.Add(122);
			}
			if ((modifier & Modifiers.New) != Modifiers.None)
			{
				arrayList.Add(89);
			}
			if ((modifier & Modifiers.Sealed) != Modifiers.None)
			{
				arrayList.Add(103);
			}
			if ((modifier & Modifiers.Extern) != Modifiers.None)
			{
				arrayList.Add(71);
			}
			if ((modifier & Modifiers.Const) != Modifiers.None)
			{
				arrayList.Add(60);
			}
			if ((modifier & Modifiers.ReadOnly) != Modifiers.None)
			{
				arrayList.Add(99);
			}
			if ((modifier & Modifiers.Volatile) != Modifiers.None)
			{
				arrayList.Add(124);
			}
			if ((modifier & Modifiers.Fixed) != Modifiers.None)
			{
				arrayList.Add(74);
			}
			this.outputFormatter.PrintTokenList(arrayList);
			if ((modifier & Modifiers.Partial) != Modifiers.None)
			{
				this.outputFormatter.PrintText("partial ");
			}
		}

		private void OutputModifier(ParameterModifiers modifier, INode node)
		{
			if ((modifier & ParameterModifiers.Ref) == ParameterModifiers.Ref)
			{
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
			}
			else if ((modifier & ParameterModifiers.Out) == ParameterModifiers.Out)
			{
				this.outputFormatter.PrintToken(93);
				this.outputFormatter.Space();
			}
			if ((modifier & ParameterModifiers.Params) == ParameterModifiers.Params)
			{
				this.outputFormatter.PrintToken(95);
				this.outputFormatter.Space();
			}
			if ((modifier & ParameterModifiers.Optional) == ParameterModifiers.Optional)
			{
				this.Error(node, string.Format("Optional parameters aren't supported in C#", new object[0]));
			}
		}

		private void PrintArrayRank(int[] rankSpecifier, int startRankIndex)
		{
			for (int i = startRankIndex; i < rankSpecifier.Length; i++)
			{
				this.outputFormatter.PrintToken(18);
				bool flag = this.prettyPrintOptions.SpacesWithinBrackets && rankSpecifier[i] > 0;
				if (flag)
				{
					this.outputFormatter.Space();
				}
				for (int j = 0; j < rankSpecifier[i]; j++)
				{
					this.outputFormatter.PrintToken(14);
				}
				if (flag)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(19);
			}
		}

		private void PrintClause(QueryExpressionClause clause)
		{
			if (!clause.IsNull)
			{
				this.outputFormatter.NewLine();
				this.outputFormatter.Indent();
				clause.AcceptVisitor(this, null);
			}
		}

		private void PrintFormattedComma()
		{
			if (this.prettyPrintOptions.SpacesBeforeComma)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(14);
			if (this.prettyPrintOptions.SpacesAfterComma)
			{
				this.outputFormatter.Space();
			}
		}

		private void PrintFormattedCommaAndNewLine()
		{
			if (this.prettyPrintOptions.SpacesBeforeComma)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(14);
			this.outputFormatter.NewLine();
			this.outputFormatter.Indent();
		}

		private void PrintIfSection(List<Statement> statements)
		{
			if (statements.Count == 1 && statements[0] is BlockStatement)
			{
				this.OutputBlock((BlockStatement)statements[0], this.prettyPrintOptions.StatementBraceStyle, this.prettyPrintOptions.PlaceElseOnNewLine);
				return;
			}
			if (statements.Count != 1)
			{
				this.outputFormatter.PrintToken(16);
			}
			else
			{
				this.outputFormatter.NewLine();
				this.outputFormatter.IndentationLevel++;
				this.outputFormatter.Indent();
			}
			foreach (Statement current in statements)
			{
				this.TrackVisit(current, this.prettyPrintOptions.StatementBraceStyle);
			}
			if (statements.Count == 1)
			{
				this.outputFormatter.IndentationLevel--;
				return;
			}
			this.outputFormatter.PrintToken(17);
		}

		private void PrintLoopCheck(DoLoopStatement doLoopStatement)
		{
			this.outputFormatter.PrintToken(125);
			if (this.prettyPrintOptions.WhileParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinWhileParentheses)
			{
				this.outputFormatter.Space();
			}
			if (doLoopStatement.ConditionType == ConditionType.Until)
			{
				this.outputFormatter.PrintToken(24);
				this.outputFormatter.PrintToken(20);
			}
			if (doLoopStatement.Condition.IsNull)
			{
				this.outputFormatter.PrintToken(113);
			}
			else
			{
				this.TrackVisit(doLoopStatement.Condition, null);
			}
			if (doLoopStatement.ConditionType == ConditionType.Until)
			{
				this.outputFormatter.PrintToken(21);
			}
			if (this.prettyPrintOptions.WithinWhileParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
		}

		private void PrintMethodDeclaration(MethodDeclaration methodDeclaration)
		{
			this.PrintTemplates(methodDeclaration.Templates);
			if (this.prettyPrintOptions.BeforeMethodDeclarationParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			bool flag = this.prettyPrintOptions.WithinMethodDeclarationParentheses && methodDeclaration.Parameters.Any<ParameterDeclarationExpression>();
			if (flag)
			{
				this.outputFormatter.Space();
			}
			if (methodDeclaration.IsExtensionMethod)
			{
				this.outputFormatter.PrintToken(111);
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(methodDeclaration.Parameters);
			if (flag)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			foreach (TemplateDefinition current in methodDeclaration.Templates)
			{
				this.TrackVisit(current, null);
			}
			this.OutputBlock(methodDeclaration.Body, this.prettyPrintOptions.MethodBraceStyle);
		}

		private void PrintStatementInline(Statement statement, object data)
		{
			this.outputFormatter.DoIndent = false;
			this.outputFormatter.DoNewLine = false;
			this.outputFormatter.EmitSemicolon = false;
			this.TrackVisit(statement, data);
			this.outputFormatter.DoIndent = true;
			this.outputFormatter.DoNewLine = true;
			this.outputFormatter.EmitSemicolon = true;
		}

		private void PrintTemplates(List<TemplateDefinition> templates)
		{
			if (templates.Count == 0)
			{
				return;
			}
			this.outputFormatter.PrintToken(23);
			for (int i = 0; i < templates.Count; i++)
			{
				if (i > 0)
				{
					this.PrintFormattedComma();
				}
				this.outputFormatter.PrintIdentifier(templates[i].Name);
			}
			this.outputFormatter.PrintToken(22);
		}

		private void PrintTypeArgumentList(List<TypeReference> typeArguments)
		{
			if (typeArguments != null && typeArguments.Count > 0)
			{
				this.outputFormatter.PrintToken(23);
				this.AppendCommaSeparatedList<TypeReference>(typeArguments);
				this.outputFormatter.PrintToken(22);
			}
		}

		private void PrintTypeReferenceWithoutArray(TypeReference typeReference)
		{
			if (typeReference.IsGlobal)
			{
				this.outputFormatter.PrintText("global::");
			}
			bool flag = true;
			if (typeReference.IsKeyword)
			{
				if (typeReference.Type == "System.Nullable" && typeReference.GenericTypes != null && typeReference.GenericTypes.Count == 1)
				{
					this.TrackVisit(typeReference.GenericTypes[0], null);
					this.outputFormatter.PrintText("?");
					flag = false;
				}
				else
				{
					this.outputFormatter.PrintText(CSharpOutputVisitor.ConvertTypeString(typeReference.Type));
				}
			}
			else
			{
				this.outputFormatter.PrintIdentifier(typeReference.Type);
			}
			if (flag && typeReference.GenericTypes != null && typeReference.GenericTypes.Count > 0)
			{
				this.outputFormatter.PrintToken(23);
				this.AppendCommaSeparatedList<TypeReference>(typeReference.GenericTypes);
				this.outputFormatter.PrintToken(22);
			}
			for (int i = 0; i < typeReference.PointerNestingLevel; i++)
			{
				this.outputFormatter.PrintToken(6);
			}
		}

		public void Reset()
		{
			this.outputFormatter.Reset();
		}

		internal static string ToCSharpString(PrimitiveExpression primitiveExpression)
		{
			if (primitiveExpression.Value == null)
			{
				return "null";
			}
			object value = primitiveExpression.Value;
			if (value is bool)
			{
				if ((bool)value)
				{
					return "true";
				}
				return "false";
			}
			else
			{
				if (value is string)
				{
					return "\"" + CSharpOutputVisitor.ConvertString(value.ToString()) + "\"";
				}
				if (value is char)
				{
					return "'" + CSharpOutputVisitor.ConvertCharLiteral((char)value) + "'";
				}
				if (value is decimal)
				{
					return ((decimal)value).ToString(NumberFormatInfo.InvariantInfo) + "m";
				}
				if (value is float)
				{
					return ((float)value).ToString(NumberFormatInfo.InvariantInfo) + "f";
				}
				if (value is double)
				{
					string text = ((double)value).ToString(NumberFormatInfo.InvariantInfo);
					if (text.IndexOf('.') < 0 && text.IndexOf('E') < 0)
					{
						return text + ".0";
					}
					return text;
				}
				else
				{
					if (value is IFormattable)
					{
						StringBuilder stringBuilder = new StringBuilder();
						if (primitiveExpression.LiteralFormat == LiteralFormat.HexadecimalNumber)
						{
							stringBuilder.Append("0x");
							stringBuilder.Append(((IFormattable)value).ToString("x", NumberFormatInfo.InvariantInfo));
						}
						else
						{
							stringBuilder.Append(((IFormattable)value).ToString(null, NumberFormatInfo.InvariantInfo));
						}
						if (value is uint || value is ulong)
						{
							stringBuilder.Append("u");
						}
						if (value is long || value is ulong)
						{
							stringBuilder.Append("L");
						}
						return stringBuilder.ToString();
					}
					return value.ToString();
				}
			}
		}

		public override object TrackedVisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			this.TrackVisit(addHandlerStatement.EventExpression, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(38);
			this.outputFormatter.Space();
			this.TrackVisit(addHandlerStatement.HandlerExpression, data);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			return this.TrackVisit(addressOfExpression.Expression, data);
		}

		public override object TrackedVisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			this.outputFormatter.PrintToken(64);
			if (anonymousMethodExpression.Parameters.Count > 0 || anonymousMethodExpression.HasParameterList)
			{
				this.outputFormatter.PrintToken(20);
				bool flag = this.prettyPrintOptions.WithinMethodDeclarationParentheses && anonymousMethodExpression.Parameters.Any<ParameterDeclarationExpression>();
				if (flag)
				{
					this.outputFormatter.Space();
				}
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(anonymousMethodExpression.Parameters);
				if (flag)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
			}
			this.OutputBlockAllowInline(anonymousMethodExpression.Body, this.prettyPrintOptions.AnonymousMethodBraceStyle, false);
			return null;
		}

		public override object TrackedVisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			this.outputFormatter.PrintToken(89);
			if (arrayCreateExpression.IsImplicitlyTyped)
			{
				this.outputFormatter.PrintToken(18);
				this.outputFormatter.PrintToken(19);
			}
			else
			{
				this.outputFormatter.Space();
				this.PrintTypeReferenceWithoutArray(arrayCreateExpression.CreateType);
				if (arrayCreateExpression.Arguments.Count > 0)
				{
					this.outputFormatter.PrintToken(18);
					bool flag = this.prettyPrintOptions.SpacesWithinBrackets && arrayCreateExpression.Arguments.Count > 0;
					if (flag)
					{
						this.outputFormatter.Space();
					}
					for (int i = 0; i < arrayCreateExpression.Arguments.Count; i++)
					{
						if (i > 0)
						{
							this.PrintFormattedComma();
						}
						this.TrackVisit(arrayCreateExpression.Arguments[i], data);
					}
					if (flag)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(19);
					this.PrintArrayRank(arrayCreateExpression.CreateType.RankSpecifier, 1);
				}
				else
				{
					this.PrintArrayRank(arrayCreateExpression.CreateType.RankSpecifier, 0);
				}
			}
			if (!arrayCreateExpression.ArrayInitializer.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(arrayCreateExpression.ArrayInitializer, data);
			}
			return null;
		}

		public override object TrackedVisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			this.TrackVisit(assignmentExpression.Left, data);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			switch (assignmentExpression.Op)
			{
			case AssignmentOperatorType.Assign:
				this.outputFormatter.PrintToken(3);
				break;
			case AssignmentOperatorType.Add:
			case AssignmentOperatorType.ConcatString:
				this.outputFormatter.PrintToken(38);
				break;
			case AssignmentOperatorType.Subtract:
				this.outputFormatter.PrintToken(39);
				break;
			case AssignmentOperatorType.Multiply:
				this.outputFormatter.PrintToken(40);
				break;
			case AssignmentOperatorType.Divide:
			case AssignmentOperatorType.DivideInteger:
				this.outputFormatter.PrintToken(41);
				break;
			case AssignmentOperatorType.Modulus:
				this.outputFormatter.PrintToken(42);
				break;
			case AssignmentOperatorType.Power:
				this.outputFormatter.PrintToken(3);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.VisitBinaryOperatorExpression(new BinaryOperatorExpression(assignmentExpression.Left, BinaryOperatorType.Power, assignmentExpression.Right), data);
				return null;
			case AssignmentOperatorType.ShiftLeft:
				this.outputFormatter.PrintToken(46);
				break;
			case AssignmentOperatorType.ShiftRight:
				this.outputFormatter.PrintToken(22);
				this.outputFormatter.PrintToken(35);
				break;
			case AssignmentOperatorType.BitwiseAnd:
				this.outputFormatter.PrintToken(43);
				break;
			case AssignmentOperatorType.BitwiseOr:
				this.outputFormatter.PrintToken(44);
				break;
			case AssignmentOperatorType.ExclusiveOr:
				this.outputFormatter.PrintToken(45);
				break;
			default:
				this.Error(assignmentExpression, string.Format("Unknown assignment operator {0}", assignmentExpression.Op));
				return null;
			}
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(assignmentExpression.Right, data);
			return null;
		}

		public override object TrackedVisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			this.outputFormatter.PrintIdentifier(attribute.Name);
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<Expression>(attribute.PositionalArguments);
			if (attribute.NamedArguments != null && attribute.NamedArguments.Count > 0)
			{
				if (attribute.PositionalArguments.Count > 0)
				{
					this.PrintFormattedComma();
				}
				for (int i = 0; i < attribute.NamedArguments.Count; i++)
				{
					this.TrackVisit(attribute.NamedArguments[i], data);
					if (i + 1 < attribute.NamedArguments.Count)
					{
						this.PrintFormattedComma();
					}
				}
			}
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitAttributeSection(AttributeSection attributeSection, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(18);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			if (!string.IsNullOrEmpty(attributeSection.AttributeTarget))
			{
				this.outputFormatter.PrintText(attributeSection.AttributeTarget);
				this.outputFormatter.PrintToken(9);
				this.outputFormatter.Space();
			}
			for (int i = 0; i < attributeSection.Attributes.Count; i++)
			{
				this.TrackVisit(attributeSection.Attributes[i], data);
				if (i + 1 < attributeSection.Attributes.Count)
				{
					this.PrintFormattedComma();
				}
			}
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(19);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			this.outputFormatter.PrintToken(51);
			return null;
		}

		public override object TrackedVisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			BinaryOperatorType op = binaryOperatorExpression.Op;
			if (op != BinaryOperatorType.Power)
			{
				switch (op)
				{
				case BinaryOperatorType.ReferenceEquality:
				case BinaryOperatorType.ReferenceInequality:
					if (!CSharpOutputVisitor.IsNullLiteralExpression(binaryOperatorExpression.Left) && !CSharpOutputVisitor.IsNullLiteralExpression(binaryOperatorExpression.Right))
					{
						if (binaryOperatorExpression.Op == BinaryOperatorType.ReferenceInequality)
						{
							this.outputFormatter.PrintToken(24);
						}
						this.outputFormatter.PrintText("object.ReferenceEquals");
						if (this.prettyPrintOptions.BeforeMethodCallParentheses)
						{
							this.outputFormatter.Space();
						}
						this.outputFormatter.PrintToken(20);
						this.TrackVisit(binaryOperatorExpression.Left, data);
						this.PrintFormattedComma();
						this.TrackVisit(binaryOperatorExpression.Right, data);
						this.outputFormatter.PrintToken(21);
						return null;
					}
					break;
				case BinaryOperatorType.DictionaryAccess:
					this.TrackVisit(binaryOperatorExpression.Left, data);
					this.outputFormatter.PrintToken(18);
					this.TrackVisit(binaryOperatorExpression.Right, data);
					this.outputFormatter.PrintToken(19);
					return null;
				}
				this.TrackVisit(binaryOperatorExpression.Left, data);
				switch (binaryOperatorExpression.Op)
				{
				case BinaryOperatorType.BitwiseAnd:
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(28);
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.BitwiseOr:
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(29);
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.LogicalAnd:
					if (this.prettyPrintOptions.AroundLogicalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(25);
					if (this.prettyPrintOptions.AroundLogicalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.LogicalOr:
					if (this.prettyPrintOptions.AroundLogicalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(26);
					if (this.prettyPrintOptions.AroundLogicalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.ExclusiveOr:
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(30);
					if (this.prettyPrintOptions.AroundBitwiseOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.GreaterThan:
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(22);
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.GreaterThanOrEqual:
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(35);
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Equality:
				case BinaryOperatorType.ReferenceEquality:
					if (this.prettyPrintOptions.AroundEqualityOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(33);
					if (this.prettyPrintOptions.AroundEqualityOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.InEquality:
				case BinaryOperatorType.ReferenceInequality:
					if (this.prettyPrintOptions.AroundEqualityOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(34);
					if (this.prettyPrintOptions.AroundEqualityOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.LessThan:
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(23);
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.LessThanOrEqual:
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(36);
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Add:
				case BinaryOperatorType.Concat:
					if (this.prettyPrintOptions.AroundAdditiveOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(4);
					if (this.prettyPrintOptions.AroundAdditiveOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Subtract:
					if (this.prettyPrintOptions.AroundAdditiveOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(5);
					if (this.prettyPrintOptions.AroundAdditiveOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Multiply:
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(6);
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Divide:
				case BinaryOperatorType.DivideInteger:
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(7);
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.Modulus:
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(8);
					if (this.prettyPrintOptions.AroundMultiplicativeOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.ShiftLeft:
					if (this.prettyPrintOptions.AroundShiftOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(37);
					if (this.prettyPrintOptions.AroundShiftOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.ShiftRight:
					if (this.prettyPrintOptions.AroundShiftOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(22);
					this.outputFormatter.PrintToken(22);
					if (this.prettyPrintOptions.AroundShiftOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				case BinaryOperatorType.NullCoalescing:
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
					}
					this.outputFormatter.PrintToken(13);
					if (this.prettyPrintOptions.AroundRelationalOperatorParentheses)
					{
						this.outputFormatter.Space();
						goto IL_75B;
					}
					goto IL_75B;
				}
				this.Error(binaryOperatorExpression, string.Format("Unknown binary operator {0}", binaryOperatorExpression.Op));
				return null;
				IL_75B:
				this.TrackVisit(binaryOperatorExpression.Right, data);
				return null;
			}
			this.outputFormatter.PrintText("Math.Pow");
			if (this.prettyPrintOptions.BeforeMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(binaryOperatorExpression.Left, data);
			this.PrintFormattedComma();
			this.TrackVisit(binaryOperatorExpression.Right, data);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitBlockStatement(BlockStatement blockStatement, object data)
		{
			if (this.outputFormatter.TextLength == 0)
			{
				using (List<INode>.Enumerator enumerator = blockStatement.Children.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Statement node = (Statement)enumerator.Current;
						this.outputFormatter.Indent();
						this.TrackVisit(node, null);
						if (!this.outputFormatter.LastCharacterIsNewLine)
						{
							this.outputFormatter.NewLine();
						}
					}
				}
				return null;
			}
			if (data is BraceStyle)
			{
				this.OutputBlock(blockStatement, (BraceStyle)data);
			}
			else
			{
				this.OutputBlock(blockStatement, BraceStyle.NextLine);
			}
			return null;
		}

		public override object TrackedVisitBreakStatement(BreakStatement breakStatement, object data)
		{
			this.outputFormatter.PrintToken(53);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitCaseLabel(CaseLabel caseLabel, object data)
		{
			this.outputFormatter.Indent();
			if (caseLabel.IsDefault)
			{
				this.outputFormatter.PrintToken(63);
			}
			else
			{
				this.outputFormatter.PrintToken(55);
				this.outputFormatter.Space();
				if (caseLabel.BinaryOperatorType != BinaryOperatorType.None)
				{
					this.Error(caseLabel, string.Format("Case labels with binary operators are unsupported : {0}", caseLabel.BinaryOperatorType));
				}
				this.TrackVisit(caseLabel.Label, data);
			}
			this.outputFormatter.PrintToken(9);
			if (!caseLabel.ToExpression.IsNull)
			{
				PrimitiveExpression primitiveExpression = caseLabel.Label as PrimitiveExpression;
				PrimitiveExpression primitiveExpression2 = caseLabel.ToExpression as PrimitiveExpression;
				if (primitiveExpression != null && primitiveExpression2 != null && primitiveExpression.Value is int && primitiveExpression2.Value is int)
				{
					int num = (int)primitiveExpression.Value;
					int num2 = (int)primitiveExpression2.Value;
					if (num < num2 && num + 12 > num2)
					{
						for (int i = num + 1; i <= num2; i++)
						{
							this.outputFormatter.NewLine();
							this.outputFormatter.Indent();
							this.outputFormatter.PrintToken(55);
							this.outputFormatter.Space();
							this.outputFormatter.PrintText(i.ToString(NumberFormatInfo.InvariantInfo));
							this.outputFormatter.PrintToken(9);
						}
					}
					else
					{
						this.outputFormatter.PrintText(" // TODO: to ");
						this.TrackVisit(caseLabel.ToExpression, data);
					}
				}
				else
				{
					this.outputFormatter.PrintText(" // TODO: to ");
					this.TrackVisit(caseLabel.ToExpression, data);
				}
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitCastExpression(CastExpression castExpression, object data)
		{
			if (castExpression.CastType == CastType.TryCast)
			{
				this.TrackVisit(castExpression.Expression, data);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.TrackVisit(castExpression.CastTo, data);
			}
			else
			{
				this.outputFormatter.PrintToken(20);
				if (this.prettyPrintOptions.WithinCastParentheses)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(castExpression.CastTo, data);
				if (this.prettyPrintOptions.WithinCastParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
				if (this.prettyPrintOptions.SpacesAfterTypecast)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(castExpression.Expression, data);
			}
			return null;
		}

		public override object TrackedVisitCatchClause(CatchClause catchClause, object data)
		{
			if (this.prettyPrintOptions.PlaceCatchOnNewLine)
			{
				this.outputFormatter.Indent();
			}
			else
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(56);
			if (!catchClause.TypeReference.IsNull)
			{
				if (this.prettyPrintOptions.CatchParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(20);
				if (this.prettyPrintOptions.WithinCatchParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintIdentifier(catchClause.TypeReference.Type);
				if (catchClause.VariableName.Length > 0)
				{
					this.outputFormatter.Space();
					this.outputFormatter.PrintIdentifier(catchClause.VariableName);
				}
				if (this.prettyPrintOptions.WithinCatchParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
			}
			this.WriteEmbeddedStatement(catchClause.StatementBlock, ((bool)data) ? this.prettyPrintOptions.PlaceFinallyOnNewLine : this.prettyPrintOptions.PlaceCatchOnNewLine);
			return null;
		}

		public override object TrackedVisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			this.outputFormatter.PrintToken(58);
			if (this.prettyPrintOptions.CheckedParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(checkedExpression.Expression, data);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			this.outputFormatter.PrintToken(58);
			this.WriteEmbeddedStatement(checkedStatement.Block);
			return null;
		}

		public override object TrackedVisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			this.NotSupported(classReferenceExpression);
			return null;
		}

		public override object TrackedVisitCollectionInitializerExpression(CollectionInitializerExpression arrayInitializerExpression, object data)
		{
			this.outputFormatter.PrintToken(16);
			if (arrayInitializerExpression.CreateExpressions.Count == 1)
			{
				this.outputFormatter.Space();
			}
			else
			{
				this.outputFormatter.IndentationLevel++;
				this.outputFormatter.NewLine();
				this.outputFormatter.Indent();
			}
			this.AppendCommaSeparatedList<Expression>(arrayInitializerExpression.CreateExpressions, true);
			if (arrayInitializerExpression.CreateExpressions.Count == 1)
			{
				this.outputFormatter.Space();
			}
			else
			{
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.NewLine();
				this.outputFormatter.Indent();
			}
			this.outputFormatter.PrintToken(17);
			return null;
		}

		public override object TrackedVisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			compilationUnit.AcceptChildren(this, data);
			this.outputFormatter.EndFile();
			return null;
		}

		public override object TrackedVisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			if (conditionalExpression.Condition is ConditionalExpression)
			{
				this.TrackedVisitParenthesizedExpression(new ParenthesizedExpression(conditionalExpression.Condition), data);
			}
			else
			{
				this.TrackVisit(conditionalExpression.Condition, data);
			}
			if (this.prettyPrintOptions.ConditionalOperatorBeforeConditionSpace)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(12);
			if (this.prettyPrintOptions.ConditionalOperatorAfterConditionSpace)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(conditionalExpression.TrueExpression, data);
			if (this.prettyPrintOptions.ConditionalOperatorBeforeSeparatorSpace)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(9);
			if (this.prettyPrintOptions.ConditionalOperatorAfterSeparatorSpace)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(conditionalExpression.FalseExpression, data);
			return null;
		}

		public override object TrackedVisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			this.VisitAttributes(constructorDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(constructorDeclaration.Modifier);
			if (this.currentType != null)
			{
				this.outputFormatter.PrintIdentifier(this.currentType.Name);
			}
			else
			{
				this.outputFormatter.PrintIdentifier(constructorDeclaration.Name);
			}
			if (this.prettyPrintOptions.BeforeConstructorDeclarationParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			bool flag = this.prettyPrintOptions.WithinMethodDeclarationParentheses && constructorDeclaration.Parameters.Any<ParameterDeclarationExpression>();
			if (flag)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(constructorDeclaration.Parameters);
			if (flag)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.TrackVisit(constructorDeclaration.ConstructorInitializer, data);
			this.OutputBlock(constructorDeclaration.Body, this.prettyPrintOptions.ConstructorBraceStyle);
			return null;
		}

		public override object TrackedVisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			if (constructorInitializer.IsNull)
			{
				return null;
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(9);
			this.outputFormatter.Space();
			if (constructorInitializer.ConstructorInitializerType == ConstructorInitializerType.Base)
			{
				this.outputFormatter.PrintToken(51);
			}
			else
			{
				this.outputFormatter.PrintToken(111);
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<Expression>(constructorInitializer.Arguments);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			this.outputFormatter.PrintToken(61);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			this.NotSupported(declareDeclaration);
			return null;
		}

		public override object TrackedVisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			this.outputFormatter.PrintToken(63);
			if (this.prettyPrintOptions.TypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinTypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(defaultValueExpression.TypeReference, data);
			if (this.prettyPrintOptions.WithinTypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			this.VisitAttributes(delegateDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(delegateDeclaration.Modifier);
			this.outputFormatter.PrintToken(64);
			this.outputFormatter.Space();
			this.TrackVisit(delegateDeclaration.ReturnType, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(delegateDeclaration.Name);
			this.PrintTemplates(delegateDeclaration.Templates);
			if (this.prettyPrintOptions.BeforeDelegateDeclarationParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			bool flag = this.prettyPrintOptions.WithinMethodDeclarationParentheses && delegateDeclaration.Parameters.Any<ParameterDeclarationExpression>();
			if (flag)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(delegateDeclaration.Parameters);
			if (flag)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			foreach (TemplateDefinition current in delegateDeclaration.Templates)
			{
				this.TrackVisit(current, data);
			}
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			this.VisitAttributes(destructorDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(destructorDeclaration.Modifier);
			this.outputFormatter.PrintToken(27);
			if (this.currentType != null)
			{
				this.outputFormatter.PrintIdentifier(this.currentType.Name);
			}
			else
			{
				this.outputFormatter.PrintIdentifier(destructorDeclaration.Name);
			}
			if (this.prettyPrintOptions.BeforeConstructorDeclarationParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			this.outputFormatter.PrintToken(21);
			this.OutputBlock(destructorDeclaration.Body, this.prettyPrintOptions.DestructorBraceStyle);
			return null;
		}

		public override object TrackedVisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			switch (directionExpression.FieldDirection)
			{
			case FieldDirection.Out:
				this.outputFormatter.PrintToken(93);
				this.outputFormatter.Space();
				break;
			case FieldDirection.Ref:
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
				break;
			}
			this.TrackVisit(directionExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			if (doLoopStatement.ConditionPosition == ConditionPosition.None)
			{
				this.Error(doLoopStatement, string.Format("Unknown condition position for loop : {0}.", doLoopStatement));
			}
			if (doLoopStatement.ConditionPosition == ConditionPosition.Start)
			{
				this.PrintLoopCheck(doLoopStatement);
			}
			else
			{
				this.outputFormatter.PrintToken(65);
			}
			this.WriteEmbeddedStatement(doLoopStatement.EmbeddedStatement, this.prettyPrintOptions.WhileBraceForcement, this.prettyPrintOptions.StatementBraceStyle, this.prettyPrintOptions.PlaceWhileOnNewLine);
			if (doLoopStatement.ConditionPosition == ConditionPosition.End)
			{
				if (this.prettyPrintOptions.PlaceWhileOnNewLine)
				{
					this.outputFormatter.Indent();
				}
				else
				{
					this.outputFormatter.Space();
				}
				this.PrintLoopCheck(doLoopStatement);
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.NewLine();
			}
			return null;
		}

		public override object TrackedVisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			if (this.prettyPrintOptions.PlaceElseOnNewLine)
			{
				this.outputFormatter.Indent();
			}
			else
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(67);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(79);
			if (this.prettyPrintOptions.IfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinIfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(elseIfSection.Condition, data);
			if (this.prettyPrintOptions.WithinIfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(elseIfSection.EmbeddedStatement, this.prettyPrintOptions.IfElseBraceForcement, this.prettyPrintOptions.StatementBraceStyle, false);
			return null;
		}

		public override object TrackedVisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitEndStatement(EndStatement endStatement, object data)
		{
			this.outputFormatter.PrintText("System.Environment.Exit(0)");
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			for (int i = 0; i < eraseStatement.Expressions.Count; i++)
			{
				if (i > 0)
				{
					this.outputFormatter.NewLine();
					this.outputFormatter.Indent();
				}
				this.TrackVisit(eraseStatement.Expressions[i], data);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(3);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(90);
				this.outputFormatter.PrintToken(11);
			}
			return null;
		}

		public override object TrackedVisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			this.NotSupported(errorStatement);
			return null;
		}

		public override object TrackedVisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			this.VisitAttributes(eventAddRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("add");
			if (this.prettyPrintOptions.AllowEventAddBlockInline)
			{
				this.OutputBlockAllowInline(eventAddRegion.Block, this.prettyPrintOptions.EventAddBraceStyle);
			}
			else
			{
				this.OutputBlock(eventAddRegion.Block, this.prettyPrintOptions.EventAddBraceStyle);
			}
			return null;
		}

		public override object TrackedVisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			this.VisitAttributes(eventDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(eventDeclaration.Modifier);
			this.outputFormatter.PrintToken(69);
			this.outputFormatter.Space();
			this.TrackVisit(eventDeclaration.TypeReference, data);
			this.outputFormatter.Space();
			if (eventDeclaration.InterfaceImplementations.Count > 0)
			{
				this.TrackVisit(eventDeclaration.InterfaceImplementations[0].InterfaceType, data);
				this.outputFormatter.PrintToken(15);
			}
			this.outputFormatter.PrintIdentifier(eventDeclaration.Name);
			if (!eventDeclaration.Initializer.IsNull)
			{
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(3);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(eventDeclaration.Initializer, data);
			}
			if (eventDeclaration.AddRegion.IsNull && eventDeclaration.RemoveRegion.IsNull)
			{
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.NewLine();
			}
			else
			{
				this.outputFormatter.BeginBrace(this.prettyPrintOptions.EventBraceStyle, this.prettyPrintOptions.IndentEventBody);
				this.TrackVisit(eventDeclaration.AddRegion, data);
				this.TrackVisit(eventDeclaration.RemoveRegion, data);
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentEventBody);
			}
			return null;
		}

		public override object TrackedVisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			this.NotSupported(eventRaiseRegion);
			return null;
		}

		public override object TrackedVisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			this.VisitAttributes(eventRemoveRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("remove");
			if (this.prettyPrintOptions.AllowEventRemoveBlockInline)
			{
				this.OutputBlockAllowInline(eventRemoveRegion.Block, this.prettyPrintOptions.EventRemoveBraceStyle);
			}
			else
			{
				this.OutputBlock(eventRemoveRegion.Block, this.prettyPrintOptions.EventRemoveBraceStyle);
			}
			return null;
		}

		public override object TrackedVisitExitStatement(ExitStatement exitStatement, object data)
		{
			if (exitStatement.ExitType == ExitType.Function || exitStatement.ExitType == ExitType.Sub || exitStatement.ExitType == ExitType.Property)
			{
				this.outputFormatter.PrintToken(101);
				this.outputFormatter.PrintToken(11);
			}
			else
			{
				this.outputFormatter.PrintToken(53);
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.PrintText(" // TODO: might not be correct. Was : Exit " + exitStatement.ExitType);
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			this.TrackVisit(expressionStatement.Expression, data);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("extern alias ");
			this.outputFormatter.PrintIdentifier(externAliasDirective.Name);
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			if (!fieldDeclaration.TypeReference.IsNull)
			{
				this.VisitAttributes(fieldDeclaration.Attributes, data);
				this.outputFormatter.Indent();
				this.OutputModifier(fieldDeclaration.Modifier);
				this.TrackVisit(fieldDeclaration.TypeReference, data);
				this.outputFormatter.Space();
				this.AppendCommaSeparatedList<VariableDeclaration>(fieldDeclaration.Fields);
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.NewLine();
			}
			else
			{
				for (int i = 0; i < fieldDeclaration.Fields.Count; i++)
				{
					this.VisitAttributes(fieldDeclaration.Attributes, data);
					this.outputFormatter.Indent();
					this.OutputModifier(fieldDeclaration.Modifier);
					this.TrackVisit(fieldDeclaration.GetTypeForField(i), data);
					this.outputFormatter.Space();
					this.TrackVisit(fieldDeclaration.Fields[i], data);
					this.outputFormatter.PrintToken(11);
					this.outputFormatter.NewLine();
				}
			}
			return null;
		}

		public override object TrackedVisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			this.outputFormatter.PrintToken(74);
			if (this.prettyPrintOptions.FixedParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.PrintStatementInline(fixedStatement.PointerDeclaration, data);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(fixedStatement.EmbeddedStatement, this.prettyPrintOptions.FixedBraceForcement, this.prettyPrintOptions.StatementBraceStyle, true);
			return null;
		}

		public override object TrackedVisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.outputFormatter.PrintToken(77);
			if (this.prettyPrintOptions.ForeachParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinForEachParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(foreachStatement.TypeReference, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(foreachStatement.VariableName);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(81);
			this.outputFormatter.Space();
			this.TrackVisit(foreachStatement.Expression, data);
			if (this.prettyPrintOptions.WithinForEachParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(foreachStatement.EmbeddedStatement, this.prettyPrintOptions.ForEachBraceForcement, this.prettyPrintOptions.StatementBraceStyle, true);
			return null;
		}

		public override object TrackedVisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			this.outputFormatter.PrintToken(76);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinForParentheses)
			{
				this.outputFormatter.Space();
			}
			if (forNextStatement.LoopVariableExpression.IsNull)
			{
				if (!forNextStatement.TypeReference.IsNull)
				{
					this.TrackVisit(forNextStatement.TypeReference, data);
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintIdentifier(forNextStatement.VariableName);
			}
			else
			{
				this.TrackVisit(forNextStatement.LoopVariableExpression, data);
			}
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(3);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(forNextStatement.Start, data);
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.Space();
			if (forNextStatement.LoopVariableExpression.IsNull)
			{
				this.outputFormatter.PrintIdentifier(forNextStatement.VariableName);
			}
			else
			{
				this.TrackVisit(forNextStatement.LoopVariableExpression, data);
			}
			this.outputFormatter.Space();
			PrimitiveExpression primitiveExpression = forNextStatement.Step as PrimitiveExpression;
			if ((primitiveExpression == null || !(primitiveExpression.Value is int) || (int)primitiveExpression.Value >= 0) && !(forNextStatement.Step is UnaryOperatorExpression))
			{
				this.outputFormatter.PrintToken(36);
			}
			else
			{
				this.outputFormatter.PrintToken(35);
			}
			this.outputFormatter.Space();
			this.TrackVisit(forNextStatement.End, data);
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.Space();
			if (forNextStatement.LoopVariableExpression.IsNull)
			{
				this.outputFormatter.PrintIdentifier(forNextStatement.VariableName);
			}
			else
			{
				this.TrackVisit(forNextStatement.LoopVariableExpression, data);
			}
			if (forNextStatement.Step.IsNull)
			{
				this.outputFormatter.PrintToken(31);
			}
			else
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(38);
				this.outputFormatter.Space();
				this.TrackVisit(forNextStatement.Step, data);
			}
			if (this.prettyPrintOptions.WithinForParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(forNextStatement.EmbeddedStatement, this.prettyPrintOptions.ForBraceForcement, this.prettyPrintOptions.StatementBraceStyle, true);
			return null;
		}

		public override object TrackedVisitForStatement(ForStatement forStatement, object data)
		{
			this.outputFormatter.PrintToken(76);
			if (this.prettyPrintOptions.ForParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinForParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.DoIndent = false;
			this.outputFormatter.DoNewLine = false;
			this.outputFormatter.EmitSemicolon = false;
			for (int i = 0; i < forStatement.Initializers.Count; i++)
			{
				INode node = forStatement.Initializers[i];
				this.TrackVisit(node, data);
				if (i + 1 < forStatement.Initializers.Count)
				{
					this.outputFormatter.PrintToken(14);
				}
			}
			this.outputFormatter.EmitSemicolon = true;
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.EmitSemicolon = false;
			if (!forStatement.Condition.IsNull)
			{
				if (this.prettyPrintOptions.SpacesAfterSemicolon)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(forStatement.Condition, data);
			}
			this.outputFormatter.EmitSemicolon = true;
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.EmitSemicolon = false;
			if (forStatement.Iterator != null && forStatement.Iterator.Count > 0)
			{
				if (this.prettyPrintOptions.SpacesAfterSemicolon)
				{
					this.outputFormatter.Space();
				}
				for (int j = 0; j < forStatement.Iterator.Count; j++)
				{
					INode node2 = forStatement.Iterator[j];
					this.TrackVisit(node2, data);
					if (j + 1 < forStatement.Iterator.Count)
					{
						this.outputFormatter.PrintToken(14);
					}
				}
			}
			if (this.prettyPrintOptions.WithinForParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.outputFormatter.EmitSemicolon = true;
			this.outputFormatter.DoNewLine = true;
			this.outputFormatter.DoIndent = true;
			this.WriteEmbeddedStatement(forStatement.EmbeddedStatement, this.prettyPrintOptions.ForBraceForcement, this.prettyPrintOptions.StatementBraceStyle, true);
			return null;
		}

		public override object TrackedVisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			this.outputFormatter.PrintToken(78);
			this.outputFormatter.Space();
			if (gotoCaseStatement.IsDefaultCase)
			{
				this.outputFormatter.PrintToken(63);
			}
			else
			{
				this.outputFormatter.PrintToken(55);
				this.outputFormatter.Space();
				this.TrackVisit(gotoCaseStatement.Expression, data);
			}
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			this.outputFormatter.PrintToken(78);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(gotoStatement.Label);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			this.outputFormatter.PrintIdentifier(identifierExpression.Identifier);
			this.PrintTypeArgumentList(identifierExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			this.outputFormatter.PrintToken(79);
			if (this.prettyPrintOptions.IfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinIfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(ifElseStatement.Condition, data);
			if (this.prettyPrintOptions.WithinIfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.PrintIfSection(ifElseStatement.TrueStatement);
			bool flag = false;
			if (ifElseStatement.TrueStatement != null && ifElseStatement.TrueStatement.Count > 0)
			{
				flag = (ifElseStatement.TrueStatement.Last<Statement>() is BlockStatement);
			}
			foreach (ElseIfSection current in ifElseStatement.ElseIfSections)
			{
				this.TrackVisit(current, data);
				flag = (current.EmbeddedStatement is BlockStatement);
			}
			if (ifElseStatement.HasElseStatements)
			{
				if (this.prettyPrintOptions.PlaceElseOnNewLine || (this.prettyPrintOptions.PlaceNonBlockElseOnNewLine && !flag))
				{
					this.outputFormatter.NewLine();
					this.outputFormatter.Indent();
				}
				else
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(67);
				this.PrintIfSection(ifElseStatement.FalseStatement);
			}
			return null;
		}

		public override object TrackedVisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			this.VisitAttributes(indexerDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(indexerDeclaration.Modifier);
			this.TrackVisit(indexerDeclaration.TypeReference, data);
			this.outputFormatter.Space();
			if (indexerDeclaration.InterfaceImplementations.Count > 0)
			{
				this.TrackVisit(indexerDeclaration.InterfaceImplementations[0].InterfaceType, data);
				this.outputFormatter.PrintToken(15);
			}
			this.outputFormatter.PrintToken(111);
			this.outputFormatter.PrintToken(18);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(indexerDeclaration.Parameters);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(19);
			this.outputFormatter.BeginBrace(this.prettyPrintOptions.PropertyBraceStyle, this.prettyPrintOptions.IndentPropertyBody);
			this.TrackVisit(indexerDeclaration.GetRegion, data);
			this.TrackVisit(indexerDeclaration.SetRegion, data);
			this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentPropertyBody);
			return null;
		}

		public override object TrackedVisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			this.TrackVisit(indexerExpression.TargetObject, data);
			this.outputFormatter.PrintToken(18);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<Expression>(indexerExpression.Indexes);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(19);
			return null;
		}

		public override object TrackedVisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			this.TrackVisit(innerClassTypeReference.BaseType, data);
			this.outputFormatter.PrintToken(15);
			return this.VisitTypeReference(innerClassTypeReference, data);
		}

		public override object TrackedVisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			throw new InvalidOperationException();
		}

		public override object TrackedVisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			this.TrackVisit(invocationExpression.TargetObject, data);
			if (this.prettyPrintOptions.BeforeMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<Expression>(invocationExpression.Arguments);
			if (this.prettyPrintOptions.WithinMethodCallParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitLabelStatement(LabelStatement labelStatement, object data)
		{
			this.outputFormatter.PrintIdentifier(labelStatement.Label);
			this.outputFormatter.PrintToken(9);
			return null;
		}

		public override object TrackedVisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			if (lambdaExpression.Parameters.Count == 1 && lambdaExpression.Parameters[0].TypeReference.IsNull)
			{
				this.outputFormatter.PrintIdentifier(lambdaExpression.Parameters[0].ParameterName);
			}
			else
			{
				this.outputFormatter.PrintToken(20);
				if (this.prettyPrintOptions.WithinParentheses)
				{
					this.outputFormatter.Space();
				}
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(lambdaExpression.Parameters);
				if (this.prettyPrintOptions.WithinParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(48);
			if (!lambdaExpression.ExpressionBody.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(lambdaExpression.ExpressionBody, null);
			}
			if (!lambdaExpression.StatementBody.IsNull)
			{
				this.OutputBlockAllowInline(lambdaExpression.StatementBody, this.prettyPrintOptions.MethodBraceStyle, false);
			}
			return null;
		}

		public override object TrackedVisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			TypeReference typeForVariable = localVariableDeclaration.GetTypeForVariable(0);
			for (int i = 1; i < localVariableDeclaration.Variables.Count; i++)
			{
				if (localVariableDeclaration.GetTypeForVariable(i) != typeForVariable)
				{
					return this.TrackedVisitLocalVariableDeclarationSeparateTypes(localVariableDeclaration, data);
				}
			}
			this.OutputModifier(localVariableDeclaration.Modifier);
			this.TrackVisit(typeForVariable ?? new TypeReference("System.Object", true), data);
			this.outputFormatter.Space();
			this.AppendCommaSeparatedList<VariableDeclaration>(localVariableDeclaration.Variables);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		private object TrackedVisitLocalVariableDeclarationSeparateTypes(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			for (int i = 0; i < localVariableDeclaration.Variables.Count; i++)
			{
				VariableDeclaration node = localVariableDeclaration.Variables[i];
				if (i > 0)
				{
					this.outputFormatter.NewLine();
					this.outputFormatter.Indent();
				}
				this.OutputModifier(localVariableDeclaration.Modifier);
				this.TrackVisit(localVariableDeclaration.GetTypeForVariable(i) ?? new TypeReference("System.Object", true), data);
				this.outputFormatter.Space();
				this.TrackVisit(node, data);
				this.outputFormatter.PrintToken(11);
			}
			return null;
		}

		public override object TrackedVisitLockStatement(LockStatement lockStatement, object data)
		{
			this.outputFormatter.PrintToken(86);
			if (this.prettyPrintOptions.LockParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinLockParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(lockStatement.LockExpression, data);
			if (this.prettyPrintOptions.WithinLockParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(lockStatement.EmbeddedStatement);
			return null;
		}

		public override object TrackedVisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			Expression targetObject = memberReferenceExpression.TargetObject;
			if (targetObject is BinaryOperatorExpression || targetObject is CastExpression)
			{
				this.outputFormatter.PrintToken(20);
				if (this.prettyPrintOptions.WithinMethodCallParentheses)
				{
					this.outputFormatter.Space();
				}
			}
			this.TrackVisit(targetObject, data);
			if (targetObject is BinaryOperatorExpression || targetObject is CastExpression)
			{
				if (this.prettyPrintOptions.WithinMethodCallParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
			}
			this.outputFormatter.PrintToken(15);
			this.outputFormatter.PrintIdentifier(memberReferenceExpression.MemberName);
			this.PrintTypeArgumentList(memberReferenceExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.VisitAttributes(methodDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(methodDeclaration.Modifier);
			this.TrackVisit(methodDeclaration.TypeReference, data);
			this.outputFormatter.Space();
			if (methodDeclaration.InterfaceImplementations.Count > 0)
			{
				this.TrackVisit(methodDeclaration.InterfaceImplementations[0].InterfaceType, data);
				this.outputFormatter.PrintToken(15);
			}
			if (methodDeclaration.HandlesClause.Count > 0)
			{
				this.Error(methodDeclaration, "Handles clauses are not supported in C#");
			}
			this.outputFormatter.PrintIdentifier(methodDeclaration.Name);
			this.PrintMethodDeclaration(methodDeclaration);
			return null;
		}

		public override object TrackedVisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			this.outputFormatter.PrintIdentifier(namedArgumentExpression.Name);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(3);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(namedArgumentExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(88);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(namespaceDeclaration.Name);
			this.outputFormatter.BeginBrace(this.prettyPrintOptions.NamespaceBraceStyle, this.prettyPrintOptions.IndentNamespaceBody);
			namespaceDeclaration.AcceptChildren(this, data);
			this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentNamespaceBody);
			return null;
		}

		public override object TrackedVisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			this.outputFormatter.PrintToken(89);
			if (!objectCreateExpression.CreateType.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(objectCreateExpression.CreateType, data);
			}
			if (objectCreateExpression.Parameters.Count > 0 || objectCreateExpression.ObjectInitializer.IsNull)
			{
				if (this.prettyPrintOptions.NewParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(20);
				if (this.prettyPrintOptions.WithinMethodCallParentheses)
				{
					this.outputFormatter.Space();
				}
				this.AppendCommaSeparatedList<Expression>(objectCreateExpression.Parameters);
				if (this.prettyPrintOptions.WithinMethodCallParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(21);
			}
			if (!objectCreateExpression.ObjectInitializer.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(objectCreateExpression.ObjectInitializer, data);
			}
			return null;
		}

		public override object TrackedVisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			this.NotSupported(onErrorStatement);
			return null;
		}

		public override object TrackedVisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			this.VisitAttributes(operatorDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(operatorDeclaration.Modifier);
			if (operatorDeclaration.IsConversionOperator)
			{
				if (operatorDeclaration.ConversionType == ConversionType.Implicit)
				{
					this.outputFormatter.PrintToken(80);
				}
				else
				{
					this.outputFormatter.PrintToken(70);
				}
			}
			else
			{
				this.TrackVisit(operatorDeclaration.TypeReference, data);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(92);
			this.outputFormatter.Space();
			if (operatorDeclaration.IsConversionOperator)
			{
				this.TrackVisit(operatorDeclaration.TypeReference, data);
			}
			else
			{
				switch (operatorDeclaration.OverloadableOperator)
				{
				case OverloadableOperatorType.Add:
				case OverloadableOperatorType.UnaryPlus:
					this.outputFormatter.PrintToken(4);
					goto IL_305;
				case OverloadableOperatorType.Subtract:
				case OverloadableOperatorType.UnaryMinus:
					this.outputFormatter.PrintToken(5);
					goto IL_305;
				case OverloadableOperatorType.Multiply:
					this.outputFormatter.PrintToken(6);
					goto IL_305;
				case OverloadableOperatorType.Divide:
				case OverloadableOperatorType.DivideInteger:
					this.outputFormatter.PrintToken(7);
					goto IL_305;
				case OverloadableOperatorType.Modulus:
					this.outputFormatter.PrintToken(8);
					goto IL_305;
				case OverloadableOperatorType.Concat:
					this.outputFormatter.PrintToken(4);
					goto IL_305;
				case OverloadableOperatorType.Not:
					this.outputFormatter.PrintToken(24);
					goto IL_305;
				case OverloadableOperatorType.BitNot:
					this.outputFormatter.PrintToken(27);
					goto IL_305;
				case OverloadableOperatorType.BitwiseAnd:
					this.outputFormatter.PrintToken(28);
					goto IL_305;
				case OverloadableOperatorType.BitwiseOr:
					this.outputFormatter.PrintToken(29);
					goto IL_305;
				case OverloadableOperatorType.ExclusiveOr:
					this.outputFormatter.PrintToken(30);
					goto IL_305;
				case OverloadableOperatorType.ShiftLeft:
					this.outputFormatter.PrintToken(37);
					goto IL_305;
				case OverloadableOperatorType.ShiftRight:
					this.outputFormatter.PrintToken(22);
					this.outputFormatter.PrintToken(22);
					goto IL_305;
				case OverloadableOperatorType.GreaterThan:
					this.outputFormatter.PrintToken(22);
					goto IL_305;
				case OverloadableOperatorType.GreaterThanOrEqual:
					this.outputFormatter.PrintToken(35);
					goto IL_305;
				case OverloadableOperatorType.Equality:
					this.outputFormatter.PrintToken(33);
					goto IL_305;
				case OverloadableOperatorType.InEquality:
					this.outputFormatter.PrintToken(34);
					goto IL_305;
				case OverloadableOperatorType.LessThan:
					this.outputFormatter.PrintToken(23);
					goto IL_305;
				case OverloadableOperatorType.LessThanOrEqual:
					this.outputFormatter.PrintToken(36);
					goto IL_305;
				case OverloadableOperatorType.Increment:
					this.outputFormatter.PrintToken(31);
					goto IL_305;
				case OverloadableOperatorType.Decrement:
					this.outputFormatter.PrintToken(32);
					goto IL_305;
				case OverloadableOperatorType.IsTrue:
					this.outputFormatter.PrintToken(113);
					goto IL_305;
				case OverloadableOperatorType.IsFalse:
					this.outputFormatter.PrintToken(72);
					goto IL_305;
				case OverloadableOperatorType.Like:
					this.outputFormatter.PrintText("Like");
					goto IL_305;
				case OverloadableOperatorType.Power:
					this.outputFormatter.PrintText("Power");
					goto IL_305;
				}
				this.Error(operatorDeclaration, operatorDeclaration.OverloadableOperator.ToString() + " is not supported as overloadable operator");
			}
			IL_305:
			this.PrintMethodDeclaration(operatorDeclaration);
			return null;
		}

		public override object TrackedVisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			if ((optionDeclaration.OptionType != OptionType.Explicit && optionDeclaration.OptionType != OptionType.Strict) || !optionDeclaration.OptionValue)
			{
				this.NotSupported(optionDeclaration);
			}
			return null;
		}

		public override object TrackedVisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			this.VisitAttributes(parameterDeclarationExpression.Attributes, data);
			if (!parameterDeclarationExpression.DefaultValue.IsNull)
			{
				this.outputFormatter.PrintText("[System.Runtime.InteropServices.OptionalAttribute, System.Runtime.InteropServices.DefaultParameterValueAttribute(");
				this.TrackVisit(parameterDeclarationExpression.DefaultValue, data);
				this.outputFormatter.PrintText(")] ");
			}
			this.OutputModifier(parameterDeclarationExpression.ParamModifier, parameterDeclarationExpression);
			if (!parameterDeclarationExpression.TypeReference.IsNull)
			{
				this.TrackVisit(parameterDeclarationExpression.TypeReference, data);
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintIdentifier(parameterDeclarationExpression.ParameterName);
			return null;
		}

		public override object TrackedVisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(parenthesizedExpression.Expression, data);
			if (this.prettyPrintOptions.WithinParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			Expression targetObject = pointerReferenceExpression.TargetObject;
			if (targetObject is BinaryOperatorExpression || targetObject is CastExpression)
			{
				this.outputFormatter.PrintToken(20);
			}
			this.TrackVisit(targetObject, data);
			if (targetObject is BinaryOperatorExpression || targetObject is CastExpression)
			{
				this.outputFormatter.PrintToken(21);
			}
			this.outputFormatter.PrintToken(47);
			this.outputFormatter.PrintIdentifier(pointerReferenceExpression.MemberName);
			this.PrintTypeArgumentList(pointerReferenceExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			this.outputFormatter.PrintText(CSharpOutputVisitor.ToCSharpString(primitiveExpression));
			return null;
		}

		public override object TrackedVisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			this.VisitAttributes(propertyDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			propertyDeclaration.Modifier &= ~Modifiers.ReadOnly;
			this.OutputModifier(propertyDeclaration.Modifier);
			this.TrackVisit(propertyDeclaration.TypeReference, data);
			this.outputFormatter.Space();
			if (propertyDeclaration.InterfaceImplementations.Count > 0)
			{
				this.TrackVisit(propertyDeclaration.InterfaceImplementations[0].InterfaceType, data);
				this.outputFormatter.PrintToken(15);
			}
			this.outputFormatter.PrintIdentifier(propertyDeclaration.Name);
			this.OutputGetAndSetRegion(propertyDeclaration.GetRegion, propertyDeclaration.SetRegion);
			return null;
		}

		public override object TrackedVisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			this.VisitAttributes(propertyGetRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(propertyGetRegion.Modifier);
			this.outputFormatter.PrintText("get");
			if (this.prettyPrintOptions.AllowPropertyGetBlockInline)
			{
				this.OutputBlockAllowInline(propertyGetRegion.Block, this.prettyPrintOptions.PropertyGetBraceStyle);
			}
			else
			{
				this.OutputBlock(propertyGetRegion.Block, this.prettyPrintOptions.PropertyGetBraceStyle);
			}
			return null;
		}

		public override object TrackedVisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			this.VisitAttributes(propertySetRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(propertySetRegion.Modifier);
			this.outputFormatter.PrintText("set");
			if (this.prettyPrintOptions.AllowPropertySetBlockInline)
			{
				this.OutputBlockAllowInline(propertySetRegion.Block, this.prettyPrintOptions.PropertySetBraceStyle);
			}
			else
			{
				this.OutputBlock(propertySetRegion.Block, this.prettyPrintOptions.PropertySetBraceStyle);
			}
			return null;
		}

		public override object TrackedVisitQueryExpression(QueryExpression queryExpression, object data)
		{
			if (queryExpression.IsQueryContinuation)
			{
				queryExpression.FromClause.InExpression.AcceptVisitor(this, data);
			}
			this.outputFormatter.IndentationLevel++;
			if (queryExpression.IsQueryContinuation)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(136);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier(queryExpression.FromClause.Identifier);
			}
			else
			{
				queryExpression.FromClause.AcceptVisitor(this, data);
			}
			queryExpression.MiddleClauses.ForEach(new Action<QueryExpressionClause>(this.PrintClause));
			this.PrintClause(queryExpression.SelectOrGroupClause);
			this.outputFormatter.IndentationLevel--;
			return null;
		}

		public override object TrackedVisitQueryExpressionFromClause(QueryExpressionFromClause fromClause, object data)
		{
			this.outputFormatter.PrintToken(137);
			this.outputFormatter.Space();
			this.VisitQueryExpressionFromOrJoinClause(fromClause, data);
			return null;
		}

		public override object TrackedVisitQueryExpressionGroupClause(QueryExpressionGroupClause groupClause, object data)
		{
			this.outputFormatter.PrintToken(134);
			this.outputFormatter.Space();
			groupClause.Projection.AcceptVisitor(this, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(135);
			this.outputFormatter.Space();
			return groupClause.GroupBy.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionJoinClause(QueryExpressionJoinClause joinClause, object data)
		{
			this.outputFormatter.PrintToken(142);
			this.outputFormatter.Space();
			this.VisitQueryExpressionFromOrJoinClause(joinClause, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(143);
			this.outputFormatter.Space();
			joinClause.OnExpression.AcceptVisitor(this, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(144);
			this.outputFormatter.Space();
			joinClause.EqualsExpression.AcceptVisitor(this, data);
			if (!string.IsNullOrEmpty(joinClause.IntoIdentifier))
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(136);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier(joinClause.IntoIdentifier);
			}
			return null;
		}

		public override object TrackedVisitQueryExpressionLetClause(QueryExpressionLetClause letClause, object data)
		{
			this.outputFormatter.PrintToken(141);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(letClause.Identifier);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(3);
			if (this.prettyPrintOptions.AroundAssignmentParentheses)
			{
				this.outputFormatter.Space();
			}
			return letClause.Expression.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			this.outputFormatter.PrintToken(140);
			this.outputFormatter.Space();
			this.AppendCommaSeparatedList<QueryExpressionOrdering>(queryExpressionOrderClause.Orderings);
			return null;
		}

		public override object TrackedVisitQueryExpressionOrdering(QueryExpressionOrdering ordering, object data)
		{
			ordering.Criteria.AcceptVisitor(this, data);
			if (ordering.Direction == QueryExpressionOrderingDirection.Ascending)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(138);
			}
			else if (ordering.Direction == QueryExpressionOrderingDirection.Descending)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(139);
			}
			return null;
		}

		public override object TrackedVisitQueryExpressionSelectClause(QueryExpressionSelectClause selectClause, object data)
		{
			this.outputFormatter.PrintToken(133);
			this.outputFormatter.Space();
			return selectClause.Projection.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionWhereClause(QueryExpressionWhereClause whereClause, object data)
		{
			this.outputFormatter.PrintToken(127);
			this.outputFormatter.Space();
			return whereClause.Condition.AcceptVisitor(this, data);
		}

		public override object TrackedVisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			this.outputFormatter.PrintToken(79);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(20);
			this.outputFormatter.PrintIdentifier(raiseEventStatement.EventName);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(34);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(90);
			this.outputFormatter.PrintToken(21);
			this.outputFormatter.BeginBrace(BraceStyle.EndOfLine, this.prettyPrintOptions.IndentBlocks);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintIdentifier(raiseEventStatement.EventName);
			this.outputFormatter.PrintToken(20);
			this.AppendCommaSeparatedList<Expression>(raiseEventStatement.Arguments);
			this.outputFormatter.PrintToken(21);
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.NewLine();
			this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentBlocks);
			return null;
		}

		public override object TrackedVisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			if (!reDimStatement.IsPreserve)
			{
				this.NotSupported(reDimStatement);
				return null;
			}
			foreach (InvocationExpression current in reDimStatement.ReDimClauses)
			{
				this.outputFormatter.PrintText("Array.Resize(ref ");
				current.TargetObject.AcceptVisitor(this, data);
				this.outputFormatter.PrintText(", ");
				for (int i = 0; i < current.Arguments.Count; i++)
				{
					if (i > 0)
					{
						this.outputFormatter.PrintText(", ");
					}
					Expression.AddInteger(current.Arguments[i], 1).AcceptVisitor(this, data);
				}
				this.outputFormatter.PrintText(")");
				this.outputFormatter.PrintToken(11);
			}
			return null;
		}

		public override object TrackedVisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			this.TrackVisit(removeHandlerStatement.EventExpression, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(39);
			this.outputFormatter.Space();
			this.TrackVisit(removeHandlerStatement.HandlerExpression, data);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			this.NotSupported(resumeStatement);
			return null;
		}

		public override object TrackedVisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			this.outputFormatter.PrintToken(101);
			if (!returnStatement.Expression.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(returnStatement.Expression, data);
			}
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			this.outputFormatter.PrintToken(105);
			if (this.prettyPrintOptions.SizeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinSizeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(sizeOfExpression.TypeReference, data);
			if (this.prettyPrintOptions.WithinSizeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			this.outputFormatter.PrintToken(106);
			this.outputFormatter.Space();
			this.TrackVisit(stackAllocExpression.TypeReference, data);
			this.outputFormatter.PrintToken(18);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(stackAllocExpression.Expression, data);
			if (this.prettyPrintOptions.SpacesWithinBrackets)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(19);
			return null;
		}

		public override object TrackedVisitStopStatement(StopStatement stopStatement, object data)
		{
			this.outputFormatter.PrintText("System.Diagnostics.Debugger.Break()");
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitSwitchSection(SwitchSection switchSection, object data)
		{
			foreach (CaseLabel current in switchSection.SwitchLabels)
			{
				this.TrackVisit(current, data);
			}
			int indentationLevel = this.outputFormatter.IndentationLevel;
			if (this.prettyPrintOptions.IndentCaseBody)
			{
				this.outputFormatter.IndentationLevel++;
			}
			for (int i = 0; i < switchSection.Children.Count; i++)
			{
				Statement node = switchSection.Children[i] as Statement;
				int indentationLevel2 = this.outputFormatter.IndentationLevel;
				if (i == switchSection.Children.Count - 1)
				{
					if (this.prettyPrintOptions.IndentBreakStatements)
					{
						this.outputFormatter.IndentationLevel = indentationLevel + 1;
					}
					else
					{
						this.outputFormatter.IndentationLevel = indentationLevel;
					}
				}
				this.outputFormatter.Indent();
				this.TrackVisit(node, data);
				this.outputFormatter.NewLine();
				this.outputFormatter.IndentationLevel = indentationLevel2;
			}
			if (this.prettyPrintOptions.IndentCaseBody)
			{
				this.outputFormatter.IndentationLevel--;
			}
			return null;
		}

		public override object TrackedVisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			this.outputFormatter.PrintToken(110);
			if (this.prettyPrintOptions.SwitchParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinSwitchParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(switchStatement.SwitchExpression, data);
			if (this.prettyPrintOptions.WithinSwitchParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(16);
			this.outputFormatter.NewLine();
			if (this.prettyPrintOptions.IndentSwitchBody)
			{
				this.outputFormatter.IndentationLevel++;
			}
			foreach (SwitchSection current in switchStatement.SwitchSections)
			{
				this.TrackVisit(current, data);
			}
			if (this.prettyPrintOptions.IndentSwitchBody)
			{
				this.outputFormatter.IndentationLevel--;
			}
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(17);
			return null;
		}

		public override object TrackedVisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			if (templateDefinition.Bases.Count == 0)
			{
				return null;
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintText("where");
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(templateDefinition.Name);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(9);
			this.outputFormatter.Space();
			for (int i = 0; i < templateDefinition.Bases.Count; i++)
			{
				this.TrackVisit(templateDefinition.Bases[i], data);
				if (i + 1 < templateDefinition.Bases.Count)
				{
					this.PrintFormattedComma();
				}
			}
			return null;
		}

		public override object TrackedVisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			this.outputFormatter.PrintToken(111);
			return null;
		}

		public override object TrackedVisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			this.outputFormatter.PrintToken(112);
			if (!throwStatement.Expression.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackVisit(throwStatement.Expression, data);
			}
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			this.outputFormatter.PrintToken(114);
			this.WriteEmbeddedStatement(tryCatchStatement.StatementBlock, this.prettyPrintOptions.PlaceCatchOnNewLine);
			for (int i = 0; i < tryCatchStatement.CatchClauses.Count; i++)
			{
				this.TrackVisit(tryCatchStatement.CatchClauses[i], i == tryCatchStatement.CatchClauses.Count - 1);
			}
			if (!tryCatchStatement.FinallyBlock.IsNull)
			{
				if (this.prettyPrintOptions.PlaceFinallyOnNewLine)
				{
					this.outputFormatter.Indent();
				}
				else
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(73);
				this.WriteEmbeddedStatement(tryCatchStatement.FinallyBlock);
			}
			return null;
		}

		public override object TrackedVisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			this.VisitAttributes(typeDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(typeDeclaration.Modifier);
			switch (typeDeclaration.Type)
			{
			case ClassType.Interface:
				this.outputFormatter.PrintToken(83);
				break;
			case ClassType.Struct:
				this.outputFormatter.PrintToken(109);
				break;
			case ClassType.Enum:
				this.outputFormatter.PrintToken(68);
				break;
			default:
				this.outputFormatter.PrintToken(59);
				break;
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(typeDeclaration.Name);
			this.PrintTemplates(typeDeclaration.Templates);
			if (typeDeclaration.BaseTypes != null && typeDeclaration.BaseTypes.Count > 0)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(9);
				this.outputFormatter.Space();
				for (int i = 0; i < typeDeclaration.BaseTypes.Count; i++)
				{
					if (i > 0)
					{
						this.PrintFormattedComma();
					}
					this.TrackVisit(typeDeclaration.BaseTypes[i], data);
				}
			}
			foreach (TemplateDefinition current in typeDeclaration.Templates)
			{
				this.TrackVisit(current, data);
			}
			switch (typeDeclaration.Type)
			{
			case ClassType.Interface:
				this.outputFormatter.BeginBrace(this.prettyPrintOptions.InterfaceBraceStyle, this.prettyPrintOptions.IndentInterfaceBody);
				break;
			case ClassType.Struct:
				this.outputFormatter.BeginBrace(this.prettyPrintOptions.StructBraceStyle, this.prettyPrintOptions.IndentStructBody);
				break;
			case ClassType.Enum:
				this.outputFormatter.BeginBrace(this.prettyPrintOptions.EnumBraceStyle, this.prettyPrintOptions.IndentEnumBody);
				break;
			default:
				this.outputFormatter.BeginBrace(this.prettyPrintOptions.ClassBraceStyle, this.prettyPrintOptions.IndentClassBody);
				break;
			}
			TypeDeclaration typeDeclaration2 = this.currentType;
			this.currentType = typeDeclaration;
			if (typeDeclaration.Type == ClassType.Enum)
			{
				this.OutputEnumMembers(typeDeclaration, data);
			}
			else
			{
				typeDeclaration.AcceptChildren(this, data);
			}
			this.currentType = typeDeclaration2;
			switch (typeDeclaration.Type)
			{
			case ClassType.Interface:
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentInterfaceBody);
				break;
			case ClassType.Struct:
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentStructBody);
				break;
			case ClassType.Enum:
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentEnumBody);
				break;
			default:
				this.outputFormatter.EndBrace(this.prettyPrintOptions.IndentCaseBody);
				break;
			}
			return null;
		}

		public override object TrackedVisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			this.outputFormatter.PrintToken(115);
			if (this.prettyPrintOptions.TypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinTypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(typeOfExpression.TypeReference, data);
			if (this.prettyPrintOptions.WithinTypeOfParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			this.TrackVisit(typeOfIsExpression.Expression, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(85);
			this.outputFormatter.Space();
			this.TrackVisit(typeOfIsExpression.TypeReference, data);
			return null;
		}

		public override object TrackedVisitTypeReference(TypeReference typeReference, object data)
		{
			if (typeReference == TypeReference.ClassConstraint)
			{
				this.outputFormatter.PrintToken(59);
			}
			else if (typeReference == TypeReference.StructConstraint)
			{
				this.outputFormatter.PrintToken(109);
			}
			else if (typeReference == TypeReference.NewConstraint)
			{
				this.outputFormatter.PrintToken(89);
				this.outputFormatter.PrintToken(20);
				this.outputFormatter.PrintToken(21);
			}
			else
			{
				this.PrintTypeReferenceWithoutArray(typeReference);
				if (typeReference.IsArrayType)
				{
					this.PrintArrayRank(typeReference.RankSpecifier, 0);
				}
			}
			return null;
		}

		public override object TrackedVisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			this.TrackVisit(typeReferenceExpression.TypeReference, data);
			return null;
		}

		public override object TrackedVisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			switch (unaryOperatorExpression.Op)
			{
			case UnaryOperatorType.Not:
				this.outputFormatter.PrintToken(24);
				break;
			case UnaryOperatorType.BitNot:
				this.outputFormatter.PrintToken(27);
				break;
			case UnaryOperatorType.Minus:
				this.outputFormatter.PrintToken(5);
				break;
			case UnaryOperatorType.Plus:
				this.outputFormatter.PrintToken(4);
				break;
			case UnaryOperatorType.Increment:
				this.outputFormatter.PrintToken(31);
				break;
			case UnaryOperatorType.Decrement:
				this.outputFormatter.PrintToken(32);
				break;
			case UnaryOperatorType.PostIncrement:
				this.TrackVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintToken(31);
				return null;
			case UnaryOperatorType.PostDecrement:
				this.TrackVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintToken(32);
				return null;
			case UnaryOperatorType.Dereference:
				this.outputFormatter.PrintToken(6);
				break;
			case UnaryOperatorType.AddressOf:
				this.outputFormatter.PrintToken(28);
				break;
			default:
				this.Error(unaryOperatorExpression, string.Format("Unknown unary operator {0}", unaryOperatorExpression.Op));
				return null;
			}
			this.TrackVisit(unaryOperatorExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			this.outputFormatter.PrintToken(118);
			if (this.prettyPrintOptions.UncheckedParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.TrackVisit(uncheckedExpression.Expression, data);
			if (this.prettyPrintOptions.WithinCheckedExpressionParantheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			return null;
		}

		public override object TrackedVisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			this.outputFormatter.PrintToken(118);
			this.WriteEmbeddedStatement(uncheckedStatement.Block);
			return null;
		}

		public override object TrackedVisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			this.outputFormatter.PrintToken(119);
			this.WriteEmbeddedStatement(unsafeStatement.Block);
			return null;
		}

		public override object TrackedVisitUsing(Using @using, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(121);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(@using.Name);
			if (@using.IsAlias)
			{
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(3);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(@using.Alias, data);
			}
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			foreach (Using current in usingDeclaration.Usings)
			{
				this.TrackVisit(current, data);
			}
			return null;
		}

		public override object TrackedVisitUsingStatement(UsingStatement usingStatement, object data)
		{
			this.outputFormatter.PrintToken(121);
			if (this.prettyPrintOptions.UsingParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(20);
			if (this.prettyPrintOptions.WithinUsingParentheses)
			{
				this.outputFormatter.Space();
			}
			this.PrintStatementInline(usingStatement.ResourceAcquisition, data);
			if (this.prettyPrintOptions.WithinUsingParentheses)
			{
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(21);
			this.WriteEmbeddedStatement(usingStatement.EmbeddedStatement, this.prettyPrintOptions.UsingBraceForcement, this.prettyPrintOptions.StatementBraceStyle, true);
			return null;
		}

		public override object TrackedVisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			this.outputFormatter.PrintIdentifier(variableDeclaration.Name);
			if (!variableDeclaration.FixedArrayInitialization.IsNull)
			{
				this.outputFormatter.PrintToken(18);
				this.TrackVisit(variableDeclaration.FixedArrayInitialization, data);
				this.outputFormatter.PrintToken(19);
			}
			if (!variableDeclaration.Initializer.IsNull)
			{
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.outputFormatter.PrintToken(3);
				if (this.prettyPrintOptions.AroundAssignmentParentheses)
				{
					this.outputFormatter.Space();
				}
				this.TrackVisit(variableDeclaration.Initializer, data);
			}
			return null;
		}

		public override object TrackedVisitWithStatement(WithStatement withStatement, object data)
		{
			this.NotSupported(withStatement);
			return null;
		}

		public override object TrackedVisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			this.outputFormatter.PrintText("yield");
			this.outputFormatter.Space();
			this.TrackVisit(yieldStatement.Statement, data);
			return null;
		}

		private object TrackVisit(INode node, object data)
		{
			return node.AcceptVisitor(this, data);
		}

		private void VisitAttributes(ICollection attributes, object data)
		{
			if (attributes == null || attributes.Count <= 0)
			{
				return;
			}
			foreach (AttributeSection node in attributes)
			{
				this.TrackVisit(node, data);
			}
		}

		private void VisitQueryExpressionFromOrJoinClause(QueryExpressionFromOrJoinClause clause, object data)
		{
			this.outputFormatter.PrintIdentifier(clause.Identifier);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(81);
			this.outputFormatter.Space();
			clause.InExpression.AcceptVisitor(this, data);
		}

		private void WriteEmbeddedStatement(Statement statement)
		{
			this.WriteEmbeddedStatement(statement, true);
		}

		private void WriteEmbeddedStatement(Statement statement, bool emitEndingNewLine)
		{
			if (statement is BlockStatement)
			{
				this.OutputBlock((BlockStatement)statement, this.prettyPrintOptions.StatementBraceStyle, emitEndingNewLine);
				return;
			}
			this.outputFormatter.IndentationLevel++;
			this.outputFormatter.NewLine();
			this.outputFormatter.Indent();
			this.TrackVisit(statement, null);
			this.outputFormatter.IndentationLevel--;
		}

		private void WriteEmbeddedStatement(Statement statement, BraceForcement forcement, BraceStyle braceStyle, bool emitEndingNewLine)
		{
			if (statement is BlockStatement)
			{
				BlockStatement blockStatement = (BlockStatement)statement;
				switch (forcement)
				{
				case BraceForcement.RemoveBraces:
				case BraceForcement.RemoveBracesForSingleLine:
					if (blockStatement.Children.Count == 1)
					{
						this.outputFormatter.IndentationLevel++;
						this.outputFormatter.NewLine();
						this.outputFormatter.Indent();
						this.TrackVisit(blockStatement.Children[0], null);
						this.outputFormatter.IndentationLevel--;
						return;
					}
					break;
				}
				this.OutputBlock((BlockStatement)statement, this.prettyPrintOptions.StatementBraceStyle, emitEndingNewLine);
				return;
			}
			if (forcement == BraceForcement.AddBraces)
			{
				BlockStatement blockStatement2 = new BlockStatement();
				blockStatement2.AddChild(statement);
				this.OutputBlock(blockStatement2, braceStyle, true);
				return;
			}
			this.WriteEmbeddedStatement(statement, emitEndingNewLine);
		}

		public Errors Errors
		{
			get
			{
				return this.errors;
			}
		}

		AbstractPrettyPrintOptions IOutputAstVisitor.Options
		{
			get
			{
				return this.prettyPrintOptions;
			}
		}

		public PrettyPrintOptions Options
		{
			get
			{
				return this.prettyPrintOptions;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.prettyPrintOptions = value;
			}
		}

		public IOutputFormatter OutputFormatter
		{
			get
			{
				return this.outputFormatter;
			}
		}

		public string Text
		{
			get
			{
				return this.outputFormatter.Text;
			}
		}

		public event Action<INode> AfterNodeVisit
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.AfterNodeVisit = (Action<INode>)Delegate.Combine(this.AfterNodeVisit, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.AfterNodeVisit = (Action<INode>)Delegate.Remove(this.AfterNodeVisit, value);
			}
		}

		public event Action<INode> BeforeNodeVisit
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BeforeNodeVisit = (Action<INode>)Delegate.Combine(this.BeforeNodeVisit, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BeforeNodeVisit = (Action<INode>)Delegate.Remove(this.BeforeNodeVisit, value);
			}
		}

		private TypeDeclaration currentType;

		private Errors errors = new Errors();

		private CSharpOutputFormatter outputFormatter;

		private PrettyPrintOptions prettyPrintOptions = new PrettyPrintOptions();
	}
}
