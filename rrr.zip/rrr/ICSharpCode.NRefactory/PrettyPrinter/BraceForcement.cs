﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public enum BraceForcement
	{
		DoNotChange,
		RemoveBraces,
		AddBraces,
		RemoveBracesForSingleLine
	}
}
