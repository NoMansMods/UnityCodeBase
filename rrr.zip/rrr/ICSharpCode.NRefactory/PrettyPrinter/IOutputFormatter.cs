﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public interface IOutputFormatter
	{
		void Indent();

		void NewLine();

		void PrintBlankLine(bool forceWriteInPreviousBlock);

		void PrintComment(Comment comment, bool forceWriteInPreviousBlock);

		void PrintPreprocessingDirective(PreprocessingDirective directive, bool forceWriteInPreviousBlock);

		int IndentationLevel
		{
			get;
			set;
		}

		bool IsInMemberBody
		{
			get;
			set;
		}

		string Text
		{
			get;
		}
	}
}
