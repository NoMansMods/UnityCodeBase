﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Parser;
using ICSharpCode.NRefactory.Visitors;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public sealed class VBNetOutputVisitor : NodeTrackingAstVisitor, IOutputAstVisitor, IAstVisitor
	{
		public VBNetOutputVisitor()
		{
			this.outputFormatter = new VBNetOutputFormatter(this.prettyPrintOptions);
		}

		public void AppendCommaSeparatedList<T>(ICollection<T> list) where T : class, INode
		{
			if (list != null)
			{
				int num = 0;
				foreach (T current in list)
				{
					this.TrackedVisit(current, null);
					if (num + 1 < list.Count)
					{
						this.outputFormatter.PrintToken(12);
						this.outputFormatter.Space();
						if ((num + 1) % 6 == 0)
						{
							this.outputFormatter.PrintLineContinuation();
							this.outputFormatter.Indent();
							this.outputFormatter.PrintText("\t");
						}
					}
					num++;
				}
			}
		}

		protected override void BeginVisit(INode node)
		{
			if (this.BeforeNodeVisit != null)
			{
				this.BeforeNodeVisit(node);
			}
			base.BeginVisit(node);
		}

		private static string ConvertCharLiteral(char ch)
		{
			if (char.IsControl(ch))
			{
				string charName = VBNetOutputVisitor.GetCharName(ch);
				if (charName != null)
				{
					return "ControlChars." + charName;
				}
				string arg_31_0 = "ChrW(";
				int num = (int)ch;
				return arg_31_0 + num.ToString() + ")";
			}
			else
			{
				if (ch == '"')
				{
					return "\"\"\"\"C";
				}
				return "\"" + ch.ToString() + "\"C";
			}
		}

		private static string ConvertString(string str)
		{
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = false;
			for (int i = 0; i < str.Length; i++)
			{
				char c = str[i];
				if (char.IsControl(c))
				{
					if (flag)
					{
						stringBuilder.Append('"');
						flag = false;
					}
					if (stringBuilder.Length > 0)
					{
						stringBuilder.Append(" & ");
					}
					string charName = VBNetOutputVisitor.GetCharName(c);
					if (charName != null)
					{
						stringBuilder.Append("vb" + charName);
					}
					else
					{
						stringBuilder.Append("ChrW(" + (int)c + ")");
					}
				}
				else
				{
					if (!flag)
					{
						if (stringBuilder.Length > 0)
						{
							stringBuilder.Append(" & ");
						}
						stringBuilder.Append('"');
						flag = true;
					}
					if (c == '"')
					{
						stringBuilder.Append("\"\"");
					}
					else
					{
						stringBuilder.Append(c);
					}
				}
			}
			if (flag)
			{
				stringBuilder.Append('"');
			}
			if (stringBuilder.Length == 0)
			{
				return "\"\"";
			}
			return stringBuilder.ToString();
		}

		private static string ConvertTypeString(string typeString)
		{
			string result;
			if (TypeReference.PrimitiveTypesVBReverse.TryGetValue(typeString, out result))
			{
				return result;
			}
			return typeString;
		}

		protected override void EndVisit(INode node)
		{
			base.EndVisit(node);
			if (this.AfterNodeVisit != null)
			{
				this.AfterNodeVisit(node);
			}
		}

		private void Error(string text, Location position)
		{
			this.errors.Error(position.Line, position.Column, text);
		}

		private static string GetCharName(char ch)
		{
			if (ch == '\0')
			{
				return "NullChar";
			}
			switch (ch)
			{
			case '\b':
				return "Back";
			case '\t':
				return "Tab";
			case '\n':
				return "Lf";
			case '\v':
				return "VerticalTab";
			case '\f':
				return "FormFeed";
			case '\r':
				return "Cr";
			default:
				return null;
			}
		}

		private static int GetTypeToken(TypeDeclaration typeDeclaration)
		{
			switch (typeDeclaration.Type)
			{
			case ClassType.Class:
				return 71;
			case ClassType.Module:
				return 141;
			case ClassType.Interface:
				return 129;
			case ClassType.Struct:
				return 194;
			case ClassType.Enum:
				return 102;
			default:
				return 71;
			}
		}

		private bool IsAbstract(AttributedNode node)
		{
			return (node.Modifier & Modifiers.Dim) == Modifiers.Dim || (this.currentType != null && this.currentType.Type == ClassType.Interface);
		}

		private void OutputAnonymousMethodWithStatementBody(List<ParameterDeclarationExpression> parameters, BlockStatement body)
		{
			this.Error("VB does not support anonymous methods/lambda expressions with a statement body", body.StartLocation);
			this.outputFormatter.PrintToken(114);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(parameters);
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(95);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.exitTokenStack.Push(114);
			body.AcceptVisitor(this, null);
			this.exitTokenStack.Pop();
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(114);
		}

		private void OutputEnumMembers(TypeDeclaration typeDeclaration, object data)
		{
			using (List<INode>.Enumerator enumerator = typeDeclaration.Children.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					FieldDeclaration fieldDeclaration = (FieldDeclaration)enumerator.Current;
					this.BeginVisit(fieldDeclaration);
					VariableDeclaration variableDeclaration = fieldDeclaration.Fields[0];
					this.VisitAttributes(fieldDeclaration.Attributes, data);
					this.outputFormatter.Indent();
					this.outputFormatter.PrintIdentifier(variableDeclaration.Name);
					if (variableDeclaration.Initializer != null && !variableDeclaration.Initializer.IsNull)
					{
						this.outputFormatter.Space();
						this.outputFormatter.PrintToken(10);
						this.outputFormatter.Space();
						this.TrackedVisit(variableDeclaration.Initializer, data);
					}
					this.outputFormatter.NewLine();
					this.EndVisit(fieldDeclaration);
				}
			}
		}

		private void OutputModifier(Modifiers modifier)
		{
			this.OutputModifier(modifier, false, false);
		}

		private void OutputModifier(ParameterModifiers modifier, Location position)
		{
			if ((modifier & ParameterModifiers.Optional) == ParameterModifiers.Optional)
			{
				this.outputFormatter.PrintToken(160);
				this.outputFormatter.Space();
			}
			if ((modifier & ParameterModifiers.Ref) == ParameterModifiers.Ref)
			{
				this.outputFormatter.PrintToken(56);
				this.outputFormatter.Space();
			}
			if ((modifier & ParameterModifiers.Params) == ParameterModifiers.Params)
			{
				this.outputFormatter.PrintToken(167);
				this.outputFormatter.Space();
			}
			if (this.prettyPrintOptions.OutputByValModifier && (modifier & (ParameterModifiers.Ref | ParameterModifiers.Params)) == ParameterModifiers.None)
			{
				this.outputFormatter.PrintToken(59);
				this.outputFormatter.Space();
			}
		}

		private void OutputModifier(Modifiers modifier, bool forTypeDecl, bool forFieldDecl)
		{
			if ((modifier & Modifiers.Public) == Modifiers.Public)
			{
				this.outputFormatter.PrintToken(173);
				this.outputFormatter.Space();
			}
			else if ((modifier & Modifiers.Private) == Modifiers.Private)
			{
				this.outputFormatter.PrintToken(170);
				this.outputFormatter.Space();
			}
			else if ((modifier & (Modifiers.Internal | Modifiers.Protected)) == (Modifiers.Internal | Modifiers.Protected))
			{
				this.outputFormatter.PrintToken(172);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(112);
				this.outputFormatter.Space();
			}
			else if ((modifier & Modifiers.Internal) == Modifiers.Internal)
			{
				this.outputFormatter.PrintToken(112);
				this.outputFormatter.Space();
			}
			else if ((modifier & Modifiers.Protected) == Modifiers.Protected)
			{
				this.outputFormatter.PrintToken(172);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Static) == Modifiers.Static)
			{
				this.outputFormatter.PrintToken(185);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Virtual) == Modifiers.Virtual)
			{
				this.outputFormatter.PrintToken(165);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Dim) == Modifiers.Dim)
			{
				if (forFieldDecl)
				{
					this.outputFormatter.PrintToken(92);
				}
				else if (forTypeDecl)
				{
					this.outputFormatter.PrintToken(142);
				}
				else
				{
					this.outputFormatter.PrintToken(143);
				}
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Overloads) == Modifiers.Overloads)
			{
				this.outputFormatter.PrintToken(164);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Override) == Modifiers.Override)
			{
				this.outputFormatter.PrintToken(166);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.New) == Modifiers.New)
			{
				this.outputFormatter.PrintToken(184);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Sealed) == Modifiers.Sealed)
			{
				this.outputFormatter.PrintToken(forTypeDecl ? 152 : 153);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.ReadOnly) == Modifiers.ReadOnly)
			{
				this.outputFormatter.PrintToken(175);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.WriteOnly) == Modifiers.WriteOnly)
			{
				this.outputFormatter.PrintToken(220);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Const) == Modifiers.Const)
			{
				this.outputFormatter.PrintToken(75);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.WithEvents) == Modifiers.WithEvents)
			{
				this.outputFormatter.PrintToken(219);
				this.outputFormatter.Space();
			}
			if ((modifier & Modifiers.Partial) == Modifiers.Partial)
			{
				this.outputFormatter.PrintToken(168);
				this.outputFormatter.Space();
			}
			Modifiers arg_2DA_0 = modifier & Modifiers.Extern;
			if ((modifier & Modifiers.Volatile) == Modifiers.Volatile)
			{
				this.Error("'Volatile' modifier not convertable", Location.Empty);
			}
			if ((modifier & Modifiers.Unsafe) == Modifiers.Unsafe)
			{
				this.Error("'Unsafe' modifier not convertable", Location.Empty);
			}
		}

		private void PrintArrayRank(int[] rankSpecifier, int startRank)
		{
			for (int i = startRank; i < rankSpecifier.Length; i++)
			{
				this.outputFormatter.PrintToken(25);
				for (int j = 0; j < rankSpecifier[i]; j++)
				{
					this.outputFormatter.PrintToken(12);
				}
				this.outputFormatter.PrintToken(26);
			}
		}

		private object PrintCast(int castToken, CastExpression castExpression)
		{
			this.outputFormatter.PrintToken(castToken);
			this.outputFormatter.PrintToken(25);
			this.TrackedVisit(castExpression.Expression, null);
			this.outputFormatter.PrintToken(12);
			this.outputFormatter.Space();
			this.TrackedVisit(castExpression.CastTo, null);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		private void PrintClause(QueryExpressionClause clause)
		{
			if (!clause.IsNull)
			{
				this.outputFormatter.PrintLineContinuation();
				this.outputFormatter.Indent();
				clause.AcceptVisitor(this, null);
			}
		}

		private void PrintIndentedBlock(Statement stmt)
		{
			this.outputFormatter.IndentationLevel++;
			if (stmt is BlockStatement)
			{
				this.TrackedVisit(stmt, null);
			}
			else
			{
				this.outputFormatter.Indent();
				this.TrackedVisit(stmt, null);
				this.outputFormatter.NewLine();
			}
			this.outputFormatter.IndentationLevel--;
		}

		private void PrintIndentedBlock(IEnumerable statements)
		{
			this.outputFormatter.IndentationLevel++;
			this.VisitStatementList(statements);
			this.outputFormatter.IndentationLevel--;
		}

		private void PrintInterfaceImplementations(IList<InterfaceImplementation> list)
		{
			if (list == null || list.Count == 0)
			{
				return;
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(123);
			for (int i = 0; i < list.Count; i++)
			{
				if (i > 0)
				{
					this.outputFormatter.PrintToken(12);
				}
				this.outputFormatter.Space();
				this.TrackedVisit(list[i].InterfaceType, null);
				this.outputFormatter.PrintToken(16);
				this.outputFormatter.PrintIdentifier(list[i].MemberName);
			}
		}

		private void PrintTemplates(List<TemplateDefinition> templates)
		{
			if (templates != null && templates.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.outputFormatter.PrintToken(155);
				this.outputFormatter.Space();
				this.AppendCommaSeparatedList<TemplateDefinition>(templates);
				this.outputFormatter.PrintToken(26);
			}
		}

		private void PrintTypeArguments(List<TypeReference> typeArguments)
		{
			if (typeArguments != null && typeArguments.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.outputFormatter.PrintToken(155);
				this.outputFormatter.Space();
				this.AppendCommaSeparatedList<TypeReference>(typeArguments);
				this.outputFormatter.PrintToken(26);
			}
		}

		private void PrintTypeReferenceWithoutArray(TypeReference typeReference)
		{
			if (typeReference.IsGlobal)
			{
				this.outputFormatter.PrintToken(117);
				this.outputFormatter.PrintToken(16);
			}
			bool flag = true;
			if (typeReference.IsKeyword)
			{
				this.outputFormatter.PrintText(VBNetOutputVisitor.ConvertTypeString(typeReference.Type));
			}
			else
			{
				this.outputFormatter.PrintIdentifier(typeReference.Type);
			}
			if (flag && typeReference.GenericTypes != null && typeReference.GenericTypes.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.outputFormatter.PrintToken(155);
				this.outputFormatter.Space();
				this.AppendCommaSeparatedList<TypeReference>(typeReference.GenericTypes);
				this.outputFormatter.PrintToken(26);
			}
			for (int i = 0; i < typeReference.PointerNestingLevel; i++)
			{
				this.outputFormatter.PrintToken(22);
			}
		}

		internal static string ToVBNetString(PrimitiveExpression primitiveExpression)
		{
			object value = primitiveExpression.Value;
			if (value == null)
			{
				return "Nothing";
			}
			if (value is bool)
			{
				if ((bool)primitiveExpression.Value)
				{
					return "True";
				}
				return "False";
			}
			else
			{
				if (value is string)
				{
					return VBNetOutputVisitor.ConvertString((string)value);
				}
				if (value is char)
				{
					return VBNetOutputVisitor.ConvertCharLiteral((char)primitiveExpression.Value);
				}
				if (value is decimal)
				{
					return ((decimal)primitiveExpression.Value).ToString(NumberFormatInfo.InvariantInfo) + "D";
				}
				if (value is float)
				{
					return ((float)primitiveExpression.Value).ToString(NumberFormatInfo.InvariantInfo) + "F";
				}
				if (value is double)
				{
					string text = ((double)value).ToString(NumberFormatInfo.InvariantInfo);
					if (text.IndexOf('.') < 0 && text.IndexOf('E') < 0)
					{
						return text + ".0";
					}
					return text;
				}
				else
				{
					if (value is IFormattable)
					{
						StringBuilder stringBuilder = new StringBuilder();
						if (primitiveExpression.LiteralFormat == LiteralFormat.HexadecimalNumber)
						{
							stringBuilder.Append("&H");
							stringBuilder.Append(((IFormattable)value).ToString("x", NumberFormatInfo.InvariantInfo));
						}
						else
						{
							stringBuilder.Append(((IFormattable)value).ToString(null, NumberFormatInfo.InvariantInfo));
						}
						if (value is ushort || value is uint || value is ulong)
						{
							stringBuilder.Append('U');
							if (value is uint)
							{
								stringBuilder.Append('I');
							}
						}
						if (value is long || value is ulong)
						{
							stringBuilder.Append('L');
						}
						if (value is short || value is ushort)
						{
							stringBuilder.Append('S');
						}
						return stringBuilder.ToString();
					}
					return value.ToString();
				}
			}
		}

		private object TrackedVisit(INode node, object data)
		{
			return node.AcceptVisitor(this, data);
		}

		public override object TrackedVisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			this.outputFormatter.PrintToken(43);
			this.outputFormatter.Space();
			this.TrackedVisit(addHandlerStatement.EventExpression, data);
			this.outputFormatter.PrintToken(12);
			this.outputFormatter.Space();
			this.TrackedVisit(addHandlerStatement.HandlerExpression, data);
			return null;
		}

		public override object TrackedVisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			this.outputFormatter.PrintToken(44);
			this.outputFormatter.Space();
			this.TrackedVisit(addressOfExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			this.OutputAnonymousMethodWithStatementBody(anonymousMethodExpression.Parameters, anonymousMethodExpression.Body);
			return null;
		}

		public override object TrackedVisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			this.outputFormatter.PrintToken(148);
			this.outputFormatter.Space();
			this.PrintTypeReferenceWithoutArray(arrayCreateExpression.CreateType);
			if (arrayCreateExpression.Arguments.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.AppendCommaSeparatedList<Expression>(arrayCreateExpression.Arguments);
				this.outputFormatter.PrintToken(26);
				this.PrintArrayRank(arrayCreateExpression.CreateType.RankSpecifier, 1);
			}
			else
			{
				this.PrintArrayRank(arrayCreateExpression.CreateType.RankSpecifier, 0);
			}
			this.outputFormatter.Space();
			if (arrayCreateExpression.ArrayInitializer.IsNull)
			{
				this.outputFormatter.PrintToken(23);
				this.outputFormatter.PrintToken(24);
			}
			else
			{
				this.TrackedVisit(arrayCreateExpression.ArrayInitializer, data);
			}
			return null;
		}

		public override object TrackedVisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			int token = 0;
			bool flag = false;
			switch (assignmentExpression.Op)
			{
			case AssignmentOperatorType.Assign:
				token = 10;
				break;
			case AssignmentOperatorType.Add:
				token = 34;
				break;
			case AssignmentOperatorType.Subtract:
				token = 36;
				break;
			case AssignmentOperatorType.Multiply:
				token = 37;
				break;
			case AssignmentOperatorType.Divide:
				token = 38;
				break;
			case AssignmentOperatorType.Modulus:
				token = 140;
				flag = true;
				break;
			case AssignmentOperatorType.ShiftLeft:
				token = 40;
				break;
			case AssignmentOperatorType.ShiftRight:
				token = 41;
				break;
			case AssignmentOperatorType.BitwiseAnd:
				token = 47;
				flag = true;
				break;
			case AssignmentOperatorType.BitwiseOr:
				token = 161;
				flag = true;
				break;
			case AssignmentOperatorType.ExclusiveOr:
				token = 221;
				flag = true;
				break;
			}
			this.TrackedVisit(assignmentExpression.Left, data);
			this.outputFormatter.Space();
			if (flag)
			{
				this.outputFormatter.PrintToken(10);
				this.outputFormatter.Space();
				this.TrackedVisit(assignmentExpression.Left, data);
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(token);
			this.outputFormatter.Space();
			this.TrackedVisit(assignmentExpression.Right, data);
			return null;
		}

		public override object TrackedVisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			this.outputFormatter.PrintIdentifier(attribute.Name);
			if (attribute.PositionalArguments.Count > 0 || attribute.NamedArguments.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.AppendCommaSeparatedList<Expression>(attribute.PositionalArguments);
				if (attribute.NamedArguments.Count > 0)
				{
					if (attribute.PositionalArguments.Count > 0)
					{
						this.outputFormatter.PrintToken(12);
						this.outputFormatter.Space();
					}
					this.AppendCommaSeparatedList<NamedArgumentExpression>(attribute.NamedArguments);
				}
				this.outputFormatter.PrintToken(26);
			}
			return null;
		}

		public override object TrackedVisitAttributeSection(AttributeSection attributeSection, object data)
		{
			if (!this.printAttributeSectionInline)
			{
				this.outputFormatter.Indent();
			}
			this.outputFormatter.PrintText("<");
			if (!string.IsNullOrEmpty(attributeSection.AttributeTarget) && !string.Equals(attributeSection.AttributeTarget, "return", StringComparison.OrdinalIgnoreCase))
			{
				this.outputFormatter.PrintText(char.ToUpperInvariant(attributeSection.AttributeTarget[0]) + attributeSection.AttributeTarget.Substring(1));
				this.outputFormatter.PrintToken(11);
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<ICSharpCode.NRefactory.Ast.Attribute>(attributeSection.Attributes);
			this.outputFormatter.PrintText(">");
			if ("assembly".Equals(attributeSection.AttributeTarget, StringComparison.InvariantCultureIgnoreCase) || "module".Equals(attributeSection.AttributeTarget, StringComparison.InvariantCultureIgnoreCase))
			{
				this.outputFormatter.NewLine();
			}
			else if (this.printAttributeSectionInline)
			{
				this.outputFormatter.Space();
			}
			else
			{
				this.outputFormatter.PrintLineContinuation();
			}
			return null;
		}

		public override object TrackedVisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			this.outputFormatter.PrintToken(144);
			return null;
		}

		public override object TrackedVisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			int token = 0;
			switch (binaryOperatorExpression.Op)
			{
			case BinaryOperatorType.BitwiseAnd:
				token = 47;
				break;
			case BinaryOperatorType.BitwiseOr:
				token = 161;
				break;
			case BinaryOperatorType.LogicalAnd:
				token = 48;
				break;
			case BinaryOperatorType.LogicalOr:
				token = 163;
				break;
			case BinaryOperatorType.ExclusiveOr:
				token = 221;
				break;
			case BinaryOperatorType.GreaterThan:
				token = 27;
				break;
			case BinaryOperatorType.GreaterThanOrEqual:
				token = 30;
				break;
			case BinaryOperatorType.Equality:
				token = 10;
				break;
			case BinaryOperatorType.InEquality:
				token = 29;
				break;
			case BinaryOperatorType.LessThan:
				token = 28;
				break;
			case BinaryOperatorType.LessThanOrEqual:
				token = 31;
				break;
			case BinaryOperatorType.Add:
				token = 19;
				break;
			case BinaryOperatorType.Subtract:
				token = 18;
				break;
			case BinaryOperatorType.Multiply:
				token = 22;
				break;
			case BinaryOperatorType.Divide:
				token = 14;
				break;
			case BinaryOperatorType.Modulus:
				token = 140;
				break;
			case BinaryOperatorType.DivideInteger:
				token = 15;
				break;
			case BinaryOperatorType.Concat:
				token = 13;
				break;
			case BinaryOperatorType.ShiftLeft:
				token = 32;
				break;
			case BinaryOperatorType.ShiftRight:
				token = 33;
				break;
			case BinaryOperatorType.ReferenceEquality:
				token = 131;
				break;
			case BinaryOperatorType.ReferenceInequality:
				token = 132;
				break;
			case BinaryOperatorType.NullCoalescing:
				this.outputFormatter.PrintText("If(");
				this.TrackedVisit(binaryOperatorExpression.Left, data);
				this.outputFormatter.PrintToken(12);
				this.outputFormatter.Space();
				this.TrackedVisit(binaryOperatorExpression.Right, data);
				this.outputFormatter.PrintToken(26);
				return null;
			case BinaryOperatorType.DictionaryAccess:
			{
				PrimitiveExpression primitiveExpression = binaryOperatorExpression.Right as PrimitiveExpression;
				this.TrackedVisit(binaryOperatorExpression.Left, data);
				if (primitiveExpression != null && primitiveExpression.Value is string)
				{
					this.outputFormatter.PrintText("!" + (string)primitiveExpression.Value);
				}
				else
				{
					this.outputFormatter.PrintToken(25);
					this.TrackedVisit(binaryOperatorExpression.Right, data);
					this.outputFormatter.PrintToken(26);
				}
				return null;
			}
			}
			BinaryOperatorExpression binaryOperatorExpression2 = binaryOperatorExpression.Left as BinaryOperatorExpression;
			bool flag = binaryOperatorExpression2 != null && OperatorPrecedence.ComparePrecedenceVB(binaryOperatorExpression.Op, binaryOperatorExpression2.Op) > 0;
			if (flag)
			{
				this.outputFormatter.PrintToken(25);
			}
			this.TrackedVisit(binaryOperatorExpression.Left, data);
			if (flag)
			{
				this.outputFormatter.PrintToken(26);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(token);
			this.outputFormatter.Space();
			binaryOperatorExpression2 = (binaryOperatorExpression.Right as BinaryOperatorExpression);
			flag = (binaryOperatorExpression2 != null && OperatorPrecedence.ComparePrecedenceVB(binaryOperatorExpression.Op, binaryOperatorExpression2.Op) >= 0);
			if (flag)
			{
				this.outputFormatter.PrintToken(25);
			}
			this.TrackedVisit(binaryOperatorExpression.Right, data);
			if (flag)
			{
				this.outputFormatter.PrintToken(26);
			}
			return null;
		}

		public override object TrackedVisitBlockStatement(BlockStatement blockStatement, object data)
		{
			if (blockStatement.Parent is BlockStatement)
			{
				this.outputFormatter.Indent();
				this.outputFormatter.PrintText("If True Then");
				this.outputFormatter.NewLine();
				this.outputFormatter.IndentationLevel++;
			}
			this.VisitStatementList(blockStatement.Children);
			if (blockStatement.Parent is BlockStatement)
			{
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.Indent();
				this.outputFormatter.PrintText("End If");
				this.outputFormatter.NewLine();
			}
			return null;
		}

		public override object TrackedVisitBreakStatement(BreakStatement breakStatement, object data)
		{
			this.outputFormatter.PrintToken(107);
			if (this.exitTokenStack.Count > 0)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(this.exitTokenStack.Peek());
			}
			return null;
		}

		public override object TrackedVisitCaseLabel(CaseLabel caseLabel, object data)
		{
			if (caseLabel.IsDefault)
			{
				this.outputFormatter.PrintToken(98);
			}
			else
			{
				if (caseLabel.BinaryOperatorType != BinaryOperatorType.None)
				{
					switch (caseLabel.BinaryOperatorType)
					{
					case BinaryOperatorType.GreaterThan:
						this.outputFormatter.PrintToken(27);
						break;
					case BinaryOperatorType.GreaterThanOrEqual:
						this.outputFormatter.PrintToken(30);
						break;
					case BinaryOperatorType.Equality:
						this.outputFormatter.PrintToken(10);
						break;
					case BinaryOperatorType.InEquality:
						this.outputFormatter.PrintToken(28);
						this.outputFormatter.PrintToken(27);
						break;
					case BinaryOperatorType.LessThan:
						this.outputFormatter.PrintToken(28);
						break;
					case BinaryOperatorType.LessThanOrEqual:
						this.outputFormatter.PrintToken(31);
						break;
					}
					this.outputFormatter.Space();
				}
				this.TrackedVisit(caseLabel.Label, data);
				if (!caseLabel.ToExpression.IsNull)
				{
					this.outputFormatter.Space();
					this.outputFormatter.PrintToken(201);
					this.outputFormatter.Space();
					this.TrackedVisit(caseLabel.ToExpression, data);
				}
			}
			return null;
		}

		public override object TrackedVisitCastExpression(CastExpression castExpression, object data)
		{
			if (castExpression.CastType == CastType.TryCast)
			{
				return this.PrintCast(204, castExpression);
			}
			if (castExpression.CastType == CastType.Cast || castExpression.CastTo.IsArrayType)
			{
				return this.PrintCast(93, castExpression);
			}
			string type;
			if ((type = castExpression.CastTo.Type) != null)
			{
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000642-1 == null)
				{
					<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000642-1 = new Dictionary<string, int>(16)
					{
						{
							"System.Boolean",
							0
						},
						{
							"System.Byte",
							1
						},
						{
							"System.SByte",
							2
						},
						{
							"System.Char",
							3
						},
						{
							"System.DateTime",
							4
						},
						{
							"System.Decimal",
							5
						},
						{
							"System.Double",
							6
						},
						{
							"System.Int16",
							7
						},
						{
							"System.Int32",
							8
						},
						{
							"System.Int64",
							9
						},
						{
							"System.UInt16",
							10
						},
						{
							"System.UInt32",
							11
						},
						{
							"System.UInt64",
							12
						},
						{
							"System.Object",
							13
						},
						{
							"System.Single",
							14
						},
						{
							"System.String",
							15
						}
					};
				}
				int num;
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000642-1.TryGetValue(type, out num))
				{
					switch (num)
					{
					case 0:
						this.outputFormatter.PrintToken(63);
						break;
					case 1:
						this.outputFormatter.PrintToken(64);
						break;
					case 2:
						this.outputFormatter.PrintToken(77);
						break;
					case 3:
						this.outputFormatter.PrintToken(65);
						break;
					case 4:
						this.outputFormatter.PrintToken(66);
						break;
					case 5:
						this.outputFormatter.PrintToken(68);
						break;
					case 6:
						this.outputFormatter.PrintToken(67);
						break;
					case 7:
						this.outputFormatter.PrintToken(78);
						break;
					case 8:
						this.outputFormatter.PrintToken(70);
						break;
					case 9:
						this.outputFormatter.PrintToken(72);
						break;
					case 10:
						this.outputFormatter.PrintToken(84);
						break;
					case 11:
						this.outputFormatter.PrintToken(82);
						break;
					case 12:
						this.outputFormatter.PrintToken(83);
						break;
					case 13:
						this.outputFormatter.PrintToken(73);
						break;
					case 14:
						this.outputFormatter.PrintToken(79);
						break;
					case 15:
						this.outputFormatter.PrintToken(80);
						break;
					default:
						goto IL_28F;
					}
					this.outputFormatter.PrintToken(25);
					this.TrackedVisit(castExpression.Expression, data);
					this.outputFormatter.PrintToken(26);
					return null;
				}
			}
			IL_28F:
			return this.PrintCast(81, castExpression);
		}

		public override object TrackedVisitCatchClause(CatchClause catchClause, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(62);
			if (!catchClause.TypeReference.IsNull)
			{
				this.outputFormatter.Space();
				if (catchClause.VariableName.Length > 0)
				{
					this.outputFormatter.PrintIdentifier(catchClause.VariableName);
				}
				else
				{
					this.outputFormatter.PrintIdentifier("generatedExceptionName");
				}
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier(catchClause.TypeReference.Type);
			}
			if (!catchClause.Condition.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(214);
				this.outputFormatter.Space();
				this.TrackedVisit(catchClause.Condition, data);
			}
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(catchClause.StatementBlock);
			return null;
		}

		public override object TrackedVisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			this.UnsupportedNode(checkedExpression);
			return this.TrackedVisit(checkedExpression.Expression, data);
		}

		public override object TrackedVisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			this.UnsupportedNode(checkedStatement);
			return this.TrackedVisit(checkedStatement.Block, data);
		}

		public override object TrackedVisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			this.outputFormatter.PrintToken(145);
			return null;
		}

		public override object TrackedVisitCollectionInitializerExpression(CollectionInitializerExpression arrayInitializerExpression, object data)
		{
			this.outputFormatter.PrintToken(23);
			this.AppendCommaSeparatedList<Expression>(arrayInitializerExpression.CreateExpressions);
			this.outputFormatter.PrintToken(24);
			return null;
		}

		public override object TrackedVisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			compilationUnit.AcceptChildren(this, data);
			this.outputFormatter.EndFile();
			return null;
		}

		public override object TrackedVisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			this.outputFormatter.PrintText("If");
			this.outputFormatter.PrintToken(25);
			this.TrackedVisit(conditionalExpression.Condition, data);
			this.outputFormatter.PrintToken(12);
			this.outputFormatter.Space();
			this.TrackedVisit(conditionalExpression.TrueExpression, data);
			this.outputFormatter.PrintToken(12);
			this.outputFormatter.Space();
			this.TrackedVisit(conditionalExpression.FalseExpression, data);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			this.VisitAttributes(constructorDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(constructorDeclaration.Modifier);
			this.outputFormatter.PrintToken(195);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(148);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(constructorDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.NewLine();
			this.outputFormatter.IsInMemberBody = true;
			this.outputFormatter.IndentationLevel++;
			this.exitTokenStack.Push(195);
			this.TrackedVisit(constructorDeclaration.ConstructorInitializer, data);
			this.TrackedVisit(constructorDeclaration.Body, data);
			this.exitTokenStack.Pop();
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.IsInMemberBody = false;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(195);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			this.outputFormatter.Indent();
			if (constructorInitializer.ConstructorInitializerType == ConstructorInitializerType.This)
			{
				this.outputFormatter.PrintToken(139);
			}
			else
			{
				this.outputFormatter.PrintToken(144);
			}
			this.outputFormatter.PrintToken(16);
			this.outputFormatter.PrintToken(148);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<Expression>(constructorInitializer.Arguments);
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			this.outputFormatter.PrintToken(76);
			this.outputFormatter.Space();
			switch (continueStatement.ContinueType)
			{
			case ContinueType.Do:
				this.outputFormatter.PrintToken(95);
				break;
			case ContinueType.For:
				this.outputFormatter.PrintToken(111);
				break;
			case ContinueType.While:
				this.outputFormatter.PrintToken(216);
				break;
			default:
				this.outputFormatter.PrintToken(this.exitTokenStack.Peek());
				break;
			}
			return null;
		}

		public override object TrackedVisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			this.VisitAttributes(declareDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(declareDeclaration.Modifier);
			this.outputFormatter.PrintToken(88);
			this.outputFormatter.Space();
			switch (declareDeclaration.Charset)
			{
			case CharsetModifier.Auto:
				this.outputFormatter.PrintToken(53);
				this.outputFormatter.Space();
				break;
			case CharsetModifier.Unicode:
				this.outputFormatter.PrintToken(208);
				this.outputFormatter.Space();
				break;
			case CharsetModifier.Ansi:
				this.outputFormatter.PrintToken(49);
				this.outputFormatter.Space();
				break;
			}
			bool flag = declareDeclaration.TypeReference.IsNull || declareDeclaration.TypeReference.Type == "System.Void";
			if (flag)
			{
				this.outputFormatter.PrintToken(195);
			}
			else
			{
				this.outputFormatter.PrintToken(114);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(declareDeclaration.Name);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(135);
			this.outputFormatter.Space();
			this.outputFormatter.PrintText(VBNetOutputVisitor.ConvertString(declareDeclaration.Library));
			this.outputFormatter.Space();
			if (declareDeclaration.Alias.Length > 0)
			{
				this.outputFormatter.PrintToken(46);
				this.outputFormatter.Space();
				this.outputFormatter.PrintText(VBNetOutputVisitor.ConvertString(declareDeclaration.Alias));
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(declareDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			if (!flag)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(declareDeclaration.Attributes, data);
				this.TrackedVisit(declareDeclaration.TypeReference, data);
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			this.outputFormatter.PrintToken(151);
			return null;
		}

		public override object TrackedVisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			this.VisitAttributes(delegateDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(delegateDeclaration.Modifier, true, false);
			this.outputFormatter.PrintToken(90);
			this.outputFormatter.Space();
			bool flag = delegateDeclaration.ReturnType.Type != "System.Void";
			if (flag)
			{
				this.outputFormatter.PrintToken(114);
				this.outputFormatter.Space();
			}
			else
			{
				this.outputFormatter.PrintToken(195);
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintIdentifier(delegateDeclaration.Name);
			this.PrintTemplates(delegateDeclaration.Templates);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(delegateDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			if (flag)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(delegateDeclaration.Attributes, data);
				this.TrackedVisit(delegateDeclaration.ReturnType, data);
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("Protected Overrides Sub Finalize()");
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.exitTokenStack.Push(195);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(203);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(destructorDeclaration.Body, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(110);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("MyBase.Finalize()");
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(203);
			this.outputFormatter.NewLine();
			this.exitTokenStack.Pop();
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(195);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			this.TrackedVisit(directionExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			if (doLoopStatement.ConditionPosition == ConditionPosition.None)
			{
				this.Error(string.Format("Unknown condition position for loop : {0}.", doLoopStatement), doLoopStatement.StartLocation);
			}
			if (doLoopStatement.ConditionPosition == ConditionPosition.Start)
			{
				switch (doLoopStatement.ConditionType)
				{
				case ConditionType.Until:
					this.exitTokenStack.Push(95);
					this.outputFormatter.PrintToken(95);
					this.outputFormatter.Space();
					this.outputFormatter.PrintToken(216);
					break;
				case ConditionType.While:
					this.exitTokenStack.Push(216);
					this.outputFormatter.PrintToken(216);
					break;
				case ConditionType.DoWhile:
					this.exitTokenStack.Push(95);
					this.outputFormatter.PrintToken(95);
					this.outputFormatter.Space();
					this.outputFormatter.PrintToken(216);
					break;
				default:
					throw new InvalidOperationException();
				}
				this.outputFormatter.Space();
				this.TrackedVisit(doLoopStatement.Condition, null);
			}
			else
			{
				this.exitTokenStack.Push(95);
				this.outputFormatter.PrintToken(95);
			}
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(doLoopStatement.EmbeddedStatement);
			this.outputFormatter.Indent();
			if (doLoopStatement.ConditionPosition == ConditionPosition.Start && doLoopStatement.ConditionType == ConditionType.While)
			{
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(216);
			}
			else
			{
				this.outputFormatter.PrintToken(138);
			}
			if (doLoopStatement.ConditionPosition == ConditionPosition.End && !doLoopStatement.Condition.IsNull)
			{
				this.outputFormatter.Space();
				switch (doLoopStatement.ConditionType)
				{
				case ConditionType.Until:
					this.outputFormatter.PrintToken(209);
					break;
				case ConditionType.While:
				case ConditionType.DoWhile:
					this.outputFormatter.PrintToken(216);
					break;
				}
				this.outputFormatter.Space();
				this.TrackedVisit(doLoopStatement.Condition, null);
			}
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(99);
			this.outputFormatter.Space();
			this.TrackedVisit(elseIfSection.Condition, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(199);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(elseIfSection.EmbeddedStatement);
			return null;
		}

		public override object TrackedVisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitEndStatement(EndStatement endStatement, object data)
		{
			this.outputFormatter.PrintToken(100);
			return null;
		}

		public override object TrackedVisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			this.outputFormatter.PrintToken(104);
			this.outputFormatter.Space();
			this.AppendCommaSeparatedList<Expression>(eraseStatement.Expressions);
			return null;
		}

		public override object TrackedVisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			this.outputFormatter.PrintToken(105);
			this.outputFormatter.Space();
			this.TrackedVisit(errorStatement.Expression, data);
			return null;
		}

		public override object TrackedVisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			this.VisitAttributes(eventAddRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("AddHandler(");
			if (eventAddRegion.Parameters.Count == 0)
			{
				this.outputFormatter.PrintToken(59);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier("value");
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.TrackedVisit(this.currentEventType, data);
			}
			else
			{
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(eventAddRegion.Parameters);
			}
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(eventAddRegion.Block, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintText("AddHandler");
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			bool flag = eventDeclaration.HasAddRegion || eventDeclaration.HasRemoveRegion;
			this.VisitAttributes(eventDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(eventDeclaration.Modifier);
			if (flag)
			{
				this.outputFormatter.PrintText("Custom");
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(106);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(eventDeclaration.Name);
			if (eventDeclaration.Parameters.Count > 0)
			{
				this.outputFormatter.PrintToken(25);
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(eventDeclaration.Parameters);
				this.outputFormatter.PrintToken(26);
			}
			if (!eventDeclaration.TypeReference.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(eventDeclaration.Attributes, data);
				this.TrackedVisit(eventDeclaration.TypeReference, data);
			}
			this.PrintInterfaceImplementations(eventDeclaration.InterfaceImplementations);
			if (!eventDeclaration.Initializer.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(10);
				this.outputFormatter.Space();
				this.TrackedVisit(eventDeclaration.Initializer, data);
			}
			this.outputFormatter.NewLine();
			if (flag)
			{
				this.outputFormatter.IndentationLevel++;
				this.currentEventType = eventDeclaration.TypeReference;
				this.exitTokenStack.Push(195);
				this.TrackedVisit(eventDeclaration.AddRegion, data);
				this.TrackedVisit(eventDeclaration.RemoveRegion, data);
				this.exitTokenStack.Pop();
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(106);
				this.outputFormatter.NewLine();
			}
			return null;
		}

		public override object TrackedVisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			this.VisitAttributes(eventRaiseRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("RaiseEvent");
			this.outputFormatter.PrintToken(25);
			if (eventRaiseRegion.Parameters.Count == 0)
			{
				this.outputFormatter.PrintToken(59);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier("value");
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.TrackedVisit(this.currentEventType, data);
			}
			else
			{
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(eventRaiseRegion.Parameters);
			}
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(eventRaiseRegion.Block, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintText("RaiseEvent");
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			this.VisitAttributes(eventRemoveRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintText("RemoveHandler");
			this.outputFormatter.PrintToken(25);
			if (eventRemoveRegion.Parameters.Count == 0)
			{
				this.outputFormatter.PrintToken(59);
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier("value");
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.TrackedVisit(this.currentEventType, data);
			}
			else
			{
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(eventRemoveRegion.Parameters);
			}
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(eventRemoveRegion.Block, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintText("RemoveHandler");
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitExitStatement(ExitStatement exitStatement, object data)
		{
			this.outputFormatter.PrintToken(107);
			if (exitStatement.ExitType != ExitType.None)
			{
				this.outputFormatter.Space();
				switch (exitStatement.ExitType)
				{
				case ExitType.Sub:
					this.outputFormatter.PrintToken(195);
					break;
				case ExitType.Function:
					this.outputFormatter.PrintToken(114);
					break;
				case ExitType.Property:
					this.outputFormatter.PrintToken(171);
					break;
				case ExitType.Do:
					this.outputFormatter.PrintToken(95);
					break;
				case ExitType.For:
					this.outputFormatter.PrintToken(111);
					break;
				case ExitType.While:
					this.outputFormatter.PrintToken(216);
					break;
				case ExitType.Select:
					this.outputFormatter.PrintToken(182);
					break;
				case ExitType.Try:
					this.outputFormatter.PrintToken(203);
					break;
				default:
					this.Error(string.Format("Unsupported exit type : {0}", exitStatement.ExitType), exitStatement.StartLocation);
					break;
				}
			}
			return null;
		}

		public override object TrackedVisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			this.TrackedVisit(expressionStatement.Expression, data);
			return null;
		}

		public override object TrackedVisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			this.UnsupportedNode(externAliasDirective);
			return null;
		}

		public override object TrackedVisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			this.VisitAttributes(fieldDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			if (fieldDeclaration.Modifier == Modifiers.None)
			{
				this.outputFormatter.PrintToken(170);
				this.outputFormatter.Space();
			}
			else
			{
				this.OutputModifier(fieldDeclaration.Modifier, false, true);
			}
			this.currentVariableType = fieldDeclaration.TypeReference;
			this.AppendCommaSeparatedList<VariableDeclaration>(fieldDeclaration.Fields);
			this.currentVariableType = null;
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			this.UnsupportedNode(fixedStatement);
			return this.TrackedVisit(fixedStatement.EmbeddedStatement, data);
		}

		public override object TrackedVisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.exitTokenStack.Push(111);
			this.outputFormatter.PrintToken(111);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(97);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(foreachStatement.VariableName);
			if (!foreachStatement.TypeReference.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.TrackedVisit(foreachStatement.TypeReference, data);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(125);
			this.outputFormatter.Space();
			this.TrackedVisit(foreachStatement.Expression, data);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(foreachStatement.EmbeddedStatement);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(149);
			if (!foreachStatement.NextExpression.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackedVisit(foreachStatement.NextExpression, data);
			}
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			this.exitTokenStack.Push(111);
			this.outputFormatter.PrintToken(111);
			this.outputFormatter.Space();
			if (!forNextStatement.LoopVariableExpression.IsNull)
			{
				this.TrackedVisit(forNextStatement.LoopVariableExpression, data);
			}
			else
			{
				this.outputFormatter.PrintIdentifier(forNextStatement.VariableName);
				if (!forNextStatement.TypeReference.IsNull)
				{
					this.outputFormatter.Space();
					this.outputFormatter.PrintToken(50);
					this.outputFormatter.Space();
					this.TrackedVisit(forNextStatement.TypeReference, data);
				}
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(10);
			this.outputFormatter.Space();
			this.TrackedVisit(forNextStatement.Start, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(201);
			this.outputFormatter.Space();
			this.TrackedVisit(forNextStatement.End, data);
			if (!forNextStatement.Step.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(190);
				this.outputFormatter.Space();
				this.TrackedVisit(forNextStatement.Step, data);
			}
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(forNextStatement.EmbeddedStatement);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(149);
			if (forNextStatement.NextExpressions.Count > 0)
			{
				this.outputFormatter.Space();
				this.AppendCommaSeparatedList<Expression>(forNextStatement.NextExpressions);
			}
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitForStatement(ForStatement forStatement, object data)
		{
			this.exitTokenStack.Push(216);
			bool flag = true;
			foreach (INode current in forStatement.Initializers)
			{
				if (!flag)
				{
					this.outputFormatter.Indent();
				}
				flag = false;
				this.TrackedVisit(current, data);
				this.outputFormatter.NewLine();
			}
			if (!flag)
			{
				this.outputFormatter.Indent();
			}
			this.outputFormatter.PrintToken(216);
			this.outputFormatter.Space();
			if (forStatement.Condition.IsNull)
			{
				this.outputFormatter.PrintToken(202);
			}
			else
			{
				this.TrackedVisit(forStatement.Condition, data);
			}
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(forStatement.EmbeddedStatement);
			this.PrintIndentedBlock(forStatement.Iterator);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(216);
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			this.outputFormatter.PrintText("goto case ");
			if (gotoCaseStatement.IsDefaultCase)
			{
				this.outputFormatter.PrintText("default");
			}
			else
			{
				this.TrackedVisit(gotoCaseStatement.Expression, null);
			}
			return null;
		}

		public override object TrackedVisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			this.outputFormatter.PrintToken(119);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(gotoStatement.Label);
			return null;
		}

		public override object TrackedVisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			this.outputFormatter.PrintIdentifier(identifierExpression.Identifier);
			this.PrintTypeArguments(identifierExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			this.outputFormatter.PrintToken(122);
			this.outputFormatter.Space();
			this.TrackedVisit(ifElseStatement.Condition, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(199);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(ifElseStatement.TrueStatement);
			foreach (ElseIfSection current in ifElseStatement.ElseIfSections)
			{
				this.TrackedVisit(current, data);
			}
			if (ifElseStatement.HasElseStatements)
			{
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(98);
				this.outputFormatter.NewLine();
				this.PrintIndentedBlock(ifElseStatement.FalseStatement);
			}
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(122);
			return null;
		}

		public override object TrackedVisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			this.VisitAttributes(indexerDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(indexerDeclaration.Modifier);
			this.outputFormatter.PrintToken(89);
			this.outputFormatter.Space();
			if (indexerDeclaration.IsReadOnly)
			{
				this.outputFormatter.PrintToken(175);
				this.outputFormatter.Space();
			}
			else if (indexerDeclaration.IsWriteOnly)
			{
				this.outputFormatter.PrintToken(220);
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(171);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier("Item");
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(indexerDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(50);
			this.outputFormatter.Space();
			this.VisitReturnTypeAttributes(indexerDeclaration.Attributes, data);
			this.TrackedVisit(indexerDeclaration.TypeReference, data);
			this.PrintInterfaceImplementations(indexerDeclaration.InterfaceImplementations);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.exitTokenStack.Push(171);
			this.TrackedVisit(indexerDeclaration.GetRegion, data);
			this.TrackedVisit(indexerDeclaration.SetRegion, data);
			this.exitTokenStack.Pop();
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(171);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			this.TrackedVisit(indexerExpression.TargetObject, data);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<Expression>(indexerExpression.Indexes);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			this.TrackedVisit(innerClassTypeReference.BaseType, data);
			this.outputFormatter.PrintToken(16);
			return this.VisitTypeReference(innerClassTypeReference, data);
		}

		public override object TrackedVisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			throw new InvalidOperationException();
		}

		public override object TrackedVisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			this.TrackedVisit(invocationExpression.TargetObject, data);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<Expression>(invocationExpression.Arguments);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitLabelStatement(LabelStatement labelStatement, object data)
		{
			this.outputFormatter.PrintIdentifier(labelStatement.Label);
			this.outputFormatter.PrintToken(11);
			return null;
		}

		public override object TrackedVisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			if (!lambdaExpression.ExpressionBody.IsNull)
			{
				this.outputFormatter.PrintToken(114);
				this.outputFormatter.PrintToken(25);
				this.AppendCommaSeparatedList<ParameterDeclarationExpression>(lambdaExpression.Parameters);
				this.outputFormatter.PrintToken(26);
				this.outputFormatter.Space();
				return lambdaExpression.ExpressionBody.AcceptVisitor(this, data);
			}
			this.OutputAnonymousMethodWithStatementBody(lambdaExpression.Parameters, lambdaExpression.StatementBody);
			return null;
		}

		public override object TrackedVisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			if (localVariableDeclaration.Modifier != Modifiers.None)
			{
				this.OutputModifier(localVariableDeclaration.Modifier & ~Modifiers.Dim);
			}
			if (!this.isUsingResourceAcquisition)
			{
				if ((localVariableDeclaration.Modifier & Modifiers.Const) == Modifiers.None)
				{
					this.outputFormatter.PrintToken(92);
				}
				this.outputFormatter.Space();
			}
			this.currentVariableType = localVariableDeclaration.TypeReference;
			this.AppendCommaSeparatedList<VariableDeclaration>(localVariableDeclaration.Variables);
			this.currentVariableType = null;
			return null;
		}

		public override object TrackedVisitLockStatement(LockStatement lockStatement, object data)
		{
			this.outputFormatter.PrintToken(196);
			this.outputFormatter.Space();
			this.TrackedVisit(lockStatement.LockExpression, data);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(lockStatement.EmbeddedStatement);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(196);
			return null;
		}

		public override object TrackedVisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			this.TrackedVisit(memberReferenceExpression.TargetObject, data);
			this.outputFormatter.PrintToken(16);
			if (string.Equals(memberReferenceExpression.MemberName, "New", StringComparison.OrdinalIgnoreCase) && (memberReferenceExpression.TargetObject is BaseReferenceExpression || memberReferenceExpression.TargetObject is ThisReferenceExpression || memberReferenceExpression.TargetObject is ClassReferenceExpression))
			{
				this.outputFormatter.PrintToken(148);
			}
			else
			{
				this.outputFormatter.PrintIdentifier(memberReferenceExpression.MemberName);
			}
			this.PrintTypeArguments(memberReferenceExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.VisitAttributes(methodDeclaration.Attributes, data);
			if (methodDeclaration.IsExtensionMethod)
			{
				this.outputFormatter.Indent();
				this.outputFormatter.PrintText("<System.Runtime.CompilerServices.Extension> _");
				this.outputFormatter.NewLine();
			}
			this.outputFormatter.Indent();
			this.OutputModifier(methodDeclaration.Modifier);
			bool flag = methodDeclaration.TypeReference.IsNull || methodDeclaration.TypeReference.Type == "System.Void";
			if (flag)
			{
				this.outputFormatter.PrintToken(195);
			}
			else
			{
				this.outputFormatter.PrintToken(114);
			}
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(methodDeclaration.Name);
			this.PrintTemplates(methodDeclaration.Templates);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(methodDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			if (!flag)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(methodDeclaration.Attributes, data);
				this.TrackedVisit(methodDeclaration.TypeReference, data);
			}
			this.PrintInterfaceImplementations(methodDeclaration.InterfaceImplementations);
			if (methodDeclaration.HandlesClause.Count > 0)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(121);
				for (int i = 0; i < methodDeclaration.HandlesClause.Count; i++)
				{
					if (i > 0)
					{
						this.outputFormatter.PrintToken(12);
					}
					this.outputFormatter.Space();
					this.outputFormatter.PrintText(methodDeclaration.HandlesClause[i]);
				}
			}
			this.outputFormatter.NewLine();
			if (!this.IsAbstract(methodDeclaration))
			{
				this.outputFormatter.IsInMemberBody = true;
				this.BeginVisit(methodDeclaration.Body);
				this.outputFormatter.IndentationLevel++;
				this.exitTokenStack.Push(flag ? 195 : 114);
				this.TrackedVisitBlockStatement(methodDeclaration.Body, data);
				this.exitTokenStack.Pop();
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
				if (flag)
				{
					this.outputFormatter.PrintToken(195);
				}
				else
				{
					this.outputFormatter.PrintToken(114);
				}
				this.outputFormatter.NewLine();
				this.EndVisit(methodDeclaration.Body);
				this.outputFormatter.IsInMemberBody = false;
			}
			return null;
		}

		public override object TrackedVisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			this.outputFormatter.PrintIdentifier(namedArgumentExpression.Name);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(11);
			this.outputFormatter.PrintToken(10);
			this.outputFormatter.Space();
			this.TrackedVisit(namedArgumentExpression.Expression, data);
			return null;
		}

		public override object TrackedVisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(146);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(namespaceDeclaration.Name);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			namespaceDeclaration.AcceptChildren(this, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(146);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			this.outputFormatter.PrintToken(148);
			if (!objectCreateExpression.IsAnonymousType)
			{
				this.outputFormatter.Space();
				this.TrackedVisit(objectCreateExpression.CreateType, data);
				this.outputFormatter.PrintToken(25);
				this.AppendCommaSeparatedList<Expression>(objectCreateExpression.Parameters);
				this.outputFormatter.PrintToken(26);
			}
			CollectionInitializerExpression objectInitializer = objectCreateExpression.ObjectInitializer;
			if (!objectInitializer.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(218);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(23);
				this.outputFormatter.IndentationLevel++;
				for (int i = 0; i < objectInitializer.CreateExpressions.Count; i++)
				{
					Expression expression = objectInitializer.CreateExpressions[i];
					if (i > 0)
					{
						this.outputFormatter.PrintToken(12);
					}
					this.outputFormatter.PrintLineContinuation();
					this.outputFormatter.Indent();
					NamedArgumentExpression namedArgumentExpression = expression as NamedArgumentExpression;
					if (namedArgumentExpression != null)
					{
						this.outputFormatter.PrintToken(16);
						this.outputFormatter.PrintIdentifier(namedArgumentExpression.Name);
						this.outputFormatter.Space();
						this.outputFormatter.PrintToken(10);
						this.outputFormatter.Space();
						this.TrackedVisit(namedArgumentExpression.Expression, data);
					}
					else
					{
						this.TrackedVisit(expression, data);
					}
				}
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.PrintLineContinuation();
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(24);
			}
			return null;
		}

		public override object TrackedVisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			this.outputFormatter.PrintToken(157);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(105);
			this.outputFormatter.Space();
			this.TrackedVisit(onErrorStatement.EmbeddedStatement, data);
			return null;
		}

		public override object TrackedVisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			this.VisitAttributes(operatorDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(operatorDeclaration.Modifier);
			if (operatorDeclaration.IsConversionOperator)
			{
				if (operatorDeclaration.ConversionType == ConversionType.Implicit)
				{
					this.outputFormatter.PrintToken(217);
				}
				else
				{
					this.outputFormatter.PrintToken(147);
				}
				this.outputFormatter.Space();
			}
			this.outputFormatter.PrintToken(158);
			this.outputFormatter.Space();
			int num = -1;
			switch (operatorDeclaration.OverloadableOperator)
			{
			case OverloadableOperatorType.Add:
			case OverloadableOperatorType.UnaryPlus:
				num = 19;
				break;
			case OverloadableOperatorType.Subtract:
			case OverloadableOperatorType.UnaryMinus:
				num = 18;
				break;
			case OverloadableOperatorType.Multiply:
				num = 22;
				break;
			case OverloadableOperatorType.Divide:
				num = 14;
				break;
			case OverloadableOperatorType.Modulus:
				num = 140;
				break;
			case OverloadableOperatorType.Concat:
				num = 13;
				break;
			case OverloadableOperatorType.Not:
				num = 150;
				break;
			case OverloadableOperatorType.BitNot:
				num = 150;
				break;
			case OverloadableOperatorType.BitwiseAnd:
				num = 47;
				break;
			case OverloadableOperatorType.BitwiseOr:
				num = 161;
				break;
			case OverloadableOperatorType.ExclusiveOr:
				num = 221;
				break;
			case OverloadableOperatorType.ShiftLeft:
				num = 32;
				break;
			case OverloadableOperatorType.ShiftRight:
				num = 33;
				break;
			case OverloadableOperatorType.GreaterThan:
				num = 27;
				break;
			case OverloadableOperatorType.GreaterThanOrEqual:
				num = 30;
				break;
			case OverloadableOperatorType.Equality:
				num = 10;
				break;
			case OverloadableOperatorType.InEquality:
				num = 29;
				break;
			case OverloadableOperatorType.LessThan:
				num = 28;
				break;
			case OverloadableOperatorType.LessThanOrEqual:
				num = 31;
				break;
			case OverloadableOperatorType.Increment:
				this.Error("Increment operator is not supported in Visual Basic", operatorDeclaration.StartLocation);
				break;
			case OverloadableOperatorType.Decrement:
				this.Error("Decrement operator is not supported in Visual Basic", operatorDeclaration.StartLocation);
				break;
			case OverloadableOperatorType.IsTrue:
				this.outputFormatter.PrintText("IsTrue");
				break;
			case OverloadableOperatorType.IsFalse:
				this.outputFormatter.PrintText("IsFalse");
				break;
			case OverloadableOperatorType.Like:
				num = 136;
				break;
			case OverloadableOperatorType.Power:
				num = 20;
				break;
			case OverloadableOperatorType.CType:
				num = 81;
				break;
			case OverloadableOperatorType.DivideInteger:
				num = 15;
				break;
			}
			if (operatorDeclaration.IsConversionOperator)
			{
				this.outputFormatter.PrintToken(81);
			}
			else if (num != -1)
			{
				this.outputFormatter.PrintToken(num);
			}
			this.PrintTemplates(operatorDeclaration.Templates);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(operatorDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			if (!operatorDeclaration.TypeReference.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(operatorDeclaration.Attributes, data);
				this.TrackedVisit(operatorDeclaration.TypeReference, data);
			}
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(operatorDeclaration.Body, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(158);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			this.outputFormatter.PrintToken(159);
			this.outputFormatter.Space();
			switch (optionDeclaration.OptionType)
			{
			case OptionType.Explicit:
				this.outputFormatter.PrintToken(108);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(optionDeclaration.OptionValue ? 157 : 156);
				break;
			case OptionType.Strict:
				this.outputFormatter.PrintToken(192);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(optionDeclaration.OptionValue ? 157 : 156);
				break;
			case OptionType.CompareBinary:
				this.outputFormatter.PrintToken(74);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(54);
				break;
			case OptionType.CompareText:
				this.outputFormatter.PrintToken(74);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(198);
				break;
			case OptionType.Infer:
				this.outputFormatter.PrintToken(126);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(optionDeclaration.OptionValue ? 157 : 156);
				break;
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			this.printAttributeSectionInline = true;
			this.VisitAttributes(parameterDeclarationExpression.Attributes, data);
			this.printAttributeSectionInline = false;
			this.OutputModifier(parameterDeclarationExpression.ParamModifier, parameterDeclarationExpression.StartLocation);
			this.outputFormatter.PrintIdentifier(parameterDeclarationExpression.ParameterName);
			if (!parameterDeclarationExpression.TypeReference.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				this.VisitReturnTypeAttributes(parameterDeclarationExpression.Attributes, data);
				this.TrackedVisit(parameterDeclarationExpression.TypeReference, data);
			}
			if (!parameterDeclarationExpression.DefaultValue.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(10);
				this.outputFormatter.Space();
				this.TrackedVisit(parameterDeclarationExpression.DefaultValue, data);
			}
			return null;
		}

		public override object TrackedVisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			this.outputFormatter.PrintToken(25);
			this.TrackedVisit(parenthesizedExpression.Expression, data);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			this.UnsupportedNode(pointerReferenceExpression);
			this.TrackedVisit(pointerReferenceExpression.TargetObject, data);
			this.outputFormatter.PrintText(".");
			this.outputFormatter.PrintIdentifier(pointerReferenceExpression.MemberName);
			this.PrintTypeArguments(pointerReferenceExpression.TypeArguments);
			return null;
		}

		public override object TrackedVisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			this.outputFormatter.PrintText(VBNetOutputVisitor.ToVBNetString(primitiveExpression));
			return null;
		}

		public override object TrackedVisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			this.VisitAttributes(propertyDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(propertyDeclaration.Modifier);
			if ((propertyDeclaration.Modifier & (Modifiers.ReadOnly | Modifiers.WriteOnly)) == Modifiers.None)
			{
				if (propertyDeclaration.IsReadOnly)
				{
					this.outputFormatter.PrintToken(175);
					this.outputFormatter.Space();
				}
				else if (propertyDeclaration.IsWriteOnly)
				{
					this.outputFormatter.PrintToken(220);
					this.outputFormatter.Space();
				}
			}
			this.outputFormatter.PrintToken(171);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(propertyDeclaration.Name);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<ParameterDeclarationExpression>(propertyDeclaration.Parameters);
			this.outputFormatter.PrintToken(26);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(50);
			this.outputFormatter.Space();
			this.VisitReturnTypeAttributes(propertyDeclaration.Attributes, data);
			this.TrackedVisit(propertyDeclaration.TypeReference, data);
			this.PrintInterfaceImplementations(propertyDeclaration.InterfaceImplementations);
			this.outputFormatter.NewLine();
			if (!this.IsAbstract(propertyDeclaration))
			{
				this.outputFormatter.IsInMemberBody = true;
				this.outputFormatter.IndentationLevel++;
				this.exitTokenStack.Push(171);
				this.TrackedVisit(propertyDeclaration.GetRegion, data);
				this.TrackedVisit(propertyDeclaration.SetRegion, data);
				this.exitTokenStack.Pop();
				this.outputFormatter.IndentationLevel--;
				this.outputFormatter.IsInMemberBody = false;
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(100);
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(171);
				this.outputFormatter.NewLine();
			}
			return null;
		}

		public override object TrackedVisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			this.VisitAttributes(propertyGetRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(propertyGetRegion.Modifier);
			this.outputFormatter.PrintToken(115);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(propertyGetRegion.Block, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(115);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			this.VisitAttributes(propertySetRegion.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(propertySetRegion.Modifier);
			this.outputFormatter.PrintToken(183);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			this.TrackedVisit(propertySetRegion.Block, data);
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(183);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitQueryExpression(QueryExpression queryExpression, object data)
		{
			if (queryExpression.IsQueryContinuation)
			{
				queryExpression.FromClause.InExpression.AcceptVisitor(this, data);
			}
			this.outputFormatter.IndentationLevel++;
			if (queryExpression.IsQueryContinuation)
			{
				this.outputFormatter.PrintToken(130);
				this.outputFormatter.PrintIdentifier(queryExpression.FromClause.Identifier);
			}
			else
			{
				queryExpression.FromClause.AcceptVisitor(this, data);
			}
			queryExpression.MiddleClauses.ForEach(new Action<QueryExpressionClause>(this.PrintClause));
			this.PrintClause(queryExpression.SelectOrGroupClause);
			this.outputFormatter.IndentationLevel--;
			return null;
		}

		public override object TrackedVisitQueryExpressionFromClause(QueryExpressionFromClause fromClause, object data)
		{
			this.outputFormatter.PrintText("From");
			this.outputFormatter.Space();
			this.VisitQueryExpressionFromOrJoinClause(fromClause, data);
			return null;
		}

		public override object TrackedVisitQueryExpressionGroupClause(QueryExpressionGroupClause groupClause, object data)
		{
			this.outputFormatter.PrintText("Group");
			this.outputFormatter.Space();
			groupClause.Projection.AcceptVisitor(this, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintText("By");
			this.outputFormatter.Space();
			return groupClause.GroupBy.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionJoinClause(QueryExpressionJoinClause joinClause, object data)
		{
			this.outputFormatter.PrintText("Join");
			this.outputFormatter.Space();
			this.VisitQueryExpressionFromOrJoinClause(joinClause, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(157);
			this.outputFormatter.Space();
			joinClause.OnExpression.AcceptVisitor(this, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(10);
			this.outputFormatter.Space();
			joinClause.EqualsExpression.AcceptVisitor(this, data);
			if (!string.IsNullOrEmpty(joinClause.IntoIdentifier))
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintText("Into");
				this.outputFormatter.Space();
				this.outputFormatter.PrintIdentifier(joinClause.IntoIdentifier);
			}
			return null;
		}

		public override object TrackedVisitQueryExpressionLetClause(QueryExpressionLetClause letClause, object data)
		{
			this.outputFormatter.PrintToken(134);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(letClause.Identifier);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(10);
			this.outputFormatter.Space();
			return letClause.Expression.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			this.outputFormatter.PrintText("Order By");
			this.outputFormatter.Space();
			this.AppendCommaSeparatedList<QueryExpressionOrdering>(queryExpressionOrderClause.Orderings);
			return null;
		}

		public override object TrackedVisitQueryExpressionOrdering(QueryExpressionOrdering ordering, object data)
		{
			ordering.Criteria.AcceptVisitor(this, data);
			if (ordering.Direction == QueryExpressionOrderingDirection.Ascending)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintText("Ascending");
			}
			else if (ordering.Direction == QueryExpressionOrderingDirection.Descending)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintText("Descending");
			}
			return null;
		}

		public override object TrackedVisitQueryExpressionSelectClause(QueryExpressionSelectClause selectClause, object data)
		{
			this.outputFormatter.PrintToken(182);
			this.outputFormatter.Space();
			return selectClause.Projection.AcceptVisitor(this, data);
		}

		public override object TrackedVisitQueryExpressionWhereClause(QueryExpressionWhereClause whereClause, object data)
		{
			this.outputFormatter.PrintText("Where");
			this.outputFormatter.Space();
			return whereClause.Condition.AcceptVisitor(this, data);
		}

		public override object TrackedVisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			this.outputFormatter.PrintToken(174);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(raiseEventStatement.EventName);
			this.outputFormatter.PrintToken(25);
			this.AppendCommaSeparatedList<Expression>(raiseEventStatement.Arguments);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			this.outputFormatter.PrintToken(176);
			this.outputFormatter.Space();
			if (reDimStatement.IsPreserve)
			{
				this.outputFormatter.PrintToken(169);
				this.outputFormatter.Space();
			}
			this.AppendCommaSeparatedList<InvocationExpression>(reDimStatement.ReDimClauses);
			return null;
		}

		public override object TrackedVisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			this.outputFormatter.PrintToken(178);
			this.outputFormatter.Space();
			this.TrackedVisit(removeHandlerStatement.EventExpression, data);
			this.outputFormatter.PrintToken(12);
			this.outputFormatter.Space();
			this.TrackedVisit(removeHandlerStatement.HandlerExpression, data);
			return null;
		}

		public override object TrackedVisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			this.outputFormatter.PrintToken(179);
			this.outputFormatter.Space();
			if (resumeStatement.IsResumeNext)
			{
				this.outputFormatter.PrintToken(149);
			}
			else
			{
				this.outputFormatter.PrintIdentifier(resumeStatement.LabelName);
			}
			return null;
		}

		public override object TrackedVisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			this.outputFormatter.PrintToken(180);
			if (!returnStatement.Expression.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackedVisit(returnStatement.Expression, data);
			}
			return null;
		}

		public override object TrackedVisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			string type;
			if (!sizeOfExpression.TypeReference.IsArrayType && sizeOfExpression.TypeReference.PointerNestingLevel == 0 && (type = sizeOfExpression.TypeReference.Type) != null)
			{
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000639-1 == null)
				{
					<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000639-1 = new Dictionary<string, int>(11)
					{
						{
							"System.Byte",
							0
						},
						{
							"System.SByte",
							1
						},
						{
							"System.Char",
							2
						},
						{
							"System.Int16",
							3
						},
						{
							"System.UInt16",
							4
						},
						{
							"System.Single",
							5
						},
						{
							"System.Int32",
							6
						},
						{
							"System.UInt32",
							7
						},
						{
							"System.Double",
							8
						},
						{
							"System.Int64",
							9
						},
						{
							"System.UInt64",
							10
						}
					};
				}
				int num;
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000639-1.TryGetValue(type, out num))
				{
					switch (num)
					{
					case 0:
					case 1:
						this.outputFormatter.PrintText("1");
						return null;
					case 2:
					case 3:
					case 4:
						this.outputFormatter.PrintText("2");
						return null;
					case 5:
					case 6:
					case 7:
						this.outputFormatter.PrintText("4");
						return null;
					case 8:
					case 9:
					case 10:
						this.outputFormatter.PrintText("8");
						return null;
					}
				}
			}
			this.UnsupportedNode(sizeOfExpression);
			this.outputFormatter.PrintText("sizeof(");
			this.TrackedVisit(sizeOfExpression.TypeReference, data);
			this.outputFormatter.PrintText(")");
			return null;
		}

		public override object TrackedVisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			this.UnsupportedNode(stackAllocExpression);
			this.outputFormatter.PrintText("stackalloc");
			return null;
		}

		public override object TrackedVisitStopStatement(StopStatement stopStatement, object data)
		{
			this.outputFormatter.PrintToken(191);
			return null;
		}

		public override object TrackedVisitSwitchSection(SwitchSection switchSection, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(61);
			this.outputFormatter.Space();
			this.AppendCommaSeparatedList<CaseLabel>(switchSection.SwitchLabels);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(switchSection.Children);
			return null;
		}

		public override object TrackedVisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			this.exitTokenStack.Push(182);
			this.outputFormatter.PrintToken(182);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(61);
			this.outputFormatter.Space();
			this.TrackedVisit(switchStatement.SwitchExpression, data);
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			foreach (SwitchSection current in switchStatement.SwitchSections)
			{
				this.TrackedVisit(current, data);
			}
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(182);
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			this.VisitAttributes(templateDefinition.Attributes, data);
			this.outputFormatter.PrintIdentifier(templateDefinition.Name);
			if (templateDefinition.Bases.Count > 0)
			{
				this.outputFormatter.PrintText(" As ");
				this.VisitReturnTypeAttributes(templateDefinition.Attributes, data);
				if (templateDefinition.Bases.Count == 1)
				{
					this.TrackedVisit(templateDefinition.Bases[0], data);
				}
				else
				{
					this.outputFormatter.PrintToken(23);
					this.AppendCommaSeparatedList<TypeReference>(templateDefinition.Bases);
					this.outputFormatter.PrintToken(24);
				}
			}
			return null;
		}

		public override object TrackedVisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			this.outputFormatter.PrintToken(139);
			return null;
		}

		public override object TrackedVisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			this.outputFormatter.PrintToken(200);
			if (!throwStatement.Expression.IsNull)
			{
				this.outputFormatter.Space();
				this.TrackedVisit(throwStatement.Expression, data);
			}
			return null;
		}

		public override object TrackedVisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			this.exitTokenStack.Push(203);
			this.outputFormatter.PrintToken(203);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(tryCatchStatement.StatementBlock);
			foreach (CatchClause current in tryCatchStatement.CatchClauses)
			{
				this.TrackedVisit(current, data);
			}
			if (!tryCatchStatement.FinallyBlock.IsNull)
			{
				this.outputFormatter.Indent();
				this.outputFormatter.PrintToken(110);
				this.outputFormatter.NewLine();
				this.PrintIndentedBlock(tryCatchStatement.FinallyBlock);
			}
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(203);
			this.exitTokenStack.Pop();
			return null;
		}

		public override object TrackedVisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			this.VisitAttributes(typeDeclaration.Attributes, data);
			this.outputFormatter.Indent();
			this.OutputModifier(typeDeclaration.Modifier, true, false);
			int typeToken = VBNetOutputVisitor.GetTypeToken(typeDeclaration);
			this.outputFormatter.PrintToken(typeToken);
			this.outputFormatter.Space();
			this.outputFormatter.PrintIdentifier(typeDeclaration.Name);
			this.PrintTemplates(typeDeclaration.Templates);
			if (typeDeclaration.Type == ClassType.Enum && typeDeclaration.BaseTypes != null && typeDeclaration.BaseTypes.Count > 0)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				foreach (TypeReference current in typeDeclaration.BaseTypes)
				{
					this.TrackedVisit(current, data);
				}
			}
			this.outputFormatter.NewLine();
			this.outputFormatter.IndentationLevel++;
			if (typeDeclaration.BaseTypes != null && typeDeclaration.Type != ClassType.Enum)
			{
				foreach (TypeReference current2 in typeDeclaration.BaseTypes)
				{
					this.outputFormatter.Indent();
					string text = current2.Type;
					if (text.IndexOf('.') >= 0)
					{
						text = text.Substring(text.LastIndexOf('.') + 1);
					}
					bool flag = text.Length >= 2 && text[0] == 'I' && char.IsUpper(text[1]);
					if (!flag || typeDeclaration.Type == ClassType.Interface)
					{
						this.outputFormatter.PrintToken(127);
					}
					else
					{
						this.outputFormatter.PrintToken(123);
					}
					this.outputFormatter.Space();
					this.TrackedVisit(current2, data);
					this.outputFormatter.NewLine();
				}
			}
			TypeDeclaration typeDeclaration2 = this.currentType;
			this.currentType = typeDeclaration;
			if (typeDeclaration.Type == ClassType.Enum)
			{
				this.OutputEnumMembers(typeDeclaration, data);
			}
			else
			{
				typeDeclaration.AcceptChildren(this, data);
			}
			this.currentType = typeDeclaration2;
			this.outputFormatter.IndentationLevel--;
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(typeToken);
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			this.outputFormatter.PrintToken(116);
			this.outputFormatter.PrintToken(25);
			this.TrackedVisit(typeOfExpression.TypeReference, data);
			this.outputFormatter.PrintToken(26);
			return null;
		}

		public override object TrackedVisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			this.outputFormatter.PrintToken(205);
			this.outputFormatter.Space();
			this.TrackedVisit(typeOfIsExpression.Expression, data);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(131);
			this.outputFormatter.Space();
			this.TrackedVisit(typeOfIsExpression.TypeReference, data);
			return null;
		}

		public override object TrackedVisitTypeReference(TypeReference typeReference, object data)
		{
			if (typeReference == TypeReference.ClassConstraint)
			{
				this.outputFormatter.PrintToken(71);
			}
			else if (typeReference == TypeReference.StructConstraint)
			{
				this.outputFormatter.PrintToken(194);
			}
			else if (typeReference == TypeReference.NewConstraint)
			{
				this.outputFormatter.PrintToken(148);
			}
			else
			{
				this.PrintTypeReferenceWithoutArray(typeReference);
				if (typeReference.IsArrayType)
				{
					this.PrintArrayRank(typeReference.RankSpecifier, 0);
				}
			}
			return null;
		}

		public override object TrackedVisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			this.TrackedVisit(typeReferenceExpression.TypeReference, data);
			return null;
		}

		public override object TrackedVisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			switch (unaryOperatorExpression.Op)
			{
			case UnaryOperatorType.Not:
			case UnaryOperatorType.BitNot:
				this.outputFormatter.PrintToken(150);
				this.outputFormatter.Space();
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				return null;
			case UnaryOperatorType.Minus:
				this.outputFormatter.PrintToken(18);
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				return null;
			case UnaryOperatorType.Plus:
				this.outputFormatter.PrintToken(19);
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				return null;
			case UnaryOperatorType.Increment:
				this.outputFormatter.PrintText("System.Threading.Interlocked.Increment(");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText(")");
				return null;
			case UnaryOperatorType.Decrement:
				this.outputFormatter.PrintText("System.Threading.Interlocked.Decrement(");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText(")");
				return null;
			case UnaryOperatorType.PostIncrement:
				this.outputFormatter.PrintText("System.Math.Max(System.Threading.Interlocked.Increment(");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText("),");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText(" - 1)");
				return null;
			case UnaryOperatorType.PostDecrement:
				this.outputFormatter.PrintText("System.Math.Max(System.Threading.Interlocked.Decrement(");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText("),");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText(" + 1)");
				return null;
			case UnaryOperatorType.Dereference:
				this.outputFormatter.PrintToken(22);
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				return null;
			case UnaryOperatorType.AddressOf:
				this.outputFormatter.PrintToken(44);
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				return null;
			default:
				this.Error("unknown unary operator: " + unaryOperatorExpression.Op.ToString(), unaryOperatorExpression.StartLocation);
				this.outputFormatter.PrintText(unaryOperatorExpression.Op.ToString());
				this.outputFormatter.PrintText("(");
				this.TrackedVisit(unaryOperatorExpression.Expression, data);
				this.outputFormatter.PrintText(")");
				return null;
			}
		}

		public override object TrackedVisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			this.UnsupportedNode(uncheckedExpression);
			return this.TrackedVisit(uncheckedExpression.Expression, data);
		}

		public override object TrackedVisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			this.UnsupportedNode(uncheckedStatement);
			return this.TrackedVisit(uncheckedStatement.Block, data);
		}

		public override object TrackedVisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			this.UnsupportedNode(unsafeStatement);
			return this.TrackedVisit(unsafeStatement.Block, data);
		}

		public override object TrackedVisitUsing(Using @using, object data)
		{
			return null;
		}

		public override object TrackedVisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(124);
			this.outputFormatter.Space();
			for (int i = 0; i < usingDeclaration.Usings.Count; i++)
			{
				this.outputFormatter.PrintIdentifier(usingDeclaration.Usings[i].Name);
				if (usingDeclaration.Usings[i].IsAlias)
				{
					this.outputFormatter.Space();
					this.outputFormatter.PrintToken(10);
					this.outputFormatter.Space();
					this.TrackedVisit(usingDeclaration.Usings[i].Alias, data);
				}
				if (i + 1 < usingDeclaration.Usings.Count)
				{
					this.outputFormatter.PrintToken(12);
					this.outputFormatter.Space();
				}
			}
			this.outputFormatter.NewLine();
			return null;
		}

		public override object TrackedVisitUsingStatement(UsingStatement usingStatement, object data)
		{
			this.outputFormatter.PrintToken(211);
			this.outputFormatter.Space();
			this.isUsingResourceAcquisition = true;
			this.TrackedVisit(usingStatement.ResourceAcquisition, data);
			this.isUsingResourceAcquisition = false;
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(usingStatement.EmbeddedStatement);
			this.outputFormatter.Indent();
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(211);
			return null;
		}

		public override object TrackedVisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			this.outputFormatter.PrintIdentifier(variableDeclaration.Name);
			TypeReference typeReference = this.currentVariableType;
			if (typeReference != null && typeReference.IsNull)
			{
				typeReference = null;
			}
			if (typeReference == null && !variableDeclaration.TypeReference.IsNull)
			{
				typeReference = variableDeclaration.TypeReference;
			}
			if (typeReference != null)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(50);
				this.outputFormatter.Space();
				ObjectCreateExpression objectCreateExpression = variableDeclaration.Initializer as ObjectCreateExpression;
				if (objectCreateExpression != null && TypeReference.AreEqualReferences(objectCreateExpression.CreateType, typeReference))
				{
					this.TrackedVisit(variableDeclaration.Initializer, data);
					return null;
				}
				this.TrackedVisit(typeReference, data);
			}
			if (!variableDeclaration.Initializer.IsNull)
			{
				this.outputFormatter.Space();
				this.outputFormatter.PrintToken(10);
				this.outputFormatter.Space();
				this.TrackedVisit(variableDeclaration.Initializer, data);
			}
			return null;
		}

		public override object TrackedVisitWithStatement(WithStatement withStatement, object data)
		{
			this.outputFormatter.PrintToken(218);
			this.outputFormatter.Space();
			this.TrackedVisit(withStatement.Expression, data);
			this.outputFormatter.NewLine();
			this.PrintIndentedBlock(withStatement.Body);
			this.outputFormatter.PrintToken(100);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(218);
			return null;
		}

		public override object TrackedVisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			this.UnsupportedNode(yieldStatement);
			this.outputFormatter.PrintText("yield ");
			this.TrackedVisit(yieldStatement.Statement, data);
			return null;
		}

		private void UnsupportedNode(INode node)
		{
			this.Error(node.GetType().Name + " is unsupported", node.StartLocation);
		}

		private void VisitAttributes(ICollection attributes, object data)
		{
			if (attributes == null)
			{
				return;
			}
			foreach (AttributeSection attributeSection in attributes)
			{
				if (!string.Equals(attributeSection.AttributeTarget, "return", StringComparison.OrdinalIgnoreCase))
				{
					this.TrackedVisit(attributeSection, data);
				}
			}
		}

		private void VisitQueryExpressionFromOrJoinClause(QueryExpressionFromOrJoinClause clause, object data)
		{
			this.outputFormatter.PrintIdentifier(clause.Identifier);
			this.outputFormatter.Space();
			this.outputFormatter.PrintToken(125);
			this.outputFormatter.Space();
			clause.InExpression.AcceptVisitor(this, data);
		}

		private void VisitReturnTypeAttributes(ICollection attributes, object data)
		{
			if (attributes == null)
			{
				return;
			}
			this.printAttributeSectionInline = true;
			foreach (AttributeSection attributeSection in attributes)
			{
				if (string.Equals(attributeSection.AttributeTarget, "return", StringComparison.OrdinalIgnoreCase))
				{
					this.TrackedVisit(attributeSection, data);
				}
			}
			this.printAttributeSectionInline = false;
		}

		private void VisitStatementList(IEnumerable statements)
		{
			foreach (Statement statement in statements)
			{
				if (statement is BlockStatement)
				{
					this.TrackedVisit(statement, null);
				}
				else
				{
					this.outputFormatter.Indent();
					this.TrackedVisit(statement, null);
					this.outputFormatter.NewLine();
				}
			}
		}

		public Errors Errors
		{
			get
			{
				return this.errors;
			}
		}

		AbstractPrettyPrintOptions IOutputAstVisitor.Options
		{
			get
			{
				return this.prettyPrintOptions;
			}
		}

		public VBNetPrettyPrintOptions Options
		{
			get
			{
				return this.prettyPrintOptions;
			}
		}

		public IOutputFormatter OutputFormatter
		{
			get
			{
				return this.outputFormatter;
			}
		}

		public string Text
		{
			get
			{
				return this.outputFormatter.Text;
			}
		}

		public event Action<INode> AfterNodeVisit
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.AfterNodeVisit = (Action<INode>)Delegate.Combine(this.AfterNodeVisit, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.AfterNodeVisit = (Action<INode>)Delegate.Remove(this.AfterNodeVisit, value);
			}
		}

		public event Action<INode> BeforeNodeVisit
		{
			[MethodImpl(MethodImplOptions.Synchronized)]
			add
			{
				this.BeforeNodeVisit = (Action<INode>)Delegate.Combine(this.BeforeNodeVisit, value);
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			remove
			{
				this.BeforeNodeVisit = (Action<INode>)Delegate.Remove(this.BeforeNodeVisit, value);
			}
		}

		private TypeReference currentEventType;

		private TypeDeclaration currentType;

		private TypeReference currentVariableType;

		private Errors errors = new Errors();

		private Stack<int> exitTokenStack = new Stack<int>();

		private bool isUsingResourceAcquisition;

		private VBNetOutputFormatter outputFormatter;

		private VBNetPrettyPrintOptions prettyPrintOptions = new VBNetPrettyPrintOptions();

		private bool printAttributeSectionInline;
	}
}
