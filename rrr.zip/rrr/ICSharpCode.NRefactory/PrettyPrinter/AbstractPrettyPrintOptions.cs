﻿using System;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public class AbstractPrettyPrintOptions
	{
		public char IndentationChar
		{
			get
			{
				return this.indentationChar;
			}
			set
			{
				this.indentationChar = value;
			}
		}

		public int IndentSize
		{
			get
			{
				return this.indentSize;
			}
			set
			{
				this.indentSize = value;
			}
		}

		public int TabSize
		{
			get
			{
				return this.tabSize;
			}
			set
			{
				this.tabSize = value;
			}
		}

		private char indentationChar = '\t';

		private int indentSize = 4;

		private int tabSize = 4;
	}
}
