﻿using System;
using ICSharpCode.NRefactory.Parser.VB;

namespace ICSharpCode.NRefactory.PrettyPrinter
{
	public sealed class VBNetOutputFormatter : AbstractOutputFormatter
	{
		public VBNetOutputFormatter(VBNetPrettyPrintOptions prettyPrintOptions) : base(prettyPrintOptions)
		{
		}

		public override void PrintComment(Comment comment, bool forceWriteInPreviousBlock)
		{
			switch (comment.CommentType)
			{
			case CommentType.Block:
				base.WriteLineInPreviousLine("'" + comment.CommentText.Replace("\n", "\n'"), forceWriteInPreviousBlock);
				return;
			case CommentType.Documentation:
				base.WriteLineInPreviousLine("'''" + comment.CommentText, forceWriteInPreviousBlock);
				return;
			}
			base.WriteLineInPreviousLine("'" + comment.CommentText, forceWriteInPreviousBlock);
		}

		public override void PrintIdentifier(string identifier)
		{
			if (Keywords.IsNonIdentifierKeyword(identifier))
			{
				base.PrintText("[");
				base.PrintText(identifier);
				base.PrintText("]");
				return;
			}
			base.PrintText(identifier);
		}

		public void PrintLineContinuation()
		{
			if (!base.LastCharacterIsWhiteSpace)
			{
				base.Space();
			}
			base.PrintText("_" + Environment.NewLine);
		}

		public override void PrintPreprocessingDirective(PreprocessingDirective directive, bool forceWriteInPreviousBlock)
		{
			if (base.IsInMemberBody && (string.Equals(directive.Cmd, "#Region", StringComparison.InvariantCultureIgnoreCase) || (string.Equals(directive.Cmd, "#End", StringComparison.InvariantCultureIgnoreCase) && directive.Arg.StartsWith("Region", StringComparison.InvariantCultureIgnoreCase))))
			{
				base.WriteLineInPreviousLine("'" + directive.Cmd + " " + directive.Arg, forceWriteInPreviousBlock);
				return;
			}
			if (!directive.Expression.IsNull)
			{
				VBNetOutputVisitor vBNetOutputVisitor = new VBNetOutputVisitor();
				directive.Expression.AcceptVisitor(vBNetOutputVisitor, null);
				base.WriteLineInPreviousLine(directive.Cmd + " " + vBNetOutputVisitor.Text + " Then", forceWriteInPreviousBlock);
				return;
			}
			base.PrintPreprocessingDirective(directive, forceWriteInPreviousBlock);
		}

		public override void PrintToken(int token)
		{
			base.PrintText(Tokens.GetTokenString(token));
		}
	}
}
