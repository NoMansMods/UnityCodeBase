﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.AstBuilder;

namespace ICSharpCode.NRefactory.Visitors
{
	public class ToVBNetConvertVisitor : ConvertVisitorBase
	{
		private void AddInlineAssignHelper()
		{
			MethodDeclaration methodDeclaration;
			foreach (INode current in this.currentType.Children)
			{
				methodDeclaration = (current as MethodDeclaration);
				if (methodDeclaration != null && methodDeclaration.Name == "InlineAssignHelper")
				{
					return;
				}
			}
			methodDeclaration = new MethodDeclaration
			{
				Name = "InlineAssignHelper",
				Modifier = (Modifiers.Private | Modifiers.Static),
				TypeReference = new TypeReference("T"),
				Parameters = new List<ParameterDeclarationExpression>
				{
					new ParameterDeclarationExpression(new TypeReference("T"), "target", ParameterModifiers.Ref),
					new ParameterDeclarationExpression(new TypeReference("T"), "value")
				}
			};
			methodDeclaration.Templates.Add(new TemplateDefinition("T", null));
			methodDeclaration.Body = new BlockStatement();
			methodDeclaration.Body.AddChild(new ExpressionStatement(new AssignmentExpression(new IdentifierExpression("target"), AssignmentOperatorType.Assign, new IdentifierExpression("value"))));
			methodDeclaration.Body.AddChild(new ReturnStatement(new IdentifierExpression("value")));
			this.currentType.AddChild(methodDeclaration);
		}

		private bool ConvertPInvoke(MethodDeclaration method, ICSharpCode.NRefactory.Ast.Attribute att)
		{
			if (att.PositionalArguments.Count != 1)
			{
				return false;
			}
			PrimitiveExpression primitiveExpression = att.PositionalArguments[0] as PrimitiveExpression;
			if (primitiveExpression == null || !(primitiveExpression.Value is string))
			{
				return false;
			}
			string library = (string)primitiveExpression.Value;
			string alias = null;
			bool flag = false;
			bool flag2 = false;
			CharsetModifier charset = CharsetModifier.Auto;
			foreach (NamedArgumentExpression current in att.NamedArguments)
			{
				string name;
				bool result;
				if ((name = current.Name) != null)
				{
					if (!(name == "SetLastError"))
					{
						if (!(name == "ExactSpelling"))
						{
							if (!(name == "CharSet"))
							{
								if (name == "EntryPoint")
								{
									primitiveExpression = (current.Expression as PrimitiveExpression);
									if (primitiveExpression != null)
									{
										alias = (primitiveExpression.Value as string);
										continue;
									}
									continue;
								}
							}
							else
							{
								MemberReferenceExpression memberReferenceExpression = current.Expression as MemberReferenceExpression;
								if (memberReferenceExpression == null || !(memberReferenceExpression.TargetObject is IdentifierExpression))
								{
									result = false;
									return result;
								}
								if ((memberReferenceExpression.TargetObject as IdentifierExpression).Identifier != "CharSet")
								{
									result = false;
									return result;
								}
								string memberName;
								if ((memberName = memberReferenceExpression.MemberName) != null)
								{
									if (memberName == "Unicode")
									{
										charset = CharsetModifier.Unicode;
										continue;
									}
									if (memberName == "Auto")
									{
										charset = CharsetModifier.Auto;
										continue;
									}
									if (memberName == "Ansi")
									{
										charset = CharsetModifier.Ansi;
										continue;
									}
								}
								result = false;
								return result;
							}
						}
						else
						{
							primitiveExpression = (current.Expression as PrimitiveExpression);
							if (primitiveExpression != null && primitiveExpression.Value is bool)
							{
								flag2 = (bool)primitiveExpression.Value;
								continue;
							}
							result = false;
							return result;
						}
					}
					else
					{
						primitiveExpression = (current.Expression as PrimitiveExpression);
						if (primitiveExpression != null && primitiveExpression.Value is bool)
						{
							flag = (bool)primitiveExpression.Value;
							continue;
						}
						result = false;
						return result;
					}
				}
				result = false;
				return result;
			}
			if (flag && flag2)
			{
				DeclareDeclaration declareDeclaration = new DeclareDeclaration(method.Name, method.Modifier & ~(Modifiers.Static | Modifiers.Extern), method.TypeReference, method.Parameters, method.Attributes, library, alias, charset);
				base.ReplaceCurrentNode(declareDeclaration);
				base.VisitDeclareDeclaration(declareDeclaration, null);
				return true;
			}
			return false;
		}

		private static string GetMemberNameOnThisReference(Expression expr)
		{
			IdentifierExpression identifierExpression = expr as IdentifierExpression;
			if (identifierExpression != null)
			{
				return identifierExpression.Identifier;
			}
			MemberReferenceExpression memberReferenceExpression = expr as MemberReferenceExpression;
			if (memberReferenceExpression != null && memberReferenceExpression.TargetObject is ThisReferenceExpression)
			{
				return memberReferenceExpression.MemberName;
			}
			return null;
		}

		private bool IsClassType(ClassType c)
		{
			return this.currentType != null && this.currentType.Type == c;
		}

		public override object VisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			base.VisitAnonymousMethodExpression(anonymousMethodExpression, data);
			if (anonymousMethodExpression.Body.Children.Count == 1)
			{
				ReturnStatement returnStatement = anonymousMethodExpression.Body.Children[0] as ReturnStatement;
				if (returnStatement != null)
				{
					base.ReplaceCurrentNode(new LambdaExpression
					{
						ExpressionBody = returnStatement.Expression,
						Parameters = anonymousMethodExpression.Parameters
					});
				}
			}
			return null;
		}

		public override object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			for (int i = 0; i < arrayCreateExpression.Arguments.Count; i++)
			{
				arrayCreateExpression.Arguments[i] = Expression.AddInteger(arrayCreateExpression.Arguments[i], -1);
			}
			return base.VisitArrayCreateExpression(arrayCreateExpression, data);
		}

		public override object VisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			base.VisitAssignmentExpression(assignmentExpression, data);
			if (assignmentExpression.Op == AssignmentOperatorType.Assign && !(assignmentExpression.Parent is ExpressionStatement))
			{
				this.AddInlineAssignHelper();
				base.ReplaceCurrentNode(new InvocationExpression(new IdentifierExpression("InlineAssignHelper"), new List<Expression>
				{
					assignmentExpression.Left,
					assignmentExpression.Right
				}));
			}
			return null;
		}

		public override object VisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			base.VisitBaseReferenceExpression(baseReferenceExpression, data);
			if (baseReferenceExpression.Parent is IndexerExpression)
			{
				base.ReplaceCurrentNode(new MemberReferenceExpression(baseReferenceExpression, "Item"));
			}
			return null;
		}

		public override object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			base.VisitCompilationUnit(compilationUnit, data);
			for (int i = 0; i < this.nodesToMoveToCompilationUnit.Count; i++)
			{
				compilationUnit.Children.Insert(i, this.nodesToMoveToCompilationUnit[i]);
				this.nodesToMoveToCompilationUnit[i].Parent = compilationUnit;
			}
			return null;
		}

		public override object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			if ((constructorDeclaration.Modifier & (Modifiers.Private | Modifiers.Internal | Modifiers.Protected | Modifiers.Public | Modifiers.Static)) == Modifiers.None)
			{
				constructorDeclaration.Modifier |= Modifiers.Private;
			}
			base.VisitConstructorDeclaration(constructorDeclaration, data);
			ToVBNetRenameConflictingVariablesVisitor.RenameConflicting(constructorDeclaration);
			return null;
		}

		public override object VisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			base.VisitDefaultValueExpression(defaultValueExpression, data);
			Expression expression = ExpressionBuilder.CreateDefaultValueForType(defaultValueExpression.TypeReference);
			if (!(expression is DefaultValueExpression))
			{
				base.ReplaceCurrentNode(expression);
			}
			return null;
		}

		public override object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			if (this.currentType != null && (delegateDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				delegateDeclaration.Modifier |= Modifiers.Private;
			}
			return base.VisitDelegateDeclaration(delegateDeclaration, data);
		}

		public override object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (eventDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				eventDeclaration.Modifier |= Modifiers.Private;
			}
			return base.VisitEventDeclaration(eventDeclaration, data);
		}

		public override object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			base.VisitExpressionStatement(expressionStatement, data);
			AssignmentExpression assignmentExpression = expressionStatement.Expression as AssignmentExpression;
			if (assignmentExpression != null && assignmentExpression.Right is AddressOfExpression)
			{
				if (assignmentExpression.Op == AssignmentOperatorType.Add)
				{
					base.ReplaceCurrentNode(new AddHandlerStatement(assignmentExpression.Left, assignmentExpression.Right));
				}
				else if (assignmentExpression.Op == AssignmentOperatorType.Subtract)
				{
					base.ReplaceCurrentNode(new RemoveHandlerStatement(assignmentExpression.Left, assignmentExpression.Right));
				}
			}
			return null;
		}

		public override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			if (localVariableDeclaration.TypeReference.Type == "var")
			{
				localVariableDeclaration.TypeReference = TypeReference.Null;
			}
			return base.VisitLocalVariableDeclaration(localVariableDeclaration, data);
		}

		public override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (methodDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				methodDeclaration.Modifier |= Modifiers.Private;
			}
			base.VisitMethodDeclaration(methodDeclaration, data);
			if ((methodDeclaration.Modifier & (Modifiers.Static | Modifiers.Extern)) == (Modifiers.Static | Modifiers.Extern) && methodDeclaration.Body.IsNull)
			{
				foreach (AttributeSection current in methodDeclaration.Attributes)
				{
					foreach (ICSharpCode.NRefactory.Ast.Attribute current2 in current.Attributes)
					{
						if ("DllImport".Equals(current2.Name, StringComparison.InvariantCultureIgnoreCase) && this.ConvertPInvoke(methodDeclaration, current2))
						{
							current.Attributes.Remove(current2);
							break;
						}
					}
					if (current.Attributes.Count == 0)
					{
						methodDeclaration.Attributes.Remove(current);
						break;
					}
				}
			}
			ToVBNetRenameConflictingVariablesVisitor.RenameConflicting(methodDeclaration);
			return null;
		}

		public override object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			base.VisitParenthesizedExpression(parenthesizedExpression, data);
			if (parenthesizedExpression.Expression is CastExpression)
			{
				base.ReplaceCurrentNode(parenthesizedExpression.Expression);
			}
			else if (parenthesizedExpression.Parent is CastExpression)
			{
				base.ReplaceCurrentNode(parenthesizedExpression.Expression);
			}
			return null;
		}

		public override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (propertyDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				propertyDeclaration.Modifier |= Modifiers.Private;
			}
			base.VisitPropertyDeclaration(propertyDeclaration, data);
			ToVBNetRenameConflictingVariablesVisitor.RenameConflicting(propertyDeclaration);
			if (!this.IsClassType(ClassType.Interface) && (propertyDeclaration.Modifier & Modifiers.Dim) == Modifiers.None && propertyDeclaration.HasGetRegion && propertyDeclaration.HasSetRegion && propertyDeclaration.GetRegion.Block.IsNull && propertyDeclaration.SetRegion.Block.IsNull)
			{
				string text = "m_" + propertyDeclaration.Name;
				Modifiers modifier = (propertyDeclaration.Modifier & ~(Modifiers.Private | Modifiers.Internal | Modifiers.Protected | Modifiers.Public)) | Modifiers.Private;
				base.InsertAfterSibling(propertyDeclaration, new FieldDeclaration(null, propertyDeclaration.TypeReference, modifier)
				{
					Fields = 
					{
						new VariableDeclaration(text)
					}
				});
				propertyDeclaration.GetRegion.Block = new BlockStatement();
				propertyDeclaration.GetRegion.Block.Return(ExpressionBuilder.Identifier(text));
				propertyDeclaration.SetRegion.Block = new BlockStatement();
				propertyDeclaration.SetRegion.Block.Assign(ExpressionBuilder.Identifier(text), ExpressionBuilder.Identifier("Value"));
			}
			return null;
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			if (this.currentType != null && (typeDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				typeDeclaration.Modifier |= Modifiers.Private;
			}
			TypeDeclaration typeDeclaration2 = this.currentType;
			this.currentType = typeDeclaration;
			if ((typeDeclaration.Modifier & Modifiers.Static) == Modifiers.Static)
			{
				typeDeclaration.Modifier &= ~Modifiers.Static;
				typeDeclaration.Modifier |= Modifiers.Sealed;
				typeDeclaration.Children.Insert(0, new ConstructorDeclaration("#ctor", Modifiers.Private, null, null));
			}
			List<string> list = new List<string>();
			foreach (object current in typeDeclaration.Children)
			{
				PropertyDeclaration propertyDeclaration = current as PropertyDeclaration;
				if (propertyDeclaration != null)
				{
					list.Add(propertyDeclaration.Name);
				}
			}
			List<VariableDeclaration> list2 = new List<VariableDeclaration>();
			foreach (object current2 in typeDeclaration.Children)
			{
				FieldDeclaration fieldDeclaration = current2 as FieldDeclaration;
				if (fieldDeclaration != null)
				{
					foreach (VariableDeclaration current3 in fieldDeclaration.Fields)
					{
						string name = current3.Name;
						foreach (string current4 in list)
						{
							if (name.Equals(current4, StringComparison.InvariantCultureIgnoreCase))
							{
								list2.Add(current3);
							}
						}
					}
				}
			}
			new PrefixFieldsVisitor(list2, "m_").Run(typeDeclaration);
			base.VisitTypeDeclaration(typeDeclaration, data);
			this.currentType = typeDeclaration2;
			return null;
		}

		public override object VisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			base.VisitUsingDeclaration(usingDeclaration, data);
			if (usingDeclaration.Parent is NamespaceDeclaration)
			{
				this.nodesToMoveToCompilationUnit.Add(usingDeclaration);
				base.RemoveCurrentNode();
			}
			return null;
		}

		private TypeDeclaration currentType;

		private List<INode> nodesToMoveToCompilationUnit = new List<INode>();
	}
}
