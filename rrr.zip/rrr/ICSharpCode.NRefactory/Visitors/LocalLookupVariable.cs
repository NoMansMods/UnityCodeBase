﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public sealed class LocalLookupVariable
	{
		public LocalLookupVariable(string name, TypeReference typeRef, Location startPos, Location endPos, bool isConst, bool isLoopVariable, Expression initializer, LambdaExpression parentLambdaExpression, bool isQueryContinuation)
		{
			this.Name = name;
			this.TypeRef = typeRef;
			this.StartPos = startPos;
			this.EndPos = endPos;
			this.IsConst = isConst;
			this.IsLoopVariable = isLoopVariable;
			this.Initializer = initializer;
			this.ParentLambdaExpression = parentLambdaExpression;
			this.IsQueryContinuation = isQueryContinuation;
		}

		public readonly Location EndPos;

		public readonly Expression Initializer;

		public readonly bool IsConst;

		public readonly bool IsLoopVariable;

		public readonly bool IsQueryContinuation;

		public readonly string Name;

		public readonly LambdaExpression ParentLambdaExpression;

		public readonly Location StartPos;

		public readonly TypeReference TypeRef;
	}
}
