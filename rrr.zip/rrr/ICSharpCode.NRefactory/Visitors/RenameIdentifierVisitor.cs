﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	internal class RenameIdentifierVisitor : AbstractAstVisitor
	{
		public RenameIdentifierVisitor(string from, string to, StringComparer nameComparer)
		{
			this.nameComparer = nameComparer;
			this.from = from;
			this.to = to;
		}

		public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			if (this.nameComparer.Equals(identifierExpression.Identifier, this.from))
			{
				identifierExpression.Identifier = this.to;
			}
			return base.VisitIdentifierExpression(identifierExpression, data);
		}

		protected string from;

		protected StringComparer nameComparer;

		protected string to;
	}
}
