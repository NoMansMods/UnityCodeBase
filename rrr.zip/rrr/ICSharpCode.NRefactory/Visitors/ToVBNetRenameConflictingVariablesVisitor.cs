﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	internal static class ToVBNetRenameConflictingVariablesVisitor
	{
		private static void AddVariableToDict(Dictionary<string, string> caseInsensitive, string varName, bool hasDeclaration)
		{
			string text;
			if (caseInsensitive.TryGetValue(varName, out text))
			{
				if (text != null && text != varName)
				{
					caseInsensitive[varName] = null;
					return;
				}
			}
			else if (hasDeclaration)
			{
				caseInsensitive.Add(varName, varName);
			}
		}

		public static void RenameConflicting(ParametrizedNode method)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			LookupTableVisitor lookupTableVisitor = new LookupTableVisitor(SupportedLanguage.CSharp);
			method.AcceptVisitor(lookupTableVisitor, null);
			foreach (ParameterDeclarationExpression current in method.Parameters)
			{
				ToVBNetRenameConflictingVariablesVisitor.AddVariableToDict(dictionary, current.ParameterName, true);
			}
			foreach (KeyValuePair<string, List<LocalLookupVariable>> current2 in lookupTableVisitor.Variables)
			{
				ToVBNetRenameConflictingVariablesVisitor.AddVariableToDict(dictionary, current2.Key, true);
			}
			ToVBNetRenameConflictingVariablesVisitor.FindIdentifiersVisitor findIdentifiersVisitor = new ToVBNetRenameConflictingVariablesVisitor.FindIdentifiersVisitor();
			method.AcceptVisitor(findIdentifiersVisitor, null);
			foreach (KeyValuePair<string, string> current3 in findIdentifiersVisitor.usedIdentifiers)
			{
				ToVBNetRenameConflictingVariablesVisitor.AddVariableToDict(dictionary, current3.Key, false);
			}
			int num = 0;
			foreach (ParameterDeclarationExpression current4 in method.Parameters)
			{
				if (dictionary[current4.ParameterName] == null)
				{
					ToVBNetRenameConflictingVariablesVisitor.RenameVariable(method, current4.ParameterName, ref num);
				}
			}
			foreach (KeyValuePair<string, List<LocalLookupVariable>> current5 in lookupTableVisitor.Variables)
			{
				if (dictionary[current5.Key] == null)
				{
					ToVBNetRenameConflictingVariablesVisitor.RenameVariable(method, current5.Key, ref num);
				}
			}
		}

		private static void RenameVariable(INode method, string from, ref int index)
		{
			index++;
			method.AcceptVisitor(new RenameLocalVariableVisitor(from, from + "__" + index, StringComparer.Ordinal), null);
		}

		private sealed class FindIdentifiersVisitor : AbstractAstVisitor
		{
			public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
			{
				this.usedIdentifiers[identifierExpression.Identifier] = null;
				return null;
			}

			internal readonly Dictionary<string, string> usedIdentifiers = new Dictionary<string, string>();
		}
	}
}
