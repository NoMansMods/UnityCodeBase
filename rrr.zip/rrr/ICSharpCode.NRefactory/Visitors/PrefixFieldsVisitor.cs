﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public class PrefixFieldsVisitor : AbstractAstVisitor
	{
		public PrefixFieldsVisitor(List<VariableDeclaration> fields, string prefix)
		{
			this.fields = fields;
			this.prefix = prefix;
		}

		private bool IsLocal(string name)
		{
			foreach (List<string> current in this.blocks)
			{
				if (current.Contains(name))
				{
					return true;
				}
			}
			return this.curBlock.Contains(name);
		}

		private void Pop()
		{
			this.curBlock = this.blocks.Pop();
		}

		private void Push()
		{
			this.blocks.Push(this.curBlock);
			this.curBlock = new List<string>();
		}

		public void Run(INode typeDeclaration)
		{
			typeDeclaration.AcceptVisitor(this, null);
			foreach (VariableDeclaration current in this.fields)
			{
				current.Name = this.prefix + current.Name;
			}
		}

		public override object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			this.Push();
			object result = base.VisitBlockStatement(blockStatement, data);
			this.Pop();
			return result;
		}

		public override object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			this.Push();
			object result = base.VisitConstructorDeclaration(constructorDeclaration, data);
			this.Pop();
			return result;
		}

		public override object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.curBlock.Add(foreachStatement.VariableName);
			return base.VisitForeachStatement(foreachStatement, data);
		}

		public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			string identifier = identifierExpression.Identifier;
			foreach (VariableDeclaration current in this.fields)
			{
				if (current.Name == identifier && !this.IsLocal(identifier))
				{
					identifierExpression.Identifier = this.prefix + identifier;
					break;
				}
			}
			return base.VisitIdentifierExpression(identifierExpression, data);
		}

		public override object VisitMemberReferenceExpression(MemberReferenceExpression fieldReferenceExpression, object data)
		{
			if (fieldReferenceExpression.TargetObject is ThisReferenceExpression)
			{
				string memberName = fieldReferenceExpression.MemberName;
				foreach (VariableDeclaration current in this.fields)
				{
					if (current.Name == memberName)
					{
						fieldReferenceExpression.MemberName = this.prefix + memberName;
						break;
					}
				}
			}
			return base.VisitMemberReferenceExpression(fieldReferenceExpression, data);
		}

		public override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.Push();
			object result = base.VisitMethodDeclaration(methodDeclaration, data);
			this.Pop();
			return result;
		}

		public override object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			this.curBlock.Add(parameterDeclarationExpression.ParameterName);
			return base.VisitParameterDeclarationExpression(parameterDeclarationExpression, data);
		}

		public override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			this.Push();
			object result = base.VisitPropertyDeclaration(propertyDeclaration, data);
			this.Pop();
			return result;
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			this.Push();
			object result = base.VisitTypeDeclaration(typeDeclaration, data);
			this.Pop();
			return result;
		}

		public override object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			if (this.fields.Contains(variableDeclaration))
			{
				return null;
			}
			this.curBlock.Add(variableDeclaration.Name);
			return base.VisitVariableDeclaration(variableDeclaration, data);
		}

		private Stack<List<string>> blocks = new Stack<List<string>>();

		private List<string> curBlock = new List<string>();

		private List<VariableDeclaration> fields;

		private string prefix;
	}
}
