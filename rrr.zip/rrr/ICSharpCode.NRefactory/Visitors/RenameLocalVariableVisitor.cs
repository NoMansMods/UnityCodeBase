﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	internal sealed class RenameLocalVariableVisitor : RenameIdentifierVisitor
	{
		public RenameLocalVariableVisitor(string from, string to, StringComparer nameComparer) : base(from, to, nameComparer)
		{
		}

		public override object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			if (this.nameComparer.Equals(this.from, foreachStatement.VariableName))
			{
				foreachStatement.VariableName = this.to;
			}
			return base.VisitForeachStatement(foreachStatement, data);
		}

		public override object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			if (this.nameComparer.Equals(this.from, parameterDeclarationExpression.ParameterName))
			{
				parameterDeclarationExpression.ParameterName = this.to;
			}
			return base.VisitParameterDeclarationExpression(parameterDeclarationExpression, data);
		}

		public override object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			if (this.nameComparer.Equals(this.from, variableDeclaration.Name))
			{
				variableDeclaration.Name = this.to;
			}
			return base.VisitVariableDeclaration(variableDeclaration, data);
		}
	}
}
