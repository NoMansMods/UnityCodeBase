﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public class ConvertVisitorBase : AbstractAstTransformer
	{
		protected void InsertAfterSibling(INode sibling, INode newNode)
		{
			if (sibling == null || sibling.Parent == null)
			{
				return;
			}
			int num = sibling.Parent.Children.IndexOf(sibling);
			sibling.Parent.Children.Insert(num + 1, newNode);
			newNode.Parent = sibling.Parent;
		}

		protected void InsertBeforeSibling(INode sibling, INode newNode)
		{
			if (sibling == null)
			{
				return;
			}
			if (!(sibling.Parent is TypeDeclaration))
			{
				throw new NotSupportedException();
			}
			this.insertions.Add(new KeyValuePair<INode, INode>(sibling, newNode));
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			object result = base.VisitTypeDeclaration(typeDeclaration, data);
			for (int i = 0; i < this.insertions.Count; i++)
			{
				if (this.insertions[i].Key.Parent == typeDeclaration)
				{
					INode key = this.insertions[i].Key;
					INode value = this.insertions[i].Value;
					int index = key.Parent.Children.IndexOf(key);
					key.Parent.Children.Insert(index, value);
					value.Parent = key.Parent;
					this.insertions.RemoveAt(i--);
				}
			}
			return result;
		}

		private List<KeyValuePair<INode, INode>> insertions = new List<KeyValuePair<INode, INode>>();
	}
}
