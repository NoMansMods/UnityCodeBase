﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public abstract class AbstractAstTransformer : IAstVisitor
	{
		public void RemoveCurrentNode()
		{
			this.nodeStack.Pop();
			this.nodeStack.Push(null);
		}

		public void ReplaceCurrentNode(INode newNode)
		{
			this.nodeStack.Pop();
			this.nodeStack.Push(newNode);
		}

		public virtual object VisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			this.nodeStack.Push(addHandlerStatement.EventExpression);
			addHandlerStatement.EventExpression.AcceptVisitor(this, data);
			addHandlerStatement.EventExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(addHandlerStatement.HandlerExpression);
			addHandlerStatement.HandlerExpression.AcceptVisitor(this, data);
			addHandlerStatement.HandlerExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			this.nodeStack.Push(addressOfExpression.Expression);
			addressOfExpression.Expression.AcceptVisitor(this, data);
			addressOfExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			for (int i = 0; i < anonymousMethodExpression.Parameters.Count; i++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = anonymousMethodExpression.Parameters[i];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					anonymousMethodExpression.Parameters.RemoveAt(i--);
				}
				else
				{
					anonymousMethodExpression.Parameters[i] = parameterDeclarationExpression;
				}
			}
			this.nodeStack.Push(anonymousMethodExpression.Body);
			anonymousMethodExpression.Body.AcceptVisitor(this, data);
			anonymousMethodExpression.Body = (BlockStatement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			this.nodeStack.Push(arrayCreateExpression.CreateType);
			arrayCreateExpression.CreateType.AcceptVisitor(this, data);
			arrayCreateExpression.CreateType = (TypeReference)this.nodeStack.Pop();
			for (int i = 0; i < arrayCreateExpression.Arguments.Count; i++)
			{
				Expression expression = arrayCreateExpression.Arguments[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					arrayCreateExpression.Arguments.RemoveAt(i--);
				}
				else
				{
					arrayCreateExpression.Arguments[i] = expression;
				}
			}
			this.nodeStack.Push(arrayCreateExpression.ArrayInitializer);
			arrayCreateExpression.ArrayInitializer.AcceptVisitor(this, data);
			arrayCreateExpression.ArrayInitializer = (CollectionInitializerExpression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			this.nodeStack.Push(assignmentExpression.Left);
			assignmentExpression.Left.AcceptVisitor(this, data);
			assignmentExpression.Left = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(assignmentExpression.Right);
			assignmentExpression.Right.AcceptVisitor(this, data);
			assignmentExpression.Right = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			for (int i = 0; i < attribute.PositionalArguments.Count; i++)
			{
				Expression expression = attribute.PositionalArguments[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					attribute.PositionalArguments.RemoveAt(i--);
				}
				else
				{
					attribute.PositionalArguments[i] = expression;
				}
			}
			for (int j = 0; j < attribute.NamedArguments.Count; j++)
			{
				NamedArgumentExpression namedArgumentExpression = attribute.NamedArguments[j];
				this.nodeStack.Push(namedArgumentExpression);
				namedArgumentExpression.AcceptVisitor(this, data);
				namedArgumentExpression = (NamedArgumentExpression)this.nodeStack.Pop();
				if (namedArgumentExpression == null)
				{
					attribute.NamedArguments.RemoveAt(j--);
				}
				else
				{
					attribute.NamedArguments[j] = namedArgumentExpression;
				}
			}
			return null;
		}

		public virtual object VisitAttributeSection(AttributeSection attributeSection, object data)
		{
			for (int i = 0; i < attributeSection.Attributes.Count; i++)
			{
				ICSharpCode.NRefactory.Ast.Attribute attribute = attributeSection.Attributes[i];
				this.nodeStack.Push(attribute);
				attribute.AcceptVisitor(this, data);
				attribute = (ICSharpCode.NRefactory.Ast.Attribute)this.nodeStack.Pop();
				if (attribute == null)
				{
					attributeSection.Attributes.RemoveAt(i--);
				}
				else
				{
					attributeSection.Attributes[i] = attribute;
				}
			}
			return null;
		}

		public virtual object VisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			this.nodeStack.Push(binaryOperatorExpression.Left);
			binaryOperatorExpression.Left.AcceptVisitor(this, data);
			binaryOperatorExpression.Left = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(binaryOperatorExpression.Right);
			binaryOperatorExpression.Right.AcceptVisitor(this, data);
			binaryOperatorExpression.Right = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			for (int i = 0; i < blockStatement.Children.Count; i++)
			{
				INode node = blockStatement.Children[i];
				this.nodeStack.Push(node);
				node.AcceptVisitor(this, data);
				node = this.nodeStack.Pop();
				if (node == null)
				{
					blockStatement.Children.RemoveAt(i--);
				}
				else
				{
					blockStatement.Children[i] = node;
				}
			}
			return null;
		}

		public virtual object VisitBreakStatement(BreakStatement breakStatement, object data)
		{
			return null;
		}

		public virtual object VisitCaseLabel(CaseLabel caseLabel, object data)
		{
			this.nodeStack.Push(caseLabel.Label);
			caseLabel.Label.AcceptVisitor(this, data);
			caseLabel.Label = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(caseLabel.ToExpression);
			caseLabel.ToExpression.AcceptVisitor(this, data);
			caseLabel.ToExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitCastExpression(CastExpression castExpression, object data)
		{
			this.nodeStack.Push(castExpression.CastTo);
			castExpression.CastTo.AcceptVisitor(this, data);
			castExpression.CastTo = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(castExpression.Expression);
			castExpression.Expression.AcceptVisitor(this, data);
			castExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitCatchClause(CatchClause catchClause, object data)
		{
			this.nodeStack.Push(catchClause.TypeReference);
			catchClause.TypeReference.AcceptVisitor(this, data);
			catchClause.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(catchClause.StatementBlock);
			catchClause.StatementBlock.AcceptVisitor(this, data);
			catchClause.StatementBlock = (Statement)this.nodeStack.Pop();
			this.nodeStack.Push(catchClause.Condition);
			catchClause.Condition.AcceptVisitor(this, data);
			catchClause.Condition = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			this.nodeStack.Push(checkedExpression.Expression);
			checkedExpression.Expression.AcceptVisitor(this, data);
			checkedExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			this.nodeStack.Push(checkedStatement.Block);
			checkedStatement.Block.AcceptVisitor(this, data);
			checkedStatement.Block = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitCollectionInitializerExpression(CollectionInitializerExpression collectionInitializerExpression, object data)
		{
			for (int i = 0; i < collectionInitializerExpression.CreateExpressions.Count; i++)
			{
				Expression expression = collectionInitializerExpression.CreateExpressions[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					collectionInitializerExpression.CreateExpressions.RemoveAt(i--);
				}
				else
				{
					collectionInitializerExpression.CreateExpressions[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			for (int i = 0; i < compilationUnit.Children.Count; i++)
			{
				INode node = compilationUnit.Children[i];
				this.nodeStack.Push(node);
				node.AcceptVisitor(this, data);
				node = this.nodeStack.Pop();
				if (node == null)
				{
					compilationUnit.Children.RemoveAt(i--);
				}
				else
				{
					compilationUnit.Children[i] = node;
				}
			}
			return null;
		}

		public virtual object VisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			this.nodeStack.Push(conditionalExpression.Condition);
			conditionalExpression.Condition.AcceptVisitor(this, data);
			conditionalExpression.Condition = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(conditionalExpression.TrueExpression);
			conditionalExpression.TrueExpression.AcceptVisitor(this, data);
			conditionalExpression.TrueExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(conditionalExpression.FalseExpression);
			conditionalExpression.FalseExpression.AcceptVisitor(this, data);
			conditionalExpression.FalseExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			for (int i = 0; i < constructorDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = constructorDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					constructorDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					constructorDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < constructorDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = constructorDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					constructorDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					constructorDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			this.nodeStack.Push(constructorDeclaration.ConstructorInitializer);
			constructorDeclaration.ConstructorInitializer.AcceptVisitor(this, data);
			constructorDeclaration.ConstructorInitializer = (ConstructorInitializer)this.nodeStack.Pop();
			this.nodeStack.Push(constructorDeclaration.Body);
			constructorDeclaration.Body.AcceptVisitor(this, data);
			constructorDeclaration.Body = (BlockStatement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			for (int i = 0; i < constructorInitializer.Arguments.Count; i++)
			{
				Expression expression = constructorInitializer.Arguments[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					constructorInitializer.Arguments.RemoveAt(i--);
				}
				else
				{
					constructorInitializer.Arguments[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			return null;
		}

		public virtual object VisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			for (int i = 0; i < declareDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = declareDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					declareDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					declareDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < declareDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = declareDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					declareDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					declareDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			this.nodeStack.Push(declareDeclaration.TypeReference);
			declareDeclaration.TypeReference.AcceptVisitor(this, data);
			declareDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			this.nodeStack.Push(defaultValueExpression.TypeReference);
			defaultValueExpression.TypeReference.AcceptVisitor(this, data);
			defaultValueExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			for (int i = 0; i < delegateDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = delegateDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					delegateDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					delegateDeclaration.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(delegateDeclaration.ReturnType);
			delegateDeclaration.ReturnType.AcceptVisitor(this, data);
			delegateDeclaration.ReturnType = (TypeReference)this.nodeStack.Pop();
			for (int j = 0; j < delegateDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = delegateDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					delegateDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					delegateDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < delegateDeclaration.Templates.Count; k++)
			{
				TemplateDefinition templateDefinition = delegateDeclaration.Templates[k];
				this.nodeStack.Push(templateDefinition);
				templateDefinition.AcceptVisitor(this, data);
				templateDefinition = (TemplateDefinition)this.nodeStack.Pop();
				if (templateDefinition == null)
				{
					delegateDeclaration.Templates.RemoveAt(k--);
				}
				else
				{
					delegateDeclaration.Templates[k] = templateDefinition;
				}
			}
			return null;
		}

		public virtual object VisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			for (int i = 0; i < destructorDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = destructorDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					destructorDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					destructorDeclaration.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(destructorDeclaration.Body);
			destructorDeclaration.Body.AcceptVisitor(this, data);
			destructorDeclaration.Body = (BlockStatement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			this.nodeStack.Push(directionExpression.Expression);
			directionExpression.Expression.AcceptVisitor(this, data);
			directionExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			this.nodeStack.Push(doLoopStatement.Condition);
			doLoopStatement.Condition.AcceptVisitor(this, data);
			doLoopStatement.Condition = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(doLoopStatement.EmbeddedStatement);
			doLoopStatement.EmbeddedStatement.AcceptVisitor(this, data);
			doLoopStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			this.nodeStack.Push(elseIfSection.Condition);
			elseIfSection.Condition.AcceptVisitor(this, data);
			elseIfSection.Condition = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(elseIfSection.EmbeddedStatement);
			elseIfSection.EmbeddedStatement.AcceptVisitor(this, data);
			elseIfSection.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			return null;
		}

		public virtual object VisitEndStatement(EndStatement endStatement, object data)
		{
			return null;
		}

		public virtual object VisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			for (int i = 0; i < eraseStatement.Expressions.Count; i++)
			{
				Expression expression = eraseStatement.Expressions[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					eraseStatement.Expressions.RemoveAt(i--);
				}
				else
				{
					eraseStatement.Expressions[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			this.nodeStack.Push(errorStatement.Expression);
			errorStatement.Expression.AcceptVisitor(this, data);
			errorStatement.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			for (int i = 0; i < eventAddRegion.Attributes.Count; i++)
			{
				AttributeSection attributeSection = eventAddRegion.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					eventAddRegion.Attributes.RemoveAt(i--);
				}
				else
				{
					eventAddRegion.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(eventAddRegion.Block);
			eventAddRegion.Block.AcceptVisitor(this, data);
			eventAddRegion.Block = (BlockStatement)this.nodeStack.Pop();
			for (int j = 0; j < eventAddRegion.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = eventAddRegion.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					eventAddRegion.Parameters.RemoveAt(j--);
				}
				else
				{
					eventAddRegion.Parameters[j] = parameterDeclarationExpression;
				}
			}
			return null;
		}

		public virtual object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			for (int i = 0; i < eventDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = eventDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					eventDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					eventDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < eventDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = eventDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					eventDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					eventDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < eventDeclaration.InterfaceImplementations.Count; k++)
			{
				InterfaceImplementation interfaceImplementation = eventDeclaration.InterfaceImplementations[k];
				this.nodeStack.Push(interfaceImplementation);
				interfaceImplementation.AcceptVisitor(this, data);
				interfaceImplementation = (InterfaceImplementation)this.nodeStack.Pop();
				if (interfaceImplementation == null)
				{
					eventDeclaration.InterfaceImplementations.RemoveAt(k--);
				}
				else
				{
					eventDeclaration.InterfaceImplementations[k] = interfaceImplementation;
				}
			}
			this.nodeStack.Push(eventDeclaration.TypeReference);
			eventDeclaration.TypeReference.AcceptVisitor(this, data);
			eventDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(eventDeclaration.AddRegion);
			eventDeclaration.AddRegion.AcceptVisitor(this, data);
			eventDeclaration.AddRegion = (EventAddRegion)this.nodeStack.Pop();
			this.nodeStack.Push(eventDeclaration.RemoveRegion);
			eventDeclaration.RemoveRegion.AcceptVisitor(this, data);
			eventDeclaration.RemoveRegion = (EventRemoveRegion)this.nodeStack.Pop();
			this.nodeStack.Push(eventDeclaration.RaiseRegion);
			eventDeclaration.RaiseRegion.AcceptVisitor(this, data);
			eventDeclaration.RaiseRegion = (EventRaiseRegion)this.nodeStack.Pop();
			this.nodeStack.Push(eventDeclaration.Initializer);
			eventDeclaration.Initializer.AcceptVisitor(this, data);
			eventDeclaration.Initializer = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			for (int i = 0; i < eventRaiseRegion.Attributes.Count; i++)
			{
				AttributeSection attributeSection = eventRaiseRegion.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					eventRaiseRegion.Attributes.RemoveAt(i--);
				}
				else
				{
					eventRaiseRegion.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(eventRaiseRegion.Block);
			eventRaiseRegion.Block.AcceptVisitor(this, data);
			eventRaiseRegion.Block = (BlockStatement)this.nodeStack.Pop();
			for (int j = 0; j < eventRaiseRegion.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = eventRaiseRegion.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					eventRaiseRegion.Parameters.RemoveAt(j--);
				}
				else
				{
					eventRaiseRegion.Parameters[j] = parameterDeclarationExpression;
				}
			}
			return null;
		}

		public virtual object VisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			for (int i = 0; i < eventRemoveRegion.Attributes.Count; i++)
			{
				AttributeSection attributeSection = eventRemoveRegion.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					eventRemoveRegion.Attributes.RemoveAt(i--);
				}
				else
				{
					eventRemoveRegion.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(eventRemoveRegion.Block);
			eventRemoveRegion.Block.AcceptVisitor(this, data);
			eventRemoveRegion.Block = (BlockStatement)this.nodeStack.Pop();
			for (int j = 0; j < eventRemoveRegion.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = eventRemoveRegion.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					eventRemoveRegion.Parameters.RemoveAt(j--);
				}
				else
				{
					eventRemoveRegion.Parameters[j] = parameterDeclarationExpression;
				}
			}
			return null;
		}

		public virtual object VisitExitStatement(ExitStatement exitStatement, object data)
		{
			return null;
		}

		public virtual object VisitExpressionRangeVariable(ExpressionRangeVariable expressionRangeVariable, object data)
		{
			this.nodeStack.Push(expressionRangeVariable.Expression);
			expressionRangeVariable.Expression.AcceptVisitor(this, data);
			expressionRangeVariable.Expression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(expressionRangeVariable.Type);
			expressionRangeVariable.Type.AcceptVisitor(this, data);
			expressionRangeVariable.Type = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			this.nodeStack.Push(expressionStatement.Expression);
			expressionStatement.Expression.AcceptVisitor(this, data);
			expressionStatement.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			return null;
		}

		public virtual object VisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			for (int i = 0; i < fieldDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = fieldDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					fieldDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					fieldDeclaration.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(fieldDeclaration.TypeReference);
			fieldDeclaration.TypeReference.AcceptVisitor(this, data);
			fieldDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			for (int j = 0; j < fieldDeclaration.Fields.Count; j++)
			{
				VariableDeclaration variableDeclaration = fieldDeclaration.Fields[j];
				this.nodeStack.Push(variableDeclaration);
				variableDeclaration.AcceptVisitor(this, data);
				variableDeclaration = (VariableDeclaration)this.nodeStack.Pop();
				if (variableDeclaration == null)
				{
					fieldDeclaration.Fields.RemoveAt(j--);
				}
				else
				{
					fieldDeclaration.Fields[j] = variableDeclaration;
				}
			}
			return null;
		}

		public virtual object VisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			this.nodeStack.Push(fixedStatement.PointerDeclaration);
			fixedStatement.PointerDeclaration.AcceptVisitor(this, data);
			fixedStatement.PointerDeclaration = (Statement)this.nodeStack.Pop();
			this.nodeStack.Push(fixedStatement.EmbeddedStatement);
			fixedStatement.EmbeddedStatement.AcceptVisitor(this, data);
			fixedStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.nodeStack.Push(foreachStatement.TypeReference);
			foreachStatement.TypeReference.AcceptVisitor(this, data);
			foreachStatement.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(foreachStatement.Expression);
			foreachStatement.Expression.AcceptVisitor(this, data);
			foreachStatement.Expression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(foreachStatement.NextExpression);
			foreachStatement.NextExpression.AcceptVisitor(this, data);
			foreachStatement.NextExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(foreachStatement.EmbeddedStatement);
			foreachStatement.EmbeddedStatement.AcceptVisitor(this, data);
			foreachStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			this.nodeStack.Push(forNextStatement.Start);
			forNextStatement.Start.AcceptVisitor(this, data);
			forNextStatement.Start = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(forNextStatement.End);
			forNextStatement.End.AcceptVisitor(this, data);
			forNextStatement.End = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(forNextStatement.Step);
			forNextStatement.Step.AcceptVisitor(this, data);
			forNextStatement.Step = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < forNextStatement.NextExpressions.Count; i++)
			{
				Expression expression = forNextStatement.NextExpressions[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					forNextStatement.NextExpressions.RemoveAt(i--);
				}
				else
				{
					forNextStatement.NextExpressions[i] = expression;
				}
			}
			this.nodeStack.Push(forNextStatement.TypeReference);
			forNextStatement.TypeReference.AcceptVisitor(this, data);
			forNextStatement.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(forNextStatement.LoopVariableExpression);
			forNextStatement.LoopVariableExpression.AcceptVisitor(this, data);
			forNextStatement.LoopVariableExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(forNextStatement.EmbeddedStatement);
			forNextStatement.EmbeddedStatement.AcceptVisitor(this, data);
			forNextStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitForStatement(ForStatement forStatement, object data)
		{
			for (int i = 0; i < forStatement.Initializers.Count; i++)
			{
				Statement statement = forStatement.Initializers[i];
				this.nodeStack.Push(statement);
				statement.AcceptVisitor(this, data);
				statement = (Statement)this.nodeStack.Pop();
				if (statement == null)
				{
					forStatement.Initializers.RemoveAt(i--);
				}
				else
				{
					forStatement.Initializers[i] = statement;
				}
			}
			this.nodeStack.Push(forStatement.Condition);
			forStatement.Condition.AcceptVisitor(this, data);
			forStatement.Condition = (Expression)this.nodeStack.Pop();
			for (int j = 0; j < forStatement.Iterator.Count; j++)
			{
				Statement statement2 = forStatement.Iterator[j];
				this.nodeStack.Push(statement2);
				statement2.AcceptVisitor(this, data);
				statement2 = (Statement)this.nodeStack.Pop();
				if (statement2 == null)
				{
					forStatement.Iterator.RemoveAt(j--);
				}
				else
				{
					forStatement.Iterator[j] = statement2;
				}
			}
			this.nodeStack.Push(forStatement.EmbeddedStatement);
			forStatement.EmbeddedStatement.AcceptVisitor(this, data);
			forStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			this.nodeStack.Push(gotoCaseStatement.Expression);
			gotoCaseStatement.Expression.AcceptVisitor(this, data);
			gotoCaseStatement.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			return null;
		}

		public virtual object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			for (int i = 0; i < identifierExpression.TypeArguments.Count; i++)
			{
				TypeReference typeReference = identifierExpression.TypeArguments[i];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					identifierExpression.TypeArguments.RemoveAt(i--);
				}
				else
				{
					identifierExpression.TypeArguments[i] = typeReference;
				}
			}
			return null;
		}

		public virtual object VisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			this.nodeStack.Push(ifElseStatement.Condition);
			ifElseStatement.Condition.AcceptVisitor(this, data);
			ifElseStatement.Condition = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < ifElseStatement.TrueStatement.Count; i++)
			{
				Statement statement = ifElseStatement.TrueStatement[i];
				this.nodeStack.Push(statement);
				statement.AcceptVisitor(this, data);
				statement = (Statement)this.nodeStack.Pop();
				if (statement == null)
				{
					ifElseStatement.TrueStatement.RemoveAt(i--);
				}
				else
				{
					ifElseStatement.TrueStatement[i] = statement;
				}
			}
			for (int j = 0; j < ifElseStatement.FalseStatement.Count; j++)
			{
				Statement statement2 = ifElseStatement.FalseStatement[j];
				this.nodeStack.Push(statement2);
				statement2.AcceptVisitor(this, data);
				statement2 = (Statement)this.nodeStack.Pop();
				if (statement2 == null)
				{
					ifElseStatement.FalseStatement.RemoveAt(j--);
				}
				else
				{
					ifElseStatement.FalseStatement[j] = statement2;
				}
			}
			for (int k = 0; k < ifElseStatement.ElseIfSections.Count; k++)
			{
				ElseIfSection elseIfSection = ifElseStatement.ElseIfSections[k];
				this.nodeStack.Push(elseIfSection);
				elseIfSection.AcceptVisitor(this, data);
				elseIfSection = (ElseIfSection)this.nodeStack.Pop();
				if (elseIfSection == null)
				{
					ifElseStatement.ElseIfSections.RemoveAt(k--);
				}
				else
				{
					ifElseStatement.ElseIfSections[k] = elseIfSection;
				}
			}
			return null;
		}

		public virtual object VisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			for (int i = 0; i < indexerDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = indexerDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					indexerDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					indexerDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < indexerDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = indexerDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					indexerDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					indexerDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < indexerDeclaration.InterfaceImplementations.Count; k++)
			{
				InterfaceImplementation interfaceImplementation = indexerDeclaration.InterfaceImplementations[k];
				this.nodeStack.Push(interfaceImplementation);
				interfaceImplementation.AcceptVisitor(this, data);
				interfaceImplementation = (InterfaceImplementation)this.nodeStack.Pop();
				if (interfaceImplementation == null)
				{
					indexerDeclaration.InterfaceImplementations.RemoveAt(k--);
				}
				else
				{
					indexerDeclaration.InterfaceImplementations[k] = interfaceImplementation;
				}
			}
			this.nodeStack.Push(indexerDeclaration.TypeReference);
			indexerDeclaration.TypeReference.AcceptVisitor(this, data);
			indexerDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(indexerDeclaration.GetRegion);
			indexerDeclaration.GetRegion.AcceptVisitor(this, data);
			indexerDeclaration.GetRegion = (PropertyGetRegion)this.nodeStack.Pop();
			this.nodeStack.Push(indexerDeclaration.SetRegion);
			indexerDeclaration.SetRegion.AcceptVisitor(this, data);
			indexerDeclaration.SetRegion = (PropertySetRegion)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			this.nodeStack.Push(indexerExpression.TargetObject);
			indexerExpression.TargetObject.AcceptVisitor(this, data);
			indexerExpression.TargetObject = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < indexerExpression.Indexes.Count; i++)
			{
				Expression expression = indexerExpression.Indexes[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					indexerExpression.Indexes.RemoveAt(i--);
				}
				else
				{
					indexerExpression.Indexes[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			for (int i = 0; i < innerClassTypeReference.GenericTypes.Count; i++)
			{
				TypeReference typeReference = innerClassTypeReference.GenericTypes[i];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					innerClassTypeReference.GenericTypes.RemoveAt(i--);
				}
				else
				{
					innerClassTypeReference.GenericTypes[i] = typeReference;
				}
			}
			this.nodeStack.Push(innerClassTypeReference.BaseType);
			innerClassTypeReference.BaseType.AcceptVisitor(this, data);
			innerClassTypeReference.BaseType = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			this.nodeStack.Push(interfaceImplementation.InterfaceType);
			interfaceImplementation.InterfaceType.AcceptVisitor(this, data);
			interfaceImplementation.InterfaceType = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			this.nodeStack.Push(invocationExpression.TargetObject);
			invocationExpression.TargetObject.AcceptVisitor(this, data);
			invocationExpression.TargetObject = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < invocationExpression.Arguments.Count; i++)
			{
				Expression expression = invocationExpression.Arguments[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					invocationExpression.Arguments.RemoveAt(i--);
				}
				else
				{
					invocationExpression.Arguments[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitLabelStatement(LabelStatement labelStatement, object data)
		{
			return null;
		}

		public virtual object VisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			for (int i = 0; i < lambdaExpression.Parameters.Count; i++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = lambdaExpression.Parameters[i];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					lambdaExpression.Parameters.RemoveAt(i--);
				}
				else
				{
					lambdaExpression.Parameters[i] = parameterDeclarationExpression;
				}
			}
			this.nodeStack.Push(lambdaExpression.StatementBody);
			lambdaExpression.StatementBody.AcceptVisitor(this, data);
			lambdaExpression.StatementBody = (BlockStatement)this.nodeStack.Pop();
			this.nodeStack.Push(lambdaExpression.ExpressionBody);
			lambdaExpression.ExpressionBody.AcceptVisitor(this, data);
			lambdaExpression.ExpressionBody = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			this.nodeStack.Push(localVariableDeclaration.TypeReference);
			localVariableDeclaration.TypeReference.AcceptVisitor(this, data);
			localVariableDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			for (int i = 0; i < localVariableDeclaration.Variables.Count; i++)
			{
				VariableDeclaration variableDeclaration = localVariableDeclaration.Variables[i];
				this.nodeStack.Push(variableDeclaration);
				variableDeclaration.AcceptVisitor(this, data);
				variableDeclaration = (VariableDeclaration)this.nodeStack.Pop();
				if (variableDeclaration == null)
				{
					localVariableDeclaration.Variables.RemoveAt(i--);
				}
				else
				{
					localVariableDeclaration.Variables[i] = variableDeclaration;
				}
			}
			return null;
		}

		public virtual object VisitLockStatement(LockStatement lockStatement, object data)
		{
			this.nodeStack.Push(lockStatement.LockExpression);
			lockStatement.LockExpression.AcceptVisitor(this, data);
			lockStatement.LockExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(lockStatement.EmbeddedStatement);
			lockStatement.EmbeddedStatement.AcceptVisitor(this, data);
			lockStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			this.nodeStack.Push(memberReferenceExpression.TargetObject);
			memberReferenceExpression.TargetObject.AcceptVisitor(this, data);
			memberReferenceExpression.TargetObject = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < memberReferenceExpression.TypeArguments.Count; i++)
			{
				TypeReference typeReference = memberReferenceExpression.TypeArguments[i];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					memberReferenceExpression.TypeArguments.RemoveAt(i--);
				}
				else
				{
					memberReferenceExpression.TypeArguments[i] = typeReference;
				}
			}
			return null;
		}

		public virtual object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			for (int i = 0; i < methodDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = methodDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					methodDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					methodDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < methodDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = methodDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					methodDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					methodDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < methodDeclaration.InterfaceImplementations.Count; k++)
			{
				InterfaceImplementation interfaceImplementation = methodDeclaration.InterfaceImplementations[k];
				this.nodeStack.Push(interfaceImplementation);
				interfaceImplementation.AcceptVisitor(this, data);
				interfaceImplementation = (InterfaceImplementation)this.nodeStack.Pop();
				if (interfaceImplementation == null)
				{
					methodDeclaration.InterfaceImplementations.RemoveAt(k--);
				}
				else
				{
					methodDeclaration.InterfaceImplementations[k] = interfaceImplementation;
				}
			}
			this.nodeStack.Push(methodDeclaration.TypeReference);
			methodDeclaration.TypeReference.AcceptVisitor(this, data);
			methodDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(methodDeclaration.Body);
			methodDeclaration.Body.AcceptVisitor(this, data);
			methodDeclaration.Body = (BlockStatement)this.nodeStack.Pop();
			for (int l = 0; l < methodDeclaration.Templates.Count; l++)
			{
				TemplateDefinition templateDefinition = methodDeclaration.Templates[l];
				this.nodeStack.Push(templateDefinition);
				templateDefinition.AcceptVisitor(this, data);
				templateDefinition = (TemplateDefinition)this.nodeStack.Pop();
				if (templateDefinition == null)
				{
					methodDeclaration.Templates.RemoveAt(l--);
				}
				else
				{
					methodDeclaration.Templates[l] = templateDefinition;
				}
			}
			return null;
		}

		public virtual object VisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			this.nodeStack.Push(namedArgumentExpression.Expression);
			namedArgumentExpression.Expression.AcceptVisitor(this, data);
			namedArgumentExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			for (int i = 0; i < namespaceDeclaration.Children.Count; i++)
			{
				INode node = namespaceDeclaration.Children[i];
				this.nodeStack.Push(node);
				node.AcceptVisitor(this, data);
				node = this.nodeStack.Pop();
				if (node == null)
				{
					namespaceDeclaration.Children.RemoveAt(i--);
				}
				else
				{
					namespaceDeclaration.Children[i] = node;
				}
			}
			return null;
		}

		public virtual object VisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			this.nodeStack.Push(objectCreateExpression.CreateType);
			objectCreateExpression.CreateType.AcceptVisitor(this, data);
			objectCreateExpression.CreateType = (TypeReference)this.nodeStack.Pop();
			for (int i = 0; i < objectCreateExpression.Parameters.Count; i++)
			{
				Expression expression = objectCreateExpression.Parameters[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					objectCreateExpression.Parameters.RemoveAt(i--);
				}
				else
				{
					objectCreateExpression.Parameters[i] = expression;
				}
			}
			this.nodeStack.Push(objectCreateExpression.ObjectInitializer);
			objectCreateExpression.ObjectInitializer.AcceptVisitor(this, data);
			objectCreateExpression.ObjectInitializer = (CollectionInitializerExpression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			this.nodeStack.Push(onErrorStatement.EmbeddedStatement);
			onErrorStatement.EmbeddedStatement.AcceptVisitor(this, data);
			onErrorStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			for (int i = 0; i < operatorDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = operatorDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					operatorDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					operatorDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < operatorDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = operatorDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					operatorDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					operatorDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < operatorDeclaration.InterfaceImplementations.Count; k++)
			{
				InterfaceImplementation interfaceImplementation = operatorDeclaration.InterfaceImplementations[k];
				this.nodeStack.Push(interfaceImplementation);
				interfaceImplementation.AcceptVisitor(this, data);
				interfaceImplementation = (InterfaceImplementation)this.nodeStack.Pop();
				if (interfaceImplementation == null)
				{
					operatorDeclaration.InterfaceImplementations.RemoveAt(k--);
				}
				else
				{
					operatorDeclaration.InterfaceImplementations[k] = interfaceImplementation;
				}
			}
			this.nodeStack.Push(operatorDeclaration.TypeReference);
			operatorDeclaration.TypeReference.AcceptVisitor(this, data);
			operatorDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(operatorDeclaration.Body);
			operatorDeclaration.Body.AcceptVisitor(this, data);
			operatorDeclaration.Body = (BlockStatement)this.nodeStack.Pop();
			for (int l = 0; l < operatorDeclaration.Templates.Count; l++)
			{
				TemplateDefinition templateDefinition = operatorDeclaration.Templates[l];
				this.nodeStack.Push(templateDefinition);
				templateDefinition.AcceptVisitor(this, data);
				templateDefinition = (TemplateDefinition)this.nodeStack.Pop();
				if (templateDefinition == null)
				{
					operatorDeclaration.Templates.RemoveAt(l--);
				}
				else
				{
					operatorDeclaration.Templates[l] = templateDefinition;
				}
			}
			for (int m = 0; m < operatorDeclaration.ReturnTypeAttributes.Count; m++)
			{
				AttributeSection attributeSection2 = operatorDeclaration.ReturnTypeAttributes[m];
				this.nodeStack.Push(attributeSection2);
				attributeSection2.AcceptVisitor(this, data);
				attributeSection2 = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection2 == null)
				{
					operatorDeclaration.ReturnTypeAttributes.RemoveAt(m--);
				}
				else
				{
					operatorDeclaration.ReturnTypeAttributes[m] = attributeSection2;
				}
			}
			return null;
		}

		public virtual object VisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			return null;
		}

		public virtual object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			for (int i = 0; i < parameterDeclarationExpression.Attributes.Count; i++)
			{
				AttributeSection attributeSection = parameterDeclarationExpression.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					parameterDeclarationExpression.Attributes.RemoveAt(i--);
				}
				else
				{
					parameterDeclarationExpression.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(parameterDeclarationExpression.TypeReference);
			parameterDeclarationExpression.TypeReference.AcceptVisitor(this, data);
			parameterDeclarationExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(parameterDeclarationExpression.DefaultValue);
			parameterDeclarationExpression.DefaultValue.AcceptVisitor(this, data);
			parameterDeclarationExpression.DefaultValue = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			this.nodeStack.Push(parenthesizedExpression.Expression);
			parenthesizedExpression.Expression.AcceptVisitor(this, data);
			parenthesizedExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			this.nodeStack.Push(pointerReferenceExpression.TargetObject);
			pointerReferenceExpression.TargetObject.AcceptVisitor(this, data);
			pointerReferenceExpression.TargetObject = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < pointerReferenceExpression.TypeArguments.Count; i++)
			{
				TypeReference typeReference = pointerReferenceExpression.TypeArguments[i];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					pointerReferenceExpression.TypeArguments.RemoveAt(i--);
				}
				else
				{
					pointerReferenceExpression.TypeArguments[i] = typeReference;
				}
			}
			return null;
		}

		public virtual object VisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			return null;
		}

		public virtual object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			for (int i = 0; i < propertyDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = propertyDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					propertyDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					propertyDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < propertyDeclaration.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = propertyDeclaration.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					propertyDeclaration.Parameters.RemoveAt(j--);
				}
				else
				{
					propertyDeclaration.Parameters[j] = parameterDeclarationExpression;
				}
			}
			for (int k = 0; k < propertyDeclaration.InterfaceImplementations.Count; k++)
			{
				InterfaceImplementation interfaceImplementation = propertyDeclaration.InterfaceImplementations[k];
				this.nodeStack.Push(interfaceImplementation);
				interfaceImplementation.AcceptVisitor(this, data);
				interfaceImplementation = (InterfaceImplementation)this.nodeStack.Pop();
				if (interfaceImplementation == null)
				{
					propertyDeclaration.InterfaceImplementations.RemoveAt(k--);
				}
				else
				{
					propertyDeclaration.InterfaceImplementations[k] = interfaceImplementation;
				}
			}
			this.nodeStack.Push(propertyDeclaration.TypeReference);
			propertyDeclaration.TypeReference.AcceptVisitor(this, data);
			propertyDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(propertyDeclaration.GetRegion);
			propertyDeclaration.GetRegion.AcceptVisitor(this, data);
			propertyDeclaration.GetRegion = (PropertyGetRegion)this.nodeStack.Pop();
			this.nodeStack.Push(propertyDeclaration.SetRegion);
			propertyDeclaration.SetRegion.AcceptVisitor(this, data);
			propertyDeclaration.SetRegion = (PropertySetRegion)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			for (int i = 0; i < propertyGetRegion.Attributes.Count; i++)
			{
				AttributeSection attributeSection = propertyGetRegion.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					propertyGetRegion.Attributes.RemoveAt(i--);
				}
				else
				{
					propertyGetRegion.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(propertyGetRegion.Block);
			propertyGetRegion.Block.AcceptVisitor(this, data);
			propertyGetRegion.Block = (BlockStatement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			for (int i = 0; i < propertySetRegion.Attributes.Count; i++)
			{
				AttributeSection attributeSection = propertySetRegion.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					propertySetRegion.Attributes.RemoveAt(i--);
				}
				else
				{
					propertySetRegion.Attributes[i] = attributeSection;
				}
			}
			this.nodeStack.Push(propertySetRegion.Block);
			propertySetRegion.Block.AcceptVisitor(this, data);
			propertySetRegion.Block = (BlockStatement)this.nodeStack.Pop();
			for (int j = 0; j < propertySetRegion.Parameters.Count; j++)
			{
				ParameterDeclarationExpression parameterDeclarationExpression = propertySetRegion.Parameters[j];
				this.nodeStack.Push(parameterDeclarationExpression);
				parameterDeclarationExpression.AcceptVisitor(this, data);
				parameterDeclarationExpression = (ParameterDeclarationExpression)this.nodeStack.Pop();
				if (parameterDeclarationExpression == null)
				{
					propertySetRegion.Parameters.RemoveAt(j--);
				}
				else
				{
					propertySetRegion.Parameters[j] = parameterDeclarationExpression;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpression(QueryExpression queryExpression, object data)
		{
			this.nodeStack.Push(queryExpression.FromClause);
			queryExpression.FromClause.AcceptVisitor(this, data);
			queryExpression.FromClause = (QueryExpressionFromClause)this.nodeStack.Pop();
			for (int i = 0; i < queryExpression.MiddleClauses.Count; i++)
			{
				QueryExpressionClause queryExpressionClause = queryExpression.MiddleClauses[i];
				this.nodeStack.Push(queryExpressionClause);
				queryExpressionClause.AcceptVisitor(this, data);
				queryExpressionClause = (QueryExpressionClause)this.nodeStack.Pop();
				if (queryExpressionClause == null)
				{
					queryExpression.MiddleClauses.RemoveAt(i--);
				}
				else
				{
					queryExpression.MiddleClauses[i] = queryExpressionClause;
				}
			}
			this.nodeStack.Push(queryExpression.SelectOrGroupClause);
			queryExpression.SelectOrGroupClause.AcceptVisitor(this, data);
			queryExpression.SelectOrGroupClause = (QueryExpressionClause)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionAggregateClause(QueryExpressionAggregateClause queryExpressionAggregateClause, object data)
		{
			this.nodeStack.Push(queryExpressionAggregateClause.FromClause);
			queryExpressionAggregateClause.FromClause.AcceptVisitor(this, data);
			queryExpressionAggregateClause.FromClause = (QueryExpressionFromClause)this.nodeStack.Pop();
			for (int i = 0; i < queryExpressionAggregateClause.MiddleClauses.Count; i++)
			{
				QueryExpressionClause queryExpressionClause = queryExpressionAggregateClause.MiddleClauses[i];
				this.nodeStack.Push(queryExpressionClause);
				queryExpressionClause.AcceptVisitor(this, data);
				queryExpressionClause = (QueryExpressionClause)this.nodeStack.Pop();
				if (queryExpressionClause == null)
				{
					queryExpressionAggregateClause.MiddleClauses.RemoveAt(i--);
				}
				else
				{
					queryExpressionAggregateClause.MiddleClauses[i] = queryExpressionClause;
				}
			}
			for (int j = 0; j < queryExpressionAggregateClause.IntoVariables.Count; j++)
			{
				ExpressionRangeVariable expressionRangeVariable = queryExpressionAggregateClause.IntoVariables[j];
				this.nodeStack.Push(expressionRangeVariable);
				expressionRangeVariable.AcceptVisitor(this, data);
				expressionRangeVariable = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable == null)
				{
					queryExpressionAggregateClause.IntoVariables.RemoveAt(j--);
				}
				else
				{
					queryExpressionAggregateClause.IntoVariables[j] = expressionRangeVariable;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionDistinctClause(QueryExpressionDistinctClause queryExpressionDistinctClause, object data)
		{
			return null;
		}

		public virtual object VisitQueryExpressionFromClause(QueryExpressionFromClause queryExpressionFromClause, object data)
		{
			this.nodeStack.Push(queryExpressionFromClause.Type);
			queryExpressionFromClause.Type.AcceptVisitor(this, data);
			queryExpressionFromClause.Type = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionFromClause.InExpression);
			queryExpressionFromClause.InExpression.AcceptVisitor(this, data);
			queryExpressionFromClause.InExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionGroupClause(QueryExpressionGroupClause queryExpressionGroupClause, object data)
		{
			this.nodeStack.Push(queryExpressionGroupClause.Projection);
			queryExpressionGroupClause.Projection.AcceptVisitor(this, data);
			queryExpressionGroupClause.Projection = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionGroupClause.GroupBy);
			queryExpressionGroupClause.GroupBy.AcceptVisitor(this, data);
			queryExpressionGroupClause.GroupBy = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionGroupJoinVBClause(QueryExpressionGroupJoinVBClause queryExpressionGroupJoinVBClause, object data)
		{
			this.nodeStack.Push(queryExpressionGroupJoinVBClause.JoinClause);
			queryExpressionGroupJoinVBClause.JoinClause.AcceptVisitor(this, data);
			queryExpressionGroupJoinVBClause.JoinClause = (QueryExpressionJoinVBClause)this.nodeStack.Pop();
			for (int i = 0; i < queryExpressionGroupJoinVBClause.IntoVariables.Count; i++)
			{
				ExpressionRangeVariable expressionRangeVariable = queryExpressionGroupJoinVBClause.IntoVariables[i];
				this.nodeStack.Push(expressionRangeVariable);
				expressionRangeVariable.AcceptVisitor(this, data);
				expressionRangeVariable = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable == null)
				{
					queryExpressionGroupJoinVBClause.IntoVariables.RemoveAt(i--);
				}
				else
				{
					queryExpressionGroupJoinVBClause.IntoVariables[i] = expressionRangeVariable;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionGroupVBClause(QueryExpressionGroupVBClause queryExpressionGroupVBClause, object data)
		{
			for (int i = 0; i < queryExpressionGroupVBClause.GroupVariables.Count; i++)
			{
				ExpressionRangeVariable expressionRangeVariable = queryExpressionGroupVBClause.GroupVariables[i];
				this.nodeStack.Push(expressionRangeVariable);
				expressionRangeVariable.AcceptVisitor(this, data);
				expressionRangeVariable = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable == null)
				{
					queryExpressionGroupVBClause.GroupVariables.RemoveAt(i--);
				}
				else
				{
					queryExpressionGroupVBClause.GroupVariables[i] = expressionRangeVariable;
				}
			}
			for (int j = 0; j < queryExpressionGroupVBClause.ByVariables.Count; j++)
			{
				ExpressionRangeVariable expressionRangeVariable2 = queryExpressionGroupVBClause.ByVariables[j];
				this.nodeStack.Push(expressionRangeVariable2);
				expressionRangeVariable2.AcceptVisitor(this, data);
				expressionRangeVariable2 = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable2 == null)
				{
					queryExpressionGroupVBClause.ByVariables.RemoveAt(j--);
				}
				else
				{
					queryExpressionGroupVBClause.ByVariables[j] = expressionRangeVariable2;
				}
			}
			for (int k = 0; k < queryExpressionGroupVBClause.IntoVariables.Count; k++)
			{
				ExpressionRangeVariable expressionRangeVariable3 = queryExpressionGroupVBClause.IntoVariables[k];
				this.nodeStack.Push(expressionRangeVariable3);
				expressionRangeVariable3.AcceptVisitor(this, data);
				expressionRangeVariable3 = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable3 == null)
				{
					queryExpressionGroupVBClause.IntoVariables.RemoveAt(k--);
				}
				else
				{
					queryExpressionGroupVBClause.IntoVariables[k] = expressionRangeVariable3;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionJoinClause(QueryExpressionJoinClause queryExpressionJoinClause, object data)
		{
			this.nodeStack.Push(queryExpressionJoinClause.Type);
			queryExpressionJoinClause.Type.AcceptVisitor(this, data);
			queryExpressionJoinClause.Type = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionJoinClause.InExpression);
			queryExpressionJoinClause.InExpression.AcceptVisitor(this, data);
			queryExpressionJoinClause.InExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionJoinClause.OnExpression);
			queryExpressionJoinClause.OnExpression.AcceptVisitor(this, data);
			queryExpressionJoinClause.OnExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionJoinClause.EqualsExpression);
			queryExpressionJoinClause.EqualsExpression.AcceptVisitor(this, data);
			queryExpressionJoinClause.EqualsExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionJoinConditionVB(QueryExpressionJoinConditionVB queryExpressionJoinConditionVB, object data)
		{
			this.nodeStack.Push(queryExpressionJoinConditionVB.LeftSide);
			queryExpressionJoinConditionVB.LeftSide.AcceptVisitor(this, data);
			queryExpressionJoinConditionVB.LeftSide = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionJoinConditionVB.RightSide);
			queryExpressionJoinConditionVB.RightSide.AcceptVisitor(this, data);
			queryExpressionJoinConditionVB.RightSide = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionJoinVBClause(QueryExpressionJoinVBClause queryExpressionJoinVBClause, object data)
		{
			this.nodeStack.Push(queryExpressionJoinVBClause.JoinVariable);
			queryExpressionJoinVBClause.JoinVariable.AcceptVisitor(this, data);
			queryExpressionJoinVBClause.JoinVariable = (QueryExpressionFromClause)this.nodeStack.Pop();
			this.nodeStack.Push(queryExpressionJoinVBClause.SubJoin);
			queryExpressionJoinVBClause.SubJoin.AcceptVisitor(this, data);
			queryExpressionJoinVBClause.SubJoin = (QueryExpressionJoinVBClause)this.nodeStack.Pop();
			for (int i = 0; i < queryExpressionJoinVBClause.Conditions.Count; i++)
			{
				QueryExpressionJoinConditionVB queryExpressionJoinConditionVB = queryExpressionJoinVBClause.Conditions[i];
				this.nodeStack.Push(queryExpressionJoinConditionVB);
				queryExpressionJoinConditionVB.AcceptVisitor(this, data);
				queryExpressionJoinConditionVB = (QueryExpressionJoinConditionVB)this.nodeStack.Pop();
				if (queryExpressionJoinConditionVB == null)
				{
					queryExpressionJoinVBClause.Conditions.RemoveAt(i--);
				}
				else
				{
					queryExpressionJoinVBClause.Conditions[i] = queryExpressionJoinConditionVB;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionLetClause(QueryExpressionLetClause queryExpressionLetClause, object data)
		{
			this.nodeStack.Push(queryExpressionLetClause.Expression);
			queryExpressionLetClause.Expression.AcceptVisitor(this, data);
			queryExpressionLetClause.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionLetVBClause(QueryExpressionLetVBClause queryExpressionLetVBClause, object data)
		{
			for (int i = 0; i < queryExpressionLetVBClause.Variables.Count; i++)
			{
				ExpressionRangeVariable expressionRangeVariable = queryExpressionLetVBClause.Variables[i];
				this.nodeStack.Push(expressionRangeVariable);
				expressionRangeVariable.AcceptVisitor(this, data);
				expressionRangeVariable = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable == null)
				{
					queryExpressionLetVBClause.Variables.RemoveAt(i--);
				}
				else
				{
					queryExpressionLetVBClause.Variables[i] = expressionRangeVariable;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			for (int i = 0; i < queryExpressionOrderClause.Orderings.Count; i++)
			{
				QueryExpressionOrdering queryExpressionOrdering = queryExpressionOrderClause.Orderings[i];
				this.nodeStack.Push(queryExpressionOrdering);
				queryExpressionOrdering.AcceptVisitor(this, data);
				queryExpressionOrdering = (QueryExpressionOrdering)this.nodeStack.Pop();
				if (queryExpressionOrdering == null)
				{
					queryExpressionOrderClause.Orderings.RemoveAt(i--);
				}
				else
				{
					queryExpressionOrderClause.Orderings[i] = queryExpressionOrdering;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionOrdering(QueryExpressionOrdering queryExpressionOrdering, object data)
		{
			this.nodeStack.Push(queryExpressionOrdering.Criteria);
			queryExpressionOrdering.Criteria.AcceptVisitor(this, data);
			queryExpressionOrdering.Criteria = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionPartitionVBClause(QueryExpressionPartitionVBClause queryExpressionPartitionVBClause, object data)
		{
			this.nodeStack.Push(queryExpressionPartitionVBClause.Expression);
			queryExpressionPartitionVBClause.Expression.AcceptVisitor(this, data);
			queryExpressionPartitionVBClause.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionSelectClause(QueryExpressionSelectClause queryExpressionSelectClause, object data)
		{
			this.nodeStack.Push(queryExpressionSelectClause.Projection);
			queryExpressionSelectClause.Projection.AcceptVisitor(this, data);
			queryExpressionSelectClause.Projection = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitQueryExpressionSelectVBClause(QueryExpressionSelectVBClause queryExpressionSelectVBClause, object data)
		{
			for (int i = 0; i < queryExpressionSelectVBClause.Variables.Count; i++)
			{
				ExpressionRangeVariable expressionRangeVariable = queryExpressionSelectVBClause.Variables[i];
				this.nodeStack.Push(expressionRangeVariable);
				expressionRangeVariable.AcceptVisitor(this, data);
				expressionRangeVariable = (ExpressionRangeVariable)this.nodeStack.Pop();
				if (expressionRangeVariable == null)
				{
					queryExpressionSelectVBClause.Variables.RemoveAt(i--);
				}
				else
				{
					queryExpressionSelectVBClause.Variables[i] = expressionRangeVariable;
				}
			}
			return null;
		}

		public virtual object VisitQueryExpressionWhereClause(QueryExpressionWhereClause queryExpressionWhereClause, object data)
		{
			this.nodeStack.Push(queryExpressionWhereClause.Condition);
			queryExpressionWhereClause.Condition.AcceptVisitor(this, data);
			queryExpressionWhereClause.Condition = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			for (int i = 0; i < raiseEventStatement.Arguments.Count; i++)
			{
				Expression expression = raiseEventStatement.Arguments[i];
				this.nodeStack.Push(expression);
				expression.AcceptVisitor(this, data);
				expression = (Expression)this.nodeStack.Pop();
				if (expression == null)
				{
					raiseEventStatement.Arguments.RemoveAt(i--);
				}
				else
				{
					raiseEventStatement.Arguments[i] = expression;
				}
			}
			return null;
		}

		public virtual object VisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			for (int i = 0; i < reDimStatement.ReDimClauses.Count; i++)
			{
				InvocationExpression invocationExpression = reDimStatement.ReDimClauses[i];
				this.nodeStack.Push(invocationExpression);
				invocationExpression.AcceptVisitor(this, data);
				invocationExpression = (InvocationExpression)this.nodeStack.Pop();
				if (invocationExpression == null)
				{
					reDimStatement.ReDimClauses.RemoveAt(i--);
				}
				else
				{
					reDimStatement.ReDimClauses[i] = invocationExpression;
				}
			}
			return null;
		}

		public virtual object VisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			this.nodeStack.Push(removeHandlerStatement.EventExpression);
			removeHandlerStatement.EventExpression.AcceptVisitor(this, data);
			removeHandlerStatement.EventExpression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(removeHandlerStatement.HandlerExpression);
			removeHandlerStatement.HandlerExpression.AcceptVisitor(this, data);
			removeHandlerStatement.HandlerExpression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			return null;
		}

		public virtual object VisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			this.nodeStack.Push(returnStatement.Expression);
			returnStatement.Expression.AcceptVisitor(this, data);
			returnStatement.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			this.nodeStack.Push(sizeOfExpression.TypeReference);
			sizeOfExpression.TypeReference.AcceptVisitor(this, data);
			sizeOfExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			this.nodeStack.Push(stackAllocExpression.TypeReference);
			stackAllocExpression.TypeReference.AcceptVisitor(this, data);
			stackAllocExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(stackAllocExpression.Expression);
			stackAllocExpression.Expression.AcceptVisitor(this, data);
			stackAllocExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitStopStatement(StopStatement stopStatement, object data)
		{
			return null;
		}

		public virtual object VisitSwitchSection(SwitchSection switchSection, object data)
		{
			for (int i = 0; i < switchSection.SwitchLabels.Count; i++)
			{
				CaseLabel caseLabel = switchSection.SwitchLabels[i];
				this.nodeStack.Push(caseLabel);
				caseLabel.AcceptVisitor(this, data);
				caseLabel = (CaseLabel)this.nodeStack.Pop();
				if (caseLabel == null)
				{
					switchSection.SwitchLabels.RemoveAt(i--);
				}
				else
				{
					switchSection.SwitchLabels[i] = caseLabel;
				}
			}
			for (int j = 0; j < switchSection.Children.Count; j++)
			{
				INode node = switchSection.Children[j];
				this.nodeStack.Push(node);
				node.AcceptVisitor(this, data);
				node = this.nodeStack.Pop();
				if (node == null)
				{
					switchSection.Children.RemoveAt(j--);
				}
				else
				{
					switchSection.Children[j] = node;
				}
			}
			return null;
		}

		public virtual object VisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			this.nodeStack.Push(switchStatement.SwitchExpression);
			switchStatement.SwitchExpression.AcceptVisitor(this, data);
			switchStatement.SwitchExpression = (Expression)this.nodeStack.Pop();
			for (int i = 0; i < switchStatement.SwitchSections.Count; i++)
			{
				SwitchSection switchSection = switchStatement.SwitchSections[i];
				this.nodeStack.Push(switchSection);
				switchSection.AcceptVisitor(this, data);
				switchSection = (SwitchSection)this.nodeStack.Pop();
				if (switchSection == null)
				{
					switchStatement.SwitchSections.RemoveAt(i--);
				}
				else
				{
					switchStatement.SwitchSections[i] = switchSection;
				}
			}
			return null;
		}

		public virtual object VisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			for (int i = 0; i < templateDefinition.Attributes.Count; i++)
			{
				AttributeSection attributeSection = templateDefinition.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					templateDefinition.Attributes.RemoveAt(i--);
				}
				else
				{
					templateDefinition.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < templateDefinition.Bases.Count; j++)
			{
				TypeReference typeReference = templateDefinition.Bases[j];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					templateDefinition.Bases.RemoveAt(j--);
				}
				else
				{
					templateDefinition.Bases[j] = typeReference;
				}
			}
			return null;
		}

		public virtual object VisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			this.nodeStack.Push(throwStatement.Expression);
			throwStatement.Expression.AcceptVisitor(this, data);
			throwStatement.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			this.nodeStack.Push(tryCatchStatement.StatementBlock);
			tryCatchStatement.StatementBlock.AcceptVisitor(this, data);
			tryCatchStatement.StatementBlock = (Statement)this.nodeStack.Pop();
			for (int i = 0; i < tryCatchStatement.CatchClauses.Count; i++)
			{
				CatchClause catchClause = tryCatchStatement.CatchClauses[i];
				this.nodeStack.Push(catchClause);
				catchClause.AcceptVisitor(this, data);
				catchClause = (CatchClause)this.nodeStack.Pop();
				if (catchClause == null)
				{
					tryCatchStatement.CatchClauses.RemoveAt(i--);
				}
				else
				{
					tryCatchStatement.CatchClauses[i] = catchClause;
				}
			}
			this.nodeStack.Push(tryCatchStatement.FinallyBlock);
			tryCatchStatement.FinallyBlock.AcceptVisitor(this, data);
			tryCatchStatement.FinallyBlock = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			for (int i = 0; i < typeDeclaration.Attributes.Count; i++)
			{
				AttributeSection attributeSection = typeDeclaration.Attributes[i];
				this.nodeStack.Push(attributeSection);
				attributeSection.AcceptVisitor(this, data);
				attributeSection = (AttributeSection)this.nodeStack.Pop();
				if (attributeSection == null)
				{
					typeDeclaration.Attributes.RemoveAt(i--);
				}
				else
				{
					typeDeclaration.Attributes[i] = attributeSection;
				}
			}
			for (int j = 0; j < typeDeclaration.BaseTypes.Count; j++)
			{
				TypeReference typeReference = typeDeclaration.BaseTypes[j];
				this.nodeStack.Push(typeReference);
				typeReference.AcceptVisitor(this, data);
				typeReference = (TypeReference)this.nodeStack.Pop();
				if (typeReference == null)
				{
					typeDeclaration.BaseTypes.RemoveAt(j--);
				}
				else
				{
					typeDeclaration.BaseTypes[j] = typeReference;
				}
			}
			for (int k = 0; k < typeDeclaration.Templates.Count; k++)
			{
				TemplateDefinition templateDefinition = typeDeclaration.Templates[k];
				this.nodeStack.Push(templateDefinition);
				templateDefinition.AcceptVisitor(this, data);
				templateDefinition = (TemplateDefinition)this.nodeStack.Pop();
				if (templateDefinition == null)
				{
					typeDeclaration.Templates.RemoveAt(k--);
				}
				else
				{
					typeDeclaration.Templates[k] = templateDefinition;
				}
			}
			for (int l = 0; l < typeDeclaration.Children.Count; l++)
			{
				INode node = typeDeclaration.Children[l];
				this.nodeStack.Push(node);
				node.AcceptVisitor(this, data);
				node = this.nodeStack.Pop();
				if (node == null)
				{
					typeDeclaration.Children.RemoveAt(l--);
				}
				else
				{
					typeDeclaration.Children[l] = node;
				}
			}
			return null;
		}

		public virtual object VisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			this.nodeStack.Push(typeOfExpression.TypeReference);
			typeOfExpression.TypeReference.AcceptVisitor(this, data);
			typeOfExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			this.nodeStack.Push(typeOfIsExpression.Expression);
			typeOfIsExpression.Expression.AcceptVisitor(this, data);
			typeOfIsExpression.Expression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(typeOfIsExpression.TypeReference);
			typeOfIsExpression.TypeReference.AcceptVisitor(this, data);
			typeOfIsExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitTypeReference(TypeReference typeReference, object data)
		{
			for (int i = 0; i < typeReference.GenericTypes.Count; i++)
			{
				TypeReference typeReference2 = typeReference.GenericTypes[i];
				this.nodeStack.Push(typeReference2);
				typeReference2.AcceptVisitor(this, data);
				typeReference2 = (TypeReference)this.nodeStack.Pop();
				if (typeReference2 == null)
				{
					typeReference.GenericTypes.RemoveAt(i--);
				}
				else
				{
					typeReference.GenericTypes[i] = typeReference2;
				}
			}
			return null;
		}

		public virtual object VisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			this.nodeStack.Push(typeReferenceExpression.TypeReference);
			typeReferenceExpression.TypeReference.AcceptVisitor(this, data);
			typeReferenceExpression.TypeReference = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			this.nodeStack.Push(unaryOperatorExpression.Expression);
			unaryOperatorExpression.Expression.AcceptVisitor(this, data);
			unaryOperatorExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			this.nodeStack.Push(uncheckedExpression.Expression);
			uncheckedExpression.Expression.AcceptVisitor(this, data);
			uncheckedExpression.Expression = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			this.nodeStack.Push(uncheckedStatement.Block);
			uncheckedStatement.Block.AcceptVisitor(this, data);
			uncheckedStatement.Block = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			this.nodeStack.Push(unsafeStatement.Block);
			unsafeStatement.Block.AcceptVisitor(this, data);
			unsafeStatement.Block = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUsing(Using @using, object data)
		{
			this.nodeStack.Push(@using.Alias);
			@using.Alias.AcceptVisitor(this, data);
			@using.Alias = (TypeReference)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			for (int i = 0; i < usingDeclaration.Usings.Count; i++)
			{
				Using @using = usingDeclaration.Usings[i];
				this.nodeStack.Push(@using);
				@using.AcceptVisitor(this, data);
				@using = (Using)this.nodeStack.Pop();
				if (@using == null)
				{
					usingDeclaration.Usings.RemoveAt(i--);
				}
				else
				{
					usingDeclaration.Usings[i] = @using;
				}
			}
			return null;
		}

		public virtual object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			this.nodeStack.Push(usingStatement.ResourceAcquisition);
			usingStatement.ResourceAcquisition.AcceptVisitor(this, data);
			usingStatement.ResourceAcquisition = (Statement)this.nodeStack.Pop();
			this.nodeStack.Push(usingStatement.EmbeddedStatement);
			usingStatement.EmbeddedStatement.AcceptVisitor(this, data);
			usingStatement.EmbeddedStatement = (Statement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			this.nodeStack.Push(variableDeclaration.Initializer);
			variableDeclaration.Initializer.AcceptVisitor(this, data);
			variableDeclaration.Initializer = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(variableDeclaration.TypeReference);
			variableDeclaration.TypeReference.AcceptVisitor(this, data);
			variableDeclaration.TypeReference = (TypeReference)this.nodeStack.Pop();
			this.nodeStack.Push(variableDeclaration.FixedArrayInitialization);
			variableDeclaration.FixedArrayInitialization.AcceptVisitor(this, data);
			variableDeclaration.FixedArrayInitialization = (Expression)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitWithStatement(WithStatement withStatement, object data)
		{
			this.nodeStack.Push(withStatement.Expression);
			withStatement.Expression.AcceptVisitor(this, data);
			withStatement.Expression = (Expression)this.nodeStack.Pop();
			this.nodeStack.Push(withStatement.Body);
			withStatement.Body.AcceptVisitor(this, data);
			withStatement.Body = (BlockStatement)this.nodeStack.Pop();
			return null;
		}

		public virtual object VisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			this.nodeStack.Push(yieldStatement.Statement);
			yieldStatement.Statement.AcceptVisitor(this, data);
			yieldStatement.Statement = (Statement)this.nodeStack.Pop();
			return null;
		}

		protected Stack<INode> nodeStack = new Stack<INode>();
	}
}
