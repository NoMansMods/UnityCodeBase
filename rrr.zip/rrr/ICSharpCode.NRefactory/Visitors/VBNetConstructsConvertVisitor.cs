﻿using System;
using System.Collections.Generic;
using System.Reflection;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.AstBuilder;

namespace ICSharpCode.NRefactory.Visitors
{
	public class VBNetConstructsConvertVisitor : ConvertVisitorBase
	{
		private Expression CallStringIsNullOrEmpty(Expression stringVariable)
		{
			List<Expression> list = new List<Expression>();
			list.Add(stringVariable);
			return new InvocationExpression(new MemberReferenceExpression(new TypeReferenceExpression(new TypeReference("System.String", true)), "IsNullOrEmpty"), list);
		}

		private static Dictionary<string, Expression> CreateDictionary(params string[] classNames)
		{
			Dictionary<string, Expression> dictionary = new Dictionary<string, Expression>(StringComparer.InvariantCultureIgnoreCase);
			Assembly assembly = Assembly.Load(VBNetConstructsConvertVisitor.VBAssemblyName);
			for (int i = 0; i < classNames.Length; i++)
			{
				string text = classNames[i];
				Type type = assembly.GetType("Microsoft.VisualBasic." + text);
				Expression value = new IdentifierExpression(text);
				MemberInfo[] members = type.GetMembers();
				for (int j = 0; j < members.Length; j++)
				{
					MemberInfo memberInfo = members[j];
					if (memberInfo.DeclaringType == type)
					{
						dictionary[memberInfo.Name] = value;
					}
				}
			}
			return dictionary;
		}

		private static PrimitiveExpression CreateStringLiteral(string text)
		{
			return new PrimitiveExpression(text, text);
		}

		private static AssignmentExpression GetAssignmentFromStatement(INode statement)
		{
			ExpressionStatement expressionStatement = statement as ExpressionStatement;
			if (expressionStatement == null)
			{
				return null;
			}
			return expressionStatement.Expression as AssignmentExpression;
		}

		private static bool IsAssignmentTo(INode statement, string varName)
		{
			AssignmentExpression assignmentFromStatement = VBNetConstructsConvertVisitor.GetAssignmentFromStatement(statement);
			if (assignmentFromStatement == null)
			{
				return false;
			}
			IdentifierExpression identifierExpression = assignmentFromStatement.Left as IdentifierExpression;
			return identifierExpression != null && identifierExpression.Identifier.Equals(varName, StringComparison.InvariantCultureIgnoreCase);
		}

		private bool IsClassType(ClassType c)
		{
			return this.currentTypeDeclaration != null && this.currentTypeDeclaration.Type == c;
		}

		private bool IsEmptyStringLiteral(Expression expression)
		{
			PrimitiveExpression primitiveExpression = expression as PrimitiveExpression;
			return primitiveExpression != null && primitiveExpression.Value as string == "";
		}

		public override object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			for (int i = 0; i < arrayCreateExpression.Arguments.Count; i++)
			{
				arrayCreateExpression.Arguments[i] = Expression.AddInteger(arrayCreateExpression.Arguments[i], 1);
			}
			if (arrayCreateExpression.ArrayInitializer.CreateExpressions.Count == 0)
			{
				arrayCreateExpression.ArrayInitializer = null;
			}
			return base.VisitArrayCreateExpression(arrayCreateExpression, data);
		}

		public override object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			base.VisitBinaryOperatorExpression(binaryOperatorExpression, data);
			if (this.IsEmptyStringLiteral(binaryOperatorExpression.Right))
			{
				if (binaryOperatorExpression.Op == BinaryOperatorType.Equality)
				{
					base.ReplaceCurrentNode(this.CallStringIsNullOrEmpty(binaryOperatorExpression.Left));
				}
				else if (binaryOperatorExpression.Op == BinaryOperatorType.InEquality)
				{
					base.ReplaceCurrentNode(new UnaryOperatorExpression(this.CallStringIsNullOrEmpty(binaryOperatorExpression.Left), UnaryOperatorType.Not));
				}
			}
			else if (this.IsEmptyStringLiteral(binaryOperatorExpression.Left))
			{
				if (binaryOperatorExpression.Op == BinaryOperatorType.Equality)
				{
					base.ReplaceCurrentNode(this.CallStringIsNullOrEmpty(binaryOperatorExpression.Right));
				}
				else if (binaryOperatorExpression.Op == BinaryOperatorType.InEquality)
				{
					base.ReplaceCurrentNode(new UnaryOperatorExpression(this.CallStringIsNullOrEmpty(binaryOperatorExpression.Right), UnaryOperatorType.Not));
				}
			}
			return null;
		}

		public override object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			this.usings = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
			this.addedUsings = new List<UsingDeclaration>();
			base.VisitCompilationUnit(compilationUnit, data);
			int num = 0;
			while (num < compilationUnit.Children.Count && compilationUnit.Children[num] is UsingDeclaration)
			{
				num++;
			}
			foreach (UsingDeclaration current in this.addedUsings)
			{
				current.Parent = compilationUnit;
				compilationUnit.Children.Insert(num++, current);
			}
			this.usings = null;
			this.addedUsings = null;
			return null;
		}

		public override object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			if ((constructorDeclaration.Modifier & (Modifiers.Private | Modifiers.Internal | Modifiers.Protected | Modifiers.Public | Modifiers.Static)) == Modifiers.None)
			{
				constructorDeclaration.Modifier |= Modifiers.Public;
			}
			BlockStatement body = constructorDeclaration.Body;
			if (body != null && body.Children.Count > 0)
			{
				ExpressionStatement expressionStatement = body.Children[0] as ExpressionStatement;
				if (expressionStatement != null)
				{
					InvocationExpression invocationExpression = expressionStatement.Expression as InvocationExpression;
					if (invocationExpression != null)
					{
						MemberReferenceExpression memberReferenceExpression = invocationExpression.TargetObject as MemberReferenceExpression;
						if (memberReferenceExpression != null && "New".Equals(memberReferenceExpression.MemberName, StringComparison.InvariantCultureIgnoreCase) && (memberReferenceExpression.TargetObject is BaseReferenceExpression || memberReferenceExpression.TargetObject is ClassReferenceExpression || memberReferenceExpression.TargetObject is ThisReferenceExpression))
						{
							body.Children.RemoveAt(0);
							ConstructorInitializer constructorInitializer = new ConstructorInitializer();
							constructorInitializer.Arguments = invocationExpression.Arguments;
							if (memberReferenceExpression.TargetObject is BaseReferenceExpression)
							{
								constructorInitializer.ConstructorInitializerType = ConstructorInitializerType.Base;
							}
							else
							{
								constructorInitializer.ConstructorInitializerType = ConstructorInitializerType.This;
							}
							constructorDeclaration.ConstructorInitializer = constructorInitializer;
						}
					}
				}
			}
			return base.VisitConstructorDeclaration(constructorDeclaration, data);
		}

		public override object VisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			if (this.usings != null && !this.usings.ContainsKey("System.Runtime.InteropServices"))
			{
				UsingDeclaration usingDeclaration = new UsingDeclaration("System.Runtime.InteropServices");
				this.addedUsings.Add(usingDeclaration);
				base.VisitUsingDeclaration(usingDeclaration, data);
			}
			MethodDeclaration methodDeclaration = new MethodDeclaration
			{
				Name = declareDeclaration.Name,
				Modifier = declareDeclaration.Modifier,
				TypeReference = declareDeclaration.TypeReference,
				Parameters = declareDeclaration.Parameters,
				Attributes = declareDeclaration.Attributes
			};
			if ((methodDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				methodDeclaration.Modifier |= Modifiers.Public;
			}
			methodDeclaration.Modifier |= (Modifiers.Static | Modifiers.Extern);
			if (methodDeclaration.TypeReference.IsNull)
			{
				methodDeclaration.TypeReference = new TypeReference("System.Void", true);
			}
			ICSharpCode.NRefactory.Ast.Attribute attribute = new ICSharpCode.NRefactory.Ast.Attribute("DllImport", null, null);
			attribute.PositionalArguments.Add(VBNetConstructsConvertVisitor.CreateStringLiteral(declareDeclaration.Library));
			if (declareDeclaration.Alias.Length > 0)
			{
				attribute.NamedArguments.Add(new NamedArgumentExpression("EntryPoint", VBNetConstructsConvertVisitor.CreateStringLiteral(declareDeclaration.Alias)));
			}
			switch (declareDeclaration.Charset)
			{
			case CharsetModifier.Auto:
				attribute.NamedArguments.Add(new NamedArgumentExpression("CharSet", new MemberReferenceExpression(new IdentifierExpression("CharSet"), "Auto")));
				break;
			case CharsetModifier.Unicode:
				attribute.NamedArguments.Add(new NamedArgumentExpression("CharSet", new MemberReferenceExpression(new IdentifierExpression("CharSet"), "Unicode")));
				break;
			default:
				attribute.NamedArguments.Add(new NamedArgumentExpression("CharSet", new MemberReferenceExpression(new IdentifierExpression("CharSet"), "Ansi")));
				break;
			}
			attribute.NamedArguments.Add(new NamedArgumentExpression("SetLastError", new PrimitiveExpression(true, true.ToString())));
			attribute.NamedArguments.Add(new NamedArgumentExpression("ExactSpelling", new PrimitiveExpression(true, true.ToString())));
			methodDeclaration.Attributes.Add(new AttributeSection
			{
				Attributes = 
				{
					attribute
				}
			});
			base.ReplaceCurrentNode(methodDeclaration);
			return base.VisitMethodDeclaration(methodDeclaration, data);
		}

		public override object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			if (this.currentTypeDeclaration != null && (delegateDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				delegateDeclaration.Modifier |= Modifiers.Public;
			}
			return base.VisitDelegateDeclaration(delegateDeclaration, data);
		}

		public override object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (eventDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				eventDeclaration.Modifier |= Modifiers.Public;
			}
			return base.VisitEventDeclaration(eventDeclaration, data);
		}

		public override object VisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			fieldDeclaration.Modifier &= ~Modifiers.Dim;
			if (this.IsClassType(ClassType.Struct) && (fieldDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				fieldDeclaration.Modifier |= Modifiers.Public;
			}
			return base.VisitFieldDeclaration(fieldDeclaration, data);
		}

		public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			if (VBNetConstructsConvertVisitor.constantTable == null)
			{
				VBNetConstructsConvertVisitor.constantTable = VBNetConstructsConvertVisitor.CreateDictionary(new string[]
				{
					"Constants"
				});
			}
			Expression targetObject;
			if (VBNetConstructsConvertVisitor.constantTable.TryGetValue(identifierExpression.Identifier, out targetObject))
			{
				MemberReferenceExpression memberReferenceExpression = new MemberReferenceExpression(targetObject, identifierExpression.Identifier);
				base.ReplaceCurrentNode(memberReferenceExpression);
				return base.VisitMemberReferenceExpression(memberReferenceExpression, data);
			}
			return base.VisitIdentifierExpression(identifierExpression, data);
		}

		public override object VisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			IdentifierExpression identifierExpression = invocationExpression.TargetObject as IdentifierExpression;
			if (identifierExpression != null)
			{
				if ("IIF".Equals(identifierExpression.Identifier, StringComparison.InvariantCultureIgnoreCase) && invocationExpression.Arguments.Count == 3)
				{
					ConditionalExpression conditionalExpression = new ConditionalExpression(invocationExpression.Arguments[0], invocationExpression.Arguments[1], invocationExpression.Arguments[2]);
					base.ReplaceCurrentNode(new ParenthesizedExpression(conditionalExpression));
					return base.VisitConditionalExpression(conditionalExpression, data);
				}
				if ("IsNothing".Equals(identifierExpression.Identifier, StringComparison.InvariantCultureIgnoreCase) && invocationExpression.Arguments.Count == 1)
				{
					BinaryOperatorExpression binaryOperatorExpression = new BinaryOperatorExpression(invocationExpression.Arguments[0], BinaryOperatorType.ReferenceEquality, new PrimitiveExpression(null, "null"));
					base.ReplaceCurrentNode(new ParenthesizedExpression(binaryOperatorExpression));
					return base.VisitBinaryOperatorExpression(binaryOperatorExpression, data);
				}
				if (VBNetConstructsConvertVisitor.methodTable == null)
				{
					VBNetConstructsConvertVisitor.methodTable = VBNetConstructsConvertVisitor.CreateDictionary(new string[]
					{
						"Conversion",
						"FileSystem",
						"Financial",
						"Information",
						"Interaction",
						"Strings",
						"VBMath"
					});
				}
				Expression targetObject;
				if (VBNetConstructsConvertVisitor.methodTable.TryGetValue(identifierExpression.Identifier, out targetObject))
				{
					MemberReferenceExpression targetObject2 = new MemberReferenceExpression(targetObject, identifierExpression.Identifier);
					invocationExpression.TargetObject = targetObject2;
				}
			}
			return base.VisitInvocationExpression(invocationExpression, data);
		}

		public override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			if (this.AddDefaultValueInitializerToLocalVariableDeclarations && (localVariableDeclaration.Modifier & Modifiers.Static) == Modifiers.None)
			{
				for (int i = 0; i < localVariableDeclaration.Variables.Count; i++)
				{
					VariableDeclaration variableDeclaration = localVariableDeclaration.Variables[i];
					if (variableDeclaration.FixedArrayInitialization.IsNull && variableDeclaration.Initializer.IsNull)
					{
						TypeReference typeForVariable = localVariableDeclaration.GetTypeForVariable(i);
						variableDeclaration.Initializer = ExpressionBuilder.CreateDefaultValueForType(typeForVariable);
					}
				}
			}
			return base.VisitLocalVariableDeclaration(localVariableDeclaration, data);
		}

		public override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (methodDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				methodDeclaration.Modifier |= Modifiers.Public;
			}
			if ("Finalize".Equals(methodDeclaration.Name, StringComparison.InvariantCultureIgnoreCase) && methodDeclaration.Parameters.Count == 0 && methodDeclaration.Modifier == (Modifiers.Protected | Modifiers.Override) && methodDeclaration.Body.Children.Count == 1)
			{
				TryCatchStatement tryCatchStatement = methodDeclaration.Body.Children[0] as TryCatchStatement;
				if (tryCatchStatement != null && tryCatchStatement.StatementBlock is BlockStatement && tryCatchStatement.CatchClauses.Count == 0 && tryCatchStatement.FinallyBlock is BlockStatement && tryCatchStatement.FinallyBlock.Children.Count == 1)
				{
					ExpressionStatement expressionStatement = tryCatchStatement.FinallyBlock.Children[0] as ExpressionStatement;
					if (expressionStatement != null)
					{
						InvocationExpression invocationExpression = expressionStatement.Expression as InvocationExpression;
						if (invocationExpression != null && invocationExpression.Arguments.Count == 0 && invocationExpression.TargetObject is MemberReferenceExpression && (invocationExpression.TargetObject as MemberReferenceExpression).TargetObject is BaseReferenceExpression && "Finalize".Equals((invocationExpression.TargetObject as MemberReferenceExpression).MemberName, StringComparison.InvariantCultureIgnoreCase))
						{
							DestructorDeclaration destructorDeclaration = new DestructorDeclaration("Destructor", Modifiers.None, methodDeclaration.Attributes);
							base.ReplaceCurrentNode(destructorDeclaration);
							destructorDeclaration.Body = (BlockStatement)tryCatchStatement.StatementBlock;
							return base.VisitDestructorDeclaration(destructorDeclaration, data);
						}
					}
				}
			}
			if ((methodDeclaration.Modifier & (Modifiers.Static | Modifiers.Extern)) == Modifiers.Static && methodDeclaration.Body.Children.Count == 0)
			{
				foreach (AttributeSection current in methodDeclaration.Attributes)
				{
					foreach (ICSharpCode.NRefactory.Ast.Attribute current2 in current.Attributes)
					{
						if ("DllImport".Equals(current2.Name, StringComparison.InvariantCultureIgnoreCase))
						{
							methodDeclaration.Modifier |= Modifiers.Extern;
							methodDeclaration.Body = null;
						}
					}
				}
			}
			if (methodDeclaration.TypeReference.Type != "System.Void" && methodDeclaration.Body.Children.Count > 0)
			{
				if (VBNetConstructsConvertVisitor.IsAssignmentTo(methodDeclaration.Body.Children[methodDeclaration.Body.Children.Count - 1], methodDeclaration.Name))
				{
					Expression right = VBNetConstructsConvertVisitor.GetAssignmentFromStatement(methodDeclaration.Body.Children[methodDeclaration.Body.Children.Count - 1]).Right;
					methodDeclaration.Body.Children.RemoveAt(methodDeclaration.Body.Children.Count - 1);
					methodDeclaration.Body.Return(right);
				}
				else
				{
					VBNetConstructsConvertVisitor.ReturnStatementForFunctionAssignment returnStatementForFunctionAssignment = new VBNetConstructsConvertVisitor.ReturnStatementForFunctionAssignment(methodDeclaration.Name);
					methodDeclaration.Body.AcceptVisitor(returnStatementForFunctionAssignment, null);
					if (returnStatementForFunctionAssignment.replacementCount > 0)
					{
						Expression initializer = ExpressionBuilder.CreateDefaultValueForType(methodDeclaration.TypeReference);
						methodDeclaration.Body.Children.Insert(0, new LocalVariableDeclaration(new VariableDeclaration("functionReturnValue", initializer, methodDeclaration.TypeReference)));
						methodDeclaration.Body.Children[0].Parent = methodDeclaration.Body;
						methodDeclaration.Body.Return(new IdentifierExpression("functionReturnValue"));
					}
				}
			}
			return base.VisitMethodDeclaration(methodDeclaration, data);
		}

		public override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			if (!this.IsClassType(ClassType.Interface) && (propertyDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				propertyDeclaration.Modifier |= Modifiers.Public;
			}
			if (propertyDeclaration.HasSetRegion)
			{
				string from = "Value";
				if (propertyDeclaration.SetRegion.Parameters.Count > 0)
				{
					ParameterDeclarationExpression parameterDeclarationExpression = propertyDeclaration.SetRegion.Parameters[0];
					from = parameterDeclarationExpression.ParameterName;
					parameterDeclarationExpression.ParameterName = "Value";
				}
				propertyDeclaration.SetRegion.AcceptVisitor(new RenameIdentifierVisitor(from, "value", StringComparer.InvariantCultureIgnoreCase), null);
			}
			return base.VisitPropertyDeclaration(propertyDeclaration, data);
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			if (this.currentTypeDeclaration != null && (typeDeclaration.Modifier & Modifiers.Visibility) == Modifiers.None)
			{
				typeDeclaration.Modifier |= Modifiers.Public;
			}
			TypeDeclaration typeDeclaration2 = this.currentTypeDeclaration;
			this.currentTypeDeclaration = typeDeclaration;
			base.VisitTypeDeclaration(typeDeclaration, data);
			this.currentTypeDeclaration = typeDeclaration2;
			return null;
		}

		public override object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			base.VisitUnaryOperatorExpression(unaryOperatorExpression, data);
			if (unaryOperatorExpression.Op == UnaryOperatorType.Not)
			{
				if (unaryOperatorExpression.Expression is BinaryOperatorExpression)
				{
					unaryOperatorExpression.Expression = new ParenthesizedExpression(unaryOperatorExpression.Expression);
				}
				ParenthesizedExpression parenthesizedExpression = unaryOperatorExpression.Expression as ParenthesizedExpression;
				if (parenthesizedExpression != null)
				{
					BinaryOperatorExpression binaryOperatorExpression = parenthesizedExpression.Expression as BinaryOperatorExpression;
					if (binaryOperatorExpression != null && binaryOperatorExpression.Op == BinaryOperatorType.ReferenceEquality)
					{
						binaryOperatorExpression.Op = BinaryOperatorType.ReferenceInequality;
						base.ReplaceCurrentNode(parenthesizedExpression);
					}
				}
			}
			return null;
		}

		public override object VisitUsing(Using @using, object data)
		{
			if (this.usings != null && !@using.IsAlias)
			{
				this.usings[@using.Name] = @using.Name;
			}
			return base.VisitUsing(@using, data);
		}

		public override object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			LocalVariableDeclaration localVariableDeclaration = usingStatement.ResourceAcquisition as LocalVariableDeclaration;
			if (localVariableDeclaration != null && localVariableDeclaration.Variables.Count > 1)
			{
				usingStatement.ResourceAcquisition = new LocalVariableDeclaration(localVariableDeclaration.Variables[0]);
				for (int i = 1; i < localVariableDeclaration.Variables.Count; i++)
				{
					UsingStatement usingStatement2 = new UsingStatement(new LocalVariableDeclaration(localVariableDeclaration.Variables[i]), usingStatement.EmbeddedStatement);
					usingStatement.EmbeddedStatement = new BlockStatement();
					usingStatement.EmbeddedStatement.AddChild(usingStatement2);
					usingStatement = usingStatement2;
				}
			}
			return base.VisitUsingStatement(usingStatement, data);
		}

		public bool AddDefaultValueInitializerToLocalVariableDeclarations = true;

		private List<UsingDeclaration> addedUsings;

		private static volatile Dictionary<string, Expression> constantTable;

		private TypeDeclaration currentTypeDeclaration;

		public const string FunctionReturnValueName = "functionReturnValue";

		private static volatile Dictionary<string, Expression> methodTable;

		private Dictionary<string, string> usings;

		public static readonly string VBAssemblyName = "Microsoft.VisualBasic, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a";

		private class ReturnStatementForFunctionAssignment : AbstractAstTransformer
		{
			public ReturnStatementForFunctionAssignment(string functionName)
			{
				this.functionName = functionName;
			}

			public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
			{
				if (identifierExpression.Identifier.Equals(this.functionName, StringComparison.InvariantCultureIgnoreCase) && !(identifierExpression.Parent is AddressOfExpression) && !(identifierExpression.Parent is InvocationExpression))
				{
					identifierExpression.Identifier = "functionReturnValue";
					this.replacementCount++;
				}
				return base.VisitIdentifierExpression(identifierExpression, data);
			}

			private string functionName;

			internal int replacementCount;
		}
	}
}
