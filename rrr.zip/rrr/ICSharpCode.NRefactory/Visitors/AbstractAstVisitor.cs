﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public abstract class AbstractAstVisitor : IAstVisitor
	{
		public virtual object VisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			addHandlerStatement.EventExpression.AcceptVisitor(this, data);
			return addHandlerStatement.HandlerExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			return addressOfExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			foreach (ParameterDeclarationExpression current in anonymousMethodExpression.Parameters)
			{
				current.AcceptVisitor(this, data);
			}
			return anonymousMethodExpression.Body.AcceptVisitor(this, data);
		}

		public virtual object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			arrayCreateExpression.CreateType.AcceptVisitor(this, data);
			foreach (Expression current in arrayCreateExpression.Arguments)
			{
				current.AcceptVisitor(this, data);
			}
			return arrayCreateExpression.ArrayInitializer.AcceptVisitor(this, data);
		}

		public virtual object VisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			assignmentExpression.Left.AcceptVisitor(this, data);
			return assignmentExpression.Right.AcceptVisitor(this, data);
		}

		public virtual object VisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			foreach (Expression current in attribute.PositionalArguments)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (NamedArgumentExpression current2 in attribute.NamedArguments)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitAttributeSection(AttributeSection attributeSection, object data)
		{
			foreach (ICSharpCode.NRefactory.Ast.Attribute current in attributeSection.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			binaryOperatorExpression.Left.AcceptVisitor(this, data);
			return binaryOperatorExpression.Right.AcceptVisitor(this, data);
		}

		public virtual object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			return blockStatement.AcceptChildren(this, data);
		}

		public virtual object VisitBreakStatement(BreakStatement breakStatement, object data)
		{
			return null;
		}

		public virtual object VisitCaseLabel(CaseLabel caseLabel, object data)
		{
			caseLabel.Label.AcceptVisitor(this, data);
			return caseLabel.ToExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitCastExpression(CastExpression castExpression, object data)
		{
			castExpression.CastTo.AcceptVisitor(this, data);
			return castExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitCatchClause(CatchClause catchClause, object data)
		{
			catchClause.TypeReference.AcceptVisitor(this, data);
			catchClause.StatementBlock.AcceptVisitor(this, data);
			return catchClause.Condition.AcceptVisitor(this, data);
		}

		public virtual object VisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			return checkedExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			return checkedStatement.Block.AcceptVisitor(this, data);
		}

		public virtual object VisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitCollectionInitializerExpression(CollectionInitializerExpression collectionInitializerExpression, object data)
		{
			foreach (Expression current in collectionInitializerExpression.CreateExpressions)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			return compilationUnit.AcceptChildren(this, data);
		}

		public virtual object VisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			conditionalExpression.Condition.AcceptVisitor(this, data);
			conditionalExpression.TrueExpression.AcceptVisitor(this, data);
			return conditionalExpression.FalseExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			foreach (AttributeSection current in constructorDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in constructorDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			constructorDeclaration.ConstructorInitializer.AcceptVisitor(this, data);
			return constructorDeclaration.Body.AcceptVisitor(this, data);
		}

		public virtual object VisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			foreach (Expression current in constructorInitializer.Arguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			return null;
		}

		public virtual object VisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			foreach (AttributeSection current in declareDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in declareDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			return declareDeclaration.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			return defaultValueExpression.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			foreach (AttributeSection current in delegateDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			delegateDeclaration.ReturnType.AcceptVisitor(this, data);
			foreach (ParameterDeclarationExpression current2 in delegateDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (TemplateDefinition current3 in delegateDeclaration.Templates)
			{
				current3.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			foreach (AttributeSection current in destructorDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			return destructorDeclaration.Body.AcceptVisitor(this, data);
		}

		public virtual object VisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			return directionExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			doLoopStatement.Condition.AcceptVisitor(this, data);
			return doLoopStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			elseIfSection.Condition.AcceptVisitor(this, data);
			return elseIfSection.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			return null;
		}

		public virtual object VisitEndStatement(EndStatement endStatement, object data)
		{
			return null;
		}

		public virtual object VisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			foreach (Expression current in eraseStatement.Expressions)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			return errorStatement.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			foreach (AttributeSection current in eventAddRegion.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			eventAddRegion.Block.AcceptVisitor(this, data);
			foreach (ParameterDeclarationExpression current2 in eventAddRegion.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			foreach (AttributeSection current in eventDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in eventDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (InterfaceImplementation current3 in eventDeclaration.InterfaceImplementations)
			{
				current3.AcceptVisitor(this, data);
			}
			eventDeclaration.TypeReference.AcceptVisitor(this, data);
			eventDeclaration.AddRegion.AcceptVisitor(this, data);
			eventDeclaration.RemoveRegion.AcceptVisitor(this, data);
			eventDeclaration.RaiseRegion.AcceptVisitor(this, data);
			return eventDeclaration.Initializer.AcceptVisitor(this, data);
		}

		public virtual object VisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			foreach (AttributeSection current in eventRaiseRegion.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			eventRaiseRegion.Block.AcceptVisitor(this, data);
			foreach (ParameterDeclarationExpression current2 in eventRaiseRegion.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			foreach (AttributeSection current in eventRemoveRegion.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			eventRemoveRegion.Block.AcceptVisitor(this, data);
			foreach (ParameterDeclarationExpression current2 in eventRemoveRegion.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitExitStatement(ExitStatement exitStatement, object data)
		{
			return null;
		}

		public virtual object VisitExpressionRangeVariable(ExpressionRangeVariable expressionRangeVariable, object data)
		{
			expressionRangeVariable.Expression.AcceptVisitor(this, data);
			return expressionRangeVariable.Type.AcceptVisitor(this, data);
		}

		public virtual object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			return expressionStatement.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			return null;
		}

		public virtual object VisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			foreach (AttributeSection current in fieldDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			fieldDeclaration.TypeReference.AcceptVisitor(this, data);
			foreach (VariableDeclaration current2 in fieldDeclaration.Fields)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			fixedStatement.PointerDeclaration.AcceptVisitor(this, data);
			return fixedStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			foreachStatement.TypeReference.AcceptVisitor(this, data);
			foreachStatement.Expression.AcceptVisitor(this, data);
			foreachStatement.NextExpression.AcceptVisitor(this, data);
			return foreachStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			forNextStatement.Start.AcceptVisitor(this, data);
			forNextStatement.End.AcceptVisitor(this, data);
			forNextStatement.Step.AcceptVisitor(this, data);
			foreach (Expression current in forNextStatement.NextExpressions)
			{
				current.AcceptVisitor(this, data);
			}
			forNextStatement.TypeReference.AcceptVisitor(this, data);
			forNextStatement.LoopVariableExpression.AcceptVisitor(this, data);
			return forNextStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitForStatement(ForStatement forStatement, object data)
		{
			foreach (Statement current in forStatement.Initializers)
			{
				current.AcceptVisitor(this, data);
			}
			forStatement.Condition.AcceptVisitor(this, data);
			foreach (Statement current2 in forStatement.Iterator)
			{
				current2.AcceptVisitor(this, data);
			}
			return forStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			return gotoCaseStatement.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			return null;
		}

		public virtual object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			foreach (TypeReference current in identifierExpression.TypeArguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			ifElseStatement.Condition.AcceptVisitor(this, data);
			foreach (Statement current in ifElseStatement.TrueStatement)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (Statement current2 in ifElseStatement.FalseStatement)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (ElseIfSection current3 in ifElseStatement.ElseIfSections)
			{
				current3.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			foreach (AttributeSection current in indexerDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in indexerDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (InterfaceImplementation current3 in indexerDeclaration.InterfaceImplementations)
			{
				current3.AcceptVisitor(this, data);
			}
			indexerDeclaration.TypeReference.AcceptVisitor(this, data);
			indexerDeclaration.GetRegion.AcceptVisitor(this, data);
			return indexerDeclaration.SetRegion.AcceptVisitor(this, data);
		}

		public virtual object VisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			indexerExpression.TargetObject.AcceptVisitor(this, data);
			foreach (Expression current in indexerExpression.Indexes)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			foreach (TypeReference current in innerClassTypeReference.GenericTypes)
			{
				current.AcceptVisitor(this, data);
			}
			return innerClassTypeReference.BaseType.AcceptVisitor(this, data);
		}

		public virtual object VisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			return interfaceImplementation.InterfaceType.AcceptVisitor(this, data);
		}

		public virtual object VisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			invocationExpression.TargetObject.AcceptVisitor(this, data);
			foreach (Expression current in invocationExpression.Arguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitLabelStatement(LabelStatement labelStatement, object data)
		{
			return null;
		}

		public virtual object VisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			foreach (ParameterDeclarationExpression current in lambdaExpression.Parameters)
			{
				current.AcceptVisitor(this, data);
			}
			lambdaExpression.StatementBody.AcceptVisitor(this, data);
			return lambdaExpression.ExpressionBody.AcceptVisitor(this, data);
		}

		public virtual object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			localVariableDeclaration.TypeReference.AcceptVisitor(this, data);
			foreach (VariableDeclaration current in localVariableDeclaration.Variables)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitLockStatement(LockStatement lockStatement, object data)
		{
			lockStatement.LockExpression.AcceptVisitor(this, data);
			return lockStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			memberReferenceExpression.TargetObject.AcceptVisitor(this, data);
			foreach (TypeReference current in memberReferenceExpression.TypeArguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			foreach (AttributeSection current in methodDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in methodDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (InterfaceImplementation current3 in methodDeclaration.InterfaceImplementations)
			{
				current3.AcceptVisitor(this, data);
			}
			methodDeclaration.TypeReference.AcceptVisitor(this, data);
			methodDeclaration.Body.AcceptVisitor(this, data);
			foreach (TemplateDefinition current4 in methodDeclaration.Templates)
			{
				current4.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			return namedArgumentExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			return namespaceDeclaration.AcceptChildren(this, data);
		}

		public virtual object VisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			objectCreateExpression.CreateType.AcceptVisitor(this, data);
			foreach (Expression current in objectCreateExpression.Parameters)
			{
				current.AcceptVisitor(this, data);
			}
			return objectCreateExpression.ObjectInitializer.AcceptVisitor(this, data);
		}

		public virtual object VisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			return onErrorStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			foreach (AttributeSection current in operatorDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in operatorDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (InterfaceImplementation current3 in operatorDeclaration.InterfaceImplementations)
			{
				current3.AcceptVisitor(this, data);
			}
			operatorDeclaration.TypeReference.AcceptVisitor(this, data);
			operatorDeclaration.Body.AcceptVisitor(this, data);
			foreach (TemplateDefinition current4 in operatorDeclaration.Templates)
			{
				current4.AcceptVisitor(this, data);
			}
			foreach (AttributeSection current5 in operatorDeclaration.ReturnTypeAttributes)
			{
				current5.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			return null;
		}

		public virtual object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			foreach (AttributeSection current in parameterDeclarationExpression.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			parameterDeclarationExpression.TypeReference.AcceptVisitor(this, data);
			return parameterDeclarationExpression.DefaultValue.AcceptVisitor(this, data);
		}

		public virtual object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			return parenthesizedExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			pointerReferenceExpression.TargetObject.AcceptVisitor(this, data);
			foreach (TypeReference current in pointerReferenceExpression.TypeArguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			return null;
		}

		public virtual object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			foreach (AttributeSection current in propertyDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ParameterDeclarationExpression current2 in propertyDeclaration.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (InterfaceImplementation current3 in propertyDeclaration.InterfaceImplementations)
			{
				current3.AcceptVisitor(this, data);
			}
			propertyDeclaration.TypeReference.AcceptVisitor(this, data);
			propertyDeclaration.GetRegion.AcceptVisitor(this, data);
			return propertyDeclaration.SetRegion.AcceptVisitor(this, data);
		}

		public virtual object VisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			foreach (AttributeSection current in propertyGetRegion.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			return propertyGetRegion.Block.AcceptVisitor(this, data);
		}

		public virtual object VisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			foreach (AttributeSection current in propertySetRegion.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			propertySetRegion.Block.AcceptVisitor(this, data);
			foreach (ParameterDeclarationExpression current2 in propertySetRegion.Parameters)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpression(QueryExpression queryExpression, object data)
		{
			queryExpression.FromClause.AcceptVisitor(this, data);
			foreach (QueryExpressionClause current in queryExpression.MiddleClauses)
			{
				current.AcceptVisitor(this, data);
			}
			return queryExpression.SelectOrGroupClause.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionAggregateClause(QueryExpressionAggregateClause queryExpressionAggregateClause, object data)
		{
			queryExpressionAggregateClause.FromClause.AcceptVisitor(this, data);
			foreach (QueryExpressionClause current in queryExpressionAggregateClause.MiddleClauses)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ExpressionRangeVariable current2 in queryExpressionAggregateClause.IntoVariables)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionDistinctClause(QueryExpressionDistinctClause queryExpressionDistinctClause, object data)
		{
			return null;
		}

		public virtual object VisitQueryExpressionFromClause(QueryExpressionFromClause queryExpressionFromClause, object data)
		{
			queryExpressionFromClause.Type.AcceptVisitor(this, data);
			return queryExpressionFromClause.InExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionGroupClause(QueryExpressionGroupClause queryExpressionGroupClause, object data)
		{
			queryExpressionGroupClause.Projection.AcceptVisitor(this, data);
			return queryExpressionGroupClause.GroupBy.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionGroupJoinVBClause(QueryExpressionGroupJoinVBClause queryExpressionGroupJoinVBClause, object data)
		{
			queryExpressionGroupJoinVBClause.JoinClause.AcceptVisitor(this, data);
			foreach (ExpressionRangeVariable current in queryExpressionGroupJoinVBClause.IntoVariables)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionGroupVBClause(QueryExpressionGroupVBClause queryExpressionGroupVBClause, object data)
		{
			foreach (ExpressionRangeVariable current in queryExpressionGroupVBClause.GroupVariables)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (ExpressionRangeVariable current2 in queryExpressionGroupVBClause.ByVariables)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (ExpressionRangeVariable current3 in queryExpressionGroupVBClause.IntoVariables)
			{
				current3.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionJoinClause(QueryExpressionJoinClause queryExpressionJoinClause, object data)
		{
			queryExpressionJoinClause.Type.AcceptVisitor(this, data);
			queryExpressionJoinClause.InExpression.AcceptVisitor(this, data);
			queryExpressionJoinClause.OnExpression.AcceptVisitor(this, data);
			return queryExpressionJoinClause.EqualsExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionJoinConditionVB(QueryExpressionJoinConditionVB queryExpressionJoinConditionVB, object data)
		{
			queryExpressionJoinConditionVB.LeftSide.AcceptVisitor(this, data);
			return queryExpressionJoinConditionVB.RightSide.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionJoinVBClause(QueryExpressionJoinVBClause queryExpressionJoinVBClause, object data)
		{
			queryExpressionJoinVBClause.JoinVariable.AcceptVisitor(this, data);
			queryExpressionJoinVBClause.SubJoin.AcceptVisitor(this, data);
			foreach (QueryExpressionJoinConditionVB current in queryExpressionJoinVBClause.Conditions)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionLetClause(QueryExpressionLetClause queryExpressionLetClause, object data)
		{
			return queryExpressionLetClause.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionLetVBClause(QueryExpressionLetVBClause queryExpressionLetVBClause, object data)
		{
			foreach (ExpressionRangeVariable current in queryExpressionLetVBClause.Variables)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			foreach (QueryExpressionOrdering current in queryExpressionOrderClause.Orderings)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionOrdering(QueryExpressionOrdering queryExpressionOrdering, object data)
		{
			return queryExpressionOrdering.Criteria.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionPartitionVBClause(QueryExpressionPartitionVBClause queryExpressionPartitionVBClause, object data)
		{
			return queryExpressionPartitionVBClause.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionSelectClause(QueryExpressionSelectClause queryExpressionSelectClause, object data)
		{
			return queryExpressionSelectClause.Projection.AcceptVisitor(this, data);
		}

		public virtual object VisitQueryExpressionSelectVBClause(QueryExpressionSelectVBClause queryExpressionSelectVBClause, object data)
		{
			foreach (ExpressionRangeVariable current in queryExpressionSelectVBClause.Variables)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitQueryExpressionWhereClause(QueryExpressionWhereClause queryExpressionWhereClause, object data)
		{
			return queryExpressionWhereClause.Condition.AcceptVisitor(this, data);
		}

		public virtual object VisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			foreach (Expression current in raiseEventStatement.Arguments)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			foreach (InvocationExpression current in reDimStatement.ReDimClauses)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			removeHandlerStatement.EventExpression.AcceptVisitor(this, data);
			return removeHandlerStatement.HandlerExpression.AcceptVisitor(this, data);
		}

		public virtual object VisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			return null;
		}

		public virtual object VisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			return returnStatement.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			return sizeOfExpression.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			stackAllocExpression.TypeReference.AcceptVisitor(this, data);
			return stackAllocExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitStopStatement(StopStatement stopStatement, object data)
		{
			return null;
		}

		public virtual object VisitSwitchSection(SwitchSection switchSection, object data)
		{
			foreach (CaseLabel current in switchSection.SwitchLabels)
			{
				current.AcceptVisitor(this, data);
			}
			return switchSection.AcceptChildren(this, data);
		}

		public virtual object VisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			switchStatement.SwitchExpression.AcceptVisitor(this, data);
			foreach (SwitchSection current in switchStatement.SwitchSections)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			foreach (AttributeSection current in templateDefinition.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (TypeReference current2 in templateDefinition.Bases)
			{
				current2.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			return null;
		}

		public virtual object VisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			return throwStatement.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			tryCatchStatement.StatementBlock.AcceptVisitor(this, data);
			foreach (CatchClause current in tryCatchStatement.CatchClauses)
			{
				current.AcceptVisitor(this, data);
			}
			return tryCatchStatement.FinallyBlock.AcceptVisitor(this, data);
		}

		public virtual object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			foreach (AttributeSection current in typeDeclaration.Attributes)
			{
				current.AcceptVisitor(this, data);
			}
			foreach (TypeReference current2 in typeDeclaration.BaseTypes)
			{
				current2.AcceptVisitor(this, data);
			}
			foreach (TemplateDefinition current3 in typeDeclaration.Templates)
			{
				current3.AcceptVisitor(this, data);
			}
			return typeDeclaration.AcceptChildren(this, data);
		}

		public virtual object VisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			return typeOfExpression.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			typeOfIsExpression.Expression.AcceptVisitor(this, data);
			return typeOfIsExpression.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitTypeReference(TypeReference typeReference, object data)
		{
			foreach (TypeReference current in typeReference.GenericTypes)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			return typeReferenceExpression.TypeReference.AcceptVisitor(this, data);
		}

		public virtual object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			return unaryOperatorExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			return uncheckedExpression.Expression.AcceptVisitor(this, data);
		}

		public virtual object VisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			return uncheckedStatement.Block.AcceptVisitor(this, data);
		}

		public virtual object VisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			return unsafeStatement.Block.AcceptVisitor(this, data);
		}

		public virtual object VisitUsing(Using @using, object data)
		{
			return @using.Alias.AcceptVisitor(this, data);
		}

		public virtual object VisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			foreach (Using current in usingDeclaration.Usings)
			{
				current.AcceptVisitor(this, data);
			}
			return null;
		}

		public virtual object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			usingStatement.ResourceAcquisition.AcceptVisitor(this, data);
			return usingStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public virtual object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			variableDeclaration.Initializer.AcceptVisitor(this, data);
			variableDeclaration.TypeReference.AcceptVisitor(this, data);
			return variableDeclaration.FixedArrayInitialization.AcceptVisitor(this, data);
		}

		public virtual object VisitWithStatement(WithStatement withStatement, object data)
		{
			withStatement.Expression.AcceptVisitor(this, data);
			return withStatement.Body.AcceptVisitor(this, data);
		}

		public virtual object VisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			return yieldStatement.Statement.AcceptVisitor(this, data);
		}
	}
}
