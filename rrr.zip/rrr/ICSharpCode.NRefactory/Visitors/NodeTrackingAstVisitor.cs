﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public abstract class NodeTrackingAstVisitor : AbstractAstVisitor
	{
		protected virtual void BeginVisit(INode node)
		{
		}

		protected virtual void EndVisit(INode node)
		{
		}

		public virtual object TrackedVisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			return base.VisitAddHandlerStatement(addHandlerStatement, data);
		}

		public virtual object TrackedVisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			return base.VisitAddressOfExpression(addressOfExpression, data);
		}

		public virtual object TrackedVisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			return base.VisitAnonymousMethodExpression(anonymousMethodExpression, data);
		}

		public virtual object TrackedVisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			return base.VisitArrayCreateExpression(arrayCreateExpression, data);
		}

		public virtual object TrackedVisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			return base.VisitAssignmentExpression(assignmentExpression, data);
		}

		public virtual object TrackedVisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			return base.VisitAttribute(attribute, data);
		}

		public virtual object TrackedVisitAttributeSection(AttributeSection attributeSection, object data)
		{
			return base.VisitAttributeSection(attributeSection, data);
		}

		public virtual object TrackedVisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			return base.VisitBaseReferenceExpression(baseReferenceExpression, data);
		}

		public virtual object TrackedVisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			return base.VisitBinaryOperatorExpression(binaryOperatorExpression, data);
		}

		public virtual object TrackedVisitBlockStatement(BlockStatement blockStatement, object data)
		{
			return base.VisitBlockStatement(blockStatement, data);
		}

		public virtual object TrackedVisitBreakStatement(BreakStatement breakStatement, object data)
		{
			return base.VisitBreakStatement(breakStatement, data);
		}

		public virtual object TrackedVisitCaseLabel(CaseLabel caseLabel, object data)
		{
			return base.VisitCaseLabel(caseLabel, data);
		}

		public virtual object TrackedVisitCastExpression(CastExpression castExpression, object data)
		{
			return base.VisitCastExpression(castExpression, data);
		}

		public virtual object TrackedVisitCatchClause(CatchClause catchClause, object data)
		{
			return base.VisitCatchClause(catchClause, data);
		}

		public virtual object TrackedVisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			return base.VisitCheckedExpression(checkedExpression, data);
		}

		public virtual object TrackedVisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			return base.VisitCheckedStatement(checkedStatement, data);
		}

		public virtual object TrackedVisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			return base.VisitClassReferenceExpression(classReferenceExpression, data);
		}

		public virtual object TrackedVisitCollectionInitializerExpression(CollectionInitializerExpression collectionInitializerExpression, object data)
		{
			return base.VisitCollectionInitializerExpression(collectionInitializerExpression, data);
		}

		public virtual object TrackedVisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			return base.VisitCompilationUnit(compilationUnit, data);
		}

		public virtual object TrackedVisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			return base.VisitConditionalExpression(conditionalExpression, data);
		}

		public virtual object TrackedVisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			return base.VisitConstructorDeclaration(constructorDeclaration, data);
		}

		public virtual object TrackedVisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			return base.VisitConstructorInitializer(constructorInitializer, data);
		}

		public virtual object TrackedVisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			return base.VisitContinueStatement(continueStatement, data);
		}

		public virtual object TrackedVisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			return base.VisitDeclareDeclaration(declareDeclaration, data);
		}

		public virtual object TrackedVisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			return base.VisitDefaultValueExpression(defaultValueExpression, data);
		}

		public virtual object TrackedVisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			return base.VisitDelegateDeclaration(delegateDeclaration, data);
		}

		public virtual object TrackedVisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			return base.VisitDestructorDeclaration(destructorDeclaration, data);
		}

		public virtual object TrackedVisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			return base.VisitDirectionExpression(directionExpression, data);
		}

		public virtual object TrackedVisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			return base.VisitDoLoopStatement(doLoopStatement, data);
		}

		public virtual object TrackedVisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			return base.VisitElseIfSection(elseIfSection, data);
		}

		public virtual object TrackedVisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			return base.VisitEmptyStatement(emptyStatement, data);
		}

		public virtual object TrackedVisitEndStatement(EndStatement endStatement, object data)
		{
			return base.VisitEndStatement(endStatement, data);
		}

		public virtual object TrackedVisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			return base.VisitEraseStatement(eraseStatement, data);
		}

		public virtual object TrackedVisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			return base.VisitErrorStatement(errorStatement, data);
		}

		public virtual object TrackedVisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			return base.VisitEventAddRegion(eventAddRegion, data);
		}

		public virtual object TrackedVisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			return base.VisitEventDeclaration(eventDeclaration, data);
		}

		public virtual object TrackedVisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			return base.VisitEventRaiseRegion(eventRaiseRegion, data);
		}

		public virtual object TrackedVisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			return base.VisitEventRemoveRegion(eventRemoveRegion, data);
		}

		public virtual object TrackedVisitExitStatement(ExitStatement exitStatement, object data)
		{
			return base.VisitExitStatement(exitStatement, data);
		}

		public virtual object TrackedVisitExpressionRangeVariable(ExpressionRangeVariable expressionRangeVariable, object data)
		{
			return base.VisitExpressionRangeVariable(expressionRangeVariable, data);
		}

		public virtual object TrackedVisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			return base.VisitExpressionStatement(expressionStatement, data);
		}

		public virtual object TrackedVisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			return base.VisitExternAliasDirective(externAliasDirective, data);
		}

		public virtual object TrackedVisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			return base.VisitFieldDeclaration(fieldDeclaration, data);
		}

		public virtual object TrackedVisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			return base.VisitFixedStatement(fixedStatement, data);
		}

		public virtual object TrackedVisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			return base.VisitForeachStatement(foreachStatement, data);
		}

		public virtual object TrackedVisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			return base.VisitForNextStatement(forNextStatement, data);
		}

		public virtual object TrackedVisitForStatement(ForStatement forStatement, object data)
		{
			return base.VisitForStatement(forStatement, data);
		}

		public virtual object TrackedVisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			return base.VisitGotoCaseStatement(gotoCaseStatement, data);
		}

		public virtual object TrackedVisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			return base.VisitGotoStatement(gotoStatement, data);
		}

		public virtual object TrackedVisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			return base.VisitIdentifierExpression(identifierExpression, data);
		}

		public virtual object TrackedVisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			return base.VisitIfElseStatement(ifElseStatement, data);
		}

		public virtual object TrackedVisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			return base.VisitIndexerDeclaration(indexerDeclaration, data);
		}

		public virtual object TrackedVisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			return base.VisitIndexerExpression(indexerExpression, data);
		}

		public virtual object TrackedVisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			return base.VisitInnerClassTypeReference(innerClassTypeReference, data);
		}

		public virtual object TrackedVisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			return base.VisitInterfaceImplementation(interfaceImplementation, data);
		}

		public virtual object TrackedVisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			return base.VisitInvocationExpression(invocationExpression, data);
		}

		public virtual object TrackedVisitLabelStatement(LabelStatement labelStatement, object data)
		{
			return base.VisitLabelStatement(labelStatement, data);
		}

		public virtual object TrackedVisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			return base.VisitLambdaExpression(lambdaExpression, data);
		}

		public virtual object TrackedVisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			return base.VisitLocalVariableDeclaration(localVariableDeclaration, data);
		}

		public virtual object TrackedVisitLockStatement(LockStatement lockStatement, object data)
		{
			return base.VisitLockStatement(lockStatement, data);
		}

		public virtual object TrackedVisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			return base.VisitMemberReferenceExpression(memberReferenceExpression, data);
		}

		public virtual object TrackedVisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			return base.VisitMethodDeclaration(methodDeclaration, data);
		}

		public virtual object TrackedVisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			return base.VisitNamedArgumentExpression(namedArgumentExpression, data);
		}

		public virtual object TrackedVisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			return base.VisitNamespaceDeclaration(namespaceDeclaration, data);
		}

		public virtual object TrackedVisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			return base.VisitObjectCreateExpression(objectCreateExpression, data);
		}

		public virtual object TrackedVisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			return base.VisitOnErrorStatement(onErrorStatement, data);
		}

		public virtual object TrackedVisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			return base.VisitOperatorDeclaration(operatorDeclaration, data);
		}

		public virtual object TrackedVisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			return base.VisitOptionDeclaration(optionDeclaration, data);
		}

		public virtual object TrackedVisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			return base.VisitParameterDeclarationExpression(parameterDeclarationExpression, data);
		}

		public virtual object TrackedVisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			return base.VisitParenthesizedExpression(parenthesizedExpression, data);
		}

		public virtual object TrackedVisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			return base.VisitPointerReferenceExpression(pointerReferenceExpression, data);
		}

		public virtual object TrackedVisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			return base.VisitPrimitiveExpression(primitiveExpression, data);
		}

		public virtual object TrackedVisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			return base.VisitPropertyDeclaration(propertyDeclaration, data);
		}

		public virtual object TrackedVisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			return base.VisitPropertyGetRegion(propertyGetRegion, data);
		}

		public virtual object TrackedVisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			return base.VisitPropertySetRegion(propertySetRegion, data);
		}

		public virtual object TrackedVisitQueryExpression(QueryExpression queryExpression, object data)
		{
			return base.VisitQueryExpression(queryExpression, data);
		}

		public virtual object TrackedVisitQueryExpressionAggregateClause(QueryExpressionAggregateClause queryExpressionAggregateClause, object data)
		{
			return base.VisitQueryExpressionAggregateClause(queryExpressionAggregateClause, data);
		}

		public virtual object TrackedVisitQueryExpressionDistinctClause(QueryExpressionDistinctClause queryExpressionDistinctClause, object data)
		{
			return base.VisitQueryExpressionDistinctClause(queryExpressionDistinctClause, data);
		}

		public virtual object TrackedVisitQueryExpressionFromClause(QueryExpressionFromClause queryExpressionFromClause, object data)
		{
			return base.VisitQueryExpressionFromClause(queryExpressionFromClause, data);
		}

		public virtual object TrackedVisitQueryExpressionGroupClause(QueryExpressionGroupClause queryExpressionGroupClause, object data)
		{
			return base.VisitQueryExpressionGroupClause(queryExpressionGroupClause, data);
		}

		public virtual object TrackedVisitQueryExpressionGroupJoinVBClause(QueryExpressionGroupJoinVBClause queryExpressionGroupJoinVBClause, object data)
		{
			return base.VisitQueryExpressionGroupJoinVBClause(queryExpressionGroupJoinVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionGroupVBClause(QueryExpressionGroupVBClause queryExpressionGroupVBClause, object data)
		{
			return base.VisitQueryExpressionGroupVBClause(queryExpressionGroupVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionJoinClause(QueryExpressionJoinClause queryExpressionJoinClause, object data)
		{
			return base.VisitQueryExpressionJoinClause(queryExpressionJoinClause, data);
		}

		public virtual object TrackedVisitQueryExpressionJoinConditionVB(QueryExpressionJoinConditionVB queryExpressionJoinConditionVB, object data)
		{
			return base.VisitQueryExpressionJoinConditionVB(queryExpressionJoinConditionVB, data);
		}

		public virtual object TrackedVisitQueryExpressionJoinVBClause(QueryExpressionJoinVBClause queryExpressionJoinVBClause, object data)
		{
			return base.VisitQueryExpressionJoinVBClause(queryExpressionJoinVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionLetClause(QueryExpressionLetClause queryExpressionLetClause, object data)
		{
			return base.VisitQueryExpressionLetClause(queryExpressionLetClause, data);
		}

		public virtual object TrackedVisitQueryExpressionLetVBClause(QueryExpressionLetVBClause queryExpressionLetVBClause, object data)
		{
			return base.VisitQueryExpressionLetVBClause(queryExpressionLetVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			return base.VisitQueryExpressionOrderClause(queryExpressionOrderClause, data);
		}

		public virtual object TrackedVisitQueryExpressionOrdering(QueryExpressionOrdering queryExpressionOrdering, object data)
		{
			return base.VisitQueryExpressionOrdering(queryExpressionOrdering, data);
		}

		public virtual object TrackedVisitQueryExpressionPartitionVBClause(QueryExpressionPartitionVBClause queryExpressionPartitionVBClause, object data)
		{
			return base.VisitQueryExpressionPartitionVBClause(queryExpressionPartitionVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionSelectClause(QueryExpressionSelectClause queryExpressionSelectClause, object data)
		{
			return base.VisitQueryExpressionSelectClause(queryExpressionSelectClause, data);
		}

		public virtual object TrackedVisitQueryExpressionSelectVBClause(QueryExpressionSelectVBClause queryExpressionSelectVBClause, object data)
		{
			return base.VisitQueryExpressionSelectVBClause(queryExpressionSelectVBClause, data);
		}

		public virtual object TrackedVisitQueryExpressionWhereClause(QueryExpressionWhereClause queryExpressionWhereClause, object data)
		{
			return base.VisitQueryExpressionWhereClause(queryExpressionWhereClause, data);
		}

		public virtual object TrackedVisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			return base.VisitRaiseEventStatement(raiseEventStatement, data);
		}

		public virtual object TrackedVisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			return base.VisitReDimStatement(reDimStatement, data);
		}

		public virtual object TrackedVisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			return base.VisitRemoveHandlerStatement(removeHandlerStatement, data);
		}

		public virtual object TrackedVisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			return base.VisitResumeStatement(resumeStatement, data);
		}

		public virtual object TrackedVisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			return base.VisitReturnStatement(returnStatement, data);
		}

		public virtual object TrackedVisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			return base.VisitSizeOfExpression(sizeOfExpression, data);
		}

		public virtual object TrackedVisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			return base.VisitStackAllocExpression(stackAllocExpression, data);
		}

		public virtual object TrackedVisitStopStatement(StopStatement stopStatement, object data)
		{
			return base.VisitStopStatement(stopStatement, data);
		}

		public virtual object TrackedVisitSwitchSection(SwitchSection switchSection, object data)
		{
			return base.VisitSwitchSection(switchSection, data);
		}

		public virtual object TrackedVisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			return base.VisitSwitchStatement(switchStatement, data);
		}

		public virtual object TrackedVisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			return base.VisitTemplateDefinition(templateDefinition, data);
		}

		public virtual object TrackedVisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			return base.VisitThisReferenceExpression(thisReferenceExpression, data);
		}

		public virtual object TrackedVisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			return base.VisitThrowStatement(throwStatement, data);
		}

		public virtual object TrackedVisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			return base.VisitTryCatchStatement(tryCatchStatement, data);
		}

		public virtual object TrackedVisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			return base.VisitTypeDeclaration(typeDeclaration, data);
		}

		public virtual object TrackedVisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			return base.VisitTypeOfExpression(typeOfExpression, data);
		}

		public virtual object TrackedVisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			return base.VisitTypeOfIsExpression(typeOfIsExpression, data);
		}

		public virtual object TrackedVisitTypeReference(TypeReference typeReference, object data)
		{
			return base.VisitTypeReference(typeReference, data);
		}

		public virtual object TrackedVisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			return base.VisitTypeReferenceExpression(typeReferenceExpression, data);
		}

		public virtual object TrackedVisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			return base.VisitUnaryOperatorExpression(unaryOperatorExpression, data);
		}

		public virtual object TrackedVisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			return base.VisitUncheckedExpression(uncheckedExpression, data);
		}

		public virtual object TrackedVisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			return base.VisitUncheckedStatement(uncheckedStatement, data);
		}

		public virtual object TrackedVisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			return base.VisitUnsafeStatement(unsafeStatement, data);
		}

		public virtual object TrackedVisitUsing(Using @using, object data)
		{
			return base.VisitUsing(@using, data);
		}

		public virtual object TrackedVisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			return base.VisitUsingDeclaration(usingDeclaration, data);
		}

		public virtual object TrackedVisitUsingStatement(UsingStatement usingStatement, object data)
		{
			return base.VisitUsingStatement(usingStatement, data);
		}

		public virtual object TrackedVisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			return base.VisitVariableDeclaration(variableDeclaration, data);
		}

		public virtual object TrackedVisitWithStatement(WithStatement withStatement, object data)
		{
			return base.VisitWithStatement(withStatement, data);
		}

		public virtual object TrackedVisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			return base.VisitYieldStatement(yieldStatement, data);
		}

		public sealed override object VisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			this.BeginVisit(addHandlerStatement);
			object result = this.TrackedVisitAddHandlerStatement(addHandlerStatement, data);
			this.EndVisit(addHandlerStatement);
			return result;
		}

		public sealed override object VisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			this.BeginVisit(addressOfExpression);
			object result = this.TrackedVisitAddressOfExpression(addressOfExpression, data);
			this.EndVisit(addressOfExpression);
			return result;
		}

		public sealed override object VisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			this.BeginVisit(anonymousMethodExpression);
			object result = this.TrackedVisitAnonymousMethodExpression(anonymousMethodExpression, data);
			this.EndVisit(anonymousMethodExpression);
			return result;
		}

		public sealed override object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			this.BeginVisit(arrayCreateExpression);
			object result = this.TrackedVisitArrayCreateExpression(arrayCreateExpression, data);
			this.EndVisit(arrayCreateExpression);
			return result;
		}

		public sealed override object VisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			this.BeginVisit(assignmentExpression);
			object result = this.TrackedVisitAssignmentExpression(assignmentExpression, data);
			this.EndVisit(assignmentExpression);
			return result;
		}

		public sealed override object VisitAttribute(ICSharpCode.NRefactory.Ast.Attribute attribute, object data)
		{
			this.BeginVisit(attribute);
			object result = this.TrackedVisitAttribute(attribute, data);
			this.EndVisit(attribute);
			return result;
		}

		public sealed override object VisitAttributeSection(AttributeSection attributeSection, object data)
		{
			this.BeginVisit(attributeSection);
			object result = this.TrackedVisitAttributeSection(attributeSection, data);
			this.EndVisit(attributeSection);
			return result;
		}

		public sealed override object VisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			this.BeginVisit(baseReferenceExpression);
			object result = this.TrackedVisitBaseReferenceExpression(baseReferenceExpression, data);
			this.EndVisit(baseReferenceExpression);
			return result;
		}

		public sealed override object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			this.BeginVisit(binaryOperatorExpression);
			object result = this.TrackedVisitBinaryOperatorExpression(binaryOperatorExpression, data);
			this.EndVisit(binaryOperatorExpression);
			return result;
		}

		public sealed override object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			this.BeginVisit(blockStatement);
			object result = this.TrackedVisitBlockStatement(blockStatement, data);
			this.EndVisit(blockStatement);
			return result;
		}

		public sealed override object VisitBreakStatement(BreakStatement breakStatement, object data)
		{
			this.BeginVisit(breakStatement);
			object result = this.TrackedVisitBreakStatement(breakStatement, data);
			this.EndVisit(breakStatement);
			return result;
		}

		public sealed override object VisitCaseLabel(CaseLabel caseLabel, object data)
		{
			this.BeginVisit(caseLabel);
			object result = this.TrackedVisitCaseLabel(caseLabel, data);
			this.EndVisit(caseLabel);
			return result;
		}

		public sealed override object VisitCastExpression(CastExpression castExpression, object data)
		{
			this.BeginVisit(castExpression);
			object result = this.TrackedVisitCastExpression(castExpression, data);
			this.EndVisit(castExpression);
			return result;
		}

		public sealed override object VisitCatchClause(CatchClause catchClause, object data)
		{
			this.BeginVisit(catchClause);
			object result = this.TrackedVisitCatchClause(catchClause, data);
			this.EndVisit(catchClause);
			return result;
		}

		public sealed override object VisitCheckedExpression(CheckedExpression checkedExpression, object data)
		{
			this.BeginVisit(checkedExpression);
			object result = this.TrackedVisitCheckedExpression(checkedExpression, data);
			this.EndVisit(checkedExpression);
			return result;
		}

		public sealed override object VisitCheckedStatement(CheckedStatement checkedStatement, object data)
		{
			this.BeginVisit(checkedStatement);
			object result = this.TrackedVisitCheckedStatement(checkedStatement, data);
			this.EndVisit(checkedStatement);
			return result;
		}

		public sealed override object VisitClassReferenceExpression(ClassReferenceExpression classReferenceExpression, object data)
		{
			this.BeginVisit(classReferenceExpression);
			object result = this.TrackedVisitClassReferenceExpression(classReferenceExpression, data);
			this.EndVisit(classReferenceExpression);
			return result;
		}

		public sealed override object VisitCollectionInitializerExpression(CollectionInitializerExpression collectionInitializerExpression, object data)
		{
			this.BeginVisit(collectionInitializerExpression);
			object result = this.TrackedVisitCollectionInitializerExpression(collectionInitializerExpression, data);
			this.EndVisit(collectionInitializerExpression);
			return result;
		}

		public sealed override object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			this.BeginVisit(compilationUnit);
			object result = this.TrackedVisitCompilationUnit(compilationUnit, data);
			this.EndVisit(compilationUnit);
			return result;
		}

		public sealed override object VisitConditionalExpression(ConditionalExpression conditionalExpression, object data)
		{
			this.BeginVisit(conditionalExpression);
			object result = this.TrackedVisitConditionalExpression(conditionalExpression, data);
			this.EndVisit(conditionalExpression);
			return result;
		}

		public sealed override object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			this.BeginVisit(constructorDeclaration);
			object result = this.TrackedVisitConstructorDeclaration(constructorDeclaration, data);
			this.EndVisit(constructorDeclaration);
			return result;
		}

		public sealed override object VisitConstructorInitializer(ConstructorInitializer constructorInitializer, object data)
		{
			this.BeginVisit(constructorInitializer);
			object result = this.TrackedVisitConstructorInitializer(constructorInitializer, data);
			this.EndVisit(constructorInitializer);
			return result;
		}

		public sealed override object VisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			this.BeginVisit(continueStatement);
			object result = this.TrackedVisitContinueStatement(continueStatement, data);
			this.EndVisit(continueStatement);
			return result;
		}

		public sealed override object VisitDeclareDeclaration(DeclareDeclaration declareDeclaration, object data)
		{
			this.BeginVisit(declareDeclaration);
			object result = this.TrackedVisitDeclareDeclaration(declareDeclaration, data);
			this.EndVisit(declareDeclaration);
			return result;
		}

		public sealed override object VisitDefaultValueExpression(DefaultValueExpression defaultValueExpression, object data)
		{
			this.BeginVisit(defaultValueExpression);
			object result = this.TrackedVisitDefaultValueExpression(defaultValueExpression, data);
			this.EndVisit(defaultValueExpression);
			return result;
		}

		public sealed override object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			this.BeginVisit(delegateDeclaration);
			object result = this.TrackedVisitDelegateDeclaration(delegateDeclaration, data);
			this.EndVisit(delegateDeclaration);
			return result;
		}

		public sealed override object VisitDestructorDeclaration(DestructorDeclaration destructorDeclaration, object data)
		{
			this.BeginVisit(destructorDeclaration);
			object result = this.TrackedVisitDestructorDeclaration(destructorDeclaration, data);
			this.EndVisit(destructorDeclaration);
			return result;
		}

		public sealed override object VisitDirectionExpression(DirectionExpression directionExpression, object data)
		{
			this.BeginVisit(directionExpression);
			object result = this.TrackedVisitDirectionExpression(directionExpression, data);
			this.EndVisit(directionExpression);
			return result;
		}

		public sealed override object VisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			this.BeginVisit(doLoopStatement);
			object result = this.TrackedVisitDoLoopStatement(doLoopStatement, data);
			this.EndVisit(doLoopStatement);
			return result;
		}

		public sealed override object VisitElseIfSection(ElseIfSection elseIfSection, object data)
		{
			this.BeginVisit(elseIfSection);
			object result = this.TrackedVisitElseIfSection(elseIfSection, data);
			this.EndVisit(elseIfSection);
			return result;
		}

		public sealed override object VisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			this.BeginVisit(emptyStatement);
			object result = this.TrackedVisitEmptyStatement(emptyStatement, data);
			this.EndVisit(emptyStatement);
			return result;
		}

		public sealed override object VisitEndStatement(EndStatement endStatement, object data)
		{
			this.BeginVisit(endStatement);
			object result = this.TrackedVisitEndStatement(endStatement, data);
			this.EndVisit(endStatement);
			return result;
		}

		public sealed override object VisitEraseStatement(EraseStatement eraseStatement, object data)
		{
			this.BeginVisit(eraseStatement);
			object result = this.TrackedVisitEraseStatement(eraseStatement, data);
			this.EndVisit(eraseStatement);
			return result;
		}

		public sealed override object VisitErrorStatement(ErrorStatement errorStatement, object data)
		{
			this.BeginVisit(errorStatement);
			object result = this.TrackedVisitErrorStatement(errorStatement, data);
			this.EndVisit(errorStatement);
			return result;
		}

		public sealed override object VisitEventAddRegion(EventAddRegion eventAddRegion, object data)
		{
			this.BeginVisit(eventAddRegion);
			object result = this.TrackedVisitEventAddRegion(eventAddRegion, data);
			this.EndVisit(eventAddRegion);
			return result;
		}

		public sealed override object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			this.BeginVisit(eventDeclaration);
			object result = this.TrackedVisitEventDeclaration(eventDeclaration, data);
			this.EndVisit(eventDeclaration);
			return result;
		}

		public sealed override object VisitEventRaiseRegion(EventRaiseRegion eventRaiseRegion, object data)
		{
			this.BeginVisit(eventRaiseRegion);
			object result = this.TrackedVisitEventRaiseRegion(eventRaiseRegion, data);
			this.EndVisit(eventRaiseRegion);
			return result;
		}

		public sealed override object VisitEventRemoveRegion(EventRemoveRegion eventRemoveRegion, object data)
		{
			this.BeginVisit(eventRemoveRegion);
			object result = this.TrackedVisitEventRemoveRegion(eventRemoveRegion, data);
			this.EndVisit(eventRemoveRegion);
			return result;
		}

		public sealed override object VisitExitStatement(ExitStatement exitStatement, object data)
		{
			this.BeginVisit(exitStatement);
			object result = this.TrackedVisitExitStatement(exitStatement, data);
			this.EndVisit(exitStatement);
			return result;
		}

		public sealed override object VisitExpressionRangeVariable(ExpressionRangeVariable expressionRangeVariable, object data)
		{
			this.BeginVisit(expressionRangeVariable);
			object result = this.TrackedVisitExpressionRangeVariable(expressionRangeVariable, data);
			this.EndVisit(expressionRangeVariable);
			return result;
		}

		public sealed override object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			this.BeginVisit(expressionStatement);
			object result = this.TrackedVisitExpressionStatement(expressionStatement, data);
			this.EndVisit(expressionStatement);
			return result;
		}

		public sealed override object VisitExternAliasDirective(ExternAliasDirective externAliasDirective, object data)
		{
			this.BeginVisit(externAliasDirective);
			object result = this.TrackedVisitExternAliasDirective(externAliasDirective, data);
			this.EndVisit(externAliasDirective);
			return result;
		}

		public sealed override object VisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			this.BeginVisit(fieldDeclaration);
			object result = this.TrackedVisitFieldDeclaration(fieldDeclaration, data);
			this.EndVisit(fieldDeclaration);
			return result;
		}

		public sealed override object VisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			this.BeginVisit(fixedStatement);
			object result = this.TrackedVisitFixedStatement(fixedStatement, data);
			this.EndVisit(fixedStatement);
			return result;
		}

		public sealed override object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.BeginVisit(foreachStatement);
			object result = this.TrackedVisitForeachStatement(foreachStatement, data);
			this.EndVisit(foreachStatement);
			return result;
		}

		public sealed override object VisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			this.BeginVisit(forNextStatement);
			object result = this.TrackedVisitForNextStatement(forNextStatement, data);
			this.EndVisit(forNextStatement);
			return result;
		}

		public sealed override object VisitForStatement(ForStatement forStatement, object data)
		{
			this.BeginVisit(forStatement);
			object result = this.TrackedVisitForStatement(forStatement, data);
			this.EndVisit(forStatement);
			return result;
		}

		public sealed override object VisitGotoCaseStatement(GotoCaseStatement gotoCaseStatement, object data)
		{
			this.BeginVisit(gotoCaseStatement);
			object result = this.TrackedVisitGotoCaseStatement(gotoCaseStatement, data);
			this.EndVisit(gotoCaseStatement);
			return result;
		}

		public sealed override object VisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			this.BeginVisit(gotoStatement);
			object result = this.TrackedVisitGotoStatement(gotoStatement, data);
			this.EndVisit(gotoStatement);
			return result;
		}

		public sealed override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			this.BeginVisit(identifierExpression);
			object result = this.TrackedVisitIdentifierExpression(identifierExpression, data);
			this.EndVisit(identifierExpression);
			return result;
		}

		public sealed override object VisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			this.BeginVisit(ifElseStatement);
			object result = this.TrackedVisitIfElseStatement(ifElseStatement, data);
			this.EndVisit(ifElseStatement);
			return result;
		}

		public sealed override object VisitIndexerDeclaration(IndexerDeclaration indexerDeclaration, object data)
		{
			this.BeginVisit(indexerDeclaration);
			object result = this.TrackedVisitIndexerDeclaration(indexerDeclaration, data);
			this.EndVisit(indexerDeclaration);
			return result;
		}

		public sealed override object VisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			this.BeginVisit(indexerExpression);
			object result = this.TrackedVisitIndexerExpression(indexerExpression, data);
			this.EndVisit(indexerExpression);
			return result;
		}

		public sealed override object VisitInnerClassTypeReference(InnerClassTypeReference innerClassTypeReference, object data)
		{
			this.BeginVisit(innerClassTypeReference);
			object result = this.TrackedVisitInnerClassTypeReference(innerClassTypeReference, data);
			this.EndVisit(innerClassTypeReference);
			return result;
		}

		public sealed override object VisitInterfaceImplementation(InterfaceImplementation interfaceImplementation, object data)
		{
			this.BeginVisit(interfaceImplementation);
			object result = this.TrackedVisitInterfaceImplementation(interfaceImplementation, data);
			this.EndVisit(interfaceImplementation);
			return result;
		}

		public sealed override object VisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			this.BeginVisit(invocationExpression);
			object result = this.TrackedVisitInvocationExpression(invocationExpression, data);
			this.EndVisit(invocationExpression);
			return result;
		}

		public sealed override object VisitLabelStatement(LabelStatement labelStatement, object data)
		{
			this.BeginVisit(labelStatement);
			object result = this.TrackedVisitLabelStatement(labelStatement, data);
			this.EndVisit(labelStatement);
			return result;
		}

		public sealed override object VisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			this.BeginVisit(lambdaExpression);
			object result = this.TrackedVisitLambdaExpression(lambdaExpression, data);
			this.EndVisit(lambdaExpression);
			return result;
		}

		public sealed override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			this.BeginVisit(localVariableDeclaration);
			object result = this.TrackedVisitLocalVariableDeclaration(localVariableDeclaration, data);
			this.EndVisit(localVariableDeclaration);
			return result;
		}

		public sealed override object VisitLockStatement(LockStatement lockStatement, object data)
		{
			this.BeginVisit(lockStatement);
			object result = this.TrackedVisitLockStatement(lockStatement, data);
			this.EndVisit(lockStatement);
			return result;
		}

		public sealed override object VisitMemberReferenceExpression(MemberReferenceExpression memberReferenceExpression, object data)
		{
			this.BeginVisit(memberReferenceExpression);
			object result = this.TrackedVisitMemberReferenceExpression(memberReferenceExpression, data);
			this.EndVisit(memberReferenceExpression);
			return result;
		}

		public sealed override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.BeginVisit(methodDeclaration);
			object result = this.TrackedVisitMethodDeclaration(methodDeclaration, data);
			this.EndVisit(methodDeclaration);
			return result;
		}

		public sealed override object VisitNamedArgumentExpression(NamedArgumentExpression namedArgumentExpression, object data)
		{
			this.BeginVisit(namedArgumentExpression);
			object result = this.TrackedVisitNamedArgumentExpression(namedArgumentExpression, data);
			this.EndVisit(namedArgumentExpression);
			return result;
		}

		public sealed override object VisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			this.BeginVisit(namespaceDeclaration);
			object result = this.TrackedVisitNamespaceDeclaration(namespaceDeclaration, data);
			this.EndVisit(namespaceDeclaration);
			return result;
		}

		public sealed override object VisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			this.BeginVisit(objectCreateExpression);
			object result = this.TrackedVisitObjectCreateExpression(objectCreateExpression, data);
			this.EndVisit(objectCreateExpression);
			return result;
		}

		public sealed override object VisitOnErrorStatement(OnErrorStatement onErrorStatement, object data)
		{
			this.BeginVisit(onErrorStatement);
			object result = this.TrackedVisitOnErrorStatement(onErrorStatement, data);
			this.EndVisit(onErrorStatement);
			return result;
		}

		public sealed override object VisitOperatorDeclaration(OperatorDeclaration operatorDeclaration, object data)
		{
			this.BeginVisit(operatorDeclaration);
			object result = this.TrackedVisitOperatorDeclaration(operatorDeclaration, data);
			this.EndVisit(operatorDeclaration);
			return result;
		}

		public sealed override object VisitOptionDeclaration(OptionDeclaration optionDeclaration, object data)
		{
			this.BeginVisit(optionDeclaration);
			object result = this.TrackedVisitOptionDeclaration(optionDeclaration, data);
			this.EndVisit(optionDeclaration);
			return result;
		}

		public sealed override object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			this.BeginVisit(parameterDeclarationExpression);
			object result = this.TrackedVisitParameterDeclarationExpression(parameterDeclarationExpression, data);
			this.EndVisit(parameterDeclarationExpression);
			return result;
		}

		public sealed override object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			this.BeginVisit(parenthesizedExpression);
			object result = this.TrackedVisitParenthesizedExpression(parenthesizedExpression, data);
			this.EndVisit(parenthesizedExpression);
			return result;
		}

		public sealed override object VisitPointerReferenceExpression(PointerReferenceExpression pointerReferenceExpression, object data)
		{
			this.BeginVisit(pointerReferenceExpression);
			object result = this.TrackedVisitPointerReferenceExpression(pointerReferenceExpression, data);
			this.EndVisit(pointerReferenceExpression);
			return result;
		}

		public sealed override object VisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			this.BeginVisit(primitiveExpression);
			object result = this.TrackedVisitPrimitiveExpression(primitiveExpression, data);
			this.EndVisit(primitiveExpression);
			return result;
		}

		public sealed override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			this.BeginVisit(propertyDeclaration);
			object result = this.TrackedVisitPropertyDeclaration(propertyDeclaration, data);
			this.EndVisit(propertyDeclaration);
			return result;
		}

		public sealed override object VisitPropertyGetRegion(PropertyGetRegion propertyGetRegion, object data)
		{
			this.BeginVisit(propertyGetRegion);
			object result = this.TrackedVisitPropertyGetRegion(propertyGetRegion, data);
			this.EndVisit(propertyGetRegion);
			return result;
		}

		public sealed override object VisitPropertySetRegion(PropertySetRegion propertySetRegion, object data)
		{
			this.BeginVisit(propertySetRegion);
			object result = this.TrackedVisitPropertySetRegion(propertySetRegion, data);
			this.EndVisit(propertySetRegion);
			return result;
		}

		public sealed override object VisitQueryExpression(QueryExpression queryExpression, object data)
		{
			this.BeginVisit(queryExpression);
			object result = this.TrackedVisitQueryExpression(queryExpression, data);
			this.EndVisit(queryExpression);
			return result;
		}

		public sealed override object VisitQueryExpressionAggregateClause(QueryExpressionAggregateClause queryExpressionAggregateClause, object data)
		{
			this.BeginVisit(queryExpressionAggregateClause);
			object result = this.TrackedVisitQueryExpressionAggregateClause(queryExpressionAggregateClause, data);
			this.EndVisit(queryExpressionAggregateClause);
			return result;
		}

		public sealed override object VisitQueryExpressionDistinctClause(QueryExpressionDistinctClause queryExpressionDistinctClause, object data)
		{
			this.BeginVisit(queryExpressionDistinctClause);
			object result = this.TrackedVisitQueryExpressionDistinctClause(queryExpressionDistinctClause, data);
			this.EndVisit(queryExpressionDistinctClause);
			return result;
		}

		public sealed override object VisitQueryExpressionFromClause(QueryExpressionFromClause queryExpressionFromClause, object data)
		{
			this.BeginVisit(queryExpressionFromClause);
			object result = this.TrackedVisitQueryExpressionFromClause(queryExpressionFromClause, data);
			this.EndVisit(queryExpressionFromClause);
			return result;
		}

		public sealed override object VisitQueryExpressionGroupClause(QueryExpressionGroupClause queryExpressionGroupClause, object data)
		{
			this.BeginVisit(queryExpressionGroupClause);
			object result = this.TrackedVisitQueryExpressionGroupClause(queryExpressionGroupClause, data);
			this.EndVisit(queryExpressionGroupClause);
			return result;
		}

		public sealed override object VisitQueryExpressionGroupJoinVBClause(QueryExpressionGroupJoinVBClause queryExpressionGroupJoinVBClause, object data)
		{
			this.BeginVisit(queryExpressionGroupJoinVBClause);
			object result = this.TrackedVisitQueryExpressionGroupJoinVBClause(queryExpressionGroupJoinVBClause, data);
			this.EndVisit(queryExpressionGroupJoinVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionGroupVBClause(QueryExpressionGroupVBClause queryExpressionGroupVBClause, object data)
		{
			this.BeginVisit(queryExpressionGroupVBClause);
			object result = this.TrackedVisitQueryExpressionGroupVBClause(queryExpressionGroupVBClause, data);
			this.EndVisit(queryExpressionGroupVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionJoinClause(QueryExpressionJoinClause queryExpressionJoinClause, object data)
		{
			this.BeginVisit(queryExpressionJoinClause);
			object result = this.TrackedVisitQueryExpressionJoinClause(queryExpressionJoinClause, data);
			this.EndVisit(queryExpressionJoinClause);
			return result;
		}

		public sealed override object VisitQueryExpressionJoinConditionVB(QueryExpressionJoinConditionVB queryExpressionJoinConditionVB, object data)
		{
			this.BeginVisit(queryExpressionJoinConditionVB);
			object result = this.TrackedVisitQueryExpressionJoinConditionVB(queryExpressionJoinConditionVB, data);
			this.EndVisit(queryExpressionJoinConditionVB);
			return result;
		}

		public sealed override object VisitQueryExpressionJoinVBClause(QueryExpressionJoinVBClause queryExpressionJoinVBClause, object data)
		{
			this.BeginVisit(queryExpressionJoinVBClause);
			object result = this.TrackedVisitQueryExpressionJoinVBClause(queryExpressionJoinVBClause, data);
			this.EndVisit(queryExpressionJoinVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionLetClause(QueryExpressionLetClause queryExpressionLetClause, object data)
		{
			this.BeginVisit(queryExpressionLetClause);
			object result = this.TrackedVisitQueryExpressionLetClause(queryExpressionLetClause, data);
			this.EndVisit(queryExpressionLetClause);
			return result;
		}

		public sealed override object VisitQueryExpressionLetVBClause(QueryExpressionLetVBClause queryExpressionLetVBClause, object data)
		{
			this.BeginVisit(queryExpressionLetVBClause);
			object result = this.TrackedVisitQueryExpressionLetVBClause(queryExpressionLetVBClause, data);
			this.EndVisit(queryExpressionLetVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionOrderClause(QueryExpressionOrderClause queryExpressionOrderClause, object data)
		{
			this.BeginVisit(queryExpressionOrderClause);
			object result = this.TrackedVisitQueryExpressionOrderClause(queryExpressionOrderClause, data);
			this.EndVisit(queryExpressionOrderClause);
			return result;
		}

		public sealed override object VisitQueryExpressionOrdering(QueryExpressionOrdering queryExpressionOrdering, object data)
		{
			this.BeginVisit(queryExpressionOrdering);
			object result = this.TrackedVisitQueryExpressionOrdering(queryExpressionOrdering, data);
			this.EndVisit(queryExpressionOrdering);
			return result;
		}

		public sealed override object VisitQueryExpressionPartitionVBClause(QueryExpressionPartitionVBClause queryExpressionPartitionVBClause, object data)
		{
			this.BeginVisit(queryExpressionPartitionVBClause);
			object result = this.TrackedVisitQueryExpressionPartitionVBClause(queryExpressionPartitionVBClause, data);
			this.EndVisit(queryExpressionPartitionVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionSelectClause(QueryExpressionSelectClause queryExpressionSelectClause, object data)
		{
			this.BeginVisit(queryExpressionSelectClause);
			object result = this.TrackedVisitQueryExpressionSelectClause(queryExpressionSelectClause, data);
			this.EndVisit(queryExpressionSelectClause);
			return result;
		}

		public sealed override object VisitQueryExpressionSelectVBClause(QueryExpressionSelectVBClause queryExpressionSelectVBClause, object data)
		{
			this.BeginVisit(queryExpressionSelectVBClause);
			object result = this.TrackedVisitQueryExpressionSelectVBClause(queryExpressionSelectVBClause, data);
			this.EndVisit(queryExpressionSelectVBClause);
			return result;
		}

		public sealed override object VisitQueryExpressionWhereClause(QueryExpressionWhereClause queryExpressionWhereClause, object data)
		{
			this.BeginVisit(queryExpressionWhereClause);
			object result = this.TrackedVisitQueryExpressionWhereClause(queryExpressionWhereClause, data);
			this.EndVisit(queryExpressionWhereClause);
			return result;
		}

		public sealed override object VisitRaiseEventStatement(RaiseEventStatement raiseEventStatement, object data)
		{
			this.BeginVisit(raiseEventStatement);
			object result = this.TrackedVisitRaiseEventStatement(raiseEventStatement, data);
			this.EndVisit(raiseEventStatement);
			return result;
		}

		public sealed override object VisitReDimStatement(ReDimStatement reDimStatement, object data)
		{
			this.BeginVisit(reDimStatement);
			object result = this.TrackedVisitReDimStatement(reDimStatement, data);
			this.EndVisit(reDimStatement);
			return result;
		}

		public sealed override object VisitRemoveHandlerStatement(RemoveHandlerStatement removeHandlerStatement, object data)
		{
			this.BeginVisit(removeHandlerStatement);
			object result = this.TrackedVisitRemoveHandlerStatement(removeHandlerStatement, data);
			this.EndVisit(removeHandlerStatement);
			return result;
		}

		public sealed override object VisitResumeStatement(ResumeStatement resumeStatement, object data)
		{
			this.BeginVisit(resumeStatement);
			object result = this.TrackedVisitResumeStatement(resumeStatement, data);
			this.EndVisit(resumeStatement);
			return result;
		}

		public sealed override object VisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			this.BeginVisit(returnStatement);
			object result = this.TrackedVisitReturnStatement(returnStatement, data);
			this.EndVisit(returnStatement);
			return result;
		}

		public sealed override object VisitSizeOfExpression(SizeOfExpression sizeOfExpression, object data)
		{
			this.BeginVisit(sizeOfExpression);
			object result = this.TrackedVisitSizeOfExpression(sizeOfExpression, data);
			this.EndVisit(sizeOfExpression);
			return result;
		}

		public sealed override object VisitStackAllocExpression(StackAllocExpression stackAllocExpression, object data)
		{
			this.BeginVisit(stackAllocExpression);
			object result = this.TrackedVisitStackAllocExpression(stackAllocExpression, data);
			this.EndVisit(stackAllocExpression);
			return result;
		}

		public sealed override object VisitStopStatement(StopStatement stopStatement, object data)
		{
			this.BeginVisit(stopStatement);
			object result = this.TrackedVisitStopStatement(stopStatement, data);
			this.EndVisit(stopStatement);
			return result;
		}

		public sealed override object VisitSwitchSection(SwitchSection switchSection, object data)
		{
			this.BeginVisit(switchSection);
			object result = this.TrackedVisitSwitchSection(switchSection, data);
			this.EndVisit(switchSection);
			return result;
		}

		public sealed override object VisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			this.BeginVisit(switchStatement);
			object result = this.TrackedVisitSwitchStatement(switchStatement, data);
			this.EndVisit(switchStatement);
			return result;
		}

		public sealed override object VisitTemplateDefinition(TemplateDefinition templateDefinition, object data)
		{
			this.BeginVisit(templateDefinition);
			object result = this.TrackedVisitTemplateDefinition(templateDefinition, data);
			this.EndVisit(templateDefinition);
			return result;
		}

		public sealed override object VisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			this.BeginVisit(thisReferenceExpression);
			object result = this.TrackedVisitThisReferenceExpression(thisReferenceExpression, data);
			this.EndVisit(thisReferenceExpression);
			return result;
		}

		public sealed override object VisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			this.BeginVisit(throwStatement);
			object result = this.TrackedVisitThrowStatement(throwStatement, data);
			this.EndVisit(throwStatement);
			return result;
		}

		public sealed override object VisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			this.BeginVisit(tryCatchStatement);
			object result = this.TrackedVisitTryCatchStatement(tryCatchStatement, data);
			this.EndVisit(tryCatchStatement);
			return result;
		}

		public sealed override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			this.BeginVisit(typeDeclaration);
			object result = this.TrackedVisitTypeDeclaration(typeDeclaration, data);
			this.EndVisit(typeDeclaration);
			return result;
		}

		public sealed override object VisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			this.BeginVisit(typeOfExpression);
			object result = this.TrackedVisitTypeOfExpression(typeOfExpression, data);
			this.EndVisit(typeOfExpression);
			return result;
		}

		public sealed override object VisitTypeOfIsExpression(TypeOfIsExpression typeOfIsExpression, object data)
		{
			this.BeginVisit(typeOfIsExpression);
			object result = this.TrackedVisitTypeOfIsExpression(typeOfIsExpression, data);
			this.EndVisit(typeOfIsExpression);
			return result;
		}

		public sealed override object VisitTypeReference(TypeReference typeReference, object data)
		{
			this.BeginVisit(typeReference);
			object result = this.TrackedVisitTypeReference(typeReference, data);
			this.EndVisit(typeReference);
			return result;
		}

		public sealed override object VisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			this.BeginVisit(typeReferenceExpression);
			object result = this.TrackedVisitTypeReferenceExpression(typeReferenceExpression, data);
			this.EndVisit(typeReferenceExpression);
			return result;
		}

		public sealed override object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			this.BeginVisit(unaryOperatorExpression);
			object result = this.TrackedVisitUnaryOperatorExpression(unaryOperatorExpression, data);
			this.EndVisit(unaryOperatorExpression);
			return result;
		}

		public sealed override object VisitUncheckedExpression(UncheckedExpression uncheckedExpression, object data)
		{
			this.BeginVisit(uncheckedExpression);
			object result = this.TrackedVisitUncheckedExpression(uncheckedExpression, data);
			this.EndVisit(uncheckedExpression);
			return result;
		}

		public sealed override object VisitUncheckedStatement(UncheckedStatement uncheckedStatement, object data)
		{
			this.BeginVisit(uncheckedStatement);
			object result = this.TrackedVisitUncheckedStatement(uncheckedStatement, data);
			this.EndVisit(uncheckedStatement);
			return result;
		}

		public sealed override object VisitUnsafeStatement(UnsafeStatement unsafeStatement, object data)
		{
			this.BeginVisit(unsafeStatement);
			object result = this.TrackedVisitUnsafeStatement(unsafeStatement, data);
			this.EndVisit(unsafeStatement);
			return result;
		}

		public sealed override object VisitUsing(Using @using, object data)
		{
			this.BeginVisit(@using);
			object result = this.TrackedVisitUsing(@using, data);
			this.EndVisit(@using);
			return result;
		}

		public sealed override object VisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			this.BeginVisit(usingDeclaration);
			object result = this.TrackedVisitUsingDeclaration(usingDeclaration, data);
			this.EndVisit(usingDeclaration);
			return result;
		}

		public sealed override object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			this.BeginVisit(usingStatement);
			object result = this.TrackedVisitUsingStatement(usingStatement, data);
			this.EndVisit(usingStatement);
			return result;
		}

		public sealed override object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			this.BeginVisit(variableDeclaration);
			object result = this.TrackedVisitVariableDeclaration(variableDeclaration, data);
			this.EndVisit(variableDeclaration);
			return result;
		}

		public sealed override object VisitWithStatement(WithStatement withStatement, object data)
		{
			this.BeginVisit(withStatement);
			object result = this.TrackedVisitWithStatement(withStatement, data);
			this.EndVisit(withStatement);
			return result;
		}

		public sealed override object VisitYieldStatement(YieldStatement yieldStatement, object data)
		{
			this.BeginVisit(yieldStatement);
			object result = this.TrackedVisitYieldStatement(yieldStatement, data);
			this.EndVisit(yieldStatement);
			return result;
		}
	}
}
