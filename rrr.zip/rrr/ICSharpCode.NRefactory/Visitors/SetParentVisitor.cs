﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public class SetParentVisitor : NodeTrackingAstVisitor
	{
		public SetParentVisitor()
		{
			this.nodeStack.Push(null);
		}

		protected override void BeginVisit(INode node)
		{
			node.Parent = this.nodeStack.Peek();
			this.nodeStack.Push(node);
		}

		protected override void EndVisit(INode node)
		{
			this.nodeStack.Pop();
		}

		private Stack<INode> nodeStack = new Stack<INode>();
	}
}
