﻿using System;
using System.CodeDom;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public class CodeDomVisitor : AbstractAstVisitor
	{
		private void AddEventHandler(Expression eventExpr, Expression handler, object data)
		{
			this.methodReference = true;
			CodeExpression codeExpression = (CodeExpression)handler.AcceptVisitor(this, data);
			this.methodReference = false;
			if (!(codeExpression is CodeObjectCreateExpression))
			{
				codeExpression = new CodeObjectCreateExpression(new CodeTypeReference("System.EventHandler"), new CodeExpression[]
				{
					codeExpression
				});
			}
			if (eventExpr is IdentifierExpression)
			{
				this.AddStmt(new CodeAttachEventStatement(new CodeEventReferenceExpression(new CodeThisReferenceExpression(), ((IdentifierExpression)eventExpr).Identifier), codeExpression));
				return;
			}
			MemberReferenceExpression memberReferenceExpression = (MemberReferenceExpression)eventExpr;
			this.AddStmt(new CodeAttachEventStatement(new CodeEventReferenceExpression((CodeExpression)memberReferenceExpression.TargetObject.AcceptVisitor(this, data), memberReferenceExpression.MemberName), codeExpression));
		}

		private void AddStmt(CodeStatement stmt)
		{
			if (this.codeStack.Count == 0)
			{
				return;
			}
			CodeStatementCollection codeStatementCollection = this.codeStack.Peek();
			if (codeStatementCollection != null)
			{
				codeStatementCollection.Add(stmt);
			}
		}

		private static CodeTypeReferenceExpression ConvertToTypeReference(MemberReferenceExpression fieldReferenceExpression)
		{
			StringBuilder stringBuilder = new StringBuilder("");
			while (fieldReferenceExpression.TargetObject is MemberReferenceExpression)
			{
				stringBuilder.Insert(0, '.');
				stringBuilder.Insert(1, fieldReferenceExpression.MemberName.ToCharArray());
				fieldReferenceExpression = (MemberReferenceExpression)fieldReferenceExpression.TargetObject;
			}
			stringBuilder.Insert(0, '.');
			stringBuilder.Insert(1, fieldReferenceExpression.MemberName.ToCharArray());
			if (fieldReferenceExpression.TargetObject is IdentifierExpression)
			{
				stringBuilder.Insert(0, ((IdentifierExpression)fieldReferenceExpression.TargetObject).Identifier.ToCharArray());
				string text = stringBuilder.ToString();
				int num = text.LastIndexOf('.');
				while (num > 0 && Type.GetType(stringBuilder.ToString()) == null)
				{
					string value = stringBuilder.ToString().Substring(num + 1);
					stringBuilder = new StringBuilder(stringBuilder.ToString().Substring(0, num));
					stringBuilder.Append("+");
					stringBuilder.Append(value);
					num = stringBuilder.ToString().LastIndexOf('.');
				}
				if (Type.GetType(stringBuilder.ToString()) == null)
				{
					stringBuilder = new StringBuilder(text);
				}
				return new CodeTypeReferenceExpression(stringBuilder.ToString());
			}
			if (fieldReferenceExpression.TargetObject is TypeReferenceExpression)
			{
				stringBuilder.Insert(0, ((TypeReferenceExpression)fieldReferenceExpression.TargetObject).TypeReference.Type);
				return new CodeTypeReferenceExpression(stringBuilder.ToString());
			}
			return null;
		}

		private static MemberAttributes ConvMemberAttributes(Modifiers modifier)
		{
			MemberAttributes memberAttributes = (MemberAttributes)0;
			if ((modifier & Modifiers.Dim) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Abstract;
			}
			if ((modifier & Modifiers.Const) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Const;
			}
			if ((modifier & Modifiers.Sealed) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Final;
			}
			if ((modifier & Modifiers.New) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.New;
			}
			if ((modifier & Modifiers.Virtual) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Overloaded;
			}
			if ((modifier & Modifiers.Override) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Override;
			}
			if ((modifier & Modifiers.Static) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Static;
			}
			if ((modifier & Modifiers.Public) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Public;
			}
			else if ((modifier & Modifiers.Internal) != Modifiers.None && (modifier & Modifiers.Protected) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.FamilyOrAssembly;
			}
			else if ((modifier & Modifiers.Internal) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Assembly;
			}
			else if ((modifier & Modifiers.Protected) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Family;
			}
			else if ((modifier & Modifiers.Private) != Modifiers.None)
			{
				memberAttributes |= MemberAttributes.Private;
			}
			return memberAttributes;
		}

		private CodeTypeReference ConvType(TypeReference type)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
			CodeTypeReference codeTypeReference = new CodeTypeReference(this.GetDotNetNameFromTypeReference(type));
			InnerClassTypeReference innerClassTypeReference = type as InnerClassTypeReference;
			if (innerClassTypeReference != null)
			{
				type = innerClassTypeReference.CombineToNormalTypeReference();
			}
			foreach (TypeReference current in type.GenericTypes)
			{
				codeTypeReference.TypeArguments.Add(this.ConvType(current));
			}
			if (type.IsArrayType)
			{
				for (int i = type.RankSpecifier.Length - 1; i >= 0; i--)
				{
					codeTypeReference = new CodeTypeReference(codeTypeReference, type.RankSpecifier[i] + 1);
				}
			}
			return codeTypeReference;
		}

		private static TypeAttributes ConvTypeAttributes(Modifiers modifier)
		{
			TypeAttributes typeAttributes = TypeAttributes.NotPublic;
			if ((modifier & Modifiers.Dim) != Modifiers.None)
			{
				typeAttributes |= TypeAttributes.Abstract;
			}
			if ((modifier & Modifiers.Sealed) != Modifiers.None)
			{
				typeAttributes |= TypeAttributes.Sealed;
			}
			if ((modifier & Modifiers.Static) != Modifiers.None)
			{
				typeAttributes |= (TypeAttributes.Abstract | TypeAttributes.Sealed);
			}
			if ((modifier & Modifiers.Public) != Modifiers.None)
			{
				typeAttributes |= TypeAttributes.Public;
			}
			else
			{
				typeAttributes = typeAttributes;
			}
			return typeAttributes;
		}

		private string GetDotNetNameFromTypeReference(TypeReference type)
		{
			InnerClassTypeReference innerClassTypeReference = type as InnerClassTypeReference;
			string text;
			if (innerClassTypeReference != null)
			{
				text = this.GetDotNetNameFromTypeReference(innerClassTypeReference.BaseType) + "+" + innerClassTypeReference.Type;
			}
			else
			{
				text = type.Type;
			}
			if (type.GenericTypes.Count != 0)
			{
				text = text + "`" + type.GenericTypes.Count.ToString();
			}
			return text;
		}

		private CodeExpression[] GetExpressionList(IList expressionList)
		{
			if (expressionList == null)
			{
				return new CodeExpression[0];
			}
			CodeExpression[] array = new CodeExpression[expressionList.Count];
			for (int i = 0; i < expressionList.Count; i++)
			{
				array[i] = (CodeExpression)((Expression)expressionList[i]).AcceptVisitor(this, null);
				if (array[i] == null)
				{
					array[i] = new CodePrimitiveExpression(0);
				}
			}
			return array;
		}

		private void InitMethodScope()
		{
			this.usingId = 0;
			this.foreachId = 0;
			this.switchId = 0;
			this.doId = 0;
			CodeDomVisitor.Breakable.NextId = 0;
			this.variables.Clear();
			this.parameters.Clear();
		}

		private bool IsField(string identifier)
		{
			if (this.currentTypeDeclaration == null)
			{
				return false;
			}
			foreach (INode current in this.currentTypeDeclaration.Children)
			{
				if (current is FieldDeclaration)
				{
					FieldDeclaration fieldDeclaration = (FieldDeclaration)current;
					if (fieldDeclaration.GetVariableDeclaration(identifier) != null)
					{
						return true;
					}
				}
			}
			return this.currentTypeDeclaration.BaseTypes.Count > 0 && this.environmentInformationProvider.HasField(this.currentTypeDeclaration.BaseTypes[0].Type, this.currentTypeDeclaration.BaseTypes[0].GenericTypes.Count, identifier);
		}

		private bool IsField(string reflectionTypeName, string fieldName)
		{
			return this.environmentInformationProvider.HasField(reflectionTypeName, 0, fieldName);
		}

		private bool IsFieldReferenceExpression(MemberReferenceExpression fieldReferenceExpression)
		{
			return (fieldReferenceExpression.TargetObject is ThisReferenceExpression || fieldReferenceExpression.TargetObject is BaseReferenceExpression) && this.IsField(fieldReferenceExpression.MemberName);
		}

		private bool IsLocalVariable(string identifier)
		{
			foreach (CodeVariableDeclarationStatement current in this.variables)
			{
				if (current.Name == identifier)
				{
					bool result = true;
					return result;
				}
			}
			foreach (CodeParameterDeclarationExpression current2 in this.parameters)
			{
				if (current2.Name == identifier)
				{
					bool result = true;
					return result;
				}
			}
			return false;
		}

		private bool IsPossibleTypeReference(MemberReferenceExpression fieldReferenceExpression)
		{
			while (fieldReferenceExpression.TargetObject is MemberReferenceExpression)
			{
				fieldReferenceExpression = (MemberReferenceExpression)fieldReferenceExpression.TargetObject;
			}
			IdentifierExpression identifierExpression = fieldReferenceExpression.TargetObject as IdentifierExpression;
			if (identifierExpression != null)
			{
				return !this.IsField(identifierExpression.Identifier) && !this.IsLocalVariable(identifierExpression.Identifier);
			}
			return fieldReferenceExpression.TargetObject is TypeReferenceExpression;
		}

		public override object VisitAddHandlerStatement(AddHandlerStatement addHandlerStatement, object data)
		{
			this.AddEventHandler(addHandlerStatement.EventExpression, addHandlerStatement.HandlerExpression, data);
			return null;
		}

		public override object VisitAddressOfExpression(AddressOfExpression addressOfExpression, object data)
		{
			return addressOfExpression.Expression.AcceptVisitor(this, data);
		}

		public override object VisitArrayCreateExpression(ArrayCreateExpression arrayCreateExpression, object data)
		{
			if (arrayCreateExpression.ArrayInitializer.IsNull)
			{
				return new CodeArrayCreateExpression(this.ConvType(arrayCreateExpression.CreateType), arrayCreateExpression.Arguments[0].AcceptVisitor(this, data) as CodeExpression);
			}
			return new CodeArrayCreateExpression(this.ConvType(arrayCreateExpression.CreateType), this.GetExpressionList(arrayCreateExpression.ArrayInitializer.CreateExpressions));
		}

		public override object VisitAssignmentExpression(AssignmentExpression assignmentExpression, object data)
		{
			if (assignmentExpression.Op == AssignmentOperatorType.Add)
			{
				this.AddEventHandler(assignmentExpression.Left, assignmentExpression.Right, data);
			}
			else if (assignmentExpression.Left is IdentifierExpression)
			{
				this.AddStmt(new CodeAssignStatement((CodeExpression)assignmentExpression.Left.AcceptVisitor(this, null), (CodeExpression)assignmentExpression.Right.AcceptVisitor(this, null)));
			}
			else
			{
				this.AddStmt(new CodeAssignStatement((CodeExpression)assignmentExpression.Left.AcceptVisitor(this, null), (CodeExpression)assignmentExpression.Right.AcceptVisitor(this, null)));
			}
			return null;
		}

		public override object VisitAttributeSection(AttributeSection attributeSection, object data)
		{
			return null;
		}

		public override object VisitBaseReferenceExpression(BaseReferenceExpression baseReferenceExpression, object data)
		{
			return new CodeBaseReferenceExpression();
		}

		public override object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			CodeBinaryOperatorType op = CodeBinaryOperatorType.Add;
			switch (binaryOperatorExpression.Op)
			{
			case BinaryOperatorType.BitwiseAnd:
				op = CodeBinaryOperatorType.BitwiseAnd;
				break;
			case BinaryOperatorType.BitwiseOr:
				op = CodeBinaryOperatorType.BitwiseOr;
				break;
			case BinaryOperatorType.LogicalAnd:
				op = CodeBinaryOperatorType.BooleanAnd;
				break;
			case BinaryOperatorType.LogicalOr:
				op = CodeBinaryOperatorType.BooleanOr;
				break;
			case BinaryOperatorType.ExclusiveOr:
				op = CodeBinaryOperatorType.BitwiseAnd;
				break;
			case BinaryOperatorType.GreaterThan:
				op = CodeBinaryOperatorType.GreaterThan;
				break;
			case BinaryOperatorType.GreaterThanOrEqual:
				op = CodeBinaryOperatorType.GreaterThanOrEqual;
				break;
			case BinaryOperatorType.Equality:
			case BinaryOperatorType.InEquality:
				op = CodeBinaryOperatorType.ValueEquality;
				break;
			case BinaryOperatorType.LessThan:
				op = CodeBinaryOperatorType.LessThan;
				break;
			case BinaryOperatorType.LessThanOrEqual:
				op = CodeBinaryOperatorType.LessThanOrEqual;
				break;
			case BinaryOperatorType.Add:
				op = CodeBinaryOperatorType.Add;
				break;
			case BinaryOperatorType.Subtract:
				op = CodeBinaryOperatorType.Subtract;
				break;
			case BinaryOperatorType.Multiply:
				op = CodeBinaryOperatorType.Multiply;
				break;
			case BinaryOperatorType.Divide:
			case BinaryOperatorType.DivideInteger:
				op = CodeBinaryOperatorType.Divide;
				break;
			case BinaryOperatorType.Modulus:
				op = CodeBinaryOperatorType.Modulus;
				break;
			case BinaryOperatorType.ShiftLeft:
			case BinaryOperatorType.ShiftRight:
				op = CodeBinaryOperatorType.Multiply;
				break;
			case BinaryOperatorType.ReferenceEquality:
				op = CodeBinaryOperatorType.IdentityEquality;
				break;
			case BinaryOperatorType.ReferenceInequality:
				op = CodeBinaryOperatorType.IdentityInequality;
				break;
			}
			CodeBinaryOperatorExpression codeBinaryOperatorExpression = new CodeBinaryOperatorExpression((CodeExpression)binaryOperatorExpression.Left.AcceptVisitor(this, data), op, (CodeExpression)binaryOperatorExpression.Right.AcceptVisitor(this, data));
			if (binaryOperatorExpression.Op == BinaryOperatorType.InEquality)
			{
				codeBinaryOperatorExpression = new CodeBinaryOperatorExpression(codeBinaryOperatorExpression, CodeBinaryOperatorType.ValueEquality, new CodePrimitiveExpression(false));
			}
			return codeBinaryOperatorExpression;
		}

		public override object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			blockStatement.AcceptChildren(this, data);
			return null;
		}

		public override object VisitBreakStatement(BreakStatement breakStatement, object data)
		{
			CodeDomVisitor.Breakable breakable = this.breakableStack.Peek();
			breakable.IsBreak = true;
			CodeGotoStatement codeGotoStatement = new CodeGotoStatement("break" + breakable.Id);
			this.AddStmt(codeGotoStatement);
			return codeGotoStatement;
		}

		public override object VisitCastExpression(CastExpression castExpression, object data)
		{
			CodeTypeReference targetType = this.ConvType(castExpression.CastTo);
			return new CodeCastExpression(targetType, (CodeExpression)castExpression.Expression.AcceptVisitor(this, data));
		}

		public override object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			if (compilationUnit == null)
			{
				throw new ArgumentNullException("compilationUnit");
			}
			CodeNamespace codeNamespace = new CodeNamespace("Global");
			this.namespaceDeclarations.Push(codeNamespace);
			compilationUnit.AcceptChildren(this, data);
			this.codeCompileUnit.Namespaces.Add(codeNamespace);
			return codeNamespace;
		}

		public override object VisitConstructorDeclaration(ConstructorDeclaration constructorDeclaration, object data)
		{
			this.InitMethodScope();
			CodeConstructor codeConstructor = new CodeConstructor();
			codeConstructor.Attributes = CodeDomVisitor.ConvMemberAttributes(constructorDeclaration.Modifier);
			this.typeDeclarations.Peek().Members.Add(codeConstructor);
			this.codeStack.Push(this.NullStmtCollection);
			foreach (ParameterDeclarationExpression current in constructorDeclaration.Parameters)
			{
				codeConstructor.Parameters.Add((CodeParameterDeclarationExpression)this.VisitParameterDeclarationExpression(current, data));
			}
			if (constructorDeclaration.ConstructorInitializer != null)
			{
				if (constructorDeclaration.ConstructorInitializer.ConstructorInitializerType == ConstructorInitializerType.Base)
				{
					if (constructorDeclaration.ConstructorInitializer.Arguments.Count == 0)
					{
						codeConstructor.BaseConstructorArgs.Add(new CodeSnippetExpression());
					}
					foreach (Expression current2 in constructorDeclaration.ConstructorInitializer.Arguments)
					{
						codeConstructor.BaseConstructorArgs.Add((CodeExpression)current2.AcceptVisitor(this, data));
					}
				}
				if (constructorDeclaration.ConstructorInitializer.ConstructorInitializerType == ConstructorInitializerType.This)
				{
					if (constructorDeclaration.ConstructorInitializer.Arguments.Count == 0)
					{
						codeConstructor.ChainedConstructorArgs.Add(new CodeSnippetExpression());
					}
					foreach (Expression current3 in constructorDeclaration.ConstructorInitializer.Arguments)
					{
						codeConstructor.ChainedConstructorArgs.Add((CodeExpression)current3.AcceptVisitor(this, data));
					}
				}
			}
			this.codeStack.Pop();
			this.codeStack.Push(codeConstructor.Statements);
			constructorDeclaration.Body.AcceptChildren(this, data);
			this.codeStack.Pop();
			return null;
		}

		public override object VisitContinueStatement(ContinueStatement continueStatement, object data)
		{
			CodeDomVisitor.Breakable breakable = this.breakableStack.Peek();
			if (!breakable.AllowContinue)
			{
				CodeDomVisitor.Breakable[] array = this.breakableStack.ToArray();
				CodeDomVisitor.Breakable[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					CodeDomVisitor.Breakable breakable2 = array2[i];
					if (breakable2.AllowContinue)
					{
						breakable = breakable2;
						break;
					}
				}
			}
			breakable.IsContinue = true;
			CodeGotoStatement codeGotoStatement = new CodeGotoStatement("continue" + breakable.Id);
			this.AddStmt(codeGotoStatement);
			return codeGotoStatement;
		}

		public override object VisitDelegateDeclaration(DelegateDeclaration delegateDeclaration, object data)
		{
			CodeTypeDelegate codeTypeDelegate = new CodeTypeDelegate(delegateDeclaration.Name);
			codeTypeDelegate.Attributes = CodeDomVisitor.ConvMemberAttributes(delegateDeclaration.Modifier);
			codeTypeDelegate.ReturnType = this.ConvType(delegateDeclaration.ReturnType);
			foreach (ParameterDeclarationExpression current in delegateDeclaration.Parameters)
			{
				codeTypeDelegate.Parameters.Add((CodeParameterDeclarationExpression)this.VisitParameterDeclarationExpression(current, data));
			}
			if (this.typeDeclarations.Count > 0)
			{
				this.typeDeclarations.Peek().Members.Add(codeTypeDelegate);
			}
			else
			{
				this.namespaceDeclarations.Peek().Types.Add(codeTypeDelegate);
			}
			return null;
		}

		public override object VisitDoLoopStatement(DoLoopStatement doLoopStatement, object data)
		{
			CodeIterationStatement codeIterationStatement = new CodeIterationStatement();
			this.breakableStack.Push(new CodeDomVisitor.Breakable());
			this.codeStack.Push(this.NullStmtCollection);
			if (doLoopStatement.ConditionPosition == ConditionPosition.End)
			{
				this.doId++;
				string text = "_do" + this.doId;
				codeIterationStatement.InitStatement = new CodeVariableDeclarationStatement(typeof(bool), text, new CodePrimitiveExpression(true));
				codeIterationStatement.TestExpression = new CodeVariableReferenceExpression(text);
				codeIterationStatement.IncrementStatement = new CodeAssignStatement(new CodeVariableReferenceExpression(text), (doLoopStatement.Condition == null) ? new CodePrimitiveExpression(true) : ((CodeExpression)doLoopStatement.Condition.AcceptVisitor(this, data)));
			}
			else
			{
				codeIterationStatement.InitStatement = new CodeExpressionStatement(new CodeSnippetExpression());
				codeIterationStatement.IncrementStatement = new CodeExpressionStatement(new CodeSnippetExpression());
				if (doLoopStatement.Condition == null)
				{
					codeIterationStatement.TestExpression = new CodePrimitiveExpression(true);
				}
				else
				{
					codeIterationStatement.TestExpression = (CodeExpression)doLoopStatement.Condition.AcceptVisitor(this, data);
				}
			}
			this.codeStack.Pop();
			this.codeStack.Push(codeIterationStatement.Statements);
			doLoopStatement.EmbeddedStatement.AcceptVisitor(this, data);
			this.codeStack.Pop();
			if (codeIterationStatement.Statements.Count == 0)
			{
				codeIterationStatement.Statements.Add(new CodeSnippetStatement());
			}
			CodeDomVisitor.Breakable breakable = this.breakableStack.Pop();
			if (breakable.IsContinue)
			{
				codeIterationStatement.Statements.Add(new CodeSnippetStatement());
				codeIterationStatement.Statements.Add(new CodeLabeledStatement("continue" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			this.AddStmt(codeIterationStatement);
			if (breakable.IsBreak)
			{
				this.AddStmt(new CodeLabeledStatement("break" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			return codeIterationStatement;
		}

		public override object VisitEmptyStatement(EmptyStatement emptyStatement, object data)
		{
			CodeSnippetStatement codeSnippetStatement = new CodeSnippetStatement();
			this.AddStmt(codeSnippetStatement);
			return codeSnippetStatement;
		}

		public override object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			CodeMemberEvent codeMemberEvent = new CodeMemberEvent();
			codeMemberEvent.Type = this.ConvType(eventDeclaration.TypeReference);
			codeMemberEvent.Name = eventDeclaration.Name;
			codeMemberEvent.Attributes = CodeDomVisitor.ConvMemberAttributes(eventDeclaration.Modifier);
			this.typeDeclarations.Peek().Members.Add(codeMemberEvent);
			return null;
		}

		public override object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			object obj = expressionStatement.Expression.AcceptVisitor(this, data);
			if (obj is CodeExpression)
			{
				this.AddStmt(new CodeExpressionStatement((CodeExpression)obj));
			}
			return obj;
		}

		public override object VisitFieldDeclaration(FieldDeclaration fieldDeclaration, object data)
		{
			for (int i = 0; i < fieldDeclaration.Fields.Count; i++)
			{
				VariableDeclaration variableDeclaration = fieldDeclaration.Fields[i];
				Modifiers arg_20_0 = fieldDeclaration.Modifier & Modifiers.WithEvents;
				TypeReference typeReference = fieldDeclaration.GetTypeForField(i);
				if (typeReference.IsNull)
				{
					typeReference = new TypeReference(this.typeDeclarations.Peek().Name);
				}
				CodeMemberField codeMemberField = new CodeMemberField(this.ConvType(typeReference), variableDeclaration.Name);
				codeMemberField.Attributes = CodeDomVisitor.ConvMemberAttributes(fieldDeclaration.Modifier);
				if (!variableDeclaration.Initializer.IsNull)
				{
					codeMemberField.InitExpression = (CodeExpression)variableDeclaration.Initializer.AcceptVisitor(this, data);
				}
				this.typeDeclarations.Peek().Members.Add(codeMemberField);
			}
			return null;
		}

		public override object VisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			throw new NotSupportedException("CodeDom does not support Fixed Statement");
		}

		public override object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.foreachId++;
			string text = "_it" + this.foreachId.ToString();
			CodeIterationStatement codeIterationStatement = new CodeIterationStatement();
			this.breakableStack.Push(new CodeDomVisitor.Breakable());
			CodeVariableDeclarationStatement codeVariableDeclarationStatement = new CodeVariableDeclarationStatement();
			CodeMethodInvokeExpression codeMethodInvokeExpression = new CodeMethodInvokeExpression();
			CodeMethodReferenceExpression codeMethodReferenceExpression = new CodeMethodReferenceExpression();
			codeMethodReferenceExpression.MethodName = "GetEnumerator";
			this.codeStack.Push(this.NullStmtCollection);
			codeMethodReferenceExpression.TargetObject = (CodeExpression)foreachStatement.Expression.AcceptVisitor(this, data);
			this.codeStack.Pop();
			codeMethodInvokeExpression.Method = codeMethodReferenceExpression;
			codeVariableDeclarationStatement.InitExpression = codeMethodInvokeExpression;
			codeVariableDeclarationStatement.Name = text;
			CodeTypeReference type = new CodeTypeReference("System.Collections.IEnumerator");
			codeVariableDeclarationStatement.Type = type;
			codeIterationStatement.InitStatement = codeVariableDeclarationStatement;
			codeIterationStatement.TestExpression = new CodeMethodInvokeExpression
			{
				Method = new CodeMethodReferenceExpression
				{
					MethodName = "MoveNext",
					TargetObject = new CodeVariableReferenceExpression
					{
						VariableName = text
					}
				}
			};
			codeIterationStatement.IncrementStatement = new CodeExpressionStatement(new CodeSnippetExpression());
			CodeVariableDeclarationStatement codeVariableDeclarationStatement2 = new CodeVariableDeclarationStatement();
			CodeCastExpression codeCastExpression = new CodeCastExpression();
			codeCastExpression.Expression = new CodePropertyReferenceExpression
			{
				PropertyName = "Current",
				TargetObject = new CodeVariableReferenceExpression
				{
					VariableName = text
				}
			};
			CodeTypeReference targetType = this.ConvType(foreachStatement.TypeReference);
			codeCastExpression.TargetType = targetType;
			codeVariableDeclarationStatement2.InitExpression = codeCastExpression;
			codeVariableDeclarationStatement2.Name = foreachStatement.VariableName;
			CodeTypeReference type2 = this.ConvType(foreachStatement.TypeReference);
			codeVariableDeclarationStatement2.Type = type2;
			codeIterationStatement.Statements.Add(codeVariableDeclarationStatement2);
			codeIterationStatement.Statements.Add(new CodeSnippetStatement());
			this.codeStack.Push(codeIterationStatement.Statements);
			foreachStatement.EmbeddedStatement.AcceptVisitor(this, data);
			this.codeStack.Pop();
			CodeDomVisitor.Breakable breakable = this.breakableStack.Pop();
			if (breakable.IsContinue)
			{
				codeIterationStatement.Statements.Add(new CodeSnippetStatement());
				codeIterationStatement.Statements.Add(new CodeLabeledStatement("continue" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			this.AddStmt(codeIterationStatement);
			if (breakable.IsBreak)
			{
				this.AddStmt(new CodeLabeledStatement("break" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			return codeIterationStatement;
		}

		public override object VisitForStatement(ForStatement forStatement, object data)
		{
			CodeIterationStatement codeIterationStatement = new CodeIterationStatement();
			this.breakableStack.Push(new CodeDomVisitor.Breakable());
			this.codeStack.Push(this.NullStmtCollection);
			if (forStatement.Initializers.Count > 0)
			{
				if (forStatement.Initializers.Count > 1)
				{
					throw new NotSupportedException("CodeDom does not support Multiple For-Loop Initializer Statements");
				}
				using (List<Statement>.Enumerator enumerator = forStatement.Initializers.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object current = enumerator.Current;
						if (current is Expression)
						{
							codeIterationStatement.InitStatement = new CodeExpressionStatement((CodeExpression)((Expression)current).AcceptVisitor(this, data));
						}
						if (current is Statement)
						{
							codeIterationStatement.InitStatement = (CodeStatement)((Statement)current).AcceptVisitor(this, data);
						}
					}
					goto IL_D6;
				}
			}
			codeIterationStatement.InitStatement = new CodeExpressionStatement(new CodeSnippetExpression());
			IL_D6:
			if (forStatement.Condition == null)
			{
				codeIterationStatement.TestExpression = new CodePrimitiveExpression(true);
			}
			else
			{
				codeIterationStatement.TestExpression = (CodeExpression)forStatement.Condition.AcceptVisitor(this, data);
			}
			this.codeStack.Push(codeIterationStatement.Statements);
			forStatement.EmbeddedStatement.AcceptVisitor(this, data);
			this.codeStack.Pop();
			if (forStatement.Iterator.Count > 0)
			{
				if (forStatement.Initializers.Count > 1)
				{
					throw new NotSupportedException("CodeDom does not support Multiple For-Loop Iterator Statements");
				}
				using (List<Statement>.Enumerator enumerator2 = forStatement.Iterator.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						Statement current2 = enumerator2.Current;
						codeIterationStatement.IncrementStatement = (CodeStatement)current2.AcceptVisitor(this, data);
					}
					goto IL_1AE;
				}
			}
			codeIterationStatement.IncrementStatement = new CodeExpressionStatement(new CodeSnippetExpression());
			IL_1AE:
			this.codeStack.Pop();
			CodeDomVisitor.Breakable breakable = this.breakableStack.Pop();
			if (breakable.IsContinue)
			{
				codeIterationStatement.Statements.Add(new CodeSnippetStatement());
				codeIterationStatement.Statements.Add(new CodeLabeledStatement("continue" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			this.AddStmt(codeIterationStatement);
			if (breakable.IsBreak)
			{
				this.AddStmt(new CodeLabeledStatement("break" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			return codeIterationStatement;
		}

		public override object VisitGotoStatement(GotoStatement gotoStatement, object data)
		{
			CodeGotoStatement codeGotoStatement = new CodeGotoStatement(gotoStatement.Label);
			this.AddStmt(codeGotoStatement);
			return codeGotoStatement;
		}

		public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			if (!this.IsLocalVariable(identifierExpression.Identifier) && this.IsField(identifierExpression.Identifier))
			{
				return new CodeFieldReferenceExpression(new CodeThisReferenceExpression(), identifierExpression.Identifier);
			}
			return new CodeVariableReferenceExpression(identifierExpression.Identifier);
		}

		public override object VisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			CodeConditionStatement codeConditionStatement = new CodeConditionStatement();
			codeConditionStatement.Condition = (CodeExpression)ifElseStatement.Condition.AcceptVisitor(this, data);
			this.codeStack.Push(codeConditionStatement.TrueStatements);
			foreach (Statement current in ifElseStatement.TrueStatement)
			{
				if (current is BlockStatement)
				{
					current.AcceptChildren(this, data);
				}
				else
				{
					current.AcceptVisitor(this, data);
				}
			}
			this.codeStack.Pop();
			this.codeStack.Push(codeConditionStatement.FalseStatements);
			foreach (Statement current2 in ifElseStatement.FalseStatement)
			{
				if (current2 is BlockStatement)
				{
					current2.AcceptChildren(this, data);
				}
				else
				{
					current2.AcceptVisitor(this, data);
				}
			}
			this.codeStack.Pop();
			this.AddStmt(codeConditionStatement);
			return codeConditionStatement;
		}

		public override object VisitIndexerExpression(IndexerExpression indexerExpression, object data)
		{
			return new CodeIndexerExpression((CodeExpression)indexerExpression.TargetObject.AcceptVisitor(this, data), this.GetExpressionList(indexerExpression.Indexes));
		}

		public override object VisitInvocationExpression(InvocationExpression invocationExpression, object data)
		{
			Expression targetObject = invocationExpression.TargetObject;
			string text = null;
			CodeExpression codeExpression;
			if (targetObject == null)
			{
				codeExpression = new CodeThisReferenceExpression();
			}
			else if (targetObject is MemberReferenceExpression)
			{
				MemberReferenceExpression memberReferenceExpression = (MemberReferenceExpression)targetObject;
				codeExpression = null;
				if (memberReferenceExpression.TargetObject is MemberReferenceExpression && this.IsPossibleTypeReference((MemberReferenceExpression)memberReferenceExpression.TargetObject))
				{
					codeExpression = CodeDomVisitor.ConvertToTypeReference((MemberReferenceExpression)memberReferenceExpression.TargetObject);
				}
				if (codeExpression == null)
				{
					codeExpression = (CodeExpression)memberReferenceExpression.TargetObject.AcceptVisitor(this, data);
				}
				text = memberReferenceExpression.MemberName;
				if (text == "ChrW")
				{
					return new CodeCastExpression("System.Char", this.GetExpressionList(invocationExpression.Arguments)[0]);
				}
			}
			else if (targetObject is IdentifierExpression)
			{
				codeExpression = new CodeThisReferenceExpression();
				text = ((IdentifierExpression)targetObject).Identifier;
			}
			else
			{
				codeExpression = (CodeExpression)targetObject.AcceptVisitor(this, data);
			}
			return new CodeMethodInvokeExpression(codeExpression, text, this.GetExpressionList(invocationExpression.Arguments));
		}

		public override object VisitLabelStatement(LabelStatement labelStatement, object data)
		{
			CodeLabeledStatement codeLabeledStatement = new CodeLabeledStatement(labelStatement.Label);
			this.AddStmt(codeLabeledStatement);
			return codeLabeledStatement;
		}

		public override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			CodeVariableDeclarationStatement codeVariableDeclarationStatement = null;
			for (int i = 0; i < localVariableDeclaration.Variables.Count; i++)
			{
				CodeTypeReference type = this.ConvType(localVariableDeclaration.GetTypeForVariable(i) ?? new TypeReference("System.Object", true));
				VariableDeclaration variableDeclaration = localVariableDeclaration.Variables[i];
				if (!variableDeclaration.Initializer.IsNull)
				{
					codeVariableDeclarationStatement = new CodeVariableDeclarationStatement(type, variableDeclaration.Name, (CodeExpression)((INode)variableDeclaration.Initializer).AcceptVisitor(this, data));
				}
				else
				{
					codeVariableDeclarationStatement = new CodeVariableDeclarationStatement(type, variableDeclaration.Name);
				}
				this.variables.Add(codeVariableDeclarationStatement);
				this.AddStmt(codeVariableDeclarationStatement);
			}
			return codeVariableDeclarationStatement;
		}

		public override object VisitMemberReferenceExpression(MemberReferenceExpression fieldReferenceExpression, object data)
		{
			if (this.methodReference)
			{
				this.methodReference = false;
				return new CodeMethodReferenceExpression((CodeExpression)fieldReferenceExpression.TargetObject.AcceptVisitor(this, data), fieldReferenceExpression.MemberName);
			}
			if (this.IsFieldReferenceExpression(fieldReferenceExpression))
			{
				return new CodeFieldReferenceExpression((CodeExpression)fieldReferenceExpression.TargetObject.AcceptVisitor(this, data), fieldReferenceExpression.MemberName);
			}
			if (!(fieldReferenceExpression.TargetObject is MemberReferenceExpression) || !this.IsPossibleTypeReference((MemberReferenceExpression)fieldReferenceExpression.TargetObject))
			{
				CodeExpression targetObject = (CodeExpression)fieldReferenceExpression.TargetObject.AcceptVisitor(this, data);
				return new CodePropertyReferenceExpression(targetObject, fieldReferenceExpression.MemberName);
			}
			CodeTypeReferenceExpression codeTypeReferenceExpression = CodeDomVisitor.ConvertToTypeReference((MemberReferenceExpression)fieldReferenceExpression.TargetObject);
			if (this.IsField(codeTypeReferenceExpression.Type.BaseType, fieldReferenceExpression.MemberName))
			{
				return new CodeFieldReferenceExpression(codeTypeReferenceExpression, fieldReferenceExpression.MemberName);
			}
			return new CodePropertyReferenceExpression(codeTypeReferenceExpression, fieldReferenceExpression.MemberName);
		}

		public override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.InitMethodScope();
			CodeMemberMethod codeMemberMethod = new CodeMemberMethod();
			codeMemberMethod.Name = methodDeclaration.Name;
			codeMemberMethod.Attributes = CodeDomVisitor.ConvMemberAttributes(methodDeclaration.Modifier);
			if ((codeMemberMethod.Attributes & MemberAttributes.Public) != MemberAttributes.Public && methodDeclaration.InterfaceImplementations.Count > 0)
			{
				codeMemberMethod.PrivateImplementationType = this.ConvType(methodDeclaration.InterfaceImplementations[0].InterfaceType);
			}
			this.codeStack.Push(codeMemberMethod.Statements);
			this.typeDeclarations.Peek().Members.Add(codeMemberMethod);
			this.parameters.Clear();
			foreach (ParameterDeclarationExpression current in methodDeclaration.Parameters)
			{
				codeMemberMethod.Parameters.Add((CodeParameterDeclarationExpression)this.VisitParameterDeclarationExpression(current, data));
			}
			this.usingId = 0;
			this.foreachId = 0;
			this.switchId = 0;
			this.doId = 0;
			CodeDomVisitor.Breakable.NextId = 0;
			this.variables.Clear();
			methodDeclaration.Body.AcceptChildren(this, data);
			this.codeStack.Pop();
			return null;
		}

		public override object VisitNamespaceDeclaration(NamespaceDeclaration namespaceDeclaration, object data)
		{
			CodeNamespace codeNamespace = new CodeNamespace(namespaceDeclaration.Name);
			foreach (CodeNamespaceImport value in this.namespaceDeclarations.Peek().Imports)
			{
				codeNamespace.Imports.Add(value);
			}
			this.namespaceDeclarations.Push(codeNamespace);
			namespaceDeclaration.AcceptChildren(this, data);
			this.namespaceDeclarations.Pop();
			this.codeCompileUnit.Namespaces.Add(codeNamespace);
			return null;
		}

		public override object VisitObjectCreateExpression(ObjectCreateExpression objectCreateExpression, object data)
		{
			return new CodeObjectCreateExpression(this.ConvType(objectCreateExpression.CreateType), (objectCreateExpression.Parameters == null) ? null : this.GetExpressionList(objectCreateExpression.Parameters));
		}

		public override object VisitParameterDeclarationExpression(ParameterDeclarationExpression parameterDeclarationExpression, object data)
		{
			CodeParameterDeclarationExpression codeParameterDeclarationExpression = new CodeParameterDeclarationExpression(this.ConvType(parameterDeclarationExpression.TypeReference), parameterDeclarationExpression.ParameterName);
			this.parameters.Add(codeParameterDeclarationExpression);
			return codeParameterDeclarationExpression;
		}

		public override object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			return parenthesizedExpression.Expression.AcceptVisitor(this, data);
		}

		public override object VisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			return new CodePrimitiveExpression(primitiveExpression.Value);
		}

		public override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			CodeMemberProperty codeMemberProperty = new CodeMemberProperty();
			codeMemberProperty.Name = propertyDeclaration.Name;
			codeMemberProperty.Attributes = CodeDomVisitor.ConvMemberAttributes(propertyDeclaration.Modifier);
			codeMemberProperty.HasGet = propertyDeclaration.HasGetRegion;
			codeMemberProperty.HasSet = propertyDeclaration.HasSetRegion;
			codeMemberProperty.Type = this.ConvType(propertyDeclaration.TypeReference);
			this.typeDeclarations.Peek().Members.Add(codeMemberProperty);
			foreach (ParameterDeclarationExpression current in propertyDeclaration.Parameters)
			{
				codeMemberProperty.Parameters.Add((CodeParameterDeclarationExpression)this.VisitParameterDeclarationExpression(current, data));
			}
			if (codeMemberProperty.HasGet)
			{
				this.codeStack.Push(codeMemberProperty.GetStatements);
				propertyDeclaration.GetRegion.Block.AcceptChildren(this, data);
				this.codeStack.Pop();
			}
			if (codeMemberProperty.HasSet)
			{
				this.codeStack.Push(codeMemberProperty.SetStatements);
				propertyDeclaration.SetRegion.Block.AcceptChildren(this, data);
				this.codeStack.Pop();
			}
			return null;
		}

		public override object VisitReturnStatement(ReturnStatement returnStatement, object data)
		{
			CodeMethodReturnStatement codeMethodReturnStatement;
			if (returnStatement.Expression.IsNull)
			{
				codeMethodReturnStatement = new CodeMethodReturnStatement();
			}
			else
			{
				codeMethodReturnStatement = new CodeMethodReturnStatement((CodeExpression)returnStatement.Expression.AcceptVisitor(this, data));
			}
			this.AddStmt(codeMethodReturnStatement);
			return codeMethodReturnStatement;
		}

		public override object VisitSwitchStatement(SwitchStatement switchStatement, object data)
		{
			this.switchId++;
			string text = "_switch" + this.switchId.ToString();
			this.breakableStack.Push(new CodeDomVisitor.Breakable(false));
			bool flag = false;
			CodeVariableReferenceExpression targetObject = null;
			SwitchSection switchSection = null;
			foreach (SwitchSection current in switchStatement.SwitchSections)
			{
				foreach (CaseLabel current2 in current.SwitchLabels)
				{
					if (current2.IsDefault)
					{
						switchSection = current;
						break;
					}
				}
				if (switchSection != null)
				{
					break;
				}
			}
			CodeConditionStatement codeConditionStatement = null;
			foreach (SwitchSection current3 in switchStatement.SwitchSections)
			{
				if (current3 != switchSection)
				{
					if (!flag)
					{
						flag = true;
						this.codeStack.Push(this.NullStmtCollection);
						CodeVariableDeclarationStatement stmt = new CodeVariableDeclarationStatement("System.Object", text, (CodeExpression)switchStatement.SwitchExpression.AcceptVisitor(this, data));
						this.codeStack.Pop();
						targetObject = new CodeVariableReferenceExpression(text);
						this.AddStmt(stmt);
						this.AddStmt(new CodeSnippetStatement());
					}
					this.codeStack.Push(this.NullStmtCollection);
					CodeExpression codeExpression = null;
					foreach (CaseLabel current4 in current3.SwitchLabels)
					{
						CodeMethodInvokeExpression codeMethodInvokeExpression = new CodeMethodInvokeExpression(targetObject, "Equals", new CodeExpression[]
						{
							(CodeExpression)current4.Label.AcceptVisitor(this, data)
						});
						if (codeExpression == null)
						{
							codeExpression = codeMethodInvokeExpression;
						}
						else
						{
							codeExpression = new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.BooleanOr, codeMethodInvokeExpression);
						}
					}
					this.codeStack.Pop();
					if (codeConditionStatement == null)
					{
						codeConditionStatement = new CodeConditionStatement();
						codeConditionStatement.Condition = codeExpression;
						this.AddStmt(codeConditionStatement);
					}
					else
					{
						CodeConditionStatement codeConditionStatement2 = new CodeConditionStatement();
						codeConditionStatement2.Condition = codeExpression;
						codeConditionStatement.FalseStatements.Add(codeConditionStatement2);
						codeConditionStatement = codeConditionStatement2;
					}
					this.codeStack.Push(codeConditionStatement.TrueStatements);
					for (int i = 0; i < current3.Children.Count; i++)
					{
						INode node = current3.Children[i];
						if (i == current3.Children.Count - 1 && node is BreakStatement)
						{
							break;
						}
						node.AcceptVisitor(this, data);
					}
					this.codeStack.Pop();
				}
			}
			if (switchSection != null)
			{
				if (codeConditionStatement != null)
				{
					this.codeStack.Push(codeConditionStatement.FalseStatements);
				}
				for (int j = 0; j < switchSection.Children.Count; j++)
				{
					INode node2 = switchSection.Children[j];
					if (j == switchSection.Children.Count - 1 && node2 is BreakStatement)
					{
						break;
					}
					node2.AcceptVisitor(this, data);
				}
				if (codeConditionStatement != null)
				{
					this.codeStack.Pop();
				}
			}
			CodeDomVisitor.Breakable breakable = this.breakableStack.Pop();
			if (breakable.IsContinue)
			{
				throw new Exception("Continue Inside Switch Not Supported");
			}
			if (breakable.IsBreak)
			{
				this.AddStmt(new CodeLabeledStatement("break" + breakable.Id, new CodeExpressionStatement(new CodeSnippetExpression())));
			}
			return null;
		}

		public override object VisitThisReferenceExpression(ThisReferenceExpression thisReferenceExpression, object data)
		{
			return new CodeThisReferenceExpression();
		}

		public override object VisitThrowStatement(ThrowStatement throwStatement, object data)
		{
			CodeThrowExceptionStatement codeThrowExceptionStatement = new CodeThrowExceptionStatement((CodeExpression)throwStatement.Expression.AcceptVisitor(this, data));
			this.AddStmt(codeThrowExceptionStatement);
			return codeThrowExceptionStatement;
		}

		public override object VisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			CodeTryCatchFinallyStatement codeTryCatchFinallyStatement = new CodeTryCatchFinallyStatement();
			this.codeStack.Push(codeTryCatchFinallyStatement.TryStatements);
			tryCatchStatement.StatementBlock.AcceptChildren(this, data);
			this.codeStack.Pop();
			if (!tryCatchStatement.FinallyBlock.IsNull)
			{
				this.codeStack.Push(codeTryCatchFinallyStatement.FinallyStatements);
				tryCatchStatement.FinallyBlock.AcceptChildren(this, data);
				this.codeStack.Pop();
			}
			foreach (CatchClause current in tryCatchStatement.CatchClauses)
			{
				CodeCatchClause codeCatchClause = new CodeCatchClause(current.VariableName);
				codeCatchClause.CatchExceptionType = this.ConvType(current.TypeReference);
				codeTryCatchFinallyStatement.CatchClauses.Add(codeCatchClause);
				this.codeStack.Push(codeCatchClause.Statements);
				current.StatementBlock.AcceptChildren(this, data);
				this.codeStack.Pop();
			}
			this.AddStmt(codeTryCatchFinallyStatement);
			return codeTryCatchFinallyStatement;
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			TypeDeclaration typeDeclaration2 = this.currentTypeDeclaration;
			this.currentTypeDeclaration = typeDeclaration;
			CodeTypeDeclaration codeTypeDeclaration = new CodeTypeDeclaration(typeDeclaration.Name);
			codeTypeDeclaration.TypeAttributes = CodeDomVisitor.ConvTypeAttributes(typeDeclaration.Modifier);
			codeTypeDeclaration.IsClass = (typeDeclaration.Type == ClassType.Class);
			codeTypeDeclaration.IsEnum = (typeDeclaration.Type == ClassType.Enum);
			codeTypeDeclaration.IsInterface = (typeDeclaration.Type == ClassType.Interface);
			codeTypeDeclaration.IsStruct = (typeDeclaration.Type == ClassType.Struct);
			codeTypeDeclaration.IsPartial = ((typeDeclaration.Modifier & Modifiers.Partial) != Modifiers.None);
			if (typeDeclaration.BaseTypes != null)
			{
				foreach (TypeReference current in typeDeclaration.BaseTypes)
				{
					codeTypeDeclaration.BaseTypes.Add(this.ConvType(current));
				}
			}
			this.typeDeclarations.Push(codeTypeDeclaration);
			typeDeclaration.AcceptChildren(this, data);
			this.typeDeclarations.Pop();
			if (this.typeDeclarations.Count > 0)
			{
				this.typeDeclarations.Peek().Members.Add(codeTypeDeclaration);
			}
			else
			{
				this.namespaceDeclarations.Peek().Types.Add(codeTypeDeclaration);
			}
			this.currentTypeDeclaration = typeDeclaration2;
			return null;
		}

		public override object VisitTypeOfExpression(TypeOfExpression typeOfExpression, object data)
		{
			return new CodeTypeOfExpression(this.ConvType(typeOfExpression.TypeReference));
		}

		public override object VisitTypeReferenceExpression(TypeReferenceExpression typeReferenceExpression, object data)
		{
			return new CodeTypeReferenceExpression(this.ConvType(typeReferenceExpression.TypeReference));
		}

		public override object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			switch (unaryOperatorExpression.Op)
			{
			case UnaryOperatorType.Not:
			{
				CodeExpression codeExpression = (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data);
				CodeBinaryOperatorExpression codeBinaryOperatorExpression = codeExpression as CodeBinaryOperatorExpression;
				if (codeBinaryOperatorExpression != null && codeBinaryOperatorExpression.Operator == CodeBinaryOperatorType.IdentityEquality)
				{
					return new CodeBinaryOperatorExpression(codeBinaryOperatorExpression.Left, CodeBinaryOperatorType.IdentityInequality, codeBinaryOperatorExpression.Right);
				}
				return new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.ValueEquality, new CodePrimitiveExpression(false));
			}
			case UnaryOperatorType.Minus:
				if (unaryOperatorExpression.Expression is PrimitiveExpression)
				{
					PrimitiveExpression primitiveExpression = (PrimitiveExpression)unaryOperatorExpression.Expression;
					if (primitiveExpression.Value is int)
					{
						return new CodePrimitiveExpression(-(int)primitiveExpression.Value);
					}
					if (primitiveExpression.Value is uint || primitiveExpression.Value is ushort)
					{
						return new CodePrimitiveExpression(int.Parse("-" + primitiveExpression.StringValue));
					}
					if (primitiveExpression.Value is long)
					{
						return new CodePrimitiveExpression(-(long)primitiveExpression.Value);
					}
					if (primitiveExpression.Value is double)
					{
						return new CodePrimitiveExpression(-(double)primitiveExpression.Value);
					}
					if (primitiveExpression.Value is float)
					{
						return new CodePrimitiveExpression(-(float)primitiveExpression.Value);
					}
				}
				return new CodeBinaryOperatorExpression(new CodePrimitiveExpression(0), CodeBinaryOperatorType.Subtract, (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data));
			case UnaryOperatorType.Plus:
				return unaryOperatorExpression.Expression.AcceptVisitor(this, data);
			case UnaryOperatorType.Increment:
			{
				CodeExpression codeExpression = (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data);
				CodeAssignStatement codeAssignStatement = new CodeAssignStatement(codeExpression, new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.Add, new CodePrimitiveExpression(1)));
				this.AddStmt(codeAssignStatement);
				return codeAssignStatement;
			}
			case UnaryOperatorType.Decrement:
			{
				CodeExpression codeExpression = (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data);
				CodeAssignStatement codeAssignStatement = new CodeAssignStatement(codeExpression, new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.Subtract, new CodePrimitiveExpression(1)));
				this.AddStmt(codeAssignStatement);
				return codeAssignStatement;
			}
			case UnaryOperatorType.PostIncrement:
			{
				CodeExpression codeExpression = (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data);
				CodeAssignStatement codeAssignStatement = new CodeAssignStatement(codeExpression, new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.Add, new CodePrimitiveExpression(1)));
				this.AddStmt(codeAssignStatement);
				return codeAssignStatement;
			}
			case UnaryOperatorType.PostDecrement:
			{
				CodeExpression codeExpression = (CodeExpression)unaryOperatorExpression.Expression.AcceptVisitor(this, data);
				CodeAssignStatement codeAssignStatement = new CodeAssignStatement(codeExpression, new CodeBinaryOperatorExpression(codeExpression, CodeBinaryOperatorType.Subtract, new CodePrimitiveExpression(1)));
				this.AddStmt(codeAssignStatement);
				return codeAssignStatement;
			}
			}
			throw new NotSupportedException("CodeDom does not support Unary Operators");
		}

		public override object VisitUsing(Using @using, object data)
		{
			return base.VisitUsing(@using, data);
		}

		public override object VisitUsingDeclaration(UsingDeclaration usingDeclaration, object data)
		{
			foreach (Using current in usingDeclaration.Usings)
			{
				this.namespaceDeclarations.Peek().Imports.Add(new CodeNamespaceImport(current.Name));
			}
			return null;
		}

		public override object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			this.usingId++;
			string text = "_dispose" + this.usingId.ToString();
			CodeVariableDeclarationStatement stmt = new CodeVariableDeclarationStatement("System.Object", text, new CodePrimitiveExpression(null));
			this.AddStmt(stmt);
			CodeTryCatchFinallyStatement codeTryCatchFinallyStatement = new CodeTryCatchFinallyStatement();
			CodeVariableReferenceExpression codeVariableReferenceExpression = new CodeVariableReferenceExpression(text);
			this.codeStack.Push(this.NullStmtCollection);
			CodeExpression right = (CodeExpression)usingStatement.ResourceAcquisition.AcceptVisitor(this, data);
			this.codeStack.Pop();
			CodeAssignStatement value = new CodeAssignStatement(codeVariableReferenceExpression, right);
			codeTryCatchFinallyStatement.TryStatements.Add(value);
			codeTryCatchFinallyStatement.TryStatements.Add(new CodeSnippetStatement());
			this.codeStack.Push(codeTryCatchFinallyStatement.TryStatements);
			usingStatement.EmbeddedStatement.AcceptChildren(this, data);
			this.codeStack.Pop();
			CodeMethodInvokeExpression left = new CodeMethodInvokeExpression(new CodeTypeOfExpression(typeof(IDisposable)), "IsInstanceOfType", new CodeExpression[]
			{
				codeVariableReferenceExpression
			});
			CodeConditionStatement codeConditionStatement = new CodeConditionStatement();
			codeConditionStatement.Condition = new CodeBinaryOperatorExpression(new CodeBinaryOperatorExpression(codeVariableReferenceExpression, CodeBinaryOperatorType.IdentityInequality, new CodePrimitiveExpression(null)), CodeBinaryOperatorType.BooleanAnd, new CodeBinaryOperatorExpression(left, CodeBinaryOperatorType.IdentityEquality, new CodePrimitiveExpression(true)));
			codeConditionStatement.TrueStatements.Add(new CodeMethodInvokeExpression(new CodeCastExpression(typeof(IDisposable), codeVariableReferenceExpression), "Dispose", new CodeExpression[0]));
			codeTryCatchFinallyStatement.FinallyStatements.Add(codeConditionStatement);
			this.AddStmt(codeTryCatchFinallyStatement);
			return null;
		}

		public override object VisitVariableDeclaration(VariableDeclaration variableDeclaration, object data)
		{
			return null;
		}

		public IEnvironmentInformationProvider EnvironmentInformationProvider
		{
			get
			{
				return this.environmentInformationProvider;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}
				this.environmentInformationProvider = value;
			}
		}

		private Stack<CodeDomVisitor.Breakable> breakableStack = new Stack<CodeDomVisitor.Breakable>();

		public CodeCompileUnit codeCompileUnit = new CodeCompileUnit();

		private Stack<CodeStatementCollection> codeStack = new Stack<CodeStatementCollection>();

		private TypeDeclaration currentTypeDeclaration;

		private int doId;

		private IEnvironmentInformationProvider environmentInformationProvider = DummyEnvironmentInformationProvider.Instance;

		private int foreachId;

		private bool methodReference;

		private Stack<CodeNamespace> namespaceDeclarations = new Stack<CodeNamespace>();

		private CodeStatementCollection NullStmtCollection = new CodeStatementCollection();

		private List<CodeParameterDeclarationExpression> parameters = new List<CodeParameterDeclarationExpression>();

		private int switchId;

		private Stack<CodeTypeDeclaration> typeDeclarations = new Stack<CodeTypeDeclaration>();

		private int usingId;

		private List<CodeVariableDeclarationStatement> variables = new List<CodeVariableDeclarationStatement>();

		private class Breakable
		{
			public Breakable()
			{
				this.Id = ++CodeDomVisitor.Breakable.NextId;
			}

			public Breakable(bool allowContinue) : this()
			{
				this.AllowContinue = allowContinue;
			}

			public bool AllowContinue = true;

			public int Id;

			public bool IsBreak;

			public bool IsContinue;

			public static int NextId;
		}
	}
}
