﻿using System;
using System.Collections.Generic;
using System.Linq;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.AstBuilder;

namespace ICSharpCode.NRefactory.Visitors
{
	public class ToCSharpConvertVisitor : ConvertVisitorBase
	{
		private void ConvertInterfaceImplementation(MethodDeclaration member)
		{
			if (member.Modifier == Modifiers.None)
			{
				return;
			}
			while (member.InterfaceImplementations.Count > 0)
			{
				InterfaceImplementation interfaceImplementation = member.InterfaceImplementations[0];
				member.InterfaceImplementations.RemoveAt(0);
				if (member.Name != interfaceImplementation.MemberName)
				{
					MethodDeclaration methodDeclaration = new MethodDeclaration
					{
						Name = interfaceImplementation.MemberName,
						TypeReference = member.TypeReference,
						Parameters = member.Parameters,
						Body = new BlockStatement()
					};
					InvocationExpression invocationExpression = new InvocationExpression(new IdentifierExpression(member.Name));
					foreach (ParameterDeclarationExpression current in member.Parameters)
					{
						invocationExpression.Arguments.Add(new IdentifierExpression(current.ParameterName));
					}
					if (member.TypeReference.Type == "System.Void")
					{
						methodDeclaration.Body.AddChild(new ExpressionStatement(invocationExpression));
					}
					else
					{
						methodDeclaration.Body.AddChild(new ReturnStatement(invocationExpression));
					}
					methodDeclaration.InterfaceImplementations.Add(interfaceImplementation);
					base.InsertAfterSibling(member, methodDeclaration);
				}
			}
		}

		private void ConvertInterfaceImplementation(PropertyDeclaration member)
		{
			if (member.Modifier == Modifiers.None)
			{
				return;
			}
			while (member.InterfaceImplementations.Count > 0)
			{
				InterfaceImplementation interfaceImplementation = member.InterfaceImplementations[0];
				member.InterfaceImplementations.RemoveAt(0);
				if (member.Name != interfaceImplementation.MemberName)
				{
					PropertyDeclaration propertyDeclaration = new PropertyDeclaration(Modifiers.None, null, interfaceImplementation.MemberName, null);
					propertyDeclaration.TypeReference = member.TypeReference;
					if (member.HasGetRegion)
					{
						propertyDeclaration.GetRegion = new PropertyGetRegion(new BlockStatement(), null);
						propertyDeclaration.GetRegion.Block.AddChild(new ReturnStatement(new IdentifierExpression(member.Name)));
					}
					if (member.HasSetRegion)
					{
						propertyDeclaration.SetRegion = new PropertySetRegion(new BlockStatement(), null);
						propertyDeclaration.SetRegion.Block.AddChild(new ExpressionStatement(new AssignmentExpression(new IdentifierExpression(member.Name), AssignmentOperatorType.Assign, new IdentifierExpression("value"))));
					}
					propertyDeclaration.Parameters = member.Parameters;
					propertyDeclaration.InterfaceImplementations.Add(interfaceImplementation);
					base.InsertAfterSibling(member, propertyDeclaration);
				}
			}
		}

		private static string GetTypeLevelEntityName(INode node)
		{
			if (node is ParametrizedNode)
			{
				return ((ParametrizedNode)node).Name;
			}
			if (node is FieldDeclaration)
			{
				return ((FieldDeclaration)node).Fields[0].Name;
			}
			throw new ArgumentException();
		}

		private INode InitStaticVariable(string initFieldName, string variableName, Expression initializer, TypeDeclaration typeDeclaration)
		{
			if (typeDeclaration != null)
			{
				if (!typeDeclaration.Children.OfType<MethodDeclaration>().Any((MethodDeclaration m) => m.Name == "InitStaticVariableHelper"))
				{
					MethodDeclaration methodDeclaration = new MethodDeclaration
					{
						Name = "InitStaticVariableHelper",
						Modifier = Modifiers.Static,
						TypeReference = new TypeReference("System.Boolean", true),
						Parameters = 
						{
							new ParameterDeclarationExpression(new TypeReference("Microsoft.VisualBasic.CompilerServices.StaticLocalInitFlag"), "flag")
						},
						Body = new BlockStatement()
					};
					BlockStatement blockStatement = new BlockStatement();
					BlockStatement blockStatement2 = new BlockStatement();
					BlockStatement blockStatement3 = new BlockStatement();
					methodDeclaration.Body.AddStatement(new IfElseStatement(ExpressionBuilder.Identifier("flag").Member("State").Operator(BinaryOperatorType.Equality, new PrimitiveExpression(0)))
					{
						TrueStatement = 
						{
							blockStatement
						},
						ElseIfSections = 
						{
							new ElseIfSection(ExpressionBuilder.Identifier("flag").Member("State").Operator(BinaryOperatorType.Equality, new PrimitiveExpression(2)), blockStatement2)
						},
						FalseStatement = 
						{
							blockStatement3
						}
					});
					blockStatement.Assign(ExpressionBuilder.Identifier("flag").Member("State"), new PrimitiveExpression(2));
					blockStatement.Return(new PrimitiveExpression(true));
					blockStatement2.Throw(new TypeReference("Microsoft.VisualBasic.CompilerServices.IncompleteInitialization").New(new Expression[0]));
					blockStatement3.Return(new PrimitiveExpression(false));
					typeDeclaration.AddChild(methodDeclaration);
				}
			}
			BlockStatement blockStatement4 = new BlockStatement();
			BlockStatement blockStatement5 = new BlockStatement();
			blockStatement4.AddStatement(new IfElseStatement(ExpressionBuilder.Identifier("InitStaticVariableHelper").Call(new Expression[]
			{
				ExpressionBuilder.Identifier(initFieldName)
			}), blockStatement5));
			blockStatement5.Assign(ExpressionBuilder.Identifier(variableName), initializer);
			BlockStatement blockStatement6 = new BlockStatement();
			blockStatement6.Assign(ExpressionBuilder.Identifier(initFieldName).Member("State"), new PrimitiveExpression(1));
			BlockStatement blockStatement7 = new BlockStatement();
			blockStatement7.AddStatement(new TryCatchStatement(blockStatement4, null, blockStatement6));
			return new LockStatement(ExpressionBuilder.Identifier(initFieldName), blockStatement7);
		}

		private static bool IsTypeLevel(INode node)
		{
			return node.Parent is TypeDeclaration;
		}

		private object ReplacePrimitiveCastWithConvertMethodCall(CastExpression castExpression, string methodName)
		{
			base.ReplaceCurrentNode(ExpressionBuilder.Identifier("Convert").Call(methodName, new Expression[]
			{
				castExpression.Expression
			}));
			return null;
		}

		public override object VisitCastExpression(CastExpression castExpression, object data)
		{
			base.VisitCastExpression(castExpression, data);
			string type;
			if ((castExpression.CastType == CastType.Conversion || castExpression.CastType == CastType.PrimitiveConversion) && (type = castExpression.CastTo.Type) != null)
			{
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000852-1 == null)
				{
					<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000852-1 = new Dictionary<string, int>(15)
					{
						{
							"System.Boolean",
							0
						},
						{
							"System.Byte",
							1
						},
						{
							"System.Char",
							2
						},
						{
							"System.DateTime",
							3
						},
						{
							"System.Decimal",
							4
						},
						{
							"System.Double",
							5
						},
						{
							"System.Int16",
							6
						},
						{
							"System.Int32",
							7
						},
						{
							"System.Int64",
							8
						},
						{
							"System.SByte",
							9
						},
						{
							"System.Single",
							10
						},
						{
							"System.String",
							11
						},
						{
							"System.UInt16",
							12
						},
						{
							"System.UInt32",
							13
						},
						{
							"System.UInt64",
							14
						}
					};
				}
				int num;
				if (<PrivateImplementationDetails>{D28BF961-CE7C-480E-AA13-BFA1B3F70A32}.$$method0x6000852-1.TryGetValue(type, out num))
				{
					switch (num)
					{
					case 0:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToBoolean");
					case 1:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToByte");
					case 2:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToChar");
					case 3:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToDateTime");
					case 4:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToDecimal");
					case 5:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToDouble");
					case 6:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToInt16");
					case 7:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToInt32");
					case 8:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToInt64");
					case 9:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToSByte");
					case 10:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToSingle");
					case 11:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToString");
					case 12:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToUInt16");
					case 13:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToUInt32");
					case 14:
						return this.ReplacePrimitiveCastWithConvertMethodCall(castExpression, "ToUInt64");
					}
				}
			}
			return null;
		}

		public override object VisitEventDeclaration(EventDeclaration eventDeclaration, object data)
		{
			if (!eventDeclaration.HasAddRegion && !eventDeclaration.HasRaiseRegion && !eventDeclaration.HasRemoveRegion && eventDeclaration.TypeReference.IsNull)
			{
				DelegateDeclaration delegateDeclaration = new DelegateDeclaration(eventDeclaration.Modifier, null);
				delegateDeclaration.Name = eventDeclaration.Name + "EventHandler";
				delegateDeclaration.Parameters = eventDeclaration.Parameters;
				delegateDeclaration.ReturnType = new TypeReference("System.Void", true);
				delegateDeclaration.Parent = eventDeclaration.Parent;
				eventDeclaration.Parameters = null;
				base.InsertAfterSibling(eventDeclaration, delegateDeclaration);
				eventDeclaration.TypeReference = new TypeReference(delegateDeclaration.Name);
			}
			return base.VisitEventDeclaration(eventDeclaration, data);
		}

		public override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			base.VisitLocalVariableDeclaration(localVariableDeclaration, data);
			if ((localVariableDeclaration.Modifier & Modifiers.Static) == Modifiers.Static)
			{
				INode parent = localVariableDeclaration.Parent;
				while (parent != null && !ToCSharpConvertVisitor.IsTypeLevel(parent))
				{
					parent = parent.Parent;
				}
				if (parent != null)
				{
					string text = "static_" + ToCSharpConvertVisitor.GetTypeLevelEntityName(parent) + "_";
					foreach (VariableDeclaration current in localVariableDeclaration.Variables)
					{
						if (!current.Initializer.IsNull)
						{
							string text2 = text + current.Name + "_Init";
							FieldDeclaration fieldDeclaration = new FieldDeclaration(null);
							fieldDeclaration.TypeReference = new TypeReference("Microsoft.VisualBasic.CompilerServices.StaticLocalInitFlag");
							fieldDeclaration.Modifier = ((((AttributedNode)parent).Modifier & Modifiers.Static) | Modifiers.ReadOnly);
							Expression initializer = fieldDeclaration.TypeReference.New(new Expression[0]);
							fieldDeclaration.Fields.Add(new VariableDeclaration(text2, initializer));
							base.InsertBeforeSibling(parent, fieldDeclaration);
							base.InsertAfterSibling(localVariableDeclaration, this.InitStaticVariable(text2, current.Name, current.Initializer, parent.Parent as TypeDeclaration));
						}
						base.InsertBeforeSibling(parent, new FieldDeclaration(null)
						{
							TypeReference = localVariableDeclaration.TypeReference,
							Modifier = (((AttributedNode)parent).Modifier & Modifiers.Static),
							Fields = 
							{
								new VariableDeclaration(text + current.Name)
								{
									TypeReference = current.TypeReference
								}
							}
						});
					}
					new PrefixFieldsVisitor(localVariableDeclaration.Variables, text).Run(parent);
					base.RemoveCurrentNode();
				}
			}
			return null;
		}

		public override object VisitMethodDeclaration(MethodDeclaration methodDeclaration, object data)
		{
			this.ConvertInterfaceImplementation(methodDeclaration);
			return base.VisitMethodDeclaration(methodDeclaration, data);
		}

		public override object VisitPropertyDeclaration(PropertyDeclaration propertyDeclaration, object data)
		{
			this.ConvertInterfaceImplementation(propertyDeclaration);
			return base.VisitPropertyDeclaration(propertyDeclaration, data);
		}

		public override object VisitSwitchSection(SwitchSection switchSection, object data)
		{
			if (switchSection.Children.Count == 0 || (!(switchSection.Children[switchSection.Children.Count - 1] is BreakStatement) && !(switchSection.Children[switchSection.Children.Count - 1] is ContinueStatement) && !(switchSection.Children[switchSection.Children.Count - 1] is ThrowStatement) && !(switchSection.Children[switchSection.Children.Count - 1] is ReturnStatement)))
			{
				switchSection.Children.Add(new BreakStatement());
			}
			return base.VisitSwitchSection(switchSection, data);
		}

		public override object VisitTypeDeclaration(TypeDeclaration typeDeclaration, object data)
		{
			if (typeDeclaration.Type == ClassType.Module)
			{
				typeDeclaration.Type = ClassType.Class;
				typeDeclaration.Modifier |= Modifiers.Static;
				foreach (INode current in typeDeclaration.Children)
				{
					MemberNode memberNode = current as MemberNode;
					if (memberNode != null)
					{
						memberNode.Modifier |= Modifiers.Static;
					}
					FieldDeclaration fieldDeclaration = current as FieldDeclaration;
					if (fieldDeclaration != null && (fieldDeclaration.Modifier & Modifiers.Const) == Modifiers.None)
					{
						fieldDeclaration.Modifier |= Modifiers.Static;
					}
				}
			}
			return base.VisitTypeDeclaration(typeDeclaration, data);
		}

		public override object VisitWithStatement(WithStatement withStatement, object data)
		{
			withStatement.Body.AcceptVisitor(new ToCSharpConvertVisitor.ReplaceWithAccessTransformer(withStatement.Expression), data);
			base.VisitWithStatement(withStatement, data);
			base.ReplaceCurrentNode(withStatement.Body);
			return null;
		}

		private sealed class ReplaceWithAccessTransformer : AbstractAstTransformer
		{
			public ReplaceWithAccessTransformer(Expression replaceWith)
			{
				this.replaceWith = replaceWith;
			}

			public override object VisitMemberReferenceExpression(MemberReferenceExpression fieldReferenceExpression, object data)
			{
				if (fieldReferenceExpression.TargetObject.IsNull)
				{
					fieldReferenceExpression.TargetObject = this.replaceWith;
					return null;
				}
				return base.VisitMemberReferenceExpression(fieldReferenceExpression, data);
			}

			public override object VisitWithStatement(WithStatement withStatement, object data)
			{
				return withStatement.Expression.AcceptVisitor(this, data);
			}

			private readonly Expression replaceWith;
		}
	}
}
