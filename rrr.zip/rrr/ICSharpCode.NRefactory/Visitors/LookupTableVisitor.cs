﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public sealed class LookupTableVisitor : AbstractAstVisitor
	{
		public LookupTableVisitor(SupportedLanguage language)
		{
			this.language = language;
			if (language == SupportedLanguage.VBNet)
			{
				this.variables = new Dictionary<string, List<LocalLookupVariable>>(StringComparer.InvariantCultureIgnoreCase);
				return;
			}
			this.variables = new Dictionary<string, List<LocalLookupVariable>>(StringComparer.InvariantCulture);
		}

		public void AddVariable(TypeReference typeRef, string name, Location startPos, Location endPos, bool isConst, bool isLoopVariable, Expression initializer, LambdaExpression parentLambdaExpression, bool isQueryContinuation)
		{
			if (name == null || name.Length == 0)
			{
				return;
			}
			List<LocalLookupVariable> list;
			if (!this.variables.ContainsKey(name))
			{
				list = (this.variables[name] = new List<LocalLookupVariable>());
			}
			else
			{
				list = this.variables[name];
			}
			list.Add(new LocalLookupVariable(name, typeRef, startPos, endPos, isConst, isLoopVariable, initializer, parentLambdaExpression, isQueryContinuation));
		}

		private Location GetQueryVariableEndScope(QueryExpression queryExpression)
		{
			return queryExpression.EndLocation;
		}

		public override object VisitAnonymousMethodExpression(AnonymousMethodExpression anonymousMethodExpression, object data)
		{
			foreach (ParameterDeclarationExpression current in anonymousMethodExpression.Parameters)
			{
				this.AddVariable(current.TypeReference, current.ParameterName, anonymousMethodExpression.StartLocation, anonymousMethodExpression.EndLocation, false, false, null, null, false);
			}
			return base.VisitAnonymousMethodExpression(anonymousMethodExpression, data);
		}

		public override object VisitBlockStatement(BlockStatement blockStatement, object data)
		{
			this.endLocationStack.Push(blockStatement.EndLocation);
			base.VisitBlockStatement(blockStatement, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitCompilationUnit(CompilationUnit compilationUnit, object data)
		{
			this.variables.Clear();
			return base.VisitCompilationUnit(compilationUnit, data);
		}

		public override object VisitFixedStatement(FixedStatement fixedStatement, object data)
		{
			if (fixedStatement.EmbeddedStatement.EndLocation.IsEmpty)
			{
				return base.VisitFixedStatement(fixedStatement, data);
			}
			this.endLocationStack.Push(fixedStatement.EmbeddedStatement.EndLocation);
			base.VisitFixedStatement(fixedStatement, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitForeachStatement(ForeachStatement foreachStatement, object data)
		{
			this.AddVariable(foreachStatement.TypeReference, foreachStatement.VariableName, foreachStatement.StartLocation, foreachStatement.EndLocation, false, true, foreachStatement.Expression, null, false);
			if (foreachStatement.Expression != null)
			{
				foreachStatement.Expression.AcceptVisitor(this, data);
			}
			if (foreachStatement.EmbeddedStatement == null)
			{
				return data;
			}
			return foreachStatement.EmbeddedStatement.AcceptVisitor(this, data);
		}

		public override object VisitForNextStatement(ForNextStatement forNextStatement, object data)
		{
			if (forNextStatement.EmbeddedStatement.EndLocation.IsEmpty)
			{
				return base.VisitForNextStatement(forNextStatement, data);
			}
			this.endLocationStack.Push(forNextStatement.EmbeddedStatement.EndLocation);
			this.AddVariable(forNextStatement.TypeReference, forNextStatement.VariableName, forNextStatement.StartLocation, forNextStatement.EndLocation, false, false, forNextStatement.Start, null, false);
			base.VisitForNextStatement(forNextStatement, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitForStatement(ForStatement forStatement, object data)
		{
			if (forStatement.EmbeddedStatement.EndLocation.IsEmpty)
			{
				return base.VisitForStatement(forStatement, data);
			}
			this.endLocationStack.Push(forStatement.EmbeddedStatement.EndLocation);
			base.VisitForStatement(forStatement, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitLambdaExpression(LambdaExpression lambdaExpression, object data)
		{
			foreach (ParameterDeclarationExpression current in lambdaExpression.Parameters)
			{
				this.AddVariable(current.TypeReference, current.ParameterName, lambdaExpression.StartLocation, lambdaExpression.ExtendedEndLocation, false, false, null, lambdaExpression, false);
			}
			return base.VisitLambdaExpression(lambdaExpression, data);
		}

		public override object VisitLocalVariableDeclaration(LocalVariableDeclaration localVariableDeclaration, object data)
		{
			for (int i = 0; i < localVariableDeclaration.Variables.Count; i++)
			{
				VariableDeclaration variableDeclaration = localVariableDeclaration.Variables[i];
				this.AddVariable(localVariableDeclaration.GetTypeForVariable(i), variableDeclaration.Name, localVariableDeclaration.StartLocation, this.CurrentEndLocation, (localVariableDeclaration.Modifier & Modifiers.Const) == Modifiers.Const, false, variableDeclaration.Initializer, null, false);
			}
			return base.VisitLocalVariableDeclaration(localVariableDeclaration, data);
		}

		public override object VisitQueryExpression(QueryExpression queryExpression, object data)
		{
			this.endLocationStack.Push(this.GetQueryVariableEndScope(queryExpression));
			base.VisitQueryExpression(queryExpression, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitQueryExpressionFromClause(QueryExpressionFromClause fromClause, object data)
		{
			QueryExpression queryExpression = fromClause.Parent as QueryExpression;
			this.AddVariable(fromClause.Type, fromClause.Identifier, fromClause.StartLocation, this.CurrentEndLocation, false, true, fromClause.InExpression, null, queryExpression != null && queryExpression.IsQueryContinuation);
			return base.VisitQueryExpressionFromClause(fromClause, data);
		}

		public override object VisitQueryExpressionJoinClause(QueryExpressionJoinClause joinClause, object data)
		{
			if (string.IsNullOrEmpty(joinClause.IntoIdentifier))
			{
				this.AddVariable(joinClause.Type, joinClause.Identifier, joinClause.StartLocation, this.CurrentEndLocation, false, true, joinClause.InExpression, null, false);
			}
			else
			{
				this.AddVariable(joinClause.Type, joinClause.Identifier, joinClause.StartLocation, joinClause.EndLocation, false, true, joinClause.InExpression, null, false);
				this.AddVariable(joinClause.Type, joinClause.IntoIdentifier, joinClause.StartLocation, this.CurrentEndLocation, false, false, joinClause.InExpression, null, false);
			}
			return base.VisitQueryExpressionJoinClause(joinClause, data);
		}

		public override object VisitQueryExpressionLetClause(QueryExpressionLetClause letClause, object data)
		{
			this.AddVariable(null, letClause.Identifier, letClause.StartLocation, this.CurrentEndLocation, false, false, letClause.Expression, null, false);
			return base.VisitQueryExpressionLetClause(letClause, data);
		}

		public override object VisitSwitchSection(SwitchSection switchSection, object data)
		{
			if (this.language == SupportedLanguage.VBNet)
			{
				return this.VisitBlockStatement(switchSection, data);
			}
			return base.VisitSwitchSection(switchSection, data);
		}

		public override object VisitTryCatchStatement(TryCatchStatement tryCatchStatement, object data)
		{
			if (tryCatchStatement == null)
			{
				return data;
			}
			if (tryCatchStatement.StatementBlock != null)
			{
				tryCatchStatement.StatementBlock.AcceptVisitor(this, data);
			}
			if (tryCatchStatement.CatchClauses != null)
			{
				foreach (CatchClause current in tryCatchStatement.CatchClauses)
				{
					if (current != null)
					{
						if (current.TypeReference != null && current.VariableName != null)
						{
							this.AddVariable(current.TypeReference, current.VariableName, current.StartLocation, current.StatementBlock.EndLocation, false, false, null, null, false);
						}
						current.StatementBlock.AcceptVisitor(this, data);
					}
				}
			}
			if (tryCatchStatement.FinallyBlock != null)
			{
				return tryCatchStatement.FinallyBlock.AcceptVisitor(this, data);
			}
			return data;
		}

		public override object VisitUsingStatement(UsingStatement usingStatement, object data)
		{
			if (usingStatement.EmbeddedStatement.EndLocation.IsEmpty)
			{
				return base.VisitUsingStatement(usingStatement, data);
			}
			this.endLocationStack.Push(usingStatement.EmbeddedStatement.EndLocation);
			base.VisitUsingStatement(usingStatement, data);
			this.endLocationStack.Pop();
			return null;
		}

		public override object VisitWithStatement(WithStatement withStatement, object data)
		{
			this.withStatements.Add(withStatement);
			return base.VisitWithStatement(withStatement, data);
		}

		private Location CurrentEndLocation
		{
			get
			{
				if (this.endLocationStack.Count != 0)
				{
					return this.endLocationStack.Peek();
				}
				return Location.Empty;
			}
		}

		public Dictionary<string, List<LocalLookupVariable>> Variables
		{
			get
			{
				return this.variables;
			}
		}

		public List<WithStatement> WithStatements
		{
			get
			{
				return this.withStatements;
			}
		}

		private Stack<Location> endLocationStack = new Stack<Location>();

		private SupportedLanguage language;

		private Dictionary<string, List<LocalLookupVariable>> variables;

		private List<WithStatement> withStatements = new List<WithStatement>();
	}
}
