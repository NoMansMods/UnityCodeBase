﻿using System;
using System.Globalization;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Visitors
{
	public class CSharpConstructsConvertVisitor : ConvertVisitorBase
	{
		private void ConvertForStatement(ForStatement forStatement)
		{
			if (forStatement.Initializers.Count != 1)
			{
				return;
			}
			if (forStatement.Iterator.Count != 1)
			{
				return;
			}
			ExpressionStatement expressionStatement = forStatement.Iterator[0] as ExpressionStatement;
			if (expressionStatement == null)
			{
				return;
			}
			AssignmentExpression assignmentExpression = expressionStatement.Expression as AssignmentExpression;
			if (assignmentExpression == null || (assignmentExpression.Op != AssignmentOperatorType.Add && assignmentExpression.Op != AssignmentOperatorType.Subtract))
			{
				return;
			}
			IdentifierExpression identifierExpression = assignmentExpression.Left as IdentifierExpression;
			if (identifierExpression == null)
			{
				return;
			}
			PrimitiveExpression primitiveExpression = assignmentExpression.Right as PrimitiveExpression;
			if (primitiveExpression == null || !(primitiveExpression.Value is int))
			{
				return;
			}
			int num = (int)primitiveExpression.Value;
			if (assignmentExpression.Op == AssignmentOperatorType.Subtract)
			{
				num = -num;
			}
			BinaryOperatorExpression binaryOperatorExpression = forStatement.Condition as BinaryOperatorExpression;
			if (binaryOperatorExpression == null || !(binaryOperatorExpression.Left is IdentifierExpression))
			{
				return;
			}
			if ((binaryOperatorExpression.Left as IdentifierExpression).Identifier != identifierExpression.Identifier)
			{
				return;
			}
			Expression end;
			if (assignmentExpression.Op == AssignmentOperatorType.Subtract)
			{
				if (binaryOperatorExpression.Op == BinaryOperatorType.GreaterThanOrEqual)
				{
					end = binaryOperatorExpression.Right;
				}
				else
				{
					if (binaryOperatorExpression.Op != BinaryOperatorType.GreaterThan)
					{
						return;
					}
					end = Expression.AddInteger(binaryOperatorExpression.Right, 1);
				}
			}
			else if (binaryOperatorExpression.Op == BinaryOperatorType.LessThanOrEqual)
			{
				end = binaryOperatorExpression.Right;
			}
			else
			{
				if (binaryOperatorExpression.Op != BinaryOperatorType.LessThan)
				{
					return;
				}
				end = Expression.AddInteger(binaryOperatorExpression.Right, -1);
			}
			TypeReference typeReference = null;
			LocalVariableDeclaration localVariableDeclaration = forStatement.Initializers[0] as LocalVariableDeclaration;
			Expression start;
			if (localVariableDeclaration != null)
			{
				if (localVariableDeclaration.Variables.Count != 1 || localVariableDeclaration.Variables[0].Name != identifierExpression.Identifier || localVariableDeclaration.Variables[0].Initializer == null)
				{
					return;
				}
				typeReference = localVariableDeclaration.GetTypeForVariable(0);
				start = localVariableDeclaration.Variables[0].Initializer;
			}
			else
			{
				expressionStatement = (forStatement.Initializers[0] as ExpressionStatement);
				if (expressionStatement == null)
				{
					return;
				}
				AssignmentExpression assignmentExpression2 = expressionStatement.Expression as AssignmentExpression;
				if (assignmentExpression2 == null || assignmentExpression2.Op != AssignmentOperatorType.Assign)
				{
					return;
				}
				if (!(assignmentExpression2.Left is IdentifierExpression))
				{
					return;
				}
				if ((assignmentExpression2.Left as IdentifierExpression).Identifier != identifierExpression.Identifier)
				{
					return;
				}
				start = assignmentExpression2.Right;
			}
			base.ReplaceCurrentNode(new ForNextStatement
			{
				TypeReference = typeReference,
				VariableName = identifierExpression.Identifier,
				Start = start,
				End = end,
				Step = ((num == 1) ? null : new PrimitiveExpression(num, num.ToString(NumberFormatInfo.InvariantInfo))),
				EmbeddedStatement = forStatement.EmbeddedStatement
			});
		}

		private string GetPossibleEventName(Expression expression)
		{
			IdentifierExpression identifierExpression = expression as IdentifierExpression;
			if (identifierExpression != null)
			{
				return identifierExpression.Identifier;
			}
			MemberReferenceExpression memberReferenceExpression = expression as MemberReferenceExpression;
			if (memberReferenceExpression != null && memberReferenceExpression.TargetObject is ThisReferenceExpression)
			{
				return memberReferenceExpression.MemberName;
			}
			return null;
		}

		private static bool IsNullLiteralExpression(Expression expr)
		{
			PrimitiveExpression primitiveExpression = expr as PrimitiveExpression;
			return primitiveExpression != null && primitiveExpression.Value == null;
		}

		public override object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			if (binaryOperatorExpression.Op == BinaryOperatorType.Equality || binaryOperatorExpression.Op == BinaryOperatorType.InEquality)
			{
				if (CSharpConstructsConvertVisitor.IsNullLiteralExpression(binaryOperatorExpression.Left))
				{
					Expression left = binaryOperatorExpression.Left;
					binaryOperatorExpression.Left = binaryOperatorExpression.Right;
					binaryOperatorExpression.Right = left;
				}
				if (CSharpConstructsConvertVisitor.IsNullLiteralExpression(binaryOperatorExpression.Right))
				{
					if (binaryOperatorExpression.Op == BinaryOperatorType.Equality)
					{
						binaryOperatorExpression.Op = BinaryOperatorType.ReferenceEquality;
					}
					else
					{
						binaryOperatorExpression.Op = BinaryOperatorType.ReferenceInequality;
					}
				}
			}
			return base.VisitBinaryOperatorExpression(binaryOperatorExpression, data);
		}

		public override object VisitCastExpression(CastExpression castExpression, object data)
		{
			string a;
			if (castExpression.CastType == CastType.Cast && TypeReference.PrimitiveTypesCSharpReverse.TryGetValue(castExpression.CastTo.Type, out a) && a != "object" && a != "string")
			{
				castExpression.CastType = CastType.Conversion;
			}
			return base.VisitCastExpression(castExpression, data);
		}

		public override object VisitExpressionStatement(ExpressionStatement expressionStatement, object data)
		{
			UnaryOperatorExpression unaryOperatorExpression = expressionStatement.Expression as UnaryOperatorExpression;
			if (unaryOperatorExpression != null)
			{
				switch (unaryOperatorExpression.Op)
				{
				case UnaryOperatorType.Increment:
				case UnaryOperatorType.PostIncrement:
					expressionStatement.Expression = new AssignmentExpression(unaryOperatorExpression.Expression, AssignmentOperatorType.Add, new PrimitiveExpression(1, "1"));
					break;
				case UnaryOperatorType.Decrement:
				case UnaryOperatorType.PostDecrement:
					expressionStatement.Expression = new AssignmentExpression(unaryOperatorExpression.Expression, AssignmentOperatorType.Subtract, new PrimitiveExpression(1, "1"));
					break;
				}
			}
			return base.VisitExpressionStatement(expressionStatement, data);
		}

		public override object VisitForStatement(ForStatement forStatement, object data)
		{
			base.VisitForStatement(forStatement, data);
			this.ConvertForStatement(forStatement);
			return null;
		}

		public override object VisitIfElseStatement(IfElseStatement ifElseStatement, object data)
		{
			BinaryOperatorExpression binaryOperatorExpression = ifElseStatement.Condition as BinaryOperatorExpression;
			if (binaryOperatorExpression == null && ifElseStatement.Condition is ParenthesizedExpression)
			{
				binaryOperatorExpression = ((ifElseStatement.Condition as ParenthesizedExpression).Expression as BinaryOperatorExpression);
			}
			if (ifElseStatement.ElseIfSections.Count == 0 && ifElseStatement.FalseStatement.Count == 0 && ifElseStatement.TrueStatement.Count == 1 && binaryOperatorExpression != null && binaryOperatorExpression.Op == BinaryOperatorType.InEquality && (CSharpConstructsConvertVisitor.IsNullLiteralExpression(binaryOperatorExpression.Left) || CSharpConstructsConvertVisitor.IsNullLiteralExpression(binaryOperatorExpression.Right)))
			{
				string text = this.GetPossibleEventName(binaryOperatorExpression.Left) ?? this.GetPossibleEventName(binaryOperatorExpression.Right);
				ExpressionStatement expressionStatement = ifElseStatement.TrueStatement[0] as ExpressionStatement;
				if (expressionStatement == null)
				{
					BlockStatement blockStatement = ifElseStatement.TrueStatement[0] as BlockStatement;
					if (blockStatement != null && blockStatement.Children.Count == 1)
					{
						expressionStatement = (blockStatement.Children[0] as ExpressionStatement);
					}
				}
				if (text != null && expressionStatement != null)
				{
					InvocationExpression invocationExpression = expressionStatement.Expression as InvocationExpression;
					if (invocationExpression != null && this.GetPossibleEventName(invocationExpression.TargetObject) == text)
					{
						base.ReplaceCurrentNode(new RaiseEventStatement(text, invocationExpression.Arguments));
					}
				}
			}
			return base.VisitIfElseStatement(ifElseStatement, data);
		}
	}
}
