﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Parser
{
	public abstract class AbstractParser : IParser, IDisposable
	{
		internal AbstractParser(ILexer lexer)
		{
			this.errors = lexer.Errors;
			this.lexer = lexer;
			this.errors.SynErr = new ErrorCodeProc(this.SynErr);
		}

		public void Dispose()
		{
			this.errors = null;
			if (this.lexer != null)
			{
				this.lexer.Dispose();
			}
			this.lexer = null;
		}

		protected void Expect(int n)
		{
			if (this.lexer.LookAhead.kind == n)
			{
				this.lexer.NextToken();
				return;
			}
			this.SynErr(n);
		}

		public abstract void Parse();

		public abstract BlockStatement ParseBlock();

		public abstract Expression ParseExpression();

		public abstract List<INode> ParseTypeMembers();

		public abstract TypeReference ParseTypeReference();

		protected void SemErr(string msg)
		{
			if (this.errDist >= 2)
			{
				this.errors.Error(this.lexer.Token.line, this.lexer.Token.col, msg);
			}
			this.errDist = 0;
		}

		protected void SynErr(int n)
		{
			if (this.errDist >= 2)
			{
				this.errors.SynErr(this.lexer.LookAhead.line, this.lexer.LookAhead.col, n);
			}
			this.errDist = 0;
		}

		protected abstract void SynErr(int line, int col, int errorNumber);

		public CompilationUnit CompilationUnit
		{
			get
			{
				return this.compilationUnit;
			}
		}

		public Errors Errors
		{
			get
			{
				return this.errors;
			}
		}

		public ILexer Lexer
		{
			get
			{
				return this.lexer;
			}
		}

		public bool ParseMethodBodies
		{
			get
			{
				return this.parseMethodContents;
			}
			set
			{
				this.parseMethodContents = value;
			}
		}

		[CLSCompliant(false)]
		protected CompilationUnit compilationUnit;

		protected int errDist = 2;

		protected const string ErrMsgFormat = "-- line {0} col {1}: {2}";

		private Errors errors;

		private ILexer lexer;

		protected const int MinErrDist = 2;

		private bool parseMethodContents = true;
	}
}
