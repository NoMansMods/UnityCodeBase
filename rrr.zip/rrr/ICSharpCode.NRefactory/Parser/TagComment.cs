﻿using System;

namespace ICSharpCode.NRefactory.Parser
{
	public class TagComment : Comment
	{
		public TagComment(string tag, string comment, bool commentStartsLine, Location startPosition, Location endPosition) : base(CommentType.SingleLine, comment, commentStartsLine, startPosition, endPosition)
		{
			this.tag = tag;
		}

		public string Tag
		{
			get
			{
				return this.tag;
			}
			set
			{
				this.tag = value;
			}
		}

		private string tag;
	}
}
