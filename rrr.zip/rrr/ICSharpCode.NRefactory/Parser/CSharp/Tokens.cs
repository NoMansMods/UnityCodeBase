﻿using System;
using System.Collections;

namespace ICSharpCode.NRefactory.Parser.CSharp
{
	public static class Tokens
	{
		public static string GetTokenString(int token)
		{
			if (token >= 0 && token < Tokens.tokenList.Length)
			{
				return Tokens.tokenList[token];
			}
			throw new NotSupportedException("Unknown token:" + token);
		}

		private static BitArray NewSet(params int[] values)
		{
			BitArray bitArray = new BitArray(145);
			for (int i = 0; i < values.Length; i++)
			{
				int index = values[i];
				bitArray[index] = true;
			}
			return bitArray;
		}

		public const int Abstract = 49;

		public const int Add = 130;

		public const int As = 50;

		public const int Ascending = 138;

		public static BitArray AssgnOps = Tokens.NewSet(new int[]
		{
			3,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			46
		});

		public const int Assign = 3;

		public static BitArray AssnStartOp = Tokens.NewSet(new int[]
		{
			4,
			5,
			24,
			27,
			6
		});

		public const int Base = 51;

		public const int BitwiseAnd = 28;

		public const int BitwiseAndAssign = 43;

		public const int BitwiseComplement = 27;

		public const int BitwiseOr = 29;

		public const int BitwiseOrAssign = 44;

		public const int Bool = 52;

		public const int Break = 53;

		public const int By = 135;

		public const int Byte = 54;

		public const int Case = 55;

		public static BitArray CastFollower = Tokens.NewSet(new int[]
		{
			57,
			52,
			91,
			108,
			102,
			54,
			104,
			120,
			82,
			116,
			87,
			117,
			75,
			66,
			62,
			1,
			126,
			127,
			128,
			129,
			130,
			131,
			132,
			133,
			134,
			135,
			136,
			137,
			138,
			139,
			140,
			141,
			142,
			143,
			144,
			123,
			2,
			20,
			27,
			24,
			51,
			64,
			72,
			89,
			90,
			105,
			111,
			113,
			115,
			58,
			118,
			137
		});

		public const int Catch = 56;

		public const int Char = 57;

		public const int Checked = 58;

		public const int Class = 59;

		public const int CloseCurlyBrace = 17;

		public const int CloseParenthesis = 21;

		public const int CloseSquareBracket = 19;

		public const int Colon = 9;

		public const int Comma = 14;

		public const int Const = 60;

		public const int Continue = 61;

		public const int Decimal = 62;

		public const int Decrement = 32;

		public const int Default = 63;

		public const int Delegate = 64;

		public const int Descending = 139;

		public const int Div = 7;

		public const int DivAssign = 41;

		public const int Do = 65;

		public const int Dot = 15;

		public const int Double = 66;

		public const int DoubleColon = 10;

		public const int DoubleQuestion = 13;

		public const int Else = 67;

		public const int Enum = 68;

		public const int EOF = 0;

		public const int Equal = 33;

		public new const int Equals = 144;

		public const int Event = 69;

		public const int Explicit = 70;

		public static BitArray ExpressionContent = Tokens.NewSet(new int[]
		{
			50,
			85,
			93,
			100,
			81
		});

		public static BitArray ExpressionStart = Tokens.NewSet(new int[]
		{
			51,
			64,
			72,
			89,
			90,
			105,
			111,
			113,
			115,
			58,
			118,
			137,
			63
		});

		public const int Extern = 71;

		public const int False = 72;

		public const int Finally = 73;

		public const int Fixed = 74;

		public const int Float = 75;

		public const int For = 76;

		public const int Foreach = 77;

		public const int From = 137;

		public static BitArray GenericFollower = Tokens.NewSet(new int[]
		{
			20,
			21,
			19,
			17,
			9,
			11,
			14,
			15,
			12,
			33,
			34
		});

		public const int Get = 128;

		public static BitArray GlobalLevel = Tokens.NewSet(new int[]
		{
			88,
			121,
			71,
			98,
			84,
			59,
			83,
			109,
			68,
			64,
			49,
			103,
			107,
			119,
			126
		});

		public const int Goto = 78;

		public const int GreaterEqual = 35;

		public const int GreaterThan = 22;

		public const int Group = 134;

		public const int Identifier = 1;

		public static BitArray IdentifierTokens = Tokens.NewSet(new int[]
		{
			1,
			126,
			127,
			128,
			129,
			130,
			131,
			132,
			133,
			134,
			135,
			136,
			137,
			138,
			139,
			140,
			141,
			142,
			143,
			144
		});

		public const int If = 79;

		public const int Implicit = 80;

		public const int In = 81;

		public const int Increment = 31;

		public static BitArray InEventDeclaration = Tokens.NewSet(new int[]
		{
			130,
			131
		});

		public static BitArray InPropertyDeclaration = Tokens.NewSet(new int[]
		{
			97,
			96,
			98,
			84,
			128,
			129
		});

		public const int Int = 82;

		public const int Interface = 83;

		public static BitArray InterfaceLevel = Tokens.NewSet(new int[]
		{
			69
		});

		public const int Internal = 84;

		public const int Into = 136;

		public const int Is = 85;

		public const int Join = 142;

		public static BitArray KCCClassModifiers = Tokens.NewSet(new int[]
		{
			49,
			103,
			107,
			119,
			126
		});

		public static BitArray KCCMemberVisibilityModifiers = Tokens.NewSet(new int[]
		{
			97,
			96,
			98,
			84
		});

		public static BitArray KCCTypeDeclarationStart = Tokens.NewSet(new int[]
		{
			98,
			84,
			59,
			83,
			109,
			68,
			64,
			49,
			103,
			107,
			119,
			126
		});

		public const int LambdaArrow = 48;

		public const int LessEqual = 36;

		public const int LessThan = 23;

		public const int Let = 141;

		public const int Literal = 2;

		public const int Lock = 86;

		public const int LogicalAnd = 25;

		public const int LogicalOr = 26;

		public const int Long = 87;

		public const int MaxToken = 145;

		public const int Minus = 5;

		public const int MinusAssign = 39;

		public const int Mod = 8;

		public const int ModAssign = 42;

		public const int Namespace = 88;

		public const int New = 89;

		public const int Not = 24;

		public const int NotEqual = 34;

		public const int Null = 90;

		public const int Object = 91;

		public const int On = 143;

		public const int OpenCurlyBrace = 16;

		public const int OpenParenthesis = 20;

		public const int OpenSquareBracket = 18;

		public const int Operator = 92;

		public const int Orderby = 140;

		public const int Out = 93;

		public static BitArray OverloadableBinaryOp = Tokens.NewSet(new int[]
		{
			4,
			5,
			6,
			7,
			8,
			28,
			29,
			30,
			37,
			33,
			34,
			22,
			23,
			35,
			36
		});

		public static BitArray OverloadableUnaryOp = Tokens.NewSet(new int[]
		{
			5,
			24,
			27,
			31,
			32,
			113,
			72
		});

		public const int Override = 94;

		public const int Params = 95;

		public const int Partial = 126;

		public const int Plus = 4;

		public const int PlusAssign = 38;

		public const int Pointer = 47;

		public const int Private = 96;

		public const int Protected = 97;

		public const int Public = 98;

		public static BitArray QueryExpressionClauseStart = Tokens.NewSet(new int[]
		{
			137,
			141,
			127,
			142,
			140,
			134,
			133
		});

		public const int Question = 12;

		public const int Readonly = 99;

		public const int Ref = 100;

		public const int Remove = 131;

		public const int Return = 101;

		public const int Sbyte = 102;

		public const int Sealed = 103;

		public const int Select = 133;

		public const int Semicolon = 11;

		public const int Set = 129;

		public const int ShiftLeft = 37;

		public const int ShiftLeftAssign = 46;

		public const int Short = 104;

		public static BitArray SimpleTypeName = Tokens.NewSet(new int[]
		{
			57,
			52,
			91,
			108,
			102,
			54,
			104,
			120,
			82,
			116,
			87,
			117,
			75,
			66,
			62,
			1,
			126,
			127,
			128,
			129,
			130,
			131,
			132,
			133,
			134,
			135,
			136,
			137,
			138,
			139,
			140,
			141,
			142,
			143,
			144,
			123
		});

		public const int Sizeof = 105;

		public const int Stackalloc = 106;

		public static BitArray StatementStart = Tokens.NewSet(new int[]
		{
			51,
			64,
			72,
			89,
			90,
			105,
			111,
			113,
			115,
			58,
			118,
			137,
			50,
			85,
			93,
			100,
			81,
			53,
			55,
			56,
			58,
			118,
			60,
			61,
			63,
			65,
			67,
			73,
			74,
			76,
			77,
			78,
			79,
			86,
			101,
			106,
			110,
			112,
			114,
			119,
			121,
			125,
			132
		});

		public const int Static = 107;

		public const int String = 108;

		public const int Struct = 109;

		public const int Switch = 110;

		public const int This = 111;

		public const int Throw = 112;

		public const int Times = 6;

		public const int TimesAssign = 40;

		private static string[] tokenList = new string[]
		{
			"<EOF>",
			"<Identifier>",
			"<Literal>",
			"=",
			"+",
			"-",
			"*",
			"/",
			"%",
			":",
			"::",
			";",
			"?",
			"??",
			",",
			".",
			"{",
			"}",
			"[",
			"]",
			"(",
			")",
			">",
			"<",
			"!",
			"&&",
			"||",
			"~",
			"&",
			"|",
			"^",
			"++",
			"--",
			"==",
			"!=",
			">=",
			"<=",
			"<<",
			"+=",
			"-=",
			"*=",
			"/=",
			"%=",
			"&=",
			"|=",
			"^=",
			"<<=",
			"->",
			"=>",
			"abstract",
			"as",
			"base",
			"bool",
			"break",
			"byte",
			"case",
			"catch",
			"char",
			"checked",
			"class",
			"const",
			"continue",
			"decimal",
			"default",
			"delegate",
			"do",
			"double",
			"else",
			"enum",
			"event",
			"explicit",
			"extern",
			"false",
			"finally",
			"fixed",
			"float",
			"for",
			"foreach",
			"goto",
			"if",
			"implicit",
			"in",
			"int",
			"interface",
			"internal",
			"is",
			"lock",
			"long",
			"namespace",
			"new",
			"null",
			"object",
			"operator",
			"out",
			"override",
			"params",
			"private",
			"protected",
			"public",
			"readonly",
			"ref",
			"return",
			"sbyte",
			"sealed",
			"short",
			"sizeof",
			"stackalloc",
			"static",
			"string",
			"struct",
			"switch",
			"this",
			"throw",
			"true",
			"try",
			"typeof",
			"uint",
			"ulong",
			"unchecked",
			"unsafe",
			"ushort",
			"using",
			"virtual",
			"void",
			"volatile",
			"while",
			"partial",
			"where",
			"get",
			"set",
			"add",
			"remove",
			"yield",
			"select",
			"group",
			"by",
			"into",
			"from",
			"ascending",
			"descending",
			"orderby",
			"let",
			"join",
			"on",
			"equals"
		};

		public const int True = 113;

		public const int Try = 114;

		public static BitArray TypeDeclarationKW = Tokens.NewSet(new int[]
		{
			59,
			83,
			109,
			68,
			64
		});

		public static BitArray TypeKW = Tokens.NewSet(new int[]
		{
			57,
			52,
			91,
			108,
			102,
			54,
			104,
			120,
			82,
			116,
			87,
			117,
			75,
			66,
			62
		});

		public static BitArray TypeLevel = Tokens.NewSet(new int[]
		{
			98,
			84,
			59,
			83,
			109,
			68,
			64,
			49,
			103,
			107,
			119,
			126,
			97,
			96,
			98,
			84,
			60,
			69,
			70,
			71,
			74,
			80,
			89,
			92,
			94,
			99,
			122,
			124
		});

		public const int Typeof = 115;

		public const int Uint = 116;

		public const int Ulong = 117;

		public static BitArray UnaryHead = Tokens.NewSet(new int[]
		{
			4,
			5,
			24,
			27,
			6,
			31,
			32,
			28
		});

		public static BitArray UnaryOp = Tokens.NewSet(new int[]
		{
			4,
			5,
			24,
			27,
			6,
			31,
			32,
			28
		});

		public const int Unchecked = 118;

		public const int Unsafe = 119;

		public const int Ushort = 120;

		public const int Using = 121;

		public static BitArray ValidInsideTypeName = Tokens.NewSet(new int[]
		{
			1,
			126,
			127,
			128,
			129,
			130,
			131,
			132,
			133,
			134,
			135,
			136,
			137,
			138,
			139,
			140,
			141,
			142,
			143,
			144,
			57,
			52,
			91,
			108,
			102,
			54,
			104,
			120,
			82,
			116,
			87,
			117,
			75,
			66,
			62,
			23,
			22,
			15,
			12,
			18,
			14,
			19,
			6,
			10
		});

		public const int Virtual = 122;

		public const int Void = 123;

		public const int Volatile = 124;

		public const int Where = 127;

		public const int While = 125;

		public const int Xor = 30;

		public const int XorAssign = 45;

		public const int Yield = 132;
	}
}
