﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Visitors;

namespace ICSharpCode.NRefactory.Parser.CSharp
{
	internal sealed class Parser : AbstractParser
	{
		public Parser(ILexer lexer) : base(lexer)
		{
			this.lexer = (Lexer)lexer;
			this.compilationUnit = new CompilationUnit();
		}

		private void AccessorDecls(out PropertyGetRegion getBlock, out PropertySetRegion setBlock)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			getBlock = null;
			setBlock = null;
			ModifierList modifierList = null;
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			if (this.la.kind == 84 || this.la.kind == 96 || this.la.kind == 97)
			{
				this.AccessorModifiers(out modifierList);
			}
			if (this.la.kind == 128)
			{
				this.GetAccessorDecl(out getBlock, list);
				if (modifierList != null)
				{
					getBlock.Modifier = modifierList.Modifier;
				}
				if (this.StartOf(27))
				{
					list = new List<AttributeSection>();
					modifierList = null;
					while (this.la.kind == 18)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list.Add(item);
					}
					if (this.la.kind == 84 || this.la.kind == 96 || this.la.kind == 97)
					{
						this.AccessorModifiers(out modifierList);
					}
					this.SetAccessorDecl(out setBlock, list);
					if (modifierList != null)
					{
						setBlock.Modifier = modifierList.Modifier;
						return;
					}
				}
			}
			else if (this.la.kind == 129)
			{
				this.SetAccessorDecl(out setBlock, list);
				if (modifierList != null)
				{
					setBlock.Modifier = modifierList.Modifier;
				}
				if (this.StartOf(28))
				{
					list = new List<AttributeSection>();
					modifierList = null;
					while (this.la.kind == 18)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list.Add(item);
					}
					if (this.la.kind == 84 || this.la.kind == 96 || this.la.kind == 97)
					{
						this.AccessorModifiers(out modifierList);
					}
					this.GetAccessorDecl(out getBlock, list);
					if (modifierList != null)
					{
						getBlock.Modifier = modifierList.Modifier;
						return;
					}
				}
			}
			else
			{
				if (this.StartOf(19))
				{
					this.Identifier();
					this.Error("get or set accessor declaration expected");
					return;
				}
				base.SynErr(186);
			}
		}

		private void AccessorModifiers(out ModifierList m)
		{
			m = new ModifierList();
			if (this.la.kind == 96)
			{
				this.lexer.NextToken();
				m.Add(Modifiers.Private, this.t.Location);
				return;
			}
			if (this.la.kind == 97)
			{
				this.lexer.NextToken();
				m.Add(Modifiers.Protected, this.t.Location);
				if (this.la.kind == 84)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Internal, this.t.Location);
					return;
				}
			}
			else if (this.la.kind == 84)
			{
				this.lexer.NextToken();
				m.Add(Modifiers.Internal, this.t.Location);
				if (this.la.kind == 97)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Protected, this.t.Location);
					return;
				}
			}
			else
			{
				base.SynErr(181);
			}
		}

		private void AddAccessorDecl(out Statement stmt)
		{
			stmt = null;
			base.Expect(130);
			this.Block(out stmt);
		}

		private void AdditiveExpr(ref Expression outExpr)
		{
			this.MultiplicativeExpr(ref outExpr);
			while (this.la.kind == 4 || this.la.kind == 5)
			{
				BinaryOperatorType op;
				if (this.la.kind == 4)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Add;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Subtract;
				}
				Expression right;
				this.UnaryExpr(out right);
				this.MultiplicativeExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void AndExpr(ref Expression outExpr)
		{
			this.EqualityExpr(ref outExpr);
			while (this.la.kind == 28)
			{
				this.lexer.NextToken();
				Expression right;
				this.UnaryExpr(out right);
				this.EqualityExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.BitwiseAnd, right);
			}
		}

		private void AnonymousMethodExpr(out Expression outExpr)
		{
			AnonymousMethodExpression anonymousMethodExpression = new AnonymousMethodExpression();
			anonymousMethodExpression.StartLocation = this.t.Location;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			outExpr = anonymousMethodExpression;
			if (this.la.kind == 20)
			{
				this.lexer.NextToken();
				if (this.StartOf(11))
				{
					this.FormalParameterList(list);
					anonymousMethodExpression.Parameters = list;
				}
				base.Expect(21);
				anonymousMethodExpression.HasParameterList = true;
			}
			BlockStatement body;
			this.BlockInsideExpression(out body);
			anonymousMethodExpression.Body = body;
			anonymousMethodExpression.EndLocation = this.t.Location;
		}

		private void Argument(out Expression argumentexpr)
		{
			FieldDirection fieldDirection = FieldDirection.None;
			if (this.la.kind == 93 || this.la.kind == 100)
			{
				if (this.la.kind == 100)
				{
					this.lexer.NextToken();
					fieldDirection = FieldDirection.Ref;
				}
				else
				{
					this.lexer.NextToken();
					fieldDirection = FieldDirection.Out;
				}
			}
			Expression expression;
			this.Expr(out expression);
			Expression arg_68_1;
			if (fieldDirection == FieldDirection.None)
			{
				arg_68_1 = expression;
			}
			else
			{
				Expression expression2;
				argumentexpr = (expression2 = new DirectionExpression(fieldDirection, expression));
				arg_68_1 = expression2;
			}
			argumentexpr = arg_68_1;
		}

		private void AssignmentOperator(out AssignmentOperatorType op)
		{
			op = AssignmentOperatorType.None;
			if (this.la.kind == 3)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Assign;
				return;
			}
			if (this.la.kind == 38)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Add;
				return;
			}
			if (this.la.kind == 39)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Subtract;
				return;
			}
			if (this.la.kind == 40)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Multiply;
				return;
			}
			if (this.la.kind == 41)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Divide;
				return;
			}
			if (this.la.kind == 42)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Modulus;
				return;
			}
			if (this.la.kind == 43)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.BitwiseAnd;
				return;
			}
			if (this.la.kind == 44)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.BitwiseOr;
				return;
			}
			if (this.la.kind == 45)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.ExclusiveOr;
				return;
			}
			if (this.la.kind == 46)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.ShiftLeft;
				return;
			}
			if (this.la.kind == 22 && this.Peek(1).kind == 35)
			{
				base.Expect(22);
				base.Expect(35);
				op = AssignmentOperatorType.ShiftRight;
				return;
			}
			base.SynErr(194);
		}

		private void Attribute(out ICSharpCode.NRefactory.Ast.Attribute attribute)
		{
			string text = null;
			Location location = this.la.Location;
			if (this.IdentAndDoubleColon())
			{
				this.Identifier();
				text = this.t.val;
				base.Expect(10);
			}
			string text2;
			this.Qualident(out text2);
			List<Expression> list = new List<Expression>();
			List<NamedArgumentExpression> list2 = new List<NamedArgumentExpression>();
			string name = (text != null && text != "global") ? (text + "." + text2) : text2;
			if (this.la.kind == 20)
			{
				this.AttributeArguments(list, list2);
			}
			attribute = new ICSharpCode.NRefactory.Ast.Attribute(name, list, list2);
			attribute.StartLocation = location;
			attribute.EndLocation = this.t.EndLocation;
		}

		private void AttributeArguments(List<Expression> positional, List<NamedArgumentExpression> named)
		{
			bool flag = false;
			string text = "";
			base.Expect(20);
			if (this.StartOf(6))
			{
				if (this.IsAssignment())
				{
					flag = true;
					this.Identifier();
					text = this.t.val;
					base.Expect(3);
				}
				Expression expression;
				this.Expr(out expression);
				if (expression != null)
				{
					if (text == "")
					{
						positional.Add(expression);
					}
					else
					{
						named.Add(new NamedArgumentExpression(text, expression));
						text = "";
					}
				}
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					if (this.IsAssignment())
					{
						flag = true;
						this.Identifier();
						text = this.t.val;
						base.Expect(3);
					}
					else if (this.StartOf(6))
					{
						if (flag)
						{
							this.Error("no positional argument after named argument");
						}
					}
					else
					{
						base.SynErr(149);
					}
					this.Expr(out expression);
					if (expression != null)
					{
						if (text == "")
						{
							positional.Add(expression);
						}
						else
						{
							named.Add(new NamedArgumentExpression(text, expression));
							text = "";
						}
					}
				}
			}
			base.Expect(21);
		}

		private void AttributeSection(out AttributeSection section)
		{
			string attributeTarget = "";
			List<ICSharpCode.NRefactory.Ast.Attribute> list = new List<ICSharpCode.NRefactory.Ast.Attribute>();
			base.Expect(18);
			Location location = this.t.Location;
			if (this.IsLocalAttrTarget())
			{
				if (this.la.kind == 69)
				{
					this.lexer.NextToken();
					attributeTarget = "event";
				}
				else if (this.la.kind == 101)
				{
					this.lexer.NextToken();
					attributeTarget = "return";
				}
				else
				{
					this.Identifier();
					attributeTarget = this.t.val;
				}
				base.Expect(9);
			}
			ICSharpCode.NRefactory.Ast.Attribute item;
			this.Attribute(out item);
			list.Add(item);
			while (this.NotFinalComma())
			{
				base.Expect(14);
				this.Attribute(out item);
				list.Add(item);
			}
			if (this.la.kind == 14)
			{
				this.lexer.NextToken();
			}
			base.Expect(19);
			section = new AttributeSection
			{
				AttributeTarget = attributeTarget,
				Attributes = list,
				StartLocation = location,
				EndLocation = this.t.EndLocation
			};
		}

		private void Block(out Statement stmt)
		{
			base.Expect(16);
			BlockStatement blockStatement = new BlockStatement();
			blockStatement.StartLocation = this.t.Location;
			this.compilationUnit.BlockStart(blockStatement);
			if (!base.ParseMethodBodies)
			{
				this.lexer.SkipCurrentBlock(0);
			}
			while (this.StartOf(25))
			{
				this.Statement();
			}
			while (this.la.kind != 0 && this.la.kind != 17)
			{
				base.SynErr(182);
				this.lexer.NextToken();
			}
			base.Expect(17);
			stmt = blockStatement;
			blockStatement.EndLocation = this.t.EndLocation;
			this.compilationUnit.BlockEnd();
		}

		private void BlockInsideExpression(out BlockStatement outStmt)
		{
			Statement statement = null;
			outStmt = null;
			if (this.compilationUnit != null)
			{
				this.Block(out statement);
				outStmt = (BlockStatement)statement;
				return;
			}
			base.Expect(16);
			this.lexer.SkipCurrentBlock(0);
			base.Expect(17);
		}

		private bool CatchAndLPar()
		{
			return this.la.kind == 56 && this.Peek(1).kind == 20;
		}

		private void CatchClause(out CatchClause catchClause)
		{
			base.Expect(56);
			Location location = this.t.Location;
			catchClause = null;
			if (this.la.kind == 16)
			{
				Statement statementBlock;
				this.Block(out statementBlock);
				catchClause = new CatchClause(statementBlock);
			}
			else if (this.la.kind == 20)
			{
				this.lexer.NextToken();
				TypeReference typeReference;
				this.ClassType(out typeReference, false);
				string variableName = null;
				if (this.StartOf(19))
				{
					this.Identifier();
					variableName = this.t.val;
				}
				base.Expect(21);
				Statement statementBlock;
				this.Block(out statementBlock);
				catchClause = new CatchClause(typeReference, variableName, statementBlock);
			}
			else
			{
				base.SynErr(205);
			}
			if (catchClause != null)
			{
				catchClause.StartLocation = location;
				catchClause.EndLocation = this.t.Location;
			}
		}

		private void ClassBase(out List<TypeReference> names)
		{
			names = new List<TypeReference>();
			base.Expect(9);
			TypeReference typeReference;
			this.ClassType(out typeReference, false);
			if (typeReference != null)
			{
				names.Add(typeReference);
			}
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference, false);
				if (typeReference != null)
				{
					names.Add(typeReference);
				}
			}
		}

		private void ClassBody()
		{
			while (this.StartOf(12))
			{
				List<AttributeSection> list = new List<AttributeSection>();
				ModifierList m = new ModifierList();
				while (!this.StartOf(13))
				{
					base.SynErr(154);
					this.lexer.NextToken();
				}
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				this.MemberModifiers(m);
				this.ClassMemberDecl(m, list);
			}
		}

		private void ClassMemberDecl(ModifierList m, List<AttributeSection> attributes)
		{
			Statement statement = null;
			if (this.StartOf(21))
			{
				this.StructMemberDecl(m, attributes);
				return;
			}
			if (this.la.kind == 27)
			{
				m.Check(Modifiers.Destructors);
				Location location = this.la.Location;
				this.lexer.NextToken();
				this.Identifier();
				DestructorDeclaration destructorDeclaration = new DestructorDeclaration(this.t.val, m.Modifier, attributes);
				destructorDeclaration.Modifier = m.Modifier;
				destructorDeclaration.StartLocation = m.GetDeclarationLocation(location);
				base.Expect(20);
				base.Expect(21);
				destructorDeclaration.EndLocation = this.t.EndLocation;
				if (this.la.kind == 16)
				{
					this.Block(out statement);
				}
				else if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				else
				{
					base.SynErr(160);
				}
				destructorDeclaration.Body = (BlockStatement)statement;
				this.compilationUnit.AddChild(destructorDeclaration);
				return;
			}
			base.SynErr(161);
		}

		private void ClassType(out TypeReference typeRef, bool canBeUnbound)
		{
			typeRef = null;
			if (this.StartOf(19))
			{
				TypeReference typeReference;
				this.TypeName(out typeReference, canBeUnbound);
				typeRef = typeReference;
				return;
			}
			if (this.la.kind == 91)
			{
				this.lexer.NextToken();
				typeRef = new TypeReference("System.Object", true);
				typeRef.StartLocation = this.t.Location;
				return;
			}
			if (this.la.kind == 108)
			{
				this.lexer.NextToken();
				typeRef = new TypeReference("System.String", true);
				typeRef.StartLocation = this.t.Location;
				return;
			}
			base.SynErr(159);
		}

		private void CollectionInitializer(out Expression outExpr)
		{
			Expression item = null;
			CollectionInitializerExpression collectionInitializerExpression = new CollectionInitializerExpression();
			base.Expect(16);
			collectionInitializerExpression.StartLocation = this.t.Location;
			if (this.StartOf(31))
			{
				this.VariableInitializer(out item);
				Parser.SafeAdd<Expression>(collectionInitializerExpression, collectionInitializerExpression.CreateExpressions, item);
				while (this.NotFinalComma())
				{
					base.Expect(14);
					this.VariableInitializer(out item);
					Parser.SafeAdd<Expression>(collectionInitializerExpression, collectionInitializerExpression.CreateExpressions, item);
				}
				if (this.la.kind == 14)
				{
					this.lexer.NextToken();
				}
			}
			base.Expect(17);
			collectionInitializerExpression.EndLocation = this.t.Location;
			outExpr = collectionInitializerExpression;
		}

		private void CollectionOrObjectInitializer(out Expression outExpr)
		{
			Expression item = null;
			CollectionInitializerExpression collectionInitializerExpression = new CollectionInitializerExpression();
			base.Expect(16);
			collectionInitializerExpression.StartLocation = this.t.Location;
			if (this.StartOf(31))
			{
				this.ObjectPropertyInitializerOrVariableInitializer(out item);
				Parser.SafeAdd<Expression>(collectionInitializerExpression, collectionInitializerExpression.CreateExpressions, item);
				while (this.NotFinalComma())
				{
					base.Expect(14);
					this.ObjectPropertyInitializerOrVariableInitializer(out item);
					Parser.SafeAdd<Expression>(collectionInitializerExpression, collectionInitializerExpression.CreateExpressions, item);
				}
				if (this.la.kind == 14)
				{
					this.lexer.NextToken();
				}
			}
			base.Expect(17);
			collectionInitializerExpression.EndLocation = this.t.Location;
			outExpr = collectionInitializerExpression;
		}

		private void ConditionalAndExpr(ref Expression outExpr)
		{
			this.InclusiveOrExpr(ref outExpr);
			while (this.la.kind == 25)
			{
				this.lexer.NextToken();
				Expression right;
				this.UnaryExpr(out right);
				this.InclusiveOrExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.LogicalAnd, right);
			}
		}

		private void ConditionalOrExpr(ref Expression outExpr)
		{
			this.ConditionalAndExpr(ref outExpr);
			while (this.la.kind == 26)
			{
				this.lexer.NextToken();
				Expression right;
				this.UnaryExpr(out right);
				this.ConditionalAndExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.LogicalOr, right);
			}
		}

		private void ConstructorInitializer(out ConstructorInitializer ci)
		{
			ci = new ConstructorInitializer();
			base.Expect(9);
			if (this.la.kind == 51)
			{
				this.lexer.NextToken();
				ci.ConstructorInitializerType = ConstructorInitializerType.Base;
			}
			else if (this.la.kind == 111)
			{
				this.lexer.NextToken();
				ci.ConstructorInitializerType = ConstructorInitializerType.This;
			}
			else
			{
				base.SynErr(184);
			}
			base.Expect(20);
			if (this.StartOf(26))
			{
				Expression item;
				this.Argument(out item);
				Parser.SafeAdd<Expression>(ci, ci.Arguments, item);
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.Argument(out item);
					Parser.SafeAdd<Expression>(ci, ci.Arguments, item);
				}
			}
			base.Expect(21);
		}

		private void CS()
		{
			this.lexer.NextToken();
			while (this.la.kind == 71)
			{
				this.ExternAliasDirective();
			}
			while (this.la.kind == 121)
			{
				this.UsingDirective();
			}
			while (this.IsGlobalAttrTarget())
			{
				this.GlobalAttributeSection();
			}
			while (this.StartOf(1))
			{
				this.NamespaceMemberDecl();
			}
			base.Expect(0);
		}

		private bool DotAndIdent()
		{
			return this.la.kind == 15 && Parser.IsIdentifierToken(this.Peek(1));
		}

		private void EmbeddedStatement(out Statement statement)
		{
			TypeReference typeReference = null;
			Expression expression = null;
			Statement statement2 = null;
			statement = null;
			Location location = this.la.Location;
			if (this.la.kind == 16)
			{
				this.Block(out statement);
			}
			else if (this.la.kind == 11)
			{
				this.lexer.NextToken();
				statement = new EmptyStatement();
			}
			else if (this.UnCheckedAndLBrace())
			{
				bool flag = true;
				if (this.la.kind == 58)
				{
					this.lexer.NextToken();
				}
				else if (this.la.kind == 118)
				{
					this.lexer.NextToken();
					flag = false;
				}
				else
				{
					base.SynErr(197);
				}
				Statement block;
				this.Block(out block);
				statement = (flag ? new CheckedStatement(block) : new UncheckedStatement(block));
			}
			else if (this.la.kind == 79)
			{
				this.IfStatement(out statement);
			}
			else if (this.la.kind == 110)
			{
				this.lexer.NextToken();
				List<SwitchSection> switchSections = new List<SwitchSection>();
				base.Expect(20);
				this.Expr(out expression);
				base.Expect(21);
				base.Expect(16);
				this.SwitchSections(switchSections);
				base.Expect(17);
				statement = new SwitchStatement(expression, switchSections);
			}
			else if (this.la.kind == 125)
			{
				this.lexer.NextToken();
				base.Expect(20);
				this.Expr(out expression);
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new DoLoopStatement(expression, statement2, ConditionType.While, ConditionPosition.Start);
			}
			else if (this.la.kind == 65)
			{
				this.lexer.NextToken();
				this.EmbeddedStatement(out statement2);
				base.Expect(125);
				base.Expect(20);
				this.Expr(out expression);
				base.Expect(21);
				base.Expect(11);
				statement = new DoLoopStatement(expression, statement2, ConditionType.While, ConditionPosition.End);
			}
			else if (this.la.kind == 76)
			{
				this.lexer.NextToken();
				List<Statement> initializers = null;
				List<Statement> iterator = null;
				base.Expect(20);
				if (this.StartOf(6))
				{
					this.ForInitializer(out initializers);
				}
				base.Expect(11);
				if (this.StartOf(6))
				{
					this.Expr(out expression);
				}
				base.Expect(11);
				if (this.StartOf(6))
				{
					this.ForIterator(out iterator);
				}
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new ForStatement(initializers, expression, iterator, statement2);
			}
			else if (this.la.kind == 77)
			{
				this.lexer.NextToken();
				base.Expect(20);
				this.Type(out typeReference);
				this.Identifier();
				string val = this.t.val;
				base.Expect(81);
				this.Expr(out expression);
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new ForeachStatement(typeReference, val, expression, statement2);
			}
			else if (this.la.kind == 53)
			{
				this.lexer.NextToken();
				base.Expect(11);
				statement = new BreakStatement();
			}
			else if (this.la.kind == 61)
			{
				this.lexer.NextToken();
				base.Expect(11);
				statement = new ContinueStatement();
			}
			else if (this.la.kind == 78)
			{
				this.GotoStatement(out statement);
			}
			else if (this.IsYieldStatement())
			{
				base.Expect(132);
				if (this.la.kind == 101)
				{
					this.lexer.NextToken();
					this.Expr(out expression);
					statement = new YieldStatement(new ReturnStatement(expression));
				}
				else if (this.la.kind == 53)
				{
					this.lexer.NextToken();
					statement = new YieldStatement(new BreakStatement());
				}
				else
				{
					base.SynErr(198);
				}
				base.Expect(11);
			}
			else if (this.la.kind == 101)
			{
				this.lexer.NextToken();
				if (this.StartOf(6))
				{
					this.Expr(out expression);
				}
				base.Expect(11);
				statement = new ReturnStatement(expression);
			}
			else if (this.la.kind == 112)
			{
				this.lexer.NextToken();
				if (this.StartOf(6))
				{
					this.Expr(out expression);
				}
				base.Expect(11);
				statement = new ThrowStatement(expression);
			}
			else if (this.StartOf(6))
			{
				this.StatementExpr(out statement);
				while (this.la.kind != 0 && this.la.kind != 11)
				{
					base.SynErr(199);
					this.lexer.NextToken();
				}
				base.Expect(11);
			}
			else if (this.la.kind == 114)
			{
				this.TryStatement(out statement);
			}
			else if (this.la.kind == 86)
			{
				this.lexer.NextToken();
				base.Expect(20);
				this.Expr(out expression);
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new LockStatement(expression, statement2);
			}
			else if (this.la.kind == 121)
			{
				Statement resourceAcquisition = null;
				this.lexer.NextToken();
				base.Expect(20);
				this.ResourceAcquisition(out resourceAcquisition);
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new UsingStatement(resourceAcquisition, statement2);
			}
			else if (this.la.kind == 119)
			{
				this.lexer.NextToken();
				this.Block(out statement2);
				statement = new UnsafeStatement(statement2);
			}
			else if (this.la.kind == 74)
			{
				Statement pointerDeclaration = null;
				this.lexer.NextToken();
				base.Expect(20);
				this.ResourceAcquisition(out pointerDeclaration);
				base.Expect(21);
				this.EmbeddedStatement(out statement2);
				statement = new FixedStatement(pointerDeclaration, statement2);
			}
			else
			{
				base.SynErr(200);
			}
			if (statement != null)
			{
				statement.StartLocation = location;
				statement.EndLocation = this.t.EndLocation;
			}
		}

		private void EnumBody()
		{
			base.Expect(16);
			if (this.StartOf(17))
			{
				FieldDeclaration childNode;
				this.EnumMemberDecl(out childNode);
				this.compilationUnit.AddChild(childNode);
				while (this.NotFinalComma())
				{
					base.Expect(14);
					this.EnumMemberDecl(out childNode);
					this.compilationUnit.AddChild(childNode);
				}
				if (this.la.kind == 14)
				{
					this.lexer.NextToken();
				}
			}
			base.Expect(17);
		}

		private void EnumMemberDecl(out FieldDeclaration f)
		{
			Expression initializer = null;
			List<AttributeSection> list = new List<AttributeSection>();
			AttributeSection item = null;
			while (this.la.kind == 18)
			{
				this.AttributeSection(out item);
				list.Add(item);
			}
			this.Identifier();
			f = new FieldDeclaration(list);
			VariableDeclaration variableDeclaration = new VariableDeclaration(this.t.val);
			f.Fields.Add(variableDeclaration);
			f.StartLocation = this.t.Location;
			f.EndLocation = this.t.EndLocation;
			if (this.la.kind == 3)
			{
				this.lexer.NextToken();
				this.Expr(out initializer);
				variableDeclaration.Initializer = initializer;
			}
		}

		private void EqualityExpr(ref Expression outExpr)
		{
			this.RelationalExpr(ref outExpr);
			while (this.la.kind == 33 || this.la.kind == 34)
			{
				BinaryOperatorType op;
				if (this.la.kind == 34)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.InEquality;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Equality;
				}
				Expression right;
				this.UnaryExpr(out right);
				this.RelationalExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		public void Error(string s)
		{
			if (this.errDist >= 2)
			{
				base.Errors.Error(this.la.line, this.la.col, s);
			}
			this.errDist = 0;
		}

		private void EventAccessorDecls(out EventAddRegion addBlock, out EventRemoveRegion removeBlock)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			addBlock = null;
			removeBlock = null;
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			if (this.la.kind == 130)
			{
				addBlock = new EventAddRegion(list);
				Statement statement;
				this.AddAccessorDecl(out statement);
				list = new List<AttributeSection>();
				addBlock.Block = (BlockStatement)statement;
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				this.RemoveAccessorDecl(out statement);
				removeBlock = new EventRemoveRegion(list);
				removeBlock.Block = (BlockStatement)statement;
				return;
			}
			if (this.la.kind == 131)
			{
				Statement statement;
				this.RemoveAccessorDecl(out statement);
				removeBlock = new EventRemoveRegion(list);
				removeBlock.Block = (BlockStatement)statement;
				list = new List<AttributeSection>();
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				this.AddAccessorDecl(out statement);
				addBlock = new EventAddRegion(list);
				addBlock.Block = (BlockStatement)statement;
				return;
			}
			base.SynErr(183);
		}

		private void ExclusiveOrExpr(ref Expression outExpr)
		{
			this.AndExpr(ref outExpr);
			while (this.la.kind == 30)
			{
				this.lexer.NextToken();
				Expression right;
				this.UnaryExpr(out right);
				this.AndExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.ExclusiveOr, right);
			}
		}

		private void Expr(out Expression expr)
		{
			expr = null;
			Expression expression = null;
			Expression falseExpression = null;
			Location location = this.la.Location;
			this.UnaryExpr(out expr);
			if (this.StartOf(7))
			{
				AssignmentOperatorType op;
				this.AssignmentOperator(out op);
				this.Expr(out expression);
				expr = new AssignmentExpression(expr, op, expression);
			}
			else if (this.la.kind == 22 && this.Peek(1).kind == 35)
			{
				AssignmentOperatorType op;
				this.AssignmentOperator(out op);
				this.Expr(out expression);
				expr = new AssignmentExpression(expr, op, expression);
			}
			else if (this.StartOf(8))
			{
				this.ConditionalOrExpr(ref expr);
				if (this.la.kind == 13)
				{
					this.lexer.NextToken();
					this.Expr(out expression);
					expr = new BinaryOperatorExpression(expr, BinaryOperatorType.NullCoalescing, expression);
				}
				if (this.la.kind == 12)
				{
					this.lexer.NextToken();
					this.Expr(out expression);
					base.Expect(9);
					this.Expr(out falseExpression);
					expr = new ConditionalExpression(expr, expression, falseExpression);
				}
			}
			else
			{
				base.SynErr(150);
			}
			if (expr != null)
			{
				if (expr.StartLocation.IsEmpty)
				{
					expr.StartLocation = location;
				}
				if (expr.EndLocation.IsEmpty)
				{
					expr.EndLocation = this.t.EndLocation;
				}
			}
		}

		private void ExternAliasDirective()
		{
			ExternAliasDirective externAliasDirective = new ExternAliasDirective
			{
				StartLocation = this.la.Location
			};
			base.Expect(71);
			this.Identifier();
			if (this.t.val != "alias")
			{
				this.Error("Expected 'extern alias'.");
			}
			this.Identifier();
			externAliasDirective.Name = this.t.val;
			base.Expect(11);
			externAliasDirective.EndLocation = this.t.EndLocation;
			this.compilationUnit.AddChild(externAliasDirective);
		}

		private void FixedParameter(out ParameterDeclarationExpression p)
		{
			ParameterModifiers paramModifier = ParameterModifiers.In;
			Location location = this.la.Location;
			if (this.la.kind == 93 || this.la.kind == 100)
			{
				if (this.la.kind == 100)
				{
					this.lexer.NextToken();
					paramModifier = ParameterModifiers.Ref;
				}
				else
				{
					this.lexer.NextToken();
					paramModifier = ParameterModifiers.Out;
				}
			}
			TypeReference typeReference;
			this.Type(out typeReference);
			this.Identifier();
			p = new ParameterDeclarationExpression(typeReference, this.t.val, paramModifier);
			p.StartLocation = location;
			p.EndLocation = this.t.Location;
		}

		private void ForInitializer(out List<Statement> initializer)
		{
			initializer = new List<Statement>();
			if (this.IsLocalVarDecl())
			{
				Statement item;
				this.LocalVariableDecl(out item);
				initializer.Add(item);
				return;
			}
			if (this.StartOf(6))
			{
				Statement item;
				this.StatementExpr(out item);
				initializer.Add(item);
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.StatementExpr(out item);
					initializer.Add(item);
				}
				return;
			}
			base.SynErr(201);
		}

		private void ForIterator(out List<Statement> iterator)
		{
			iterator = new List<Statement>();
			Statement item;
			this.StatementExpr(out item);
			iterator.Add(item);
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.StatementExpr(out item);
				iterator.Add(item);
			}
		}

		private void FormalParameterList(List<ParameterDeclarationExpression> parameter)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			if (this.StartOf(18))
			{
				ParameterDeclarationExpression parameterDeclarationExpression;
				this.FixedParameter(out parameterDeclarationExpression);
				bool flag = false;
				parameterDeclarationExpression.Attributes = list;
				parameter.Add(parameterDeclarationExpression);
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					list = new List<AttributeSection>();
					if (flag)
					{
						this.Error("params array must be at end of parameter list");
					}
					while (this.la.kind == 18)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list.Add(item);
					}
					if (this.StartOf(18))
					{
						this.FixedParameter(out parameterDeclarationExpression);
						parameterDeclarationExpression.Attributes = list;
						parameter.Add(parameterDeclarationExpression);
					}
					else if (this.la.kind == 95)
					{
						this.ParameterArray(out parameterDeclarationExpression);
						flag = true;
						parameterDeclarationExpression.Attributes = list;
						parameter.Add(parameterDeclarationExpression);
					}
					else
					{
						base.SynErr(157);
					}
				}
				return;
			}
			if (this.la.kind == 95)
			{
				ParameterDeclarationExpression parameterDeclarationExpression;
				this.ParameterArray(out parameterDeclarationExpression);
				parameterDeclarationExpression.Attributes = list;
				parameter.Add(parameterDeclarationExpression);
				return;
			}
			base.SynErr(158);
		}

		private void GetAccessorDecl(out PropertyGetRegion getBlock, List<AttributeSection> attributes)
		{
			Statement statement = null;
			base.Expect(128);
			Location location = this.t.Location;
			if (this.la.kind == 16)
			{
				this.Block(out statement);
			}
			else if (this.la.kind == 11)
			{
				this.lexer.NextToken();
			}
			else
			{
				base.SynErr(189);
			}
			getBlock = new PropertyGetRegion((BlockStatement)statement, attributes);
			getBlock.StartLocation = location;
			getBlock.EndLocation = this.t.EndLocation;
		}

		internal static string GetReflectionNameForOperator(OverloadableOperatorType op)
		{
			switch (op)
			{
			case OverloadableOperatorType.Add:
				return "op_Addition";
			case OverloadableOperatorType.Subtract:
				return "op_Subtraction";
			case OverloadableOperatorType.Multiply:
				return "op_Multiply";
			case OverloadableOperatorType.Divide:
				return "op_Division";
			case OverloadableOperatorType.Modulus:
				return "op_Modulus";
			case OverloadableOperatorType.Concat:
			case OverloadableOperatorType.CType:
				return "op_unknown";
			case OverloadableOperatorType.UnaryPlus:
				return "op_UnaryPlus";
			case OverloadableOperatorType.UnaryMinus:
				return "op_UnaryNegation";
			case OverloadableOperatorType.Not:
				return "op_LogicalNot";
			case OverloadableOperatorType.BitNot:
				return "op_OnesComplement";
			case OverloadableOperatorType.BitwiseAnd:
				return "op_BitwiseAnd";
			case OverloadableOperatorType.BitwiseOr:
				return "op_BitwiseOr";
			case OverloadableOperatorType.ExclusiveOr:
				return "op_ExclusiveOr";
			case OverloadableOperatorType.ShiftLeft:
				return "op_LeftShift";
			case OverloadableOperatorType.ShiftRight:
				return "op_RightShift";
			case OverloadableOperatorType.GreaterThan:
				return "op_GreaterThan";
			case OverloadableOperatorType.GreaterThanOrEqual:
				return "op_GreaterThanOrEqual";
			case OverloadableOperatorType.Equality:
				return "op_Equality";
			case OverloadableOperatorType.InEquality:
				return "op_Inequality";
			case OverloadableOperatorType.LessThan:
				return "op_LessThan";
			case OverloadableOperatorType.LessThanOrEqual:
				return "op_LessThanOrEqual";
			case OverloadableOperatorType.Increment:
				return "op_Increment";
			case OverloadableOperatorType.Decrement:
				return "op_Decrement";
			case OverloadableOperatorType.IsTrue:
				return "op_True";
			case OverloadableOperatorType.IsFalse:
				return "op_False";
			case OverloadableOperatorType.Like:
				return "op_unknown";
			case OverloadableOperatorType.Power:
				return "op_unknown";
			case OverloadableOperatorType.DivideInteger:
				return "op_unknown";
			default:
				return "op_unknown";
			}
		}

		private TypeReference GetTypeReferenceFromExpression(Expression expr)
		{
			if (expr is TypeReferenceExpression)
			{
				return (expr as TypeReferenceExpression).TypeReference;
			}
			IdentifierExpression identifierExpression = expr as IdentifierExpression;
			if (identifierExpression != null)
			{
				return new TypeReference(identifierExpression.Identifier, identifierExpression.TypeArguments);
			}
			MemberReferenceExpression memberReferenceExpression = expr as MemberReferenceExpression;
			if (memberReferenceExpression != null)
			{
				TypeReference typeReferenceFromExpression = this.GetTypeReferenceFromExpression(memberReferenceExpression.TargetObject);
				if (typeReferenceFromExpression != null)
				{
					if (typeReferenceFromExpression.GenericTypes.Count == 0 && !typeReferenceFromExpression.IsArrayType)
					{
						TypeReference typeReference = typeReferenceFromExpression.Clone();
						typeReference.Type = typeReference.Type + "." + memberReferenceExpression.MemberName;
						typeReference.GenericTypes.AddRange(memberReferenceExpression.TypeArguments);
						return typeReference;
					}
					return new InnerClassTypeReference(typeReferenceFromExpression, memberReferenceExpression.MemberName, memberReferenceExpression.TypeArguments);
				}
			}
			return null;
		}

		private void GlobalAttributeSection()
		{
			base.Expect(18);
			Location location = this.t.Location;
			this.Identifier();
			if (this.t.val != "assembly" && this.t.val != "module")
			{
				this.Error("global attribute target specifier (assembly or module) expected");
			}
			string val = this.t.val;
			List<ICSharpCode.NRefactory.Ast.Attribute> list = new List<ICSharpCode.NRefactory.Ast.Attribute>();
			base.Expect(9);
			ICSharpCode.NRefactory.Ast.Attribute item;
			this.Attribute(out item);
			list.Add(item);
			while (this.NotFinalComma())
			{
				base.Expect(14);
				this.Attribute(out item);
				list.Add(item);
			}
			if (this.la.kind == 14)
			{
				this.lexer.NextToken();
			}
			base.Expect(19);
			AttributeSection childNode = new AttributeSection
			{
				AttributeTarget = val,
				Attributes = list,
				StartLocation = location,
				EndLocation = this.t.EndLocation
			};
			this.compilationUnit.AddChild(childNode);
		}

		private void GotoStatement(out Statement stmt)
		{
			stmt = null;
			base.Expect(78);
			if (this.StartOf(19))
			{
				this.Identifier();
				stmt = new GotoStatement(this.t.val);
				base.Expect(11);
				return;
			}
			if (this.la.kind == 55)
			{
				this.lexer.NextToken();
				Expression expression;
				this.Expr(out expression);
				base.Expect(11);
				stmt = new GotoCaseStatement(expression);
				return;
			}
			if (this.la.kind == 63)
			{
				this.lexer.NextToken();
				base.Expect(11);
				stmt = new GotoCaseStatement(null);
				return;
			}
			base.SynErr(202);
		}

		private bool IdentAndAsgn()
		{
			return Parser.IsIdentifierToken(this.la) && this.Peek(1).kind == 3;
		}

		private bool IdentAndColon()
		{
			return Parser.IsIdentifierToken(this.la) && this.Peek(1).kind == 9;
		}

		private bool IdentAndDoubleColon()
		{
			return Parser.IsIdentifierToken(this.la) && this.Peek(1).kind == 10;
		}

		private bool IdentAndLPar()
		{
			return Parser.IsIdentifierToken(this.la) && this.Peek(1).kind == 20;
		}

		private void Identifier()
		{
			int kind = this.la.kind;
			if (kind == 1)
			{
				this.lexer.NextToken();
				return;
			}
			switch (kind)
			{
			case 126:
				this.lexer.NextToken();
				return;
			case 127:
				this.lexer.NextToken();
				return;
			case 128:
				this.lexer.NextToken();
				return;
			case 129:
				this.lexer.NextToken();
				return;
			case 130:
				this.lexer.NextToken();
				return;
			case 131:
				this.lexer.NextToken();
				return;
			case 132:
				this.lexer.NextToken();
				return;
			case 133:
				this.lexer.NextToken();
				return;
			case 134:
				this.lexer.NextToken();
				return;
			case 135:
				this.lexer.NextToken();
				return;
			case 136:
				this.lexer.NextToken();
				return;
			case 137:
				this.lexer.NextToken();
				return;
			case 138:
				this.lexer.NextToken();
				return;
			case 139:
				this.lexer.NextToken();
				return;
			case 140:
				this.lexer.NextToken();
				return;
			case 141:
				this.lexer.NextToken();
				return;
			case 142:
				this.lexer.NextToken();
				return;
			case 143:
				this.lexer.NextToken();
				return;
			case 144:
				this.lexer.NextToken();
				return;
			default:
				base.SynErr(147);
				return;
			}
		}

		private void IfStatement(out Statement statement)
		{
			Expression condition = null;
			Statement trueStatement = null;
			statement = null;
			base.Expect(79);
			base.Expect(20);
			this.Expr(out condition);
			base.Expect(21);
			this.EmbeddedStatement(out trueStatement);
			Statement statement2 = null;
			if (this.la.kind == 67)
			{
				this.lexer.NextToken();
				this.EmbeddedStatement(out statement2);
			}
			statement = ((statement2 != null) ? new IfElseStatement(condition, trueStatement, statement2) : new IfElseStatement(condition, trueStatement));
			if (statement2 is IfElseStatement && (statement2 as IfElseStatement).TrueStatement.Count == 1)
			{
				(statement as IfElseStatement).ElseIfSections.Add(new ElseIfSection((statement2 as IfElseStatement).Condition, (statement2 as IfElseStatement).TrueStatement[0]));
				(statement as IfElseStatement).ElseIfSections.AddRange((statement2 as IfElseStatement).ElseIfSections);
				(statement as IfElseStatement).FalseStatement = (statement2 as IfElseStatement).FalseStatement;
			}
		}

		private void InclusiveOrExpr(ref Expression outExpr)
		{
			this.ExclusiveOrExpr(ref outExpr);
			while (this.la.kind == 29)
			{
				this.lexer.NextToken();
				Expression right;
				this.UnaryExpr(out right);
				this.ExclusiveOrExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.BitwiseOr, right);
			}
		}

		private void IntegralType(out string name)
		{
			name = "";
			int kind = this.la.kind;
			if (kind <= 82)
			{
				if (kind == 54)
				{
					this.lexer.NextToken();
					name = "System.Byte";
					return;
				}
				if (kind == 57)
				{
					this.lexer.NextToken();
					name = "System.Char";
					return;
				}
				if (kind == 82)
				{
					this.lexer.NextToken();
					name = "System.Int32";
					return;
				}
			}
			else
			{
				if (kind == 87)
				{
					this.lexer.NextToken();
					name = "System.Int64";
					return;
				}
				switch (kind)
				{
				case 102:
					this.lexer.NextToken();
					name = "System.SByte";
					return;
				case 103:
					break;
				case 104:
					this.lexer.NextToken();
					name = "System.Int16";
					return;
				default:
					switch (kind)
					{
					case 116:
						this.lexer.NextToken();
						name = "System.UInt32";
						return;
					case 117:
						this.lexer.NextToken();
						name = "System.UInt64";
						return;
					case 120:
						this.lexer.NextToken();
						name = "System.UInt16";
						return;
					}
					break;
				}
			}
			base.SynErr(156);
		}

		private void InterfaceAccessors(out PropertyGetRegion getBlock, out PropertySetRegion setBlock)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			getBlock = null;
			setBlock = null;
			PropertyGetSetRegion propertyGetSetRegion = null;
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			Location location = this.la.Location;
			if (this.la.kind == 128)
			{
				this.lexer.NextToken();
				getBlock = new PropertyGetRegion(null, list);
			}
			else if (this.la.kind == 129)
			{
				this.lexer.NextToken();
				setBlock = new PropertySetRegion(null, list);
			}
			else
			{
				base.SynErr(187);
			}
			base.Expect(11);
			if (getBlock != null)
			{
				getBlock.StartLocation = location;
				getBlock.EndLocation = this.t.EndLocation;
			}
			if (setBlock != null)
			{
				setBlock.StartLocation = location;
				setBlock.EndLocation = this.t.EndLocation;
			}
			list = new List<AttributeSection>();
			if (this.la.kind != 18 && this.la.kind != 128)
			{
				if (this.la.kind != 129)
				{
					return;
				}
			}
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			location = this.la.Location;
			if (this.la.kind == 128)
			{
				this.lexer.NextToken();
				if (getBlock != null)
				{
					this.Error("get already declared");
				}
				else
				{
					getBlock = new PropertyGetRegion(null, list);
					propertyGetSetRegion = getBlock;
				}
			}
			else if (this.la.kind == 129)
			{
				this.lexer.NextToken();
				if (setBlock != null)
				{
					this.Error("set already declared");
				}
				else
				{
					setBlock = new PropertySetRegion(null, list);
					propertyGetSetRegion = setBlock;
				}
			}
			else
			{
				base.SynErr(188);
			}
			base.Expect(11);
			if (propertyGetSetRegion != null)
			{
				propertyGetSetRegion.StartLocation = location;
				propertyGetSetRegion.EndLocation = this.t.EndLocation;
			}
		}

		private void InterfaceBase(out List<TypeReference> names)
		{
			names = new List<TypeReference>();
			base.Expect(9);
			TypeReference typeReference;
			this.TypeName(out typeReference, false);
			if (typeReference != null)
			{
				names.Add(typeReference);
			}
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference, false);
				if (typeReference != null)
				{
					names.Add(typeReference);
				}
			}
		}

		private void InterfaceBody()
		{
			base.Expect(16);
			while (this.StartOf(15))
			{
				while (!this.StartOf(16))
				{
					base.SynErr(155);
					this.lexer.NextToken();
				}
				this.InterfaceMemberDecl();
			}
			base.Expect(17);
		}

		private void InterfaceMemberDecl()
		{
			Modifiers modifier = Modifiers.None;
			List<AttributeSection> list = new List<AttributeSection>();
			List<ParameterDeclarationExpression> list2 = new List<ParameterDeclarationExpression>();
			Location location = new Location(-1, -1);
			List<TemplateDefinition> templates = new List<TemplateDefinition>();
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			if (this.la.kind == 89)
			{
				this.lexer.NextToken();
				modifier = Modifiers.New;
				location = this.t.Location;
			}
			if (this.NotVoidPointer())
			{
				base.Expect(123);
				if (location.IsEmpty)
				{
					location = this.t.Location;
				}
				this.Identifier();
				string val = this.t.val;
				if (this.la.kind == 23)
				{
					this.TypeParameterList(templates);
				}
				base.Expect(20);
				if (this.StartOf(11))
				{
					this.FormalParameterList(list2);
				}
				base.Expect(21);
				while (this.la.kind == 127)
				{
					this.TypeParameterConstraintsClause(templates);
				}
				base.Expect(11);
				MethodDeclaration childNode = new MethodDeclaration
				{
					Name = val,
					Modifier = modifier,
					TypeReference = new TypeReference("System.Void", true),
					Parameters = list2,
					Attributes = list,
					Templates = templates,
					StartLocation = location,
					EndLocation = this.t.EndLocation
				};
				this.compilationUnit.AddChild(childNode);
				return;
			}
			if (!this.StartOf(23))
			{
				base.SynErr(177);
				return;
			}
			TypeReference typeReference;
			if (!this.StartOf(10))
			{
				this.lexer.NextToken();
				if (location.IsEmpty)
				{
					location = this.t.Location;
				}
				this.Type(out typeReference);
				this.Identifier();
				EventDeclaration eventDeclaration = new EventDeclaration
				{
					TypeReference = typeReference,
					Name = this.t.val,
					Modifier = modifier,
					Attributes = list
				};
				this.compilationUnit.AddChild(eventDeclaration);
				base.Expect(11);
				eventDeclaration.StartLocation = location;
				eventDeclaration.EndLocation = this.t.EndLocation;
				return;
			}
			this.Type(out typeReference);
			if (location.IsEmpty)
			{
				location = this.t.Location;
			}
			if (this.StartOf(19))
			{
				this.Identifier();
				string val = this.t.val;
				Location endLocation = this.t.EndLocation;
				if (this.la.kind == 20 || this.la.kind == 23)
				{
					if (this.la.kind == 23)
					{
						this.TypeParameterList(templates);
					}
					base.Expect(20);
					if (this.StartOf(11))
					{
						this.FormalParameterList(list2);
					}
					base.Expect(21);
					while (this.la.kind == 127)
					{
						this.TypeParameterConstraintsClause(templates);
					}
					base.Expect(11);
					MethodDeclaration childNode2 = new MethodDeclaration
					{
						Name = val,
						Modifier = modifier,
						TypeReference = typeReference,
						Parameters = list2,
						Attributes = list,
						Templates = templates,
						StartLocation = location,
						EndLocation = this.t.EndLocation
					};
					this.compilationUnit.AddChild(childNode2);
					return;
				}
				if (this.la.kind == 16)
				{
					PropertyDeclaration propertyDeclaration = new PropertyDeclaration(val, typeReference, modifier, list);
					this.compilationUnit.AddChild(propertyDeclaration);
					this.lexer.NextToken();
					Location location2 = this.t.Location;
					PropertyGetRegion getRegion;
					PropertySetRegion setRegion;
					this.InterfaceAccessors(out getRegion, out setRegion);
					base.Expect(17);
					propertyDeclaration.GetRegion = getRegion;
					propertyDeclaration.SetRegion = setRegion;
					propertyDeclaration.StartLocation = location;
					propertyDeclaration.EndLocation = endLocation;
					propertyDeclaration.BodyStart = location2;
					propertyDeclaration.BodyEnd = this.t.EndLocation;
					return;
				}
				base.SynErr(175);
				return;
			}
			else
			{
				if (this.la.kind == 111)
				{
					this.lexer.NextToken();
					base.Expect(18);
					this.FormalParameterList(list2);
					base.Expect(19);
					Location endLocation2 = this.t.EndLocation;
					IndexerDeclaration indexerDeclaration = new IndexerDeclaration(typeReference, list2, modifier, list);
					this.compilationUnit.AddChild(indexerDeclaration);
					base.Expect(16);
					Location location3 = this.t.Location;
					PropertyGetRegion getRegion;
					PropertySetRegion setRegion;
					this.InterfaceAccessors(out getRegion, out setRegion);
					base.Expect(17);
					indexerDeclaration.GetRegion = getRegion;
					indexerDeclaration.SetRegion = setRegion;
					indexerDeclaration.StartLocation = location;
					indexerDeclaration.EndLocation = endLocation2;
					indexerDeclaration.BodyStart = location3;
					indexerDeclaration.BodyEnd = this.t.EndLocation;
					return;
				}
				base.SynErr(176);
				return;
			}
		}

		private bool IsAssignment()
		{
			return this.IdentAndAsgn();
		}

		private bool IsExplicitInterfaceImplementation()
		{
			this.StartPeek();
			Token token = this.la;
			token = this.Peek();
			return token.kind == 15 || token.kind == 10 || (token.kind == 23 && this.SkipGeneric(ref token) && token.kind == 15);
		}

		private bool IsGenericExpression(Expression expr)
		{
			if (expr is IdentifierExpression)
			{
				return ((IdentifierExpression)expr).TypeArguments.Count > 0;
			}
			return expr is MemberReferenceExpression && ((MemberReferenceExpression)expr).TypeArguments.Count > 0;
		}

		private bool IsGenericInSimpleNameOrMemberAccess()
		{
			Token la = this.la;
			if (la.kind != 23)
			{
				return false;
			}
			this.StartPeek();
			return this.SkipGeneric(ref la) && Tokens.GenericFollower[la.kind];
		}

		private bool IsGlobalAttrTarget()
		{
			Token token = this.Peek(1);
			return this.la.kind == 18 && Parser.IsIdentifierToken(token) && (token.val == "assembly" || token.val == "module");
		}

		private static bool IsIdentifierToken(Token tk)
		{
			return Tokens.IdentifierTokens[tk.kind];
		}

		private bool IsLabel()
		{
			return this.IdentAndColon();
		}

		private bool IsLambdaExpression()
		{
			if (this.la.kind != 20)
			{
				return false;
			}
			this.StartPeek();
			Token token = this.Peek();
			while (token.kind != 21)
			{
				if (token.kind == 93 || token.kind == 100)
				{
					token = this.Peek();
				}
				if (!this.IsTypeNameOrKWForTypeCast(ref token))
				{
					return false;
				}
				if (Parser.IsIdentifierToken(token))
				{
					token = this.Peek();
				}
				if (token.kind == 21)
				{
					break;
				}
				if (token.kind != 14)
				{
					return false;
				}
				token = this.Peek();
			}
			token = this.Peek();
			return token.kind == 48;
		}

		private bool IsLocalAttrTarget()
		{
			int kind = this.la.kind;
			string arg_17_0 = this.la.val;
			return (kind == 69 || kind == 101 || Tokens.IdentifierTokens[kind]) && this.Peek(1).kind == 9;
		}

		private bool IsLocalVarDecl()
		{
			if (this.IsYieldStatement())
			{
				return false;
			}
			if ((Tokens.TypeKW[this.la.kind] && this.Peek(1).kind != 15) || this.la.kind == 123)
			{
				return true;
			}
			this.StartPeek();
			Token la = this.la;
			return this.IsTypeNameOrKWForTypeCast(ref la) && Parser.IsIdentifierToken(la);
		}

		private bool IsMostNegativeIntegerWithoutTypeSuffix()
		{
			Token la = this.la;
			return la.kind == 2 && (la.val == "2147483648" || la.val == "9223372036854775808");
		}

		private bool IsPointer()
		{
			return this.la.kind == 6;
		}

		private bool IsPointerOrDims()
		{
			return this.TimesOrLBrackAndCommaOrRBrack();
		}

		private bool IsPointerOrDims(ref Token pt)
		{
			while (true)
			{
				if (pt.kind == 18)
				{
					do
					{
						pt = this.Peek();
					}
					while (pt.kind == 14);
					if (pt.kind != 19)
					{
						break;
					}
				}
				else if (pt.kind != 6)
				{
					return true;
				}
				pt = this.Peek();
			}
			return false;
		}

		private bool IsPossibleExpressionStart(int token)
		{
			return Tokens.CastFollower[token] || Tokens.UnaryOp[token];
		}

		private bool IsQualident(ref Token pt, out string qualident)
		{
			if (Parser.IsIdentifierToken(pt))
			{
				this.qualidentBuilder.Length = 0;
				this.qualidentBuilder.Append(pt.val);
				pt = this.Peek();
				while (pt.kind == 15 || pt.kind == 10)
				{
					pt = this.Peek();
					if (!Parser.IsIdentifierToken(pt))
					{
						qualident = string.Empty;
						return false;
					}
					this.qualidentBuilder.Append('.');
					this.qualidentBuilder.Append(pt.val);
					pt = this.Peek();
				}
				qualident = this.qualidentBuilder.ToString();
				return true;
			}
			qualident = string.Empty;
			return false;
		}

		private bool IsShiftRight()
		{
			Token token = this.Peek(1);
			return this.la.kind == 22 && token.kind == 22;
		}

		private bool IsTypeCast()
		{
			if (this.la.kind != 20)
			{
				return false;
			}
			bool flag = true;
			this.lexer.StartPeek();
			Token token = this.lexer.Peek();
			if (!this.IsTypeNameOrKWForTypeCast(ref token, ref flag))
			{
				return false;
			}
			if (token.kind != 21)
			{
				return false;
			}
			if (flag)
			{
				token = this.lexer.Peek();
				return Tokens.CastFollower[token.kind];
			}
			return true;
		}

		private bool IsTypedCatch()
		{
			return this.CatchAndLPar();
		}

		private bool IsTypeKWForTypeCast(ref Token pt)
		{
			if (Tokens.TypeKW[pt.kind])
			{
				pt = this.lexer.Peek();
				return this.IsPointerOrDims(ref pt) && this.SkipQuestionMark(ref pt);
			}
			if (pt.kind == 123)
			{
				pt = this.lexer.Peek();
				return this.IsPointerOrDims(ref pt);
			}
			return false;
		}

		private bool IsTypeNameForTypeCast(ref Token pt, ref bool isPossibleExpression)
		{
			if (!Parser.IsIdentifierToken(pt))
			{
				return false;
			}
			pt = this.Peek();
			if (pt.kind == 10)
			{
				pt = this.Peek();
				if (!Parser.IsIdentifierToken(pt))
				{
					return false;
				}
				pt = this.Peek();
			}
			while (true)
			{
				if (pt.kind == 23)
				{
					do
					{
						pt = this.Peek();
						if (!this.IsTypeNameOrKWForTypeCast(ref pt))
						{
							return false;
						}
					}
					while (pt.kind == 14);
					if (pt.kind != 22)
					{
						return false;
					}
					pt = this.Peek();
				}
				if (pt.kind != 15)
				{
					goto IL_A0;
				}
				pt = this.Peek();
				if (pt.kind != 1)
				{
					return false;
				}
				pt = this.Peek();
			}
			return false;
			IL_A0:
			if (pt.kind == 12)
			{
				pt = this.Peek();
			}
			if (pt.kind == 6 || pt.kind == 18)
			{
				isPossibleExpression = false;
				return this.IsPointerOrDims(ref pt);
			}
			return true;
		}

		private bool IsTypeNameOrKWForTypeCast(ref Token pt)
		{
			bool flag = false;
			return this.IsTypeNameOrKWForTypeCast(ref pt, ref flag);
		}

		private bool IsTypeNameOrKWForTypeCast(ref Token pt, ref bool isPossibleExpression)
		{
			if (Tokens.TypeKW[pt.kind] || pt.kind == 123)
			{
				isPossibleExpression = false;
				return this.IsTypeKWForTypeCast(ref pt);
			}
			return this.IsTypeNameForTypeCast(ref pt, ref isPossibleExpression);
		}

		private bool IsVarDecl()
		{
			int kind = this.Peek(1).kind;
			return Parser.IsIdentifierToken(this.la) && (kind == 14 || kind == 3 || kind == 11 || kind == 18);
		}

		private bool IsYieldStatement()
		{
			return this.la.kind == 132 && (this.Peek(1).kind == 101 || this.Peek(1).kind == 53);
		}

		private void LambdaExpression(out Expression outExpr)
		{
			LambdaExpression lambdaExpression = new LambdaExpression();
			lambdaExpression.StartLocation = this.la.Location;
			outExpr = lambdaExpression;
			base.Expect(20);
			if (this.StartOf(18))
			{
				ParameterDeclarationExpression item;
				this.LambdaExpressionParameter(out item);
				Parser.SafeAdd<ParameterDeclarationExpression>(lambdaExpression, lambdaExpression.Parameters, item);
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.LambdaExpressionParameter(out item);
					Parser.SafeAdd<ParameterDeclarationExpression>(lambdaExpression, lambdaExpression.Parameters, item);
				}
			}
			base.Expect(21);
			base.Expect(48);
			this.LambdaExpressionBody(lambdaExpression);
		}

		private void LambdaExpressionBody(LambdaExpression lambda)
		{
			if (this.la.kind == 16)
			{
				BlockStatement statementBody;
				this.BlockInsideExpression(out statementBody);
				lambda.StatementBody = statementBody;
			}
			else if (this.StartOf(6))
			{
				Expression expressionBody;
				this.Expr(out expressionBody);
				lambda.ExpressionBody = expressionBody;
			}
			else
			{
				base.SynErr(213);
			}
			lambda.EndLocation = this.t.EndLocation;
			lambda.ExtendedEndLocation = this.la.Location;
		}

		private void LambdaExpressionParameter(out ParameterDeclarationExpression p)
		{
			Location location = this.la.Location;
			p = null;
			ParameterModifiers paramModifier = ParameterModifiers.In;
			if (this.Peek(1).kind == 14 || this.Peek(1).kind == 21)
			{
				this.Identifier();
				p = new ParameterDeclarationExpression(null, this.t.val);
				p.StartLocation = location;
				p.EndLocation = this.t.EndLocation;
				return;
			}
			if (this.StartOf(18))
			{
				if (this.la.kind == 93 || this.la.kind == 100)
				{
					if (this.la.kind == 100)
					{
						this.lexer.NextToken();
						paramModifier = ParameterModifiers.Ref;
					}
					else
					{
						this.lexer.NextToken();
						paramModifier = ParameterModifiers.Out;
					}
				}
				TypeReference typeReference;
				this.Type(out typeReference);
				this.Identifier();
				p = new ParameterDeclarationExpression(typeReference, this.t.val, paramModifier);
				p.StartLocation = location;
				p.EndLocation = this.t.EndLocation;
				return;
			}
			base.SynErr(212);
		}

		private bool LastExpressionIsUnaryMinus(ArrayList expressions)
		{
			if (expressions.Count == 0)
			{
				return false;
			}
			UnaryOperatorExpression unaryOperatorExpression = expressions[expressions.Count - 1] as UnaryOperatorExpression;
			return unaryOperatorExpression != null && unaryOperatorExpression.Op == UnaryOperatorType.Minus;
		}

		private bool LBrackAndCommaOrRBrack()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 18 && (kind == 14 || kind == 19);
		}

		private void LocalVariableDecl(out Statement stmt)
		{
			VariableDeclaration item = null;
			Location location = this.la.Location;
			TypeReference typeReference;
			this.Type(out typeReference);
			LocalVariableDeclaration localVariableDeclaration = new LocalVariableDeclaration(typeReference);
			localVariableDeclaration.StartLocation = location;
			this.LocalVariableDeclarator(out item);
			Parser.SafeAdd<VariableDeclaration>(localVariableDeclaration, localVariableDeclaration.Variables, item);
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.LocalVariableDeclarator(out item);
				Parser.SafeAdd<VariableDeclaration>(localVariableDeclaration, localVariableDeclaration.Variables, item);
			}
			stmt = localVariableDeclaration;
			stmt.EndLocation = this.t.EndLocation;
		}

		private void LocalVariableDeclarator(out VariableDeclaration var)
		{
			Expression initializer = null;
			this.Identifier();
			var = new VariableDeclaration(this.t.val);
			var.StartLocation = this.t.Location;
			if (this.la.kind == 3)
			{
				this.lexer.NextToken();
				this.VariableInitializer(out initializer);
				var.Initializer = initializer;
			}
			var.EndLocation = this.t.EndLocation;
		}

		private void MemberAccess(out Expression expr, Expression target)
		{
			if (this.ShouldConvertTargetExpressionToTypeReference(target))
			{
				TypeReference typeReferenceFromExpression = this.GetTypeReferenceFromExpression(target);
				if (typeReferenceFromExpression != null)
				{
					target = new TypeReferenceExpression(typeReferenceFromExpression)
					{
						StartLocation = this.t.Location,
						EndLocation = this.t.EndLocation
					};
				}
			}
			base.Expect(15);
			Location location = this.t.Location;
			this.Identifier();
			expr = new MemberReferenceExpression(target, this.t.val);
			expr.StartLocation = location;
			expr.EndLocation = this.t.EndLocation;
			if (this.IsGenericInSimpleNameOrMemberAccess())
			{
				List<TypeReference> typeArguments;
				this.TypeArgumentList(out typeArguments, false);
				((MemberReferenceExpression)expr).TypeArguments = typeArguments;
			}
		}

		private void MemberModifiers(ModifierList m)
		{
			while (this.StartOf(20))
			{
				int kind = this.la.kind;
				if (kind <= 84)
				{
					if (kind <= 71)
					{
						if (kind != 49)
						{
							if (kind == 71)
							{
								this.lexer.NextToken();
								m.Add(Modifiers.Extern, this.t.Location);
							}
						}
						else
						{
							this.lexer.NextToken();
							m.Add(Modifiers.Dim, this.t.Location);
						}
					}
					else if (kind != 74)
					{
						if (kind == 84)
						{
							this.lexer.NextToken();
							m.Add(Modifiers.Internal, this.t.Location);
						}
					}
					else
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Fixed, this.t.Location);
					}
				}
				else if (kind <= 103)
				{
					switch (kind)
					{
					case 89:
						this.lexer.NextToken();
						m.Add(Modifiers.New, this.t.Location);
						break;
					case 90:
					case 91:
					case 92:
					case 93:
					case 95:
						break;
					case 94:
						this.lexer.NextToken();
						m.Add(Modifiers.Override, this.t.Location);
						break;
					case 96:
						this.lexer.NextToken();
						m.Add(Modifiers.Private, this.t.Location);
						break;
					case 97:
						this.lexer.NextToken();
						m.Add(Modifiers.Protected, this.t.Location);
						break;
					case 98:
						this.lexer.NextToken();
						m.Add(Modifiers.Public, this.t.Location);
						break;
					case 99:
						this.lexer.NextToken();
						m.Add(Modifiers.ReadOnly, this.t.Location);
						break;
					default:
						if (kind == 103)
						{
							this.lexer.NextToken();
							m.Add(Modifiers.Sealed, this.t.Location);
						}
						break;
					}
				}
				else if (kind != 107)
				{
					if (kind != 119)
					{
						switch (kind)
						{
						case 122:
							this.lexer.NextToken();
							m.Add(Modifiers.Virtual, this.t.Location);
							break;
						case 124:
							this.lexer.NextToken();
							m.Add(Modifiers.Volatile, this.t.Location);
							break;
						case 126:
							this.lexer.NextToken();
							m.Add(Modifiers.Partial, this.t.Location);
							break;
						}
					}
					else
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Unsafe, this.t.Location);
					}
				}
				else
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Static, this.t.Location);
				}
			}
		}

		private void MultiplicativeExpr(ref Expression outExpr)
		{
			while (this.la.kind == 6 || this.la.kind == 7 || this.la.kind == 8)
			{
				BinaryOperatorType op;
				if (this.la.kind == 6)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Multiply;
				}
				else if (this.la.kind == 7)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Divide;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Modulus;
				}
				Expression right;
				this.UnaryExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void NamespaceMemberDecl()
		{
			List<AttributeSection> list = new List<AttributeSection>();
			ModifierList m = new ModifierList();
			if (this.la.kind == 88)
			{
				this.lexer.NextToken();
				Location location = this.t.Location;
				string name;
				this.Qualident(out name);
				INode node = new NamespaceDeclaration(name);
				node.StartLocation = location;
				this.compilationUnit.AddChild(node);
				this.compilationUnit.BlockStart(node);
				base.Expect(16);
				while (this.la.kind == 71)
				{
					this.ExternAliasDirective();
				}
				while (this.la.kind == 121)
				{
					this.UsingDirective();
				}
				while (this.StartOf(1))
				{
					this.NamespaceMemberDecl();
				}
				base.Expect(17);
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				node.EndLocation = this.t.EndLocation;
				this.compilationUnit.BlockEnd();
				return;
			}
			if (this.StartOf(2))
			{
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				while (this.StartOf(3))
				{
					this.TypeModifier(m);
				}
				this.TypeDecl(m, list);
				return;
			}
			base.SynErr(146);
		}

		private void NewExpression(out Expression pexpr)
		{
			pexpr = null;
			List<Expression> list = new List<Expression>();
			TypeReference typeReference = null;
			base.Expect(89);
			if (this.StartOf(10))
			{
				this.NonArrayType(out typeReference);
			}
			if (this.la.kind == 16 || this.la.kind == 20)
			{
				if (this.la.kind != 20)
				{
					ObjectCreateExpression objectCreateExpression = new ObjectCreateExpression(typeReference, list);
					Expression expression;
					this.CollectionOrObjectInitializer(out expression);
					objectCreateExpression.ObjectInitializer = (CollectionInitializerExpression)expression;
					pexpr = objectCreateExpression;
					return;
				}
				ObjectCreateExpression objectCreateExpression2 = new ObjectCreateExpression(typeReference, list);
				this.lexer.NextToken();
				if (typeReference == null)
				{
					this.Error("Cannot use an anonymous type with arguments for the constructor");
				}
				if (this.StartOf(26))
				{
					Expression expression;
					this.Argument(out expression);
					Parser.SafeAdd<Expression>(objectCreateExpression2, list, expression);
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						this.Argument(out expression);
						Parser.SafeAdd<Expression>(objectCreateExpression2, list, expression);
					}
				}
				base.Expect(21);
				pexpr = objectCreateExpression2;
				if (this.la.kind == 16)
				{
					Expression expression;
					this.CollectionOrObjectInitializer(out expression);
					objectCreateExpression2.ObjectInitializer = (CollectionInitializerExpression)expression;
					return;
				}
			}
			else
			{
				if (this.la.kind == 18)
				{
					this.lexer.NextToken();
					ArrayCreateExpression arrayCreateExpression = new ArrayCreateExpression(typeReference);
					if (arrayCreateExpression.CreateType.IsNull)
					{
						arrayCreateExpression.CreateType = new TypeReference("");
					}
					pexpr = arrayCreateExpression;
					int num = 0;
					List<int> list2 = new List<int>();
					Expression expression;
					if (this.la.kind != 14)
					{
						if (this.la.kind != 19)
						{
							if (!this.StartOf(6))
							{
								base.SynErr(210);
								return;
							}
							this.Expr(out expression);
							if (expression != null)
							{
								list.Add(expression);
							}
							while (this.la.kind == 14)
							{
								this.lexer.NextToken();
								num++;
								this.Expr(out expression);
								if (expression != null)
								{
									list.Add(expression);
								}
							}
							base.Expect(19);
							list2.Add(num);
							arrayCreateExpression.Arguments = list;
							num = 0;
							while (this.la.kind == 18)
							{
								this.lexer.NextToken();
								while (this.la.kind == 14)
								{
									this.lexer.NextToken();
									num++;
								}
								base.Expect(19);
								list2.Add(num);
								num = 0;
							}
							arrayCreateExpression.CreateType.RankSpecifier = list2.ToArray();
							if (this.la.kind == 16)
							{
								this.CollectionInitializer(out expression);
								arrayCreateExpression.ArrayInitializer = (CollectionInitializerExpression)expression;
								return;
							}
							return;
						}
					}
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						num++;
					}
					base.Expect(19);
					list2.Add(num);
					num = 0;
					while (this.la.kind == 18)
					{
						this.lexer.NextToken();
						while (this.la.kind == 14)
						{
							this.lexer.NextToken();
							num++;
						}
						base.Expect(19);
						list2.Add(num);
						num = 0;
					}
					arrayCreateExpression.CreateType.RankSpecifier = list2.ToArray();
					this.CollectionInitializer(out expression);
					arrayCreateExpression.ArrayInitializer = (CollectionInitializerExpression)expression;
					return;
				}
				base.SynErr(211);
			}
		}

		private void NonArrayType(out TypeReference type)
		{
			Location location = this.la.Location;
			int num = 0;
			type = null;
			if (this.StartOf(4))
			{
				this.ClassType(out type, false);
			}
			else if (this.StartOf(5))
			{
				string type2;
				this.SimpleType(out type2);
				type = new TypeReference(type2, true);
			}
			else if (this.la.kind == 123)
			{
				this.lexer.NextToken();
				base.Expect(6);
				num = 1;
				type = new TypeReference("System.Void", true);
			}
			else
			{
				base.SynErr(148);
			}
			if (this.la.kind == 12)
			{
				this.NullableQuestionMark(ref type);
			}
			while (this.IsPointer())
			{
				base.Expect(6);
				num++;
			}
			if (type != null)
			{
				type.PointerNestingLevel = num;
				type.EndLocation = this.t.EndLocation;
				type.StartLocation = location;
			}
		}

		private bool NotFinalComma()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 14 && kind != 17 && kind != 19;
		}

		private bool NotVoidPointer()
		{
			return this.la.kind == 123 && this.Peek(1).kind != 6;
		}

		private void NullableQuestionMark(ref TypeReference typeRef)
		{
			List<TypeReference> list = new List<TypeReference>(1);
			base.Expect(12);
			if (typeRef != null)
			{
				list.Add(typeRef);
			}
			typeRef = new TypeReference("System.Nullable", list)
			{
				IsKeyword = true
			};
		}

		private void ObjectPropertyInitializerOrVariableInitializer(out Expression expr)
		{
			expr = null;
			if (this.IdentAndAsgn())
			{
				this.Identifier();
				NamedArgumentExpression namedArgumentExpression = new NamedArgumentExpression(this.t.val, null);
				namedArgumentExpression.StartLocation = this.t.Location;
				Expression expression = null;
				base.Expect(3);
				if (this.la.kind == 16)
				{
					this.CollectionOrObjectInitializer(out expression);
				}
				else if (this.StartOf(31))
				{
					this.VariableInitializer(out expression);
				}
				else
				{
					base.SynErr(195);
				}
				namedArgumentExpression.Expression = expression;
				namedArgumentExpression.EndLocation = this.t.EndLocation;
				expr = namedArgumentExpression;
				return;
			}
			if (this.StartOf(31))
			{
				this.VariableInitializer(out expr);
				return;
			}
			base.SynErr(196);
		}

		private void OverloadableOperator(out OverloadableOperatorType op)
		{
			op = OverloadableOperatorType.None;
			int kind = this.la.kind;
			switch (kind)
			{
			case 4:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Add;
				return;
			case 5:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Subtract;
				return;
			case 6:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Multiply;
				return;
			case 7:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Divide;
				return;
			case 8:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Modulus;
				return;
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
			case 25:
			case 26:
				break;
			case 22:
				this.lexer.NextToken();
				op = OverloadableOperatorType.GreaterThan;
				if (this.la.kind == 22)
				{
					this.lexer.NextToken();
					op = OverloadableOperatorType.ShiftRight;
					return;
				}
				return;
			case 23:
				this.lexer.NextToken();
				op = OverloadableOperatorType.LessThan;
				return;
			case 24:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Not;
				return;
			case 27:
				this.lexer.NextToken();
				op = OverloadableOperatorType.BitNot;
				return;
			case 28:
				this.lexer.NextToken();
				op = OverloadableOperatorType.BitwiseAnd;
				return;
			case 29:
				this.lexer.NextToken();
				op = OverloadableOperatorType.BitwiseOr;
				return;
			case 30:
				this.lexer.NextToken();
				op = OverloadableOperatorType.ExclusiveOr;
				return;
			case 31:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Increment;
				return;
			case 32:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Decrement;
				return;
			case 33:
				this.lexer.NextToken();
				op = OverloadableOperatorType.Equality;
				return;
			case 34:
				this.lexer.NextToken();
				op = OverloadableOperatorType.InEquality;
				return;
			case 35:
				this.lexer.NextToken();
				op = OverloadableOperatorType.GreaterThanOrEqual;
				return;
			case 36:
				this.lexer.NextToken();
				op = OverloadableOperatorType.LessThanOrEqual;
				return;
			case 37:
				this.lexer.NextToken();
				op = OverloadableOperatorType.ShiftLeft;
				return;
			default:
				if (kind == 72)
				{
					this.lexer.NextToken();
					op = OverloadableOperatorType.IsFalse;
					return;
				}
				if (kind == 113)
				{
					this.lexer.NextToken();
					op = OverloadableOperatorType.IsTrue;
					return;
				}
				break;
			}
			base.SynErr(185);
		}

		private void ParameterArray(out ParameterDeclarationExpression p)
		{
			base.Expect(95);
			TypeReference typeReference;
			this.Type(out typeReference);
			this.Identifier();
			p = new ParameterDeclarationExpression(typeReference, this.t.val, ParameterModifiers.Params);
		}

		public override void Parse()
		{
			this.ParseRoot();
			this.compilationUnit.AcceptVisitor(new SetParentVisitor(), null);
		}

		public override BlockStatement ParseBlock()
		{
			this.lexer.NextToken();
			this.compilationUnit = new CompilationUnit();
			BlockStatement blockStatement = new BlockStatement();
			blockStatement.StartLocation = this.la.Location;
			this.compilationUnit.BlockStart(blockStatement);
			while (this.la.kind != 0)
			{
				Token la = this.la;
				this.Statement();
				if (this.la == la)
				{
					return null;
				}
			}
			this.compilationUnit.BlockEnd();
			blockStatement.EndLocation = this.t.EndLocation;
			base.Expect(0);
			blockStatement.AcceptVisitor(new SetParentVisitor(), null);
			return blockStatement;
		}

		public override Expression ParseExpression()
		{
			this.lexer.NextToken();
			Location location = this.la.Location;
			Expression expression;
			this.Expr(out expression);
			if (this.la.kind == 11)
			{
				this.lexer.NextToken();
			}
			if (expression != null)
			{
				if (expression.StartLocation.IsEmpty)
				{
					expression.StartLocation = location;
				}
				if (expression.EndLocation.IsEmpty)
				{
					expression.EndLocation = this.t.EndLocation;
				}
				expression.AcceptVisitor(new SetParentVisitor(), null);
			}
			base.Expect(0);
			return expression;
		}

		private void ParseRoot()
		{
			this.CS();
		}

		public override List<INode> ParseTypeMembers()
		{
			this.lexer.NextToken();
			this.compilationUnit = new CompilationUnit();
			TypeDeclaration typeDeclaration = new TypeDeclaration(Modifiers.None, null);
			this.compilationUnit.BlockStart(typeDeclaration);
			this.ClassBody();
			this.compilationUnit.BlockEnd();
			base.Expect(0);
			typeDeclaration.AcceptVisitor(new SetParentVisitor(), null);
			return typeDeclaration.Children;
		}

		public override TypeReference ParseTypeReference()
		{
			this.lexer.NextToken();
			TypeReference result;
			this.Type(out result);
			return result;
		}

		private Token Peek()
		{
			return this.lexer.Peek();
		}

		private Token Peek(int n)
		{
			this.lexer.StartPeek();
			Token result = this.la;
			while (n > 0)
			{
				result = this.lexer.Peek();
				n--;
			}
			return result;
		}

		private void PointerMemberAccess(out Expression expr, Expression target)
		{
			base.Expect(47);
			this.Identifier();
			expr = new PointerReferenceExpression(target, this.t.val);
			expr.StartLocation = this.t.Location;
			expr.EndLocation = this.t.EndLocation;
			if (this.IsGenericInSimpleNameOrMemberAccess())
			{
				List<TypeReference> typeArguments;
				this.TypeArgumentList(out typeArguments, false);
				((MemberReferenceExpression)expr).TypeArguments = typeArguments;
			}
		}

		private void PrimaryExpr(out Expression pexpr)
		{
			TypeReference typeReference = null;
			pexpr = null;
			Location location = this.la.Location;
			if (this.la.kind == 113)
			{
				this.lexer.NextToken();
				pexpr = new PrimitiveExpression(true, "true");
			}
			else if (this.la.kind == 72)
			{
				this.lexer.NextToken();
				pexpr = new PrimitiveExpression(false, "false");
			}
			else if (this.la.kind == 90)
			{
				this.lexer.NextToken();
				pexpr = new PrimitiveExpression(null, "null");
			}
			else if (this.la.kind == 2)
			{
				this.lexer.NextToken();
				pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
				{
					LiteralFormat = this.t.literalFormat
				};
			}
			else if (this.StartOfQueryExpression())
			{
				this.QueryExpression(out pexpr);
			}
			else if (this.IdentAndDoubleColon())
			{
				this.Identifier();
				typeReference = new TypeReference(this.t.val);
				base.Expect(10);
				pexpr = new TypeReferenceExpression(typeReference);
				this.Identifier();
				if (typeReference.Type == "global")
				{
					typeReference.IsGlobal = true;
					typeReference.Type = (this.t.val ?? "?");
				}
				else
				{
					TypeReference expr_176 = typeReference;
					expr_176.Type = expr_176.Type + "." + (this.t.val ?? "?");
				}
			}
			else if (this.StartOf(19))
			{
				this.Identifier();
				pexpr = new IdentifierExpression(this.t.val);
				if (this.la.kind == 48 || this.IsGenericInSimpleNameOrMemberAccess())
				{
					if (this.la.kind == 48)
					{
						this.ShortedLambdaExpression((IdentifierExpression)pexpr, out pexpr);
					}
					else
					{
						List<TypeReference> typeArguments;
						this.TypeArgumentList(out typeArguments, false);
						((IdentifierExpression)pexpr).TypeArguments = typeArguments;
					}
				}
			}
			else if (this.IsLambdaExpression())
			{
				this.LambdaExpression(out pexpr);
			}
			else if (this.la.kind == 20)
			{
				this.lexer.NextToken();
				Expression expression;
				this.Expr(out expression);
				base.Expect(21);
				pexpr = new ParenthesizedExpression(expression);
			}
			else if (this.StartOf(35))
			{
				string type = null;
				int kind = this.la.kind;
				if (kind <= 82)
				{
					if (kind <= 62)
					{
						switch (kind)
						{
						case 52:
							this.lexer.NextToken();
							type = "System.Boolean";
							break;
						case 53:
							break;
						case 54:
							this.lexer.NextToken();
							type = "System.Byte";
							break;
						default:
							if (kind != 57)
							{
								if (kind == 62)
								{
									this.lexer.NextToken();
									type = "System.Decimal";
								}
							}
							else
							{
								this.lexer.NextToken();
								type = "System.Char";
							}
							break;
						}
					}
					else if (kind != 66)
					{
						if (kind != 75)
						{
							if (kind == 82)
							{
								this.lexer.NextToken();
								type = "System.Int32";
							}
						}
						else
						{
							this.lexer.NextToken();
							type = "System.Single";
						}
					}
					else
					{
						this.lexer.NextToken();
						type = "System.Double";
					}
				}
				else if (kind <= 104)
				{
					if (kind != 87)
					{
						if (kind != 91)
						{
							switch (kind)
							{
							case 102:
								this.lexer.NextToken();
								type = "System.SByte";
								break;
							case 104:
								this.lexer.NextToken();
								type = "System.Int16";
								break;
							}
						}
						else
						{
							this.lexer.NextToken();
							type = "System.Object";
						}
					}
					else
					{
						this.lexer.NextToken();
						type = "System.Int64";
					}
				}
				else if (kind != 108)
				{
					switch (kind)
					{
					case 116:
						this.lexer.NextToken();
						type = "System.UInt32";
						break;
					case 117:
						this.lexer.NextToken();
						type = "System.UInt64";
						break;
					case 118:
					case 119:
						break;
					case 120:
						this.lexer.NextToken();
						type = "System.UInt16";
						break;
					default:
						if (kind == 123)
						{
							this.lexer.NextToken();
							type = "System.Void";
						}
						break;
					}
				}
				else
				{
					this.lexer.NextToken();
					type = "System.String";
				}
				pexpr = new TypeReferenceExpression(new TypeReference(type, true))
				{
					StartLocation = this.t.Location,
					EndLocation = this.t.EndLocation
				};
			}
			else if (this.la.kind == 111)
			{
				this.lexer.NextToken();
				pexpr = new ThisReferenceExpression();
				pexpr.StartLocation = this.t.Location;
				pexpr.EndLocation = this.t.EndLocation;
			}
			else if (this.la.kind == 51)
			{
				this.lexer.NextToken();
				pexpr = new BaseReferenceExpression();
				pexpr.StartLocation = this.t.Location;
				pexpr.EndLocation = this.t.EndLocation;
			}
			else if (this.la.kind == 89)
			{
				this.NewExpression(out pexpr);
			}
			else if (this.la.kind == 115)
			{
				this.lexer.NextToken();
				base.Expect(20);
				if (this.NotVoidPointer())
				{
					base.Expect(123);
					typeReference = new TypeReference("System.Void", true);
				}
				else if (this.StartOf(10))
				{
					this.TypeWithRestriction(out typeReference, true, true);
				}
				else
				{
					base.SynErr(207);
				}
				base.Expect(21);
				pexpr = new TypeOfExpression(typeReference);
			}
			else if (this.la.kind == 63)
			{
				this.lexer.NextToken();
				base.Expect(20);
				this.Type(out typeReference);
				base.Expect(21);
				pexpr = new DefaultValueExpression(typeReference);
			}
			else if (this.la.kind == 105)
			{
				this.lexer.NextToken();
				base.Expect(20);
				this.Type(out typeReference);
				base.Expect(21);
				pexpr = new SizeOfExpression(typeReference);
			}
			else if (this.la.kind == 58)
			{
				this.lexer.NextToken();
				base.Expect(20);
				Expression expression;
				this.Expr(out expression);
				base.Expect(21);
				pexpr = new CheckedExpression(expression);
			}
			else if (this.la.kind == 118)
			{
				this.lexer.NextToken();
				base.Expect(20);
				Expression expression;
				this.Expr(out expression);
				base.Expect(21);
				pexpr = new UncheckedExpression(expression);
			}
			else if (this.la.kind == 64)
			{
				this.lexer.NextToken();
				Expression expression;
				this.AnonymousMethodExpr(out expression);
				pexpr = expression;
			}
			else
			{
				base.SynErr(208);
			}
			if (pexpr != null)
			{
				if (pexpr.StartLocation.IsEmpty)
				{
					pexpr.StartLocation = location;
				}
				if (pexpr.EndLocation.IsEmpty)
				{
					pexpr.EndLocation = this.t.EndLocation;
				}
			}
			while (this.StartOf(36))
			{
				location = this.la.Location;
				int kind2 = this.la.kind;
				if (kind2 <= 20)
				{
					if (kind2 != 15)
					{
						switch (kind2)
						{
						case 18:
						{
							List<Expression> list = new List<Expression>();
							pexpr = new IndexerExpression(pexpr, list);
							this.lexer.NextToken();
							Expression expression;
							this.Expr(out expression);
							Parser.SafeAdd<Expression>(pexpr, list, expression);
							while (this.la.kind == 14)
							{
								this.lexer.NextToken();
								this.Expr(out expression);
								Parser.SafeAdd<Expression>(pexpr, list, expression);
							}
							base.Expect(19);
							break;
						}
						case 20:
						{
							this.lexer.NextToken();
							List<Expression> list2 = new List<Expression>();
							pexpr = new InvocationExpression(pexpr, list2);
							if (this.StartOf(26))
							{
								Expression expression;
								this.Argument(out expression);
								Parser.SafeAdd<Expression>(pexpr, list2, expression);
								while (this.la.kind == 14)
								{
									this.lexer.NextToken();
									this.Argument(out expression);
									Parser.SafeAdd<Expression>(pexpr, list2, expression);
								}
							}
							base.Expect(21);
							break;
						}
						}
					}
					else
					{
						this.MemberAccess(out pexpr, pexpr);
					}
				}
				else
				{
					switch (kind2)
					{
					case 31:
						this.lexer.NextToken();
						pexpr = new UnaryOperatorExpression(pexpr, UnaryOperatorType.PostIncrement);
						break;
					case 32:
						this.lexer.NextToken();
						pexpr = new UnaryOperatorExpression(pexpr, UnaryOperatorType.PostDecrement);
						break;
					default:
						if (kind2 == 47)
						{
							this.PointerMemberAccess(out pexpr, pexpr);
						}
						break;
					}
				}
				if (pexpr != null)
				{
					if (pexpr.StartLocation.IsEmpty)
					{
						pexpr.StartLocation = location;
					}
					if (pexpr.EndLocation.IsEmpty)
					{
						pexpr.EndLocation = this.t.EndLocation;
					}
				}
			}
		}

		private void Qualident(out string qualident)
		{
			this.Identifier();
			this.qualidentBuilder.Length = 0;
			this.qualidentBuilder.Append(this.t.val);
			while (this.DotAndIdent())
			{
				base.Expect(15);
				this.Identifier();
				this.qualidentBuilder.Append('.');
				this.qualidentBuilder.Append(this.t.val);
			}
			qualident = this.qualidentBuilder.ToString();
		}

		private void QueryExpression(out Expression outExpr)
		{
			QueryExpression queryExpression = new QueryExpression();
			outExpr = queryExpression;
			queryExpression.StartLocation = this.la.Location;
			QueryExpressionFromClause fromClause;
			this.QueryExpressionFromClause(out fromClause);
			queryExpression.FromClause = fromClause;
			this.QueryExpressionBody(ref queryExpression);
			queryExpression.EndLocation = this.t.EndLocation;
			outExpr = queryExpression;
		}

		private void QueryExpressionBody(ref QueryExpression q)
		{
			while (this.StartOf(39))
			{
				if (this.la.kind == 137)
				{
					QueryExpressionFromClause item;
					this.QueryExpressionFromClause(out item);
					Parser.SafeAdd<QueryExpressionClause>(q, q.MiddleClauses, item);
				}
				else if (this.la.kind == 127)
				{
					QueryExpressionWhereClause item2;
					this.QueryExpressionWhereClause(out item2);
					Parser.SafeAdd<QueryExpressionClause>(q, q.MiddleClauses, item2);
				}
				else if (this.la.kind == 141)
				{
					QueryExpressionLetClause item3;
					this.QueryExpressionLetClause(out item3);
					Parser.SafeAdd<QueryExpressionClause>(q, q.MiddleClauses, item3);
				}
				else if (this.la.kind == 142)
				{
					QueryExpressionJoinClause item4;
					this.QueryExpressionJoinClause(out item4);
					Parser.SafeAdd<QueryExpressionClause>(q, q.MiddleClauses, item4);
				}
				else
				{
					QueryExpressionOrderClause item5;
					this.QueryExpressionOrderByClause(out item5);
					Parser.SafeAdd<QueryExpressionClause>(q, q.MiddleClauses, item5);
				}
			}
			if (this.la.kind == 133)
			{
				QueryExpressionSelectClause selectOrGroupClause;
				this.QueryExpressionSelectClause(out selectOrGroupClause);
				q.SelectOrGroupClause = selectOrGroupClause;
			}
			else if (this.la.kind == 134)
			{
				QueryExpressionGroupClause selectOrGroupClause2;
				this.QueryExpressionGroupClause(out selectOrGroupClause2);
				q.SelectOrGroupClause = selectOrGroupClause2;
			}
			else
			{
				base.SynErr(217);
			}
			if (this.la.kind == 136)
			{
				this.QueryExpressionIntoClause(ref q);
			}
		}

		private void QueryExpressionFromClause(out QueryExpressionFromClause fc)
		{
			fc = new QueryExpressionFromClause();
			fc.StartLocation = this.la.Location;
			base.Expect(137);
			this.QueryExpressionFromOrJoinClause(fc);
			fc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionFromOrJoinClause(QueryExpressionFromOrJoinClause fjc)
		{
			fjc.Type = null;
			if (this.IsLocalVarDecl())
			{
				TypeReference type;
				this.Type(out type);
				fjc.Type = type;
			}
			this.Identifier();
			fjc.Identifier = this.t.val;
			base.Expect(81);
			Expression inExpression;
			this.Expr(out inExpression);
			fjc.InExpression = inExpression;
		}

		private void QueryExpressionGroupClause(out QueryExpressionGroupClause gc)
		{
			gc = new QueryExpressionGroupClause();
			gc.StartLocation = this.la.Location;
			base.Expect(134);
			Expression expression;
			this.Expr(out expression);
			gc.Projection = expression;
			base.Expect(135);
			this.Expr(out expression);
			gc.GroupBy = expression;
			gc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionIntoClause(ref QueryExpression q)
		{
			QueryExpression queryExpression = q;
			QueryExpression queryExpression2 = new QueryExpression();
			queryExpression2.StartLocation = q.StartLocation;
			queryExpression.EndLocation = this.la.Location;
			queryExpression2.FromClause = new QueryExpressionFromClause();
			queryExpression2.FromClause.StartLocation = this.la.Location;
			queryExpression2.FromClause.InExpression = queryExpression;
			queryExpression2.IsQueryContinuation = true;
			q = queryExpression2;
			base.Expect(136);
			this.Identifier();
			queryExpression2.FromClause.Identifier = this.t.val;
			queryExpression2.FromClause.EndLocation = this.t.EndLocation;
			this.QueryExpressionBody(ref q);
		}

		private void QueryExpressionJoinClause(out QueryExpressionJoinClause jc)
		{
			jc = new QueryExpressionJoinClause();
			jc.StartLocation = this.la.Location;
			base.Expect(142);
			this.QueryExpressionFromOrJoinClause(jc);
			base.Expect(143);
			Expression expression;
			this.Expr(out expression);
			jc.OnExpression = expression;
			base.Expect(144);
			this.Expr(out expression);
			jc.EqualsExpression = expression;
			if (this.la.kind == 136)
			{
				this.lexer.NextToken();
				this.Identifier();
				jc.IntoIdentifier = this.t.val;
			}
			jc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionLetClause(out QueryExpressionLetClause wc)
		{
			wc = new QueryExpressionLetClause();
			wc.StartLocation = this.la.Location;
			base.Expect(141);
			this.Identifier();
			wc.Identifier = this.t.val;
			base.Expect(3);
			Expression expression;
			this.Expr(out expression);
			wc.Expression = expression;
			wc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionOrderByClause(out QueryExpressionOrderClause oc)
		{
			oc = new QueryExpressionOrderClause();
			oc.StartLocation = this.la.Location;
			base.Expect(140);
			QueryExpressionOrdering item;
			this.QueryExpressionOrdering(out item);
			Parser.SafeAdd<QueryExpressionOrdering>(oc, oc.Orderings, item);
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.QueryExpressionOrdering(out item);
				Parser.SafeAdd<QueryExpressionOrdering>(oc, oc.Orderings, item);
			}
			oc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionOrdering(out QueryExpressionOrdering ordering)
		{
			ordering = new QueryExpressionOrdering();
			ordering.StartLocation = this.la.Location;
			Expression criteria;
			this.Expr(out criteria);
			ordering.Criteria = criteria;
			if (this.la.kind == 138 || this.la.kind == 139)
			{
				if (this.la.kind == 138)
				{
					this.lexer.NextToken();
					ordering.Direction = QueryExpressionOrderingDirection.Ascending;
				}
				else
				{
					this.lexer.NextToken();
					ordering.Direction = QueryExpressionOrderingDirection.Descending;
				}
			}
			ordering.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionSelectClause(out QueryExpressionSelectClause sc)
		{
			sc = new QueryExpressionSelectClause();
			sc.StartLocation = this.la.Location;
			base.Expect(133);
			Expression projection;
			this.Expr(out projection);
			sc.Projection = projection;
			sc.EndLocation = this.t.EndLocation;
		}

		private void QueryExpressionWhereClause(out QueryExpressionWhereClause wc)
		{
			wc = new QueryExpressionWhereClause();
			wc.StartLocation = this.la.Location;
			base.Expect(127);
			Expression condition;
			this.Expr(out condition);
			wc.Condition = condition;
			wc.EndLocation = this.t.EndLocation;
		}

		private void RelationalExpr(ref Expression outExpr)
		{
			BinaryOperatorType op = BinaryOperatorType.None;
			this.ShiftExpr(ref outExpr);
			while (this.StartOf(37))
			{
				if (this.StartOf(38))
				{
					if (this.la.kind == 23)
					{
						this.lexer.NextToken();
						op = BinaryOperatorType.LessThan;
					}
					else if (this.la.kind == 22)
					{
						this.lexer.NextToken();
						op = BinaryOperatorType.GreaterThan;
					}
					else if (this.la.kind == 36)
					{
						this.lexer.NextToken();
						op = BinaryOperatorType.LessThanOrEqual;
					}
					else if (this.la.kind == 35)
					{
						this.lexer.NextToken();
						op = BinaryOperatorType.GreaterThanOrEqual;
					}
					else
					{
						base.SynErr(214);
					}
					Expression right;
					this.UnaryExpr(out right);
					this.ShiftExpr(ref right);
					outExpr = new BinaryOperatorExpression(outExpr, op, right);
				}
				else if (this.la.kind == 85)
				{
					this.lexer.NextToken();
					TypeReference typeReference;
					this.TypeWithRestriction(out typeReference, false, false);
					if (this.la.kind == 12 && !this.IsPossibleExpressionStart(this.Peek(1).kind))
					{
						this.NullableQuestionMark(ref typeReference);
					}
					outExpr = new TypeOfIsExpression(outExpr, typeReference);
				}
				else if (this.la.kind == 50)
				{
					this.lexer.NextToken();
					TypeReference typeReference;
					this.TypeWithRestriction(out typeReference, false, false);
					if (this.la.kind == 12 && !this.IsPossibleExpressionStart(this.Peek(1).kind))
					{
						this.NullableQuestionMark(ref typeReference);
					}
					outExpr = new CastExpression(typeReference, outExpr, CastType.TryCast);
				}
				else
				{
					base.SynErr(215);
				}
			}
		}

		private void RemoveAccessorDecl(out Statement stmt)
		{
			stmt = null;
			base.Expect(131);
			this.Block(out stmt);
		}

		private void ResourceAcquisition(out Statement stmt)
		{
			stmt = null;
			if (this.IsLocalVarDecl())
			{
				this.LocalVariableDecl(out stmt);
				return;
			}
			if (this.StartOf(6))
			{
				Expression expression;
				this.Expr(out expression);
				stmt = new ExpressionStatement(expression);
				return;
			}
			base.SynErr(203);
		}

		private static void SafeAdd<T>(INode parent, List<T> list, T item) where T : class, INode
		{
			if (item != null)
			{
				list.Add(item);
				item.Parent = parent;
			}
		}

		private void SetAccessorDecl(out PropertySetRegion setBlock, List<AttributeSection> attributes)
		{
			Statement statement = null;
			base.Expect(129);
			Location location = this.t.Location;
			if (this.la.kind == 16)
			{
				this.Block(out statement);
			}
			else if (this.la.kind == 11)
			{
				this.lexer.NextToken();
			}
			else
			{
				base.SynErr(190);
			}
			setBlock = new PropertySetRegion((BlockStatement)statement, attributes);
			setBlock.StartLocation = location;
			setBlock.EndLocation = this.t.EndLocation;
		}

		private void ShiftExpr(ref Expression outExpr)
		{
			this.AdditiveExpr(ref outExpr);
			while (this.la.kind == 37 || this.IsShiftRight())
			{
				BinaryOperatorType op;
				if (this.la.kind == 37)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.ShiftLeft;
				}
				else
				{
					base.Expect(22);
					base.Expect(22);
					op = BinaryOperatorType.ShiftRight;
				}
				Expression right;
				this.UnaryExpr(out right);
				this.AdditiveExpr(ref right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void ShortedLambdaExpression(IdentifierExpression ident, out Expression pexpr)
		{
			LambdaExpression lambdaExpression = new LambdaExpression();
			pexpr = lambdaExpression;
			base.Expect(48);
			lambdaExpression.StartLocation = ident.StartLocation;
			Parser.SafeAdd<ParameterDeclarationExpression>(lambdaExpression, lambdaExpression.Parameters, new ParameterDeclarationExpression(null, ident.Identifier));
			lambdaExpression.Parameters[0].StartLocation = ident.StartLocation;
			lambdaExpression.Parameters[0].EndLocation = ident.EndLocation;
			this.LambdaExpressionBody(lambdaExpression);
		}

		private bool ShouldConvertTargetExpressionToTypeReference(Expression targetExpr)
		{
			if (targetExpr is IdentifierExpression)
			{
				return ((IdentifierExpression)targetExpr).TypeArguments.Count > 0;
			}
			return targetExpr is MemberReferenceExpression && ((MemberReferenceExpression)targetExpr).TypeArguments.Count > 0;
		}

		private void SimpleType(out string name)
		{
			name = string.Empty;
			if (this.StartOf(24))
			{
				this.IntegralType(out name);
				return;
			}
			if (this.la.kind == 75)
			{
				this.lexer.NextToken();
				name = "System.Single";
				return;
			}
			if (this.la.kind == 66)
			{
				this.lexer.NextToken();
				name = "System.Double";
				return;
			}
			if (this.la.kind == 62)
			{
				this.lexer.NextToken();
				name = "System.Decimal";
				return;
			}
			if (this.la.kind == 52)
			{
				this.lexer.NextToken();
				name = "System.Boolean";
				return;
			}
			base.SynErr(180);
		}

		private bool SkipGeneric(ref Token pt)
		{
			if (pt.kind == 23)
			{
				while (true)
				{
					pt = this.Peek();
					if (!this.IsTypeNameOrKWForTypeCast(ref pt))
					{
						break;
					}
					if (pt.kind != 14)
					{
						goto Block_2;
					}
				}
				return false;
				Block_2:
				if (pt.kind != 22)
				{
					return false;
				}
				pt = this.Peek();
			}
			return true;
		}

		private bool SkipQuestionMark(ref Token pt)
		{
			if (pt.kind == 12)
			{
				pt = this.Peek();
			}
			return true;
		}

		private bool StartOf(int s)
		{
			return Parser.set[s, this.lexer.LookAhead.kind];
		}

		private bool StartOfQueryExpression()
		{
			if (this.la.kind == 137)
			{
				Token token = this.Peek(1);
				if (Parser.IsIdentifierToken(token) || Tokens.TypeKW[token.kind])
				{
					return true;
				}
			}
			return false;
		}

		private void StartPeek()
		{
			this.lexer.StartPeek();
		}

		private void Statement()
		{
			Statement statement = null;
			Location location = this.la.Location;
			while (!this.StartOf(29))
			{
				base.SynErr(192);
				this.lexer.NextToken();
			}
			if (this.IsLabel())
			{
				this.Identifier();
				this.compilationUnit.AddChild(new LabelStatement(this.t.val));
				base.Expect(9);
				this.Statement();
			}
			else if (this.la.kind == 60)
			{
				this.lexer.NextToken();
				this.LocalVariableDecl(out statement);
				if (statement != null)
				{
					((LocalVariableDeclaration)statement).Modifier |= Modifiers.Const;
				}
				base.Expect(11);
				this.compilationUnit.AddChild(statement);
			}
			else if (this.IsLocalVarDecl())
			{
				this.LocalVariableDecl(out statement);
				base.Expect(11);
				this.compilationUnit.AddChild(statement);
			}
			else if (this.StartOf(30))
			{
				this.EmbeddedStatement(out statement);
				this.compilationUnit.AddChild(statement);
			}
			else
			{
				base.SynErr(193);
			}
			if (statement != null)
			{
				statement.StartLocation = location;
				statement.EndLocation = this.t.EndLocation;
			}
		}

		private void StatementExpr(out Statement stmt)
		{
			Expression expression;
			this.Expr(out expression);
			stmt = new ExpressionStatement(expression);
		}

		private void StructBody()
		{
			base.Expect(16);
			while (this.StartOf(14))
			{
				List<AttributeSection> list = new List<AttributeSection>();
				ModifierList m = new ModifierList();
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				this.MemberModifiers(m);
				this.StructMemberDecl(m, list);
			}
			base.Expect(17);
		}

		private void StructInterfaces(out List<TypeReference> names)
		{
			names = new List<TypeReference>();
			base.Expect(9);
			TypeReference typeReference;
			this.TypeName(out typeReference, false);
			if (typeReference != null)
			{
				names.Add(typeReference);
			}
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference, false);
				if (typeReference != null)
				{
					names.Add(typeReference);
				}
			}
		}

		private void StructMemberDecl(ModifierList m, List<AttributeSection> attributes)
		{
			string text = null;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			Statement statement = null;
			List<TemplateDefinition> templates = new List<TemplateDefinition>();
			TypeReference typeReference = null;
			bool isExtensionMethod = false;
			TypeReference typeReference2;
			if (this.la.kind == 60)
			{
				m.Check(Modifiers.VBStructures);
				this.lexer.NextToken();
				Location location = this.t.Location;
				this.Type(out typeReference2);
				this.Identifier();
				FieldDeclaration fieldDeclaration = new FieldDeclaration(attributes, typeReference2, m.Modifier | Modifiers.Const);
				fieldDeclaration.StartLocation = m.GetDeclarationLocation(location);
				VariableDeclaration variableDeclaration = new VariableDeclaration(this.t.val);
				variableDeclaration.StartLocation = this.t.Location;
				variableDeclaration.TypeReference = typeReference2;
				Parser.SafeAdd<VariableDeclaration>(fieldDeclaration, fieldDeclaration.Fields, variableDeclaration);
				base.Expect(3);
				Expression expression;
				this.Expr(out expression);
				variableDeclaration.Initializer = expression;
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.Identifier();
					variableDeclaration = new VariableDeclaration(this.t.val);
					variableDeclaration.StartLocation = this.t.Location;
					variableDeclaration.TypeReference = typeReference2;
					Parser.SafeAdd<VariableDeclaration>(fieldDeclaration, fieldDeclaration.Fields, variableDeclaration);
					base.Expect(3);
					this.Expr(out expression);
					variableDeclaration.EndLocation = this.t.EndLocation;
					variableDeclaration.Initializer = expression;
				}
				base.Expect(11);
				fieldDeclaration.EndLocation = this.t.EndLocation;
				this.compilationUnit.AddChild(fieldDeclaration);
				return;
			}
			if (this.NotVoidPointer())
			{
				m.Check(Modifiers.PropertysEventsMethods);
				base.Expect(123);
				Location location2 = this.t.Location;
				if (this.IsExplicitInterfaceImplementation())
				{
					this.TypeName(out typeReference, false);
					if (this.la.kind != 15 || this.Peek(1).kind != 111)
					{
						text = TypeReference.StripLastIdentifierFromType(ref typeReference);
					}
				}
				else if (this.StartOf(19))
				{
					this.Identifier();
					text = this.t.val;
				}
				else
				{
					base.SynErr(162);
				}
				if (this.la.kind == 23)
				{
					this.TypeParameterList(templates);
				}
				base.Expect(20);
				if (this.la.kind == 111)
				{
					this.lexer.NextToken();
					isExtensionMethod = true;
				}
				if (this.StartOf(11))
				{
					this.FormalParameterList(list);
				}
				base.Expect(21);
				MethodDeclaration methodDeclaration = new MethodDeclaration
				{
					Name = text,
					Modifier = m.Modifier,
					TypeReference = new TypeReference("System.Void", true),
					Parameters = list,
					Attributes = attributes,
					StartLocation = m.GetDeclarationLocation(location2),
					EndLocation = this.t.EndLocation,
					Templates = templates,
					IsExtensionMethod = isExtensionMethod
				};
				if (typeReference != null)
				{
					Parser.SafeAdd<InterfaceImplementation>(methodDeclaration, methodDeclaration.InterfaceImplementations, new InterfaceImplementation(typeReference, text));
				}
				this.compilationUnit.AddChild(methodDeclaration);
				this.compilationUnit.BlockStart(methodDeclaration);
				while (this.la.kind == 127)
				{
					this.TypeParameterConstraintsClause(templates);
				}
				if (this.la.kind == 16)
				{
					this.Block(out statement);
				}
				else if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				else
				{
					base.SynErr(163);
				}
				this.compilationUnit.BlockEnd();
				methodDeclaration.Body = (BlockStatement)statement;
				return;
			}
			if (this.la.kind == 69)
			{
				m.Check(Modifiers.PropertysEventsMethods);
				this.lexer.NextToken();
				EventDeclaration eventDeclaration = new EventDeclaration
				{
					Modifier = m.Modifier,
					Attributes = attributes,
					StartLocation = this.t.Location
				};
				this.compilationUnit.AddChild(eventDeclaration);
				this.compilationUnit.BlockStart(eventDeclaration);
				EventAddRegion addRegion = null;
				EventRemoveRegion removeRegion = null;
				this.Type(out typeReference2);
				eventDeclaration.TypeReference = typeReference2;
				if (this.IsExplicitInterfaceImplementation())
				{
					this.TypeName(out typeReference, false);
					text = TypeReference.StripLastIdentifierFromType(ref typeReference);
					eventDeclaration.InterfaceImplementations.Add(new InterfaceImplementation(typeReference, text));
				}
				else if (this.StartOf(19))
				{
					this.Identifier();
					text = this.t.val;
					if (this.la.kind == 3)
					{
						this.lexer.NextToken();
						Expression expression;
						this.Expr(out expression);
						eventDeclaration.Initializer = expression;
					}
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						eventDeclaration.Name = text;
						eventDeclaration.EndLocation = this.t.EndLocation;
						this.compilationUnit.BlockEnd();
						eventDeclaration = new EventDeclaration
						{
							Modifier = eventDeclaration.Modifier,
							Attributes = eventDeclaration.Attributes,
							StartLocation = eventDeclaration.StartLocation,
							TypeReference = eventDeclaration.TypeReference.Clone()
						};
						this.compilationUnit.AddChild(eventDeclaration);
						this.compilationUnit.BlockStart(eventDeclaration);
						this.Identifier();
						text = this.t.val;
						if (this.la.kind == 3)
						{
							this.lexer.NextToken();
							Expression expression;
							this.Expr(out expression);
							eventDeclaration.Initializer = expression;
						}
					}
				}
				else
				{
					base.SynErr(164);
				}
				eventDeclaration.Name = text;
				eventDeclaration.EndLocation = this.t.EndLocation;
				if (this.la.kind == 16)
				{
					this.lexer.NextToken();
					eventDeclaration.BodyStart = this.t.Location;
					this.EventAccessorDecls(out addRegion, out removeRegion);
					base.Expect(17);
					eventDeclaration.BodyEnd = this.t.EndLocation;
				}
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				this.compilationUnit.BlockEnd();
				eventDeclaration.AddRegion = addRegion;
				eventDeclaration.RemoveRegion = removeRegion;
				return;
			}
			if (this.IdentAndLPar())
			{
				m.Check(Modifiers.Private | Modifiers.Internal | Modifiers.Protected | Modifiers.Public | Modifiers.Static | Modifiers.Extern | Modifiers.Unsafe);
				this.Identifier();
				string val = this.t.val;
				Location location3 = this.t.Location;
				base.Expect(20);
				if (this.StartOf(11))
				{
					m.Check(Modifiers.Constructors);
					this.FormalParameterList(list);
				}
				base.Expect(21);
				ConstructorInitializer constructorInitializer = null;
				if (this.la.kind == 9)
				{
					m.Check(Modifiers.Constructors);
					this.ConstructorInitializer(out constructorInitializer);
				}
				ConstructorDeclaration constructorDeclaration = new ConstructorDeclaration(val, m.Modifier, list, constructorInitializer, attributes);
				constructorDeclaration.StartLocation = location3;
				constructorDeclaration.EndLocation = this.t.EndLocation;
				if (this.la.kind == 16)
				{
					this.Block(out statement);
				}
				else if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				else
				{
					base.SynErr(165);
				}
				constructorDeclaration.Body = (BlockStatement)statement;
				this.compilationUnit.AddChild(constructorDeclaration);
				return;
			}
			if (this.la.kind == 70 || this.la.kind == 80)
			{
				m.Check(Modifiers.Operators);
				if (m.isNone)
				{
					this.Error("at least one modifier must be set");
				}
				bool flag = true;
				Location keywordLocation = Location.Empty;
				if (this.la.kind == 80)
				{
					this.lexer.NextToken();
					keywordLocation = this.t.Location;
				}
				else
				{
					this.lexer.NextToken();
					flag = false;
					keywordLocation = this.t.Location;
				}
				base.Expect(92);
				this.Type(out typeReference2);
				TypeReference typeReference3 = typeReference2;
				base.Expect(20);
				this.Type(out typeReference2);
				this.Identifier();
				string val2 = this.t.val;
				base.Expect(21);
				Location location4 = this.t.Location;
				if (this.la.kind == 16)
				{
					this.Block(out statement);
				}
				else if (this.la.kind == 11)
				{
					this.lexer.NextToken();
					statement = null;
				}
				else
				{
					base.SynErr(166);
				}
				List<ParameterDeclarationExpression> list2 = new List<ParameterDeclarationExpression>();
				list2.Add(new ParameterDeclarationExpression(typeReference2, val2));
				OperatorDeclaration childNode = new OperatorDeclaration
				{
					Name = (flag ? "op_Implicit" : "op_Explicit"),
					Modifier = m.Modifier,
					Attributes = attributes,
					Parameters = list2,
					TypeReference = typeReference3,
					ConversionType = (flag ? ConversionType.Implicit : ConversionType.Explicit),
					Body = (BlockStatement)statement,
					StartLocation = m.GetDeclarationLocation(keywordLocation),
					EndLocation = location4
				};
				this.compilationUnit.AddChild(childNode);
				return;
			}
			if (this.StartOf(22))
			{
				this.TypeDecl(m, attributes);
				return;
			}
			if (!this.StartOf(10))
			{
				base.SynErr(174);
				return;
			}
			this.Type(out typeReference2);
			Location location5 = this.t.Location;
			if (this.la.kind == 92)
			{
				m.Check(Modifiers.Operators);
				if (m.isNone)
				{
					this.Error("at least one modifier must be set");
				}
				this.lexer.NextToken();
				OverloadableOperatorType overloadableOperatorType;
				this.OverloadableOperator(out overloadableOperatorType);
				TypeReference typeReference4 = null;
				string parameterName = null;
				base.Expect(20);
				TypeReference typeReference5;
				this.Type(out typeReference5);
				this.Identifier();
				string val3 = this.t.val;
				if (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.Type(out typeReference4);
					this.Identifier();
					parameterName = this.t.val;
				}
				else if (this.la.kind != 21)
				{
					base.SynErr(167);
				}
				Location location6 = this.t.Location;
				base.Expect(21);
				if (this.la.kind == 16)
				{
					this.Block(out statement);
				}
				else if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				else
				{
					base.SynErr(168);
				}
				if (overloadableOperatorType == OverloadableOperatorType.Add && typeReference4 == null)
				{
					overloadableOperatorType = OverloadableOperatorType.UnaryPlus;
				}
				if (overloadableOperatorType == OverloadableOperatorType.Subtract && typeReference4 == null)
				{
					overloadableOperatorType = OverloadableOperatorType.UnaryMinus;
				}
				OperatorDeclaration operatorDeclaration = new OperatorDeclaration
				{
					Modifier = m.Modifier,
					Attributes = attributes,
					TypeReference = typeReference2,
					OverloadableOperator = overloadableOperatorType,
					Name = Parser.GetReflectionNameForOperator(overloadableOperatorType),
					Body = (BlockStatement)statement,
					StartLocation = m.GetDeclarationLocation(location5),
					EndLocation = location6
				};
				Parser.SafeAdd<ParameterDeclarationExpression>(operatorDeclaration, operatorDeclaration.Parameters, new ParameterDeclarationExpression(typeReference5, val3));
				if (typeReference4 != null)
				{
					Parser.SafeAdd<ParameterDeclarationExpression>(operatorDeclaration, operatorDeclaration.Parameters, new ParameterDeclarationExpression(typeReference4, parameterName));
				}
				this.compilationUnit.AddChild(operatorDeclaration);
				return;
			}
			if (this.IsVarDecl())
			{
				m.Check(Modifiers.Fields);
				FieldDeclaration fieldDeclaration2 = new FieldDeclaration(attributes, typeReference2, m.Modifier);
				fieldDeclaration2.StartLocation = m.GetDeclarationLocation(location5);
				if (m.Contains(Modifiers.Fixed))
				{
					this.VariableDeclarator(fieldDeclaration2);
					base.Expect(18);
					Expression expression;
					this.Expr(out expression);
					if (fieldDeclaration2.Fields.Count > 0)
					{
						fieldDeclaration2.Fields[fieldDeclaration2.Fields.Count - 1].FixedArrayInitialization = expression;
					}
					base.Expect(19);
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						this.VariableDeclarator(fieldDeclaration2);
						base.Expect(18);
						this.Expr(out expression);
						if (fieldDeclaration2.Fields.Count > 0)
						{
							fieldDeclaration2.Fields[fieldDeclaration2.Fields.Count - 1].FixedArrayInitialization = expression;
						}
						base.Expect(19);
					}
				}
				else if (this.StartOf(19))
				{
					this.VariableDeclarator(fieldDeclaration2);
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						this.VariableDeclarator(fieldDeclaration2);
					}
				}
				else
				{
					base.SynErr(169);
				}
				base.Expect(11);
				fieldDeclaration2.EndLocation = this.t.EndLocation;
				this.compilationUnit.AddChild(fieldDeclaration2);
				return;
			}
			if (this.la.kind == 111)
			{
				m.Check(Modifiers.Indexers);
				this.lexer.NextToken();
				base.Expect(18);
				this.FormalParameterList(list);
				base.Expect(19);
				Location endLocation = this.t.EndLocation;
				base.Expect(16);
				IndexerDeclaration indexerDeclaration = new IndexerDeclaration(typeReference2, list, m.Modifier, attributes);
				indexerDeclaration.StartLocation = location5;
				indexerDeclaration.EndLocation = endLocation;
				indexerDeclaration.BodyStart = this.t.Location;
				PropertyGetRegion getRegion;
				PropertySetRegion setRegion;
				this.AccessorDecls(out getRegion, out setRegion);
				base.Expect(17);
				indexerDeclaration.BodyEnd = this.t.EndLocation;
				indexerDeclaration.GetRegion = getRegion;
				indexerDeclaration.SetRegion = setRegion;
				this.compilationUnit.AddChild(indexerDeclaration);
				return;
			}
			if (!Parser.IsIdentifierToken(this.la))
			{
				base.SynErr(173);
				return;
			}
			if (this.IsExplicitInterfaceImplementation())
			{
				this.TypeName(out typeReference, false);
				if (this.la.kind != 15 || this.Peek(1).kind != 111)
				{
					text = TypeReference.StripLastIdentifierFromType(ref typeReference);
				}
			}
			else if (this.StartOf(19))
			{
				this.Identifier();
				text = this.t.val;
			}
			else
			{
				base.SynErr(170);
			}
			Location endLocation2 = this.t.EndLocation;
			if (this.la.kind == 16 || this.la.kind == 20 || this.la.kind == 23)
			{
				if (this.la.kind == 20 || this.la.kind == 23)
				{
					m.Check(Modifiers.PropertysEventsMethods);
					if (this.la.kind == 23)
					{
						this.TypeParameterList(templates);
					}
					base.Expect(20);
					if (this.la.kind == 111)
					{
						this.lexer.NextToken();
						isExtensionMethod = true;
					}
					if (this.StartOf(11))
					{
						this.FormalParameterList(list);
					}
					base.Expect(21);
					MethodDeclaration methodDeclaration2 = new MethodDeclaration
					{
						Name = text,
						Modifier = m.Modifier,
						TypeReference = typeReference2,
						Parameters = list,
						Attributes = attributes
					};
					if (typeReference != null)
					{
						methodDeclaration2.InterfaceImplementations.Add(new InterfaceImplementation(typeReference, text));
					}
					methodDeclaration2.StartLocation = m.GetDeclarationLocation(location5);
					methodDeclaration2.EndLocation = this.t.EndLocation;
					methodDeclaration2.IsExtensionMethod = isExtensionMethod;
					methodDeclaration2.Templates = templates;
					this.compilationUnit.AddChild(methodDeclaration2);
					while (this.la.kind == 127)
					{
						this.TypeParameterConstraintsClause(templates);
					}
					if (this.la.kind == 16)
					{
						this.Block(out statement);
					}
					else if (this.la.kind == 11)
					{
						this.lexer.NextToken();
					}
					else
					{
						base.SynErr(171);
					}
					methodDeclaration2.Body = (BlockStatement)statement;
					return;
				}
				this.lexer.NextToken();
				PropertyDeclaration propertyDeclaration = new PropertyDeclaration(text, typeReference2, m.Modifier, attributes);
				if (typeReference != null)
				{
					propertyDeclaration.InterfaceImplementations.Add(new InterfaceImplementation(typeReference, text));
				}
				propertyDeclaration.StartLocation = m.GetDeclarationLocation(location5);
				propertyDeclaration.EndLocation = endLocation2;
				propertyDeclaration.BodyStart = this.t.Location;
				PropertyGetRegion getRegion2;
				PropertySetRegion setRegion2;
				this.AccessorDecls(out getRegion2, out setRegion2);
				base.Expect(17);
				propertyDeclaration.GetRegion = getRegion2;
				propertyDeclaration.SetRegion = setRegion2;
				propertyDeclaration.BodyEnd = this.t.EndLocation;
				this.compilationUnit.AddChild(propertyDeclaration);
				return;
			}
			else
			{
				if (this.la.kind == 15)
				{
					m.Check(Modifiers.Indexers);
					this.lexer.NextToken();
					base.Expect(111);
					base.Expect(18);
					this.FormalParameterList(list);
					base.Expect(19);
					IndexerDeclaration indexerDeclaration2 = new IndexerDeclaration(typeReference2, list, m.Modifier, attributes);
					indexerDeclaration2.StartLocation = m.GetDeclarationLocation(location5);
					indexerDeclaration2.EndLocation = this.t.EndLocation;
					if (typeReference != null)
					{
						Parser.SafeAdd<InterfaceImplementation>(indexerDeclaration2, indexerDeclaration2.InterfaceImplementations, new InterfaceImplementation(typeReference, "this"));
					}
					base.Expect(16);
					Location location7 = this.t.Location;
					PropertyGetRegion getRegion3;
					PropertySetRegion setRegion3;
					this.AccessorDecls(out getRegion3, out setRegion3);
					base.Expect(17);
					indexerDeclaration2.BodyStart = location7;
					indexerDeclaration2.BodyEnd = this.t.EndLocation;
					indexerDeclaration2.GetRegion = getRegion3;
					indexerDeclaration2.SetRegion = setRegion3;
					this.compilationUnit.AddChild(indexerDeclaration2);
					return;
				}
				base.SynErr(172);
				return;
			}
		}

		private void SwitchLabel(out CaseLabel label)
		{
			Expression label2 = null;
			label = null;
			if (this.la.kind == 55)
			{
				this.lexer.NextToken();
				this.Expr(out label2);
				base.Expect(9);
				label = new CaseLabel(label2);
				return;
			}
			if (this.la.kind == 63)
			{
				this.lexer.NextToken();
				base.Expect(9);
				label = new CaseLabel();
				return;
			}
			base.SynErr(204);
		}

		private void SwitchSections(List<SwitchSection> switchSections)
		{
			SwitchSection switchSection = new SwitchSection();
			CaseLabel caseLabel;
			this.SwitchLabel(out caseLabel);
			Parser.SafeAdd<CaseLabel>(switchSection, switchSection.SwitchLabels, caseLabel);
			this.compilationUnit.BlockStart(switchSection);
			while (this.StartOf(32))
			{
				if (this.la.kind == 55 || this.la.kind == 63)
				{
					this.SwitchLabel(out caseLabel);
					if (caseLabel != null)
					{
						if (switchSection.Children.Count > 0)
						{
							this.compilationUnit.BlockEnd();
							switchSections.Add(switchSection);
							switchSection = new SwitchSection();
							this.compilationUnit.BlockStart(switchSection);
						}
						Parser.SafeAdd<CaseLabel>(switchSection, switchSection.SwitchLabels, caseLabel);
					}
				}
				else
				{
					this.Statement();
				}
			}
			this.compilationUnit.BlockEnd();
			switchSections.Add(switchSection);
		}

		protected override void SynErr(int line, int col, int errorNumber)
		{
			string msg;
			switch (errorNumber)
			{
			case 0:
				msg = "EOF expected";
				break;
			case 1:
				msg = "ident expected";
				break;
			case 2:
				msg = "Literal expected";
				break;
			case 3:
				msg = "\"=\" expected";
				break;
			case 4:
				msg = "\"+\" expected";
				break;
			case 5:
				msg = "\"-\" expected";
				break;
			case 6:
				msg = "\"*\" expected";
				break;
			case 7:
				msg = "\"/\" expected";
				break;
			case 8:
				msg = "\"%\" expected";
				break;
			case 9:
				msg = "\":\" expected";
				break;
			case 10:
				msg = "\"::\" expected";
				break;
			case 11:
				msg = "\";\" expected";
				break;
			case 12:
				msg = "\"?\" expected";
				break;
			case 13:
				msg = "\"??\" expected";
				break;
			case 14:
				msg = "\",\" expected";
				break;
			case 15:
				msg = "\".\" expected";
				break;
			case 16:
				msg = "\"{\" expected";
				break;
			case 17:
				msg = "\"}\" expected";
				break;
			case 18:
				msg = "\"[\" expected";
				break;
			case 19:
				msg = "\"]\" expected";
				break;
			case 20:
				msg = "\"(\" expected";
				break;
			case 21:
				msg = "\")\" expected";
				break;
			case 22:
				msg = "\">\" expected";
				break;
			case 23:
				msg = "\"<\" expected";
				break;
			case 24:
				msg = "\"!\" expected";
				break;
			case 25:
				msg = "\"&&\" expected";
				break;
			case 26:
				msg = "\"||\" expected";
				break;
			case 27:
				msg = "\"~\" expected";
				break;
			case 28:
				msg = "\"&\" expected";
				break;
			case 29:
				msg = "\"|\" expected";
				break;
			case 30:
				msg = "\"^\" expected";
				break;
			case 31:
				msg = "\"++\" expected";
				break;
			case 32:
				msg = "\"--\" expected";
				break;
			case 33:
				msg = "\"==\" expected";
				break;
			case 34:
				msg = "\"!=\" expected";
				break;
			case 35:
				msg = "\">=\" expected";
				break;
			case 36:
				msg = "\"<=\" expected";
				break;
			case 37:
				msg = "\"<<\" expected";
				break;
			case 38:
				msg = "\"+=\" expected";
				break;
			case 39:
				msg = "\"-=\" expected";
				break;
			case 40:
				msg = "\"*=\" expected";
				break;
			case 41:
				msg = "\"/=\" expected";
				break;
			case 42:
				msg = "\"%=\" expected";
				break;
			case 43:
				msg = "\"&=\" expected";
				break;
			case 44:
				msg = "\"|=\" expected";
				break;
			case 45:
				msg = "\"^=\" expected";
				break;
			case 46:
				msg = "\"<<=\" expected";
				break;
			case 47:
				msg = "\"->\" expected";
				break;
			case 48:
				msg = "\"=>\" expected";
				break;
			case 49:
				msg = "\"abstract\" expected";
				break;
			case 50:
				msg = "\"as\" expected";
				break;
			case 51:
				msg = "\"base\" expected";
				break;
			case 52:
				msg = "\"bool\" expected";
				break;
			case 53:
				msg = "\"break\" expected";
				break;
			case 54:
				msg = "\"byte\" expected";
				break;
			case 55:
				msg = "\"case\" expected";
				break;
			case 56:
				msg = "\"catch\" expected";
				break;
			case 57:
				msg = "\"char\" expected";
				break;
			case 58:
				msg = "\"checked\" expected";
				break;
			case 59:
				msg = "\"class\" expected";
				break;
			case 60:
				msg = "\"const\" expected";
				break;
			case 61:
				msg = "\"continue\" expected";
				break;
			case 62:
				msg = "\"decimal\" expected";
				break;
			case 63:
				msg = "\"default\" expected";
				break;
			case 64:
				msg = "\"delegate\" expected";
				break;
			case 65:
				msg = "\"do\" expected";
				break;
			case 66:
				msg = "\"double\" expected";
				break;
			case 67:
				msg = "\"else\" expected";
				break;
			case 68:
				msg = "\"enum\" expected";
				break;
			case 69:
				msg = "\"event\" expected";
				break;
			case 70:
				msg = "\"explicit\" expected";
				break;
			case 71:
				msg = "\"extern\" expected";
				break;
			case 72:
				msg = "\"false\" expected";
				break;
			case 73:
				msg = "\"finally\" expected";
				break;
			case 74:
				msg = "\"fixed\" expected";
				break;
			case 75:
				msg = "\"float\" expected";
				break;
			case 76:
				msg = "\"for\" expected";
				break;
			case 77:
				msg = "\"foreach\" expected";
				break;
			case 78:
				msg = "\"goto\" expected";
				break;
			case 79:
				msg = "\"if\" expected";
				break;
			case 80:
				msg = "\"implicit\" expected";
				break;
			case 81:
				msg = "\"in\" expected";
				break;
			case 82:
				msg = "\"int\" expected";
				break;
			case 83:
				msg = "\"interface\" expected";
				break;
			case 84:
				msg = "\"internal\" expected";
				break;
			case 85:
				msg = "\"is\" expected";
				break;
			case 86:
				msg = "\"lock\" expected";
				break;
			case 87:
				msg = "\"long\" expected";
				break;
			case 88:
				msg = "\"namespace\" expected";
				break;
			case 89:
				msg = "\"new\" expected";
				break;
			case 90:
				msg = "\"null\" expected";
				break;
			case 91:
				msg = "\"object\" expected";
				break;
			case 92:
				msg = "\"operator\" expected";
				break;
			case 93:
				msg = "\"out\" expected";
				break;
			case 94:
				msg = "\"override\" expected";
				break;
			case 95:
				msg = "\"params\" expected";
				break;
			case 96:
				msg = "\"private\" expected";
				break;
			case 97:
				msg = "\"protected\" expected";
				break;
			case 98:
				msg = "\"public\" expected";
				break;
			case 99:
				msg = "\"readonly\" expected";
				break;
			case 100:
				msg = "\"ref\" expected";
				break;
			case 101:
				msg = "\"return\" expected";
				break;
			case 102:
				msg = "\"sbyte\" expected";
				break;
			case 103:
				msg = "\"sealed\" expected";
				break;
			case 104:
				msg = "\"short\" expected";
				break;
			case 105:
				msg = "\"sizeof\" expected";
				break;
			case 106:
				msg = "\"stackalloc\" expected";
				break;
			case 107:
				msg = "\"static\" expected";
				break;
			case 108:
				msg = "\"string\" expected";
				break;
			case 109:
				msg = "\"struct\" expected";
				break;
			case 110:
				msg = "\"switch\" expected";
				break;
			case 111:
				msg = "\"this\" expected";
				break;
			case 112:
				msg = "\"throw\" expected";
				break;
			case 113:
				msg = "\"true\" expected";
				break;
			case 114:
				msg = "\"try\" expected";
				break;
			case 115:
				msg = "\"typeof\" expected";
				break;
			case 116:
				msg = "\"uint\" expected";
				break;
			case 117:
				msg = "\"ulong\" expected";
				break;
			case 118:
				msg = "\"unchecked\" expected";
				break;
			case 119:
				msg = "\"unsafe\" expected";
				break;
			case 120:
				msg = "\"ushort\" expected";
				break;
			case 121:
				msg = "\"using\" expected";
				break;
			case 122:
				msg = "\"virtual\" expected";
				break;
			case 123:
				msg = "\"void\" expected";
				break;
			case 124:
				msg = "\"volatile\" expected";
				break;
			case 125:
				msg = "\"while\" expected";
				break;
			case 126:
				msg = "\"partial\" expected";
				break;
			case 127:
				msg = "\"where\" expected";
				break;
			case 128:
				msg = "\"get\" expected";
				break;
			case 129:
				msg = "\"set\" expected";
				break;
			case 130:
				msg = "\"add\" expected";
				break;
			case 131:
				msg = "\"remove\" expected";
				break;
			case 132:
				msg = "\"yield\" expected";
				break;
			case 133:
				msg = "\"select\" expected";
				break;
			case 134:
				msg = "\"group\" expected";
				break;
			case 135:
				msg = "\"by\" expected";
				break;
			case 136:
				msg = "\"into\" expected";
				break;
			case 137:
				msg = "\"from\" expected";
				break;
			case 138:
				msg = "\"ascending\" expected";
				break;
			case 139:
				msg = "\"descending\" expected";
				break;
			case 140:
				msg = "\"orderby\" expected";
				break;
			case 141:
				msg = "\"let\" expected";
				break;
			case 142:
				msg = "\"join\" expected";
				break;
			case 143:
				msg = "\"on\" expected";
				break;
			case 144:
				msg = "\"equals\" expected";
				break;
			case 145:
				msg = "??? expected";
				break;
			case 146:
				msg = "invalid NamespaceMemberDecl";
				break;
			case 147:
				msg = "invalid Identifier";
				break;
			case 148:
				msg = "invalid NonArrayType";
				break;
			case 149:
				msg = "invalid AttributeArguments";
				break;
			case 150:
				msg = "invalid Expr";
				break;
			case 151:
				msg = "invalid TypeModifier";
				break;
			case 152:
				msg = "invalid TypeDecl";
				break;
			case 153:
				msg = "invalid TypeDecl";
				break;
			case 154:
				msg = "this symbol not expected in ClassBody";
				break;
			case 155:
				msg = "this symbol not expected in InterfaceBody";
				break;
			case 156:
				msg = "invalid IntegralType";
				break;
			case 157:
				msg = "invalid FormalParameterList";
				break;
			case 158:
				msg = "invalid FormalParameterList";
				break;
			case 159:
				msg = "invalid ClassType";
				break;
			case 160:
				msg = "invalid ClassMemberDecl";
				break;
			case 161:
				msg = "invalid ClassMemberDecl";
				break;
			case 162:
				msg = "invalid StructMemberDecl";
				break;
			case 163:
				msg = "invalid StructMemberDecl";
				break;
			case 164:
				msg = "invalid StructMemberDecl";
				break;
			case 165:
				msg = "invalid StructMemberDecl";
				break;
			case 166:
				msg = "invalid StructMemberDecl";
				break;
			case 167:
				msg = "invalid StructMemberDecl";
				break;
			case 168:
				msg = "invalid StructMemberDecl";
				break;
			case 169:
				msg = "invalid StructMemberDecl";
				break;
			case 170:
				msg = "invalid StructMemberDecl";
				break;
			case 171:
				msg = "invalid StructMemberDecl";
				break;
			case 172:
				msg = "invalid StructMemberDecl";
				break;
			case 173:
				msg = "invalid StructMemberDecl";
				break;
			case 174:
				msg = "invalid StructMemberDecl";
				break;
			case 175:
				msg = "invalid InterfaceMemberDecl";
				break;
			case 176:
				msg = "invalid InterfaceMemberDecl";
				break;
			case 177:
				msg = "invalid InterfaceMemberDecl";
				break;
			case 178:
				msg = "invalid TypeWithRestriction";
				break;
			case 179:
				msg = "invalid TypeWithRestriction";
				break;
			case 180:
				msg = "invalid SimpleType";
				break;
			case 181:
				msg = "invalid AccessorModifiers";
				break;
			case 182:
				msg = "this symbol not expected in Block";
				break;
			case 183:
				msg = "invalid EventAccessorDecls";
				break;
			case 184:
				msg = "invalid ConstructorInitializer";
				break;
			case 185:
				msg = "invalid OverloadableOperator";
				break;
			case 186:
				msg = "invalid AccessorDecls";
				break;
			case 187:
				msg = "invalid InterfaceAccessors";
				break;
			case 188:
				msg = "invalid InterfaceAccessors";
				break;
			case 189:
				msg = "invalid GetAccessorDecl";
				break;
			case 190:
				msg = "invalid SetAccessorDecl";
				break;
			case 191:
				msg = "invalid VariableInitializer";
				break;
			case 192:
				msg = "this symbol not expected in Statement";
				break;
			case 193:
				msg = "invalid Statement";
				break;
			case 194:
				msg = "invalid AssignmentOperator";
				break;
			case 195:
				msg = "invalid ObjectPropertyInitializerOrVariableInitializer";
				break;
			case 196:
				msg = "invalid ObjectPropertyInitializerOrVariableInitializer";
				break;
			case 197:
				msg = "invalid EmbeddedStatement";
				break;
			case 198:
				msg = "invalid EmbeddedStatement";
				break;
			case 199:
				msg = "this symbol not expected in EmbeddedStatement";
				break;
			case 200:
				msg = "invalid EmbeddedStatement";
				break;
			case 201:
				msg = "invalid ForInitializer";
				break;
			case 202:
				msg = "invalid GotoStatement";
				break;
			case 203:
				msg = "invalid ResourceAcquisition";
				break;
			case 204:
				msg = "invalid SwitchLabel";
				break;
			case 205:
				msg = "invalid CatchClause";
				break;
			case 206:
				msg = "invalid UnaryExpr";
				break;
			case 207:
				msg = "invalid PrimaryExpr";
				break;
			case 208:
				msg = "invalid PrimaryExpr";
				break;
			case 209:
				msg = "invalid TypeArgumentList";
				break;
			case 210:
				msg = "invalid NewExpression";
				break;
			case 211:
				msg = "invalid NewExpression";
				break;
			case 212:
				msg = "invalid LambdaExpressionParameter";
				break;
			case 213:
				msg = "invalid LambdaExpressionBody";
				break;
			case 214:
				msg = "invalid RelationalExpr";
				break;
			case 215:
				msg = "invalid RelationalExpr";
				break;
			case 216:
				msg = "invalid TypeParameterConstraintsClauseBase";
				break;
			case 217:
				msg = "invalid QueryExpressionBody";
				break;
			default:
				msg = "error " + errorNumber;
				break;
			}
			base.Errors.Error(line, col, msg);
		}

		private bool TimesOrLBrackAndCommaOrRBrack()
		{
			return this.la.kind == 6 || this.LBrackAndCommaOrRBrack();
		}

		private void TryStatement(out Statement tryStatement)
		{
			Statement statementBlock = null;
			Statement finallyBlock = null;
			CatchClause catchClause = null;
			List<CatchClause> list = new List<CatchClause>();
			base.Expect(114);
			this.Block(out statementBlock);
			while (this.la.kind == 56)
			{
				this.CatchClause(out catchClause);
				if (catchClause != null)
				{
					list.Add(catchClause);
				}
			}
			if (this.la.kind == 73)
			{
				this.lexer.NextToken();
				this.Block(out finallyBlock);
			}
			tryStatement = new TryCatchStatement(statementBlock, list, finallyBlock);
			if (list != null)
			{
				foreach (CatchClause current in list)
				{
					current.Parent = tryStatement;
				}
			}
		}

		private void Type(out TypeReference type)
		{
			this.TypeWithRestriction(out type, true, false);
		}

		private void TypeArgumentList(out List<TypeReference> types, bool canBeUnbound)
		{
			types = new List<TypeReference>();
			TypeReference typeReference = null;
			base.Expect(23);
			if (canBeUnbound && (this.la.kind == 22 || this.la.kind == 14))
			{
				types.Add(TypeReference.Null);
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					types.Add(TypeReference.Null);
				}
			}
			else if (this.StartOf(10))
			{
				this.Type(out typeReference);
				if (typeReference != null)
				{
					types.Add(typeReference);
				}
				while (this.la.kind == 14)
				{
					this.lexer.NextToken();
					this.Type(out typeReference);
					if (typeReference != null)
					{
						types.Add(typeReference);
					}
				}
			}
			else
			{
				base.SynErr(209);
			}
			base.Expect(22);
		}

		private void TypeDecl(ModifierList m, List<AttributeSection> attributes)
		{
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			List<TemplateDefinition> templates;
			if (this.la.kind == 59)
			{
				m.Check(Modifiers.Classes);
				this.lexer.NextToken();
				TypeDeclaration typeDeclaration = new TypeDeclaration(m.Modifier, attributes);
				templates = typeDeclaration.Templates;
				this.compilationUnit.AddChild(typeDeclaration);
				this.compilationUnit.BlockStart(typeDeclaration);
				typeDeclaration.StartLocation = m.GetDeclarationLocation(this.t.Location);
				typeDeclaration.Type = ICSharpCode.NRefactory.Ast.ClassType.Class;
				this.Identifier();
				typeDeclaration.Name = this.t.val;
				if (this.la.kind == 23)
				{
					this.TypeParameterList(templates);
				}
				if (this.la.kind == 9)
				{
					List<TypeReference> baseTypes;
					this.ClassBase(out baseTypes);
					typeDeclaration.BaseTypes = baseTypes;
				}
				while (this.la.kind == 127)
				{
					this.TypeParameterConstraintsClause(templates);
				}
				typeDeclaration.BodyStartLocation = this.t.EndLocation;
				base.Expect(16);
				this.ClassBody();
				base.Expect(17);
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				typeDeclaration.EndLocation = this.t.EndLocation;
				this.compilationUnit.BlockEnd();
				return;
			}
			if (!this.StartOf(9))
			{
				base.SynErr(153);
				return;
			}
			m.Check(Modifiers.StructsInterfacesEnumsDelegates);
			if (this.la.kind == 109)
			{
				this.lexer.NextToken();
				TypeDeclaration typeDeclaration2 = new TypeDeclaration(m.Modifier, attributes);
				templates = typeDeclaration2.Templates;
				typeDeclaration2.StartLocation = m.GetDeclarationLocation(this.t.Location);
				this.compilationUnit.AddChild(typeDeclaration2);
				this.compilationUnit.BlockStart(typeDeclaration2);
				typeDeclaration2.Type = ICSharpCode.NRefactory.Ast.ClassType.Struct;
				this.Identifier();
				typeDeclaration2.Name = this.t.val;
				if (this.la.kind == 23)
				{
					this.TypeParameterList(templates);
				}
				if (this.la.kind == 9)
				{
					List<TypeReference> baseTypes;
					this.StructInterfaces(out baseTypes);
					typeDeclaration2.BaseTypes = baseTypes;
				}
				while (this.la.kind == 127)
				{
					this.TypeParameterConstraintsClause(templates);
				}
				typeDeclaration2.BodyStartLocation = this.t.EndLocation;
				this.StructBody();
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				typeDeclaration2.EndLocation = this.t.EndLocation;
				this.compilationUnit.BlockEnd();
				return;
			}
			if (this.la.kind == 83)
			{
				this.lexer.NextToken();
				TypeDeclaration typeDeclaration3 = new TypeDeclaration(m.Modifier, attributes);
				templates = typeDeclaration3.Templates;
				this.compilationUnit.AddChild(typeDeclaration3);
				this.compilationUnit.BlockStart(typeDeclaration3);
				typeDeclaration3.StartLocation = m.GetDeclarationLocation(this.t.Location);
				typeDeclaration3.Type = ICSharpCode.NRefactory.Ast.ClassType.Interface;
				this.Identifier();
				typeDeclaration3.Name = this.t.val;
				if (this.la.kind == 23)
				{
					this.TypeParameterList(templates);
				}
				if (this.la.kind == 9)
				{
					List<TypeReference> baseTypes;
					this.InterfaceBase(out baseTypes);
					typeDeclaration3.BaseTypes = baseTypes;
				}
				while (this.la.kind == 127)
				{
					this.TypeParameterConstraintsClause(templates);
				}
				typeDeclaration3.BodyStartLocation = this.t.EndLocation;
				this.InterfaceBody();
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				typeDeclaration3.EndLocation = this.t.EndLocation;
				this.compilationUnit.BlockEnd();
				return;
			}
			if (this.la.kind == 68)
			{
				this.lexer.NextToken();
				TypeDeclaration typeDeclaration4 = new TypeDeclaration(m.Modifier, attributes);
				this.compilationUnit.AddChild(typeDeclaration4);
				this.compilationUnit.BlockStart(typeDeclaration4);
				typeDeclaration4.StartLocation = m.GetDeclarationLocation(this.t.Location);
				typeDeclaration4.Type = ICSharpCode.NRefactory.Ast.ClassType.Enum;
				this.Identifier();
				typeDeclaration4.Name = this.t.val;
				if (this.la.kind == 9)
				{
					this.lexer.NextToken();
					string type;
					this.IntegralType(out type);
					typeDeclaration4.BaseTypes.Add(new TypeReference(type, true));
				}
				typeDeclaration4.BodyStartLocation = this.t.EndLocation;
				this.EnumBody();
				if (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				typeDeclaration4.EndLocation = this.t.EndLocation;
				this.compilationUnit.BlockEnd();
				return;
			}
			this.lexer.NextToken();
			DelegateDeclaration delegateDeclaration = new DelegateDeclaration(m.Modifier, attributes);
			templates = delegateDeclaration.Templates;
			delegateDeclaration.StartLocation = m.GetDeclarationLocation(this.t.Location);
			if (this.NotVoidPointer())
			{
				base.Expect(123);
				delegateDeclaration.ReturnType = new TypeReference("System.Void", true);
			}
			else if (this.StartOf(10))
			{
				TypeReference returnType;
				this.Type(out returnType);
				delegateDeclaration.ReturnType = returnType;
			}
			else
			{
				base.SynErr(152);
			}
			this.Identifier();
			delegateDeclaration.Name = this.t.val;
			if (this.la.kind == 23)
			{
				this.TypeParameterList(templates);
			}
			base.Expect(20);
			if (this.StartOf(11))
			{
				this.FormalParameterList(list);
				delegateDeclaration.Parameters = list;
			}
			base.Expect(21);
			while (this.la.kind == 127)
			{
				this.TypeParameterConstraintsClause(templates);
			}
			base.Expect(11);
			delegateDeclaration.EndLocation = this.t.EndLocation;
			this.compilationUnit.AddChild(delegateDeclaration);
		}

		private void TypeModifier(ModifierList m)
		{
			int kind = this.la.kind;
			if (kind <= 98)
			{
				if (kind <= 84)
				{
					if (kind == 49)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Dim, this.t.Location);
						return;
					}
					if (kind == 84)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Internal, this.t.Location);
						return;
					}
				}
				else
				{
					if (kind == 89)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.New, this.t.Location);
						return;
					}
					switch (kind)
					{
					case 96:
						this.lexer.NextToken();
						m.Add(Modifiers.Private, this.t.Location);
						return;
					case 97:
						this.lexer.NextToken();
						m.Add(Modifiers.Protected, this.t.Location);
						return;
					case 98:
						this.lexer.NextToken();
						m.Add(Modifiers.Public, this.t.Location);
						return;
					}
				}
			}
			else if (kind <= 107)
			{
				if (kind == 103)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Sealed, this.t.Location);
					return;
				}
				if (kind == 107)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Static, this.t.Location);
					return;
				}
			}
			else
			{
				if (kind == 119)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Unsafe, this.t.Location);
					return;
				}
				if (kind == 126)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Partial, this.t.Location);
					return;
				}
			}
			base.SynErr(151);
		}

		private void TypeName(out TypeReference typeRef, bool canBeUnbound)
		{
			List<TypeReference> list = null;
			string text = null;
			Location location = this.la.Location;
			if (this.IdentAndDoubleColon())
			{
				this.Identifier();
				text = this.t.val;
				base.Expect(10);
			}
			string text2;
			this.Qualident(out text2);
			if (this.la.kind == 23)
			{
				this.TypeArgumentList(out list, canBeUnbound);
			}
			if (text == null)
			{
				typeRef = new TypeReference(text2, list);
			}
			else if (text == "global")
			{
				typeRef = new TypeReference(text2, list);
				typeRef.IsGlobal = true;
			}
			else
			{
				typeRef = new TypeReference(text + "." + text2, list);
			}
			while (this.DotAndIdent())
			{
				base.Expect(15);
				list = null;
				this.Qualident(out text2);
				if (this.la.kind == 23)
				{
					this.TypeArgumentList(out list, canBeUnbound);
				}
				typeRef = new InnerClassTypeReference(typeRef, text2, list);
			}
			typeRef.StartLocation = location;
		}

		private void TypeParameterConstraintsClause(List<TemplateDefinition> templates)
		{
			string b = "";
			base.Expect(127);
			this.Identifier();
			b = this.t.val;
			base.Expect(9);
			TypeReference typeReference;
			this.TypeParameterConstraintsClauseBase(out typeReference);
			TemplateDefinition templateDefinition = null;
			foreach (TemplateDefinition current in templates)
			{
				if (current.Name == b)
				{
					templateDefinition = current;
					break;
				}
			}
			if (templateDefinition != null && typeReference != null)
			{
				templateDefinition.Bases.Add(typeReference);
			}
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				this.TypeParameterConstraintsClauseBase(out typeReference);
				templateDefinition = null;
				foreach (TemplateDefinition current2 in templates)
				{
					if (current2.Name == b)
					{
						templateDefinition = current2;
						break;
					}
				}
				if (templateDefinition != null && typeReference != null)
				{
					templateDefinition.Bases.Add(typeReference);
				}
			}
		}

		private void TypeParameterConstraintsClauseBase(out TypeReference type)
		{
			type = null;
			if (this.la.kind == 109)
			{
				this.lexer.NextToken();
				type = TypeReference.StructConstraint;
				return;
			}
			if (this.la.kind == 59)
			{
				this.lexer.NextToken();
				type = TypeReference.ClassConstraint;
				return;
			}
			if (this.la.kind == 89)
			{
				this.lexer.NextToken();
				base.Expect(20);
				base.Expect(21);
				type = TypeReference.NewConstraint;
				return;
			}
			if (this.StartOf(10))
			{
				TypeReference typeReference;
				this.Type(out typeReference);
				type = typeReference;
				return;
			}
			base.SynErr(216);
		}

		private void TypeParameterList(List<TemplateDefinition> templates)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			base.Expect(23);
			while (this.la.kind == 18)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			this.Identifier();
			templates.Add(new TemplateDefinition(this.t.val, list));
			while (this.la.kind == 14)
			{
				this.lexer.NextToken();
				while (this.la.kind == 18)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				this.Identifier();
				templates.Add(new TemplateDefinition(this.t.val, list));
			}
			base.Expect(22);
		}

		private void TypeWithRestriction(out TypeReference type, bool allowNullable, bool canBeUnbound)
		{
			Location location = this.la.Location;
			int num = 0;
			type = null;
			if (this.StartOf(4))
			{
				this.ClassType(out type, canBeUnbound);
			}
			else if (this.StartOf(5))
			{
				string type2;
				this.SimpleType(out type2);
				type = new TypeReference(type2, true);
			}
			else if (this.la.kind == 123)
			{
				this.lexer.NextToken();
				base.Expect(6);
				num = 1;
				type = new TypeReference("System.Void", true);
			}
			else
			{
				base.SynErr(178);
			}
			List<int> list = new List<int>();
			if (allowNullable && this.la.kind == 12)
			{
				this.NullableQuestionMark(ref type);
			}
			while (this.IsPointerOrDims())
			{
				int num2 = 0;
				if (this.la.kind == 6)
				{
					this.lexer.NextToken();
					num++;
				}
				else if (this.la.kind == 18)
				{
					this.lexer.NextToken();
					while (this.la.kind == 14)
					{
						this.lexer.NextToken();
						num2++;
					}
					base.Expect(19);
					list.Add(num2);
				}
				else
				{
					base.SynErr(179);
				}
			}
			if (type != null)
			{
				type.RankSpecifier = list.ToArray();
				type.PointerNestingLevel = num;
				type.EndLocation = this.t.EndLocation;
				type.StartLocation = location;
			}
		}

		private void UnaryExpr(out Expression uExpr)
		{
			TypeReference castTo = null;
			Expression expression = null;
			ArrayList arrayList = new ArrayList();
			uExpr = null;
			while (this.StartOf(33) || this.IsTypeCast())
			{
				if (this.la.kind == 4)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Plus));
				}
				else if (this.la.kind == 5)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Minus));
				}
				else if (this.la.kind == 24)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Not));
				}
				else if (this.la.kind == 27)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.BitNot));
				}
				else if (this.la.kind == 6)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Dereference));
				}
				else if (this.la.kind == 31)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Increment));
				}
				else if (this.la.kind == 32)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.Decrement));
				}
				else if (this.la.kind == 28)
				{
					this.lexer.NextToken();
					arrayList.Add(new UnaryOperatorExpression(UnaryOperatorType.AddressOf));
				}
				else
				{
					base.Expect(20);
					this.Type(out castTo);
					base.Expect(21);
					arrayList.Add(new CastExpression(castTo));
				}
			}
			if (this.LastExpressionIsUnaryMinus(arrayList) && this.IsMostNegativeIntegerWithoutTypeSuffix())
			{
				base.Expect(2);
				arrayList.RemoveAt(arrayList.Count - 1);
				if (this.t.literalValue is uint)
				{
					expression = new PrimitiveExpression(-2147483648, -2147483648.ToString());
				}
				else
				{
					if (!(this.t.literalValue is ulong))
					{
						throw new Exception("t.literalValue must be uint or ulong");
					}
					expression = new PrimitiveExpression(-9223372036854775808L, -9223372036854775808L.ToString());
				}
			}
			else if (this.StartOf(34))
			{
				this.PrimaryExpr(out expression);
			}
			else
			{
				base.SynErr(206);
			}
			for (int i = 0; i < arrayList.Count; i++)
			{
				Expression expression2 = (i + 1 < arrayList.Count) ? ((Expression)arrayList[i + 1]) : expression;
				if (arrayList[i] is CastExpression)
				{
					((CastExpression)arrayList[i]).Expression = expression2;
				}
				else
				{
					((UnaryOperatorExpression)arrayList[i]).Expression = expression2;
				}
			}
			if (arrayList.Count > 0)
			{
				uExpr = (Expression)arrayList[0];
				return;
			}
			uExpr = expression;
		}

		private bool UnCheckedAndLBrace()
		{
			return (this.la.kind == 58 || this.la.kind == 118) && this.Peek(1).kind == 16;
		}

		private void UsingDirective()
		{
			string text = null;
			TypeReference typeReference = null;
			string text2 = null;
			base.Expect(121);
			Location location = this.t.Location;
			if (this.IdentAndDoubleColon())
			{
				this.Identifier();
				text2 = this.t.val;
				base.Expect(10);
			}
			this.Qualident(out text);
			if (this.la.kind == 3)
			{
				this.lexer.NextToken();
				this.NonArrayType(out typeReference);
			}
			base.Expect(11);
			if (text != null && text.Length > 0)
			{
				string @namespace = (text2 != null && text2 != "global") ? (text2 + "." + text) : text;
				INode node;
				if (typeReference != null)
				{
					node = new UsingDeclaration(@namespace, typeReference);
				}
				else
				{
					node = new UsingDeclaration(@namespace);
				}
				node.StartLocation = location;
				node.EndLocation = this.t.EndLocation;
				this.compilationUnit.AddChild(node);
			}
		}

		private void VariableDeclarator(FieldDeclaration parentFieldDeclaration)
		{
			Expression initializer = null;
			this.Identifier();
			VariableDeclaration variableDeclaration = new VariableDeclaration(this.t.val);
			variableDeclaration.StartLocation = this.t.Location;
			if (this.la.kind == 3)
			{
				this.lexer.NextToken();
				this.VariableInitializer(out initializer);
				variableDeclaration.Initializer = initializer;
			}
			variableDeclaration.EndLocation = this.t.EndLocation;
			Parser.SafeAdd<VariableDeclaration>(parentFieldDeclaration, parentFieldDeclaration.Fields, variableDeclaration);
		}

		private void VariableInitializer(out Expression initializerExpression)
		{
			TypeReference typeReference = null;
			Expression expression = null;
			initializerExpression = null;
			if (this.StartOf(6))
			{
				this.Expr(out initializerExpression);
				return;
			}
			if (this.la.kind == 16)
			{
				this.CollectionInitializer(out initializerExpression);
				return;
			}
			if (this.la.kind == 106)
			{
				this.lexer.NextToken();
				this.Type(out typeReference);
				base.Expect(18);
				this.Expr(out expression);
				base.Expect(19);
				initializerExpression = new StackAllocExpression(typeReference, expression);
				return;
			}
			base.SynErr(191);
		}

		private Token la
		{
			[DebuggerStepThrough]
			get
			{
				return this.lexer.LookAhead;
			}
		}

		private Token t
		{
			[DebuggerStepThrough]
			get
			{
				return this.lexer.Token;
			}
		}

		private Lexer lexer;

		private const int maxT = 145;

		private StringBuilder qualidentBuilder = new StringBuilder();

		private static bool[,] set = new bool[,]
		{
			{
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false
			}
		};

		private const bool T = true;

		private const bool x = false;
	}
}
