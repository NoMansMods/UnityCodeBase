﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Visitors;

namespace ICSharpCode.NRefactory.Parser.CSharp
{
	public sealed class ConditionalCompilation : AbstractAstVisitor
	{
		public void Define(string symbol)
		{
			this.symbols[symbol] = ConditionalCompilation.SymbolDefined;
		}

		public bool Evaluate(Expression condition)
		{
			return condition.AcceptVisitor(this, null) == ConditionalCompilation.SymbolDefined;
		}

		public void Undefine(string symbol)
		{
			this.symbols.Remove(symbol);
		}

		public override object VisitBinaryOperatorExpression(BinaryOperatorExpression binaryOperatorExpression, object data)
		{
			bool flag = binaryOperatorExpression.Left.AcceptVisitor(this, data) == ConditionalCompilation.SymbolDefined;
			bool flag2 = binaryOperatorExpression.Right.AcceptVisitor(this, data) == ConditionalCompilation.SymbolDefined;
			bool flag3;
			switch (binaryOperatorExpression.Op)
			{
			case BinaryOperatorType.LogicalAnd:
				flag3 = (flag && flag2);
				goto IL_7E;
			case BinaryOperatorType.LogicalOr:
				flag3 = (flag || flag2);
				goto IL_7E;
			case BinaryOperatorType.Equality:
				flag3 = (flag == flag2);
				goto IL_7E;
			case BinaryOperatorType.InEquality:
				flag3 = (flag != flag2);
				goto IL_7E;
			}
			return null;
			IL_7E:
			if (!flag3)
			{
				return null;
			}
			return ConditionalCompilation.SymbolDefined;
		}

		public override object VisitIdentifierExpression(IdentifierExpression identifierExpression, object data)
		{
			if (!this.symbols.ContainsKey(identifierExpression.Identifier))
			{
				return null;
			}
			return ConditionalCompilation.SymbolDefined;
		}

		public override object VisitParenthesizedExpression(ParenthesizedExpression parenthesizedExpression, object data)
		{
			return parenthesizedExpression.Expression.AcceptVisitor(this, data);
		}

		public override object VisitPrimitiveExpression(PrimitiveExpression primitiveExpression, object data)
		{
			if (!(primitiveExpression.Value is bool))
			{
				return null;
			}
			if (!(bool)primitiveExpression.Value)
			{
				return null;
			}
			return ConditionalCompilation.SymbolDefined;
		}

		public override object VisitUnaryOperatorExpression(UnaryOperatorExpression unaryOperatorExpression, object data)
		{
			if (unaryOperatorExpression.Op != UnaryOperatorType.Not)
			{
				return null;
			}
			if (unaryOperatorExpression.Expression.AcceptVisitor(this, data) != ConditionalCompilation.SymbolDefined)
			{
				return ConditionalCompilation.SymbolDefined;
			}
			return null;
		}

		public IDictionary<string, object> Symbols
		{
			get
			{
				return this.symbols;
			}
		}

		private static readonly object SymbolDefined = new object();

		private Dictionary<string, object> symbols = new Dictionary<string, object>();
	}
}
