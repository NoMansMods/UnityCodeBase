﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Parser.CSharp
{
	internal sealed class Lexer : AbstractLexer
	{
		public Lexer(TextReader reader) : base(reader)
		{
		}

		protected override Token Next()
		{
			bool flag = false;
			if (base.Line == 1 && base.Col == 1)
			{
				this.isAtLineBegin = true;
				flag = true;
			}
			int num;
			while ((num = base.ReaderRead()) != -1)
			{
				int num2 = num;
				Token token;
				char c;
				if (num2 <= 35)
				{
					switch (num2)
					{
					case 9:
						continue;
					case 10:
					case 13:
						if (flag)
						{
							this.specialTracker.AddEndOfLine(new Location(base.Col, base.Line));
						}
						base.HandleLineEnd((char)num);
						flag = true;
						this.isAtLineBegin = true;
						continue;
					case 11:
					case 12:
						goto IL_1F2;
					default:
						switch (num2)
						{
						case 32:
							continue;
						case 33:
							goto IL_1F2;
						case 34:
							token = this.ReadString();
							this.isAtLineBegin = false;
							break;
						case 35:
							this.ReadPreProcessingDirective();
							this.isAtLineBegin = false;
							continue;
						default:
							goto IL_1F2;
						}
						break;
					}
				}
				else if (num2 != 39)
				{
					if (num2 != 47)
					{
						if (num2 != 64)
						{
							goto IL_1F2;
						}
						this.isAtLineBegin = false;
						int num3 = base.ReaderRead();
						if (num3 == -1)
						{
							this.errors.Error(base.Line, base.Col, string.Format("EOF after @", new object[0]));
							continue;
						}
						int num4 = base.Col - 1;
						int line = base.Line;
						c = (char)num3;
						if (c == '"')
						{
							token = this.ReadVerbatimString();
						}
						else
						{
							if (!char.IsLetterOrDigit(c) && c != '_')
							{
								base.HandleLineEnd(c);
								this.errors.Error(line, num4, string.Format("Unexpected char in Lexer.Next() : {0}", c));
								continue;
							}
							bool flag2;
							token = new Token(1, num4 - 1, line, this.ReadIdent(c, out flag2));
						}
					}
					else
					{
						int num5 = base.ReaderPeek();
						if (num5 == 47 || num5 == 42)
						{
							this.ReadComment();
							continue;
						}
						this.isAtLineBegin = false;
						token = this.ReadOperator('/');
					}
				}
				else
				{
					token = this.ReadChar();
					this.isAtLineBegin = false;
				}
				IL_27A:
				if (token != null)
				{
					return token;
				}
				continue;
				IL_1F2:
				this.isAtLineBegin = false;
				c = (char)num;
				if (char.IsLetter(c) || c == '_' || c == '\\')
				{
					int col = base.Col - 1;
					int line2 = base.Line;
					bool flag3;
					string text = this.ReadIdent(c, out flag3);
					if (flag3)
					{
						int token2 = Keywords.GetToken(text);
						if (token2 >= 0)
						{
							return new Token(token2, col, line2, text);
						}
					}
					return new Token(1, col, line2, text);
				}
				if (char.IsDigit(c))
				{
					token = this.ReadDigit(c, base.Col - 1);
					goto IL_27A;
				}
				token = this.ReadOperator(c);
				goto IL_27A;
			}
			return new Token(0, base.Col, base.Line, string.Empty);
		}

		private Expression PPAndExpression()
		{
			Expression expression = this.PPEqualityExpression();
			while (base.ReaderPeek() == 38)
			{
				Token token = this.ReadOperator((char)base.ReaderRead());
				if (token == null || token.kind != 25)
				{
					break;
				}
				Expression right = this.PPEqualityExpression();
				expression = new BinaryOperatorExpression(expression, BinaryOperatorType.LogicalAnd, right);
			}
			return expression;
		}

		private Expression PPEqualityExpression()
		{
			Expression expression = this.PPUnaryExpression();
			while (base.ReaderPeek() == 61 || base.ReaderPeek() == 33)
			{
				Token token = this.ReadOperator((char)base.ReaderRead());
				if (token == null || (token.kind != 144 && token.kind != 34))
				{
					break;
				}
				Expression right = this.PPUnaryExpression();
				expression = new BinaryOperatorExpression(expression, (token.kind == 144) ? BinaryOperatorType.Equality : BinaryOperatorType.InEquality, right);
			}
			return expression;
		}

		private Expression PPExpression()
		{
			Expression expression = this.PPAndExpression();
			while (base.ReaderPeek() == 124)
			{
				Token token = this.ReadOperator((char)base.ReaderRead());
				if (token == null || token.kind != 26)
				{
					return expression;
				}
				Expression right = this.PPAndExpression();
				expression = new BinaryOperatorExpression(expression, BinaryOperatorType.LogicalOr, right);
			}
			return expression;
		}

		private Expression PPPrimaryExpression()
		{
			int num = base.ReaderRead();
			if (num < 0)
			{
				return Expression.Null;
			}
			if (num == 40)
			{
				Expression result = new ParenthesizedExpression(this.PPExpression());
				this.PPWhitespace();
				if (base.ReaderRead() != 41)
				{
					this.errors.Error(base.Col, base.Line, "Expected ')'");
				}
				this.PPWhitespace();
				return result;
			}
			if (num != 95 && !char.IsLetterOrDigit((char)num) && num != 92)
			{
				this.errors.Error(base.Col, base.Line, "Expected conditional symbol");
			}
			bool flag;
			string text = this.ReadIdent((char)num, out flag);
			this.PPWhitespace();
			if (flag && text == "true")
			{
				return new PrimitiveExpression(true, "true");
			}
			if (flag && text == "false")
			{
				return new PrimitiveExpression(false, "false");
			}
			return new IdentifierExpression(text);
		}

		private Expression PPUnaryExpression()
		{
			this.PPWhitespace();
			if (base.ReaderPeek() == 33)
			{
				base.ReaderRead();
				this.PPWhitespace();
				return new UnaryOperatorExpression(this.PPUnaryExpression(), UnaryOperatorType.Not);
			}
			return this.PPPrimaryExpression();
		}

		private void PPWhitespace()
		{
			while (base.ReaderPeek() == 32 || base.ReaderPeek() == 9)
			{
				base.ReaderRead();
			}
		}

		private Token ReadChar()
		{
			int num = base.Col - 1;
			int line = base.Line;
			int num2 = base.ReaderRead();
			if (num2 == -1 || base.HandleLineEnd((char)num2))
			{
				this.errors.Error(line, num, string.Format("End of line reached inside character literal", new object[0]));
				return null;
			}
			char c = (char)num2;
			char c2 = c;
			string text = string.Empty;
			if (c == '\\')
			{
				string text2;
				text = this.ReadEscapeSequence(out c2, out text2);
				if (text2 != null)
				{
					this.errors.Error(line, num, string.Format("The unicode character must be represented by a surrogate pair and does not fit into a System.Char", new object[0]));
				}
			}
			if ((ushort)base.ReaderRead() != 39)
			{
				this.errors.Error(line, num, string.Format("Char not terminated", new object[0]));
			}
			return new Token(2, num, line, string.Concat(new object[]
			{
				"'",
				c,
				text,
				"'"
			}), c2, LiteralFormat.CharLiteral);
		}

		private void ReadComment()
		{
			int num = base.ReaderRead();
			if (num == 42)
			{
				this.ReadMultiLineComment();
				this.isAtLineBegin = false;
				return;
			}
			if (num != 47)
			{
				this.errors.Error(base.Line, base.Col, string.Format("Error while reading comment", new object[0]));
				return;
			}
			if (base.ReaderPeek() == 47)
			{
				base.ReaderRead();
				this.ReadSingleLineComment(CommentType.Documentation);
			}
			else
			{
				this.ReadSingleLineComment(CommentType.SingleLine);
			}
			this.isAtLineBegin = true;
		}

		private string ReadCommentToEOL()
		{
			if (this.specialCommentHash == null)
			{
				return base.ReadToEndOfLine();
			}
			this.sb.Length = 0;
			StringBuilder stringBuilder = new StringBuilder();
			int num;
			while ((num = base.ReaderRead()) != -1)
			{
				char c = (char)num;
				if (base.HandleLineEnd(c))
				{
					break;
				}
				this.sb.Append(c);
				if (AbstractLexer.IsIdentifierPart(num))
				{
					stringBuilder.Append(c);
				}
				else
				{
					string text = stringBuilder.ToString();
					stringBuilder.Length = 0;
					if (this.specialCommentHash.ContainsKey(text))
					{
						Location startPosition = new Location(base.Col, base.Line);
						string text2 = c + base.ReadToEndOfLine();
						base.TagComments.Add(new TagComment(text, text2, this.isAtLineBegin, startPosition, new Location(base.Col, base.Line)));
						this.sb.Append(text2);
						break;
					}
				}
			}
			return this.sb.ToString();
		}

		private Token ReadDigit(char ch, int x)
		{
			int line = base.Line;
			this.sb.Length = 0;
			this.sb.Append(ch);
			string str = null;
			string str2 = null;
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			bool flag5 = false;
			bool flag6 = false;
			char c = (char)base.ReaderPeek();
			if (ch == '.')
			{
				flag5 = true;
				while (char.IsDigit((char)base.ReaderPeek()))
				{
					this.sb.Append((char)base.ReaderRead());
				}
				c = (char)base.ReaderPeek();
			}
			else if (ch == '0' && (c == 'x' || c == 'X'))
			{
				base.ReaderRead();
				this.sb.Length = 0;
				while (AbstractLexer.IsHex((char)base.ReaderPeek()))
				{
					this.sb.Append((char)base.ReaderRead());
				}
				if (this.sb.Length == 0)
				{
					this.sb.Append('0');
					this.errors.Error(line, x, "Invalid hexadecimal integer literal");
				}
				flag = true;
				str = "0x";
				c = (char)base.ReaderPeek();
			}
			else
			{
				while (char.IsDigit((char)base.ReaderPeek()))
				{
					this.sb.Append((char)base.ReaderRead());
				}
				c = (char)base.ReaderPeek();
			}
			Token next = null;
			if (c == '.')
			{
				base.ReaderRead();
				c = (char)base.ReaderPeek();
				if (!char.IsDigit(c))
				{
					next = new Token(15, base.Col - 1, base.Line);
					c = '.';
				}
				else
				{
					flag5 = true;
					if (flag)
					{
						this.errors.Error(line, x, string.Format("No hexadecimal floating point values allowed", new object[0]));
					}
					this.sb.Append('.');
					while (char.IsDigit((char)base.ReaderPeek()))
					{
						this.sb.Append((char)base.ReaderRead());
					}
					c = (char)base.ReaderPeek();
				}
			}
			if (c == 'e' || c == 'E')
			{
				flag5 = true;
				this.sb.Append((char)base.ReaderRead());
				c = (char)base.ReaderPeek();
				if (c == '-' || c == '+')
				{
					this.sb.Append((char)base.ReaderRead());
				}
				while (char.IsDigit((char)base.ReaderPeek()))
				{
					this.sb.Append((char)base.ReaderRead());
				}
				flag2 = true;
				c = (char)base.ReaderPeek();
			}
			if (c == 'f' || c == 'F')
			{
				base.ReaderRead();
				str2 = "f";
				flag4 = true;
			}
			else if (c == 'd' || c == 'D')
			{
				base.ReaderRead();
				str2 = "d";
				flag5 = true;
			}
			else if (c == 'm' || c == 'M')
			{
				base.ReaderRead();
				str2 = "m";
				flag6 = true;
			}
			else if (!flag5)
			{
				if (c == 'u' || c == 'U')
				{
					base.ReaderRead();
					str2 = "u";
					flag2 = true;
					c = (char)base.ReaderPeek();
				}
				if (c == 'l' || c == 'L')
				{
					base.ReaderRead();
					c = (char)base.ReaderPeek();
					flag3 = true;
					if (!flag2 && (c == 'u' || c == 'U'))
					{
						base.ReaderRead();
						str2 = "Lu";
						flag2 = true;
					}
					else
					{
						str2 = (flag2 ? "uL" : "L");
					}
				}
			}
			string text = this.sb.ToString();
			string text2 = str + text + str2;
			if (flag4)
			{
				float num;
				if (float.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num))
				{
					return new Token(2, x, line, text2, num, LiteralFormat.DecimalNumber);
				}
				this.errors.Error(line, x, string.Format("Can't parse float {0}", text));
				return new Token(2, x, line, text2, 0f, LiteralFormat.DecimalNumber);
			}
			else if (flag6)
			{
				decimal num2;
				if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num2))
				{
					return new Token(2, x, line, text2, num2, LiteralFormat.DecimalNumber);
				}
				this.errors.Error(line, x, string.Format("Can't parse decimal {0}", text));
				return new Token(2, x, line, text2, 0m, LiteralFormat.DecimalNumber);
			}
			else
			{
				if (!flag5)
				{
					ulong num3;
					if (flag)
					{
						if (!ulong.TryParse(text, NumberStyles.HexNumber, null, out num3))
						{
							this.errors.Error(line, x, string.Format("Can't parse hexadecimal constant {0}", text));
							return new Token(2, x, line, text2.ToString(), 0, LiteralFormat.HexadecimalNumber);
						}
					}
					else if (!ulong.TryParse(text, NumberStyles.Integer, null, out num3))
					{
						this.errors.Error(line, x, string.Format("Can't parse integral constant {0}", text));
						return new Token(2, x, line, text2.ToString(), 0, LiteralFormat.DecimalNumber);
					}
					if (num3 > 9223372036854775807uL)
					{
						flag3 = true;
						flag2 = true;
					}
					else if (num3 > (ulong)-1)
					{
						flag3 = true;
					}
					else if (!flag3 && num3 > 2147483647uL)
					{
						flag2 = true;
					}
					LiteralFormat literalFormat = flag ? LiteralFormat.HexadecimalNumber : LiteralFormat.DecimalNumber;
					Token token;
					int num7;
					if (flag3)
					{
						long num5;
						if (flag2)
						{
							ulong num4;
							if (ulong.TryParse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number, CultureInfo.InvariantCulture, out num4))
							{
								token = new Token(2, x, line, text2, num4, literalFormat);
							}
							else
							{
								this.errors.Error(line, x, string.Format("Can't parse unsigned long {0}", text));
								token = new Token(2, x, line, text2, 0uL, literalFormat);
							}
						}
						else if (long.TryParse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number, CultureInfo.InvariantCulture, out num5))
						{
							token = new Token(2, x, line, text2, num5, literalFormat);
						}
						else
						{
							this.errors.Error(line, x, string.Format("Can't parse long {0}", text));
							token = new Token(2, x, line, text2, 0L, literalFormat);
						}
					}
					else if (flag2)
					{
						uint num6;
						if (uint.TryParse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number, CultureInfo.InvariantCulture, out num6))
						{
							token = new Token(2, x, line, text2, num6, literalFormat);
						}
						else
						{
							this.errors.Error(line, x, string.Format("Can't parse unsigned int {0}", text));
							token = new Token(2, x, line, text2, 0u, literalFormat);
						}
					}
					else if (int.TryParse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number, CultureInfo.InvariantCulture, out num7))
					{
						token = new Token(2, x, line, text2, num7, literalFormat);
					}
					else
					{
						this.errors.Error(line, x, string.Format("Can't parse int {0}", text));
						token = new Token(2, x, line, text2, 0, literalFormat);
					}
					token.next = next;
					return token;
				}
				double num8;
				if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out num8))
				{
					return new Token(2, x, line, text2, num8, LiteralFormat.DecimalNumber);
				}
				this.errors.Error(line, x, string.Format("Can't parse double {0}", text));
				return new Token(2, x, line, text2, 0.0, LiteralFormat.DecimalNumber);
			}
		}

		private string ReadEscapeSequence(out char ch, out string surrogatePair)
		{
			surrogatePair = null;
			int num = base.ReaderRead();
			if (num == -1)
			{
				this.errors.Error(base.Line, base.Col, string.Format("End of file reached inside escape sequence", new object[0]));
				ch = '\0';
				return string.Empty;
			}
			char c = (char)num;
			int length = 1;
			this.escapeSequenceBuffer[0] = c;
			char c2 = c;
			if (c2 <= 'U')
			{
				if (c2 <= '\'')
				{
					if (c2 == '"')
					{
						ch = '"';
						goto IL_2B6;
					}
					if (c2 == '\'')
					{
						ch = '\'';
						goto IL_2B6;
					}
				}
				else
				{
					if (c2 == '0')
					{
						ch = '\0';
						goto IL_2B6;
					}
					if (c2 == 'U')
					{
						int num2 = 0;
						for (int i = 0; i < 8; i++)
						{
							if (!AbstractLexer.IsHex((char)base.ReaderPeek()))
							{
								this.errors.Error(base.Line, base.Col - 1, string.Format("Invalid char in literal : {0}", (char)base.ReaderPeek()));
								break;
							}
							c = (char)base.ReaderRead();
							int hexNumber = base.GetHexNumber(c);
							this.escapeSequenceBuffer[length++] = c;
							num2 = 16 * num2 + hexNumber;
						}
						if (num2 > 65535)
						{
							ch = '\0';
							surrogatePair = char.ConvertFromUtf32(num2);
							goto IL_2B6;
						}
						ch = (char)num2;
						goto IL_2B6;
					}
				}
			}
			else if (c2 <= 'b')
			{
				if (c2 == '\\')
				{
					ch = '\\';
					goto IL_2B6;
				}
				switch (c2)
				{
				case 'a':
					ch = '\a';
					goto IL_2B6;
				case 'b':
					ch = '\b';
					goto IL_2B6;
				}
			}
			else
			{
				if (c2 == 'f')
				{
					ch = '\f';
					goto IL_2B6;
				}
				switch (c2)
				{
				case 'n':
					ch = '\n';
					goto IL_2B6;
				case 'r':
					ch = '\r';
					goto IL_2B6;
				case 't':
					ch = '\t';
					goto IL_2B6;
				case 'u':
				case 'x':
				{
					c = (char)base.ReaderRead();
					int num2 = base.GetHexNumber(c);
					this.escapeSequenceBuffer[length++] = c;
					if (num2 < 0)
					{
						this.errors.Error(base.Line, base.Col - 1, string.Format("Invalid char in literal : {0}", c));
					}
					int num3 = 0;
					while (num3 < 3 && AbstractLexer.IsHex((char)base.ReaderPeek()))
					{
						c = (char)base.ReaderRead();
						int hexNumber2 = base.GetHexNumber(c);
						this.escapeSequenceBuffer[length++] = c;
						num2 = 16 * num2 + hexNumber2;
						num3++;
					}
					ch = (char)num2;
					goto IL_2B6;
				}
				case 'v':
					ch = '\v';
					goto IL_2B6;
				}
			}
			this.errors.Error(base.Line, base.Col, string.Format("Unexpected escape sequence : {0}", c));
			ch = '\0';
			IL_2B6:
			return new string(this.escapeSequenceBuffer, 0, length);
		}

		private string ReadIdent(char ch, out bool canBeKeyword)
		{
			int num = 0;
			canBeKeyword = true;
			while (true)
			{
				int num2;
				if (ch == '\\')
				{
					num2 = base.ReaderPeek();
					if (num2 != 117 && num2 != 85)
					{
						this.errors.Error(base.Line, base.Col, "Identifiers can only contain unicode escape sequences");
					}
					canBeKeyword = false;
					string text;
					this.ReadEscapeSequence(out ch, out text);
					if (text != null)
					{
						if (!char.IsLetterOrDigit(text, 0))
						{
							this.errors.Error(base.Line, base.Col, "Unicode escape sequences in identifiers cannot be used to represent characters that are invalid in identifiers");
						}
						for (int i = 0; i < text.Length - 1; i++)
						{
							if (num < 512)
							{
								this.identBuffer[num++] = text[i];
							}
						}
						ch = text[text.Length - 1];
					}
					else if (!AbstractLexer.IsIdentifierPart((int)ch))
					{
						this.errors.Error(base.Line, base.Col, "Unicode escape sequences in identifiers cannot be used to represent characters that are invalid in identifiers");
					}
				}
				if (num >= 512)
				{
					break;
				}
				this.identBuffer[num++] = ch;
				num2 = base.ReaderPeek();
				if (!AbstractLexer.IsIdentifierPart(num2) && num2 != 92)
				{
					goto IL_160;
				}
				ch = (char)base.ReaderRead();
			}
			this.errors.Error(base.Line, base.Col, string.Format("Identifier too long", new object[0]));
			while (AbstractLexer.IsIdentifierPart(base.ReaderPeek()))
			{
				base.ReaderRead();
			}
			IL_160:
			return new string(this.identBuffer, 0, num);
		}

		private void ReadMultiLineComment()
		{
			if (base.SkipAllComments)
			{
				int num;
				while ((num = base.ReaderRead()) != -1)
				{
					char c = (char)num;
					if (c == '*' && base.ReaderPeek() == 47)
					{
						base.ReaderRead();
						return;
					}
					base.HandleLineEnd(c);
				}
			}
			else
			{
				this.specialTracker.StartComment(CommentType.Block, this.isAtLineBegin, new Location(base.Col, base.Line));
				string text = null;
				StringBuilder stringBuilder = new StringBuilder();
				Location empty = Location.Empty;
				int num;
				while ((num = base.ReaderRead()) != -1)
				{
					char c2 = (char)num;
					if (base.HandleLineEnd(c2))
					{
						if (text != null)
						{
							base.TagComments.Add(new TagComment(text, stringBuilder.ToString(), this.isAtLineBegin, empty, new Location(base.Col, base.Line)));
							text = null;
						}
						stringBuilder.Length = 0;
						this.specialTracker.AddString(Environment.NewLine);
					}
					else
					{
						if (c2 == '*' && base.ReaderPeek() == 47)
						{
							if (text != null)
							{
								base.TagComments.Add(new TagComment(text, stringBuilder.ToString(), this.isAtLineBegin, empty, new Location(base.Col, base.Line)));
							}
							base.ReaderRead();
							this.specialTracker.FinishComment(new Location(base.Col, base.Line));
							return;
						}
						this.specialTracker.AddChar(c2);
						if (text != null || AbstractLexer.IsIdentifierPart((int)c2))
						{
							stringBuilder.Append(c2);
						}
						else
						{
							if (this.specialCommentHash != null && this.specialCommentHash.ContainsKey(stringBuilder.ToString()))
							{
								text = stringBuilder.ToString();
								empty = new Location(base.Col, base.Line);
							}
							stringBuilder.Length = 0;
						}
					}
				}
				this.specialTracker.FinishComment(new Location(base.Col, base.Line));
			}
			this.errors.Error(base.Line, base.Col, string.Format("Reached EOF before the end of a multiline comment", new object[0]));
		}

		private Token ReadOperator(char ch)
		{
			int col = base.Col - 1;
			int line = base.Line;
			switch (ch)
			{
			case '!':
			{
				int num = base.ReaderPeek();
				if (num == 61)
				{
					base.ReaderRead();
					return new Token(34, col, line);
				}
				return new Token(24, col, line);
			}
			case '"':
			case '#':
			case '$':
			case '\'':
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				break;
			case '%':
			{
				int num2 = base.ReaderPeek();
				if (num2 == 61)
				{
					base.ReaderRead();
					return new Token(42, col, line);
				}
				return new Token(8, col, line);
			}
			case '&':
			{
				int num3 = base.ReaderPeek();
				if (num3 == 38)
				{
					base.ReaderRead();
					return new Token(25, col, line);
				}
				if (num3 != 61)
				{
					return new Token(28, col, line);
				}
				base.ReaderRead();
				return new Token(43, col, line);
			}
			case '(':
				return new Token(20, col, line);
			case ')':
				return new Token(21, col, line);
			case '*':
			{
				int num4 = base.ReaderPeek();
				if (num4 == 61)
				{
					base.ReaderRead();
					return new Token(40, col, line);
				}
				return new Token(6, col, line);
			}
			case '+':
			{
				int num5 = base.ReaderPeek();
				if (num5 == 43)
				{
					base.ReaderRead();
					return new Token(31, col, line);
				}
				if (num5 != 61)
				{
					return new Token(4, col, line);
				}
				base.ReaderRead();
				return new Token(38, col, line);
			}
			case ',':
				return new Token(14, col, line);
			case '-':
			{
				int num6 = base.ReaderPeek();
				if (num6 == 45)
				{
					base.ReaderRead();
					return new Token(32, col, line);
				}
				switch (num6)
				{
				case 61:
					base.ReaderRead();
					return new Token(39, col, line);
				case 62:
					base.ReaderRead();
					return new Token(47, col, line);
				default:
					return new Token(5, col, line);
				}
				break;
			}
			case '.':
			{
				int num7 = base.ReaderPeek();
				if (num7 > 0 && char.IsDigit((char)num7))
				{
					return this.ReadDigit('.', base.Col - 1);
				}
				return new Token(15, col, line);
			}
			case '/':
			{
				int num8 = base.ReaderPeek();
				if (num8 == 61)
				{
					base.ReaderRead();
					return new Token(41, col, line);
				}
				return new Token(7, col, line);
			}
			case ':':
				if (base.ReaderPeek() == 58)
				{
					base.ReaderRead();
					return new Token(10, col, line);
				}
				return new Token(9, col, line);
			case ';':
				return new Token(11, col, line);
			case '<':
				switch (base.ReaderPeek())
				{
				case 60:
				{
					base.ReaderRead();
					int num9 = base.ReaderPeek();
					if (num9 == 61)
					{
						base.ReaderRead();
						return new Token(46, col, line);
					}
					return new Token(37, col, line);
				}
				case 61:
					base.ReaderRead();
					return new Token(36, col, line);
				default:
					return new Token(23, col, line);
				}
				break;
			case '=':
				switch (base.ReaderPeek())
				{
				case 61:
					base.ReaderRead();
					return new Token(33, col, line);
				case 62:
					base.ReaderRead();
					return new Token(48, col, line);
				default:
					return new Token(3, col, line);
				}
				break;
			case '>':
			{
				int num10 = base.ReaderPeek();
				if (num10 == 61)
				{
					base.ReaderRead();
					return new Token(35, col, line);
				}
				return new Token(22, col, line);
			}
			case '?':
				if (base.ReaderPeek() == 63)
				{
					base.ReaderRead();
					return new Token(13, col, line);
				}
				return new Token(12, col, line);
			default:
				switch (ch)
				{
				case '[':
					return new Token(18, col, line);
				case '\\':
					break;
				case ']':
					return new Token(19, col, line);
				case '^':
				{
					int num11 = base.ReaderPeek();
					if (num11 == 61)
					{
						base.ReaderRead();
						return new Token(45, col, line);
					}
					return new Token(30, col, line);
				}
				default:
					switch (ch)
					{
					case '{':
						return new Token(16, col, line);
					case '|':
					{
						int num12 = base.ReaderPeek();
						if (num12 == 61)
						{
							base.ReaderRead();
							return new Token(44, col, line);
						}
						if (num12 == 124)
						{
							base.ReaderRead();
							return new Token(26, col, line);
						}
						return new Token(29, col, line);
					}
					case '}':
						return new Token(17, col, line);
					case '~':
						return new Token(27, col, line);
					}
					break;
				}
				break;
			}
			return null;
		}

		private void ReadPreProcessingDirective()
		{
			PreprocessingDirective preprocessingDirective = this.ReadPreProcessingDirectiveInternal(true, true);
			this.specialTracker.AddPreprocessingDirective(preprocessingDirective);
			string cmd;
			if (base.EvaluateConditionalCompilation && (cmd = preprocessingDirective.Cmd) != null)
			{
				if (cmd == "#define")
				{
					this.conditionalCompilation.Define(preprocessingDirective.Arg);
					return;
				}
				if (cmd == "#undef")
				{
					this.conditionalCompilation.Undefine(preprocessingDirective.Arg);
					return;
				}
				if (!(cmd == "#if"))
				{
					if (!(cmd == "#elif") && !(cmd == "#else"))
					{
						return;
					}
					int num = 1;
					while (true)
					{
						preprocessingDirective = this.SkipToPreProcessingDirective(false, false);
						if (preprocessingDirective == null)
						{
							break;
						}
						if (preprocessingDirective.Cmd == "#if")
						{
							num++;
						}
						else if (preprocessingDirective.Cmd == "#endif")
						{
							num--;
							if (num == 0)
							{
								break;
							}
						}
					}
					if (preprocessingDirective != null)
					{
						this.specialTracker.AddPreprocessingDirective(preprocessingDirective);
					}
				}
				else if (!this.conditionalCompilation.Evaluate(preprocessingDirective.Expression))
				{
					int num2 = 1;
					while (true)
					{
						preprocessingDirective = this.SkipToPreProcessingDirective(false, num2 == 1);
						if (preprocessingDirective == null)
						{
							break;
						}
						if (preprocessingDirective.Cmd == "#if")
						{
							num2++;
						}
						else if (preprocessingDirective.Cmd == "#endif")
						{
							num2--;
							if (num2 == 0)
							{
								break;
							}
						}
						else if (num2 == 1 && (preprocessingDirective.Cmd == "#else" || (preprocessingDirective.Cmd == "#elif" && this.conditionalCompilation.Evaluate(preprocessingDirective.Expression))))
						{
							break;
						}
					}
					if (preprocessingDirective != null)
					{
						this.specialTracker.AddPreprocessingDirective(preprocessingDirective);
						return;
					}
				}
			}
		}

		private PreprocessingDirective ReadPreProcessingDirectiveInternal(bool parseIfExpression, bool parseElifExpression)
		{
			Location start = new Location(base.Col - 1, base.Line);
			this.PPWhitespace();
			bool flag;
			string text = this.ReadIdent('#', out flag);
			this.PPWhitespace();
			if ((parseIfExpression && text == "#if") || (parseElifExpression && text == "#elif"))
			{
				this.recordedText.Length = 0;
				this.recordRead = true;
				Expression expression = this.PPExpression();
				string arg = this.recordedText.ToString();
				this.recordRead = false;
				Location end = new Location(base.Col, base.Line);
				int num = base.ReaderRead();
				if (num >= 0 && !base.HandleLineEnd((char)num))
				{
					if (num != 47 || base.ReaderRead() != 47)
					{
						this.errors.Error(base.Col, base.Line, "Expected end of line");
					}
					base.SkipToEndOfLine();
				}
				return new PreprocessingDirective(text, arg, start, end)
				{
					Expression = expression,
					LastLineEnd = this.lastLineEnd
				};
			}
			Location end2 = new Location(base.Col, base.Line);
			string text2 = base.ReadToEndOfLine();
			end2.Column += text2.Length;
			int num2 = text2.IndexOf("//");
			if (num2 >= 0)
			{
				text2 = text2.Substring(0, num2);
			}
			text2 = text2.Trim();
			return new PreprocessingDirective(text, text2, start, end2)
			{
				LastLineEnd = this.lastLineEnd
			};
		}

		private void ReadSingleLineComment(CommentType commentType)
		{
			if (base.SkipAllComments)
			{
				base.SkipToEndOfLine();
				return;
			}
			this.specialTracker.StartComment(commentType, this.isAtLineBegin, new Location(base.Col, base.Line));
			this.specialTracker.AddString(this.ReadCommentToEOL());
			this.specialTracker.FinishComment(new Location(base.Col, base.Line));
		}

		private Token ReadString()
		{
			int num = base.Col - 1;
			int line = base.Line;
			this.sb.Length = 0;
			this.originalValue.Length = 0;
			this.originalValue.Append('"');
			bool flag = false;
			int num2;
			while ((num2 = base.ReaderRead()) != -1)
			{
				char c = (char)num2;
				if (c == '"')
				{
					flag = true;
					this.originalValue.Append('"');
					break;
				}
				if (c == '\\')
				{
					this.originalValue.Append('\\');
					string text;
					this.originalValue.Append(this.ReadEscapeSequence(out c, out text));
					if (text != null)
					{
						this.sb.Append(text);
					}
					else
					{
						this.sb.Append(c);
					}
				}
				else
				{
					if (base.HandleLineEnd(c))
					{
						this.errors.Error(line, num, string.Format("No new line is allowed inside a string literal", new object[0]));
						break;
					}
					this.originalValue.Append(c);
					this.sb.Append(c);
				}
			}
			if (!flag)
			{
				this.errors.Error(line, num, string.Format("End of file reached inside string literal", new object[0]));
			}
			return new Token(2, num, line, this.originalValue.ToString(), this.sb.ToString(), LiteralFormat.StringLiteral);
		}

		private Token ReadVerbatimString()
		{
			this.sb.Length = 0;
			this.originalValue.Length = 0;
			this.originalValue.Append("@\"");
			Location startLocation = new Location(base.Col - 2, base.Line);
			int num;
			while ((num = base.ReaderRead()) != -1)
			{
				char c = (char)num;
				if (c == '"')
				{
					if (base.ReaderPeek() != 34)
					{
						this.originalValue.Append('"');
						break;
					}
					this.originalValue.Append("\"\"");
					this.sb.Append('"');
					base.ReaderRead();
				}
				else if (base.HandleLineEnd(c))
				{
					this.sb.Append("\r\n");
					this.originalValue.Append("\r\n");
				}
				else
				{
					this.sb.Append(c);
					this.originalValue.Append(c);
				}
			}
			if (num == -1)
			{
				this.errors.Error(startLocation.Line, startLocation.Column, string.Format("End of file reached inside verbatim string literal", new object[0]));
			}
			return new Token(2, startLocation, new Location(base.Col, base.Line), this.originalValue.ToString(), this.sb.ToString(), LiteralFormat.VerbatimStringLiteral);
		}

		public override void SetConditionalCompilationSymbols(string symbols)
		{
			foreach (string current in AbstractLexer.GetSymbols(symbols))
			{
				this.conditionalCompilation.Define(current);
			}
		}

		public override void SkipCurrentBlock(int targetToken)
		{
			int num = 0;
			while (this.curToken != null)
			{
				if (this.curToken.kind == 16)
				{
					num++;
				}
				else if (this.curToken.kind == 17 && --num < 0)
				{
					return;
				}
				this.lastToken = this.curToken;
				this.curToken = this.curToken.next;
			}
			this.isAtLineBegin = true;
			int num2;
			while ((num2 = base.ReaderRead()) != -1)
			{
				int num3 = num2;
				if (num3 <= 35)
				{
					if (num3 != 10 && num3 != 13)
					{
						switch (num3)
						{
						case 34:
							this.ReadString();
							this.isAtLineBegin = false;
							break;
						case 35:
							this.ReadPreProcessingDirective();
							this.isAtLineBegin = false;
							break;
						}
					}
					else
					{
						base.HandleLineEnd((char)num2);
						this.isAtLineBegin = true;
					}
				}
				else if (num3 <= 47)
				{
					if (num3 != 39)
					{
						if (num3 == 47)
						{
							int num4 = base.ReaderPeek();
							if (num4 == 47 || num4 == 42)
							{
								this.ReadComment();
							}
							this.isAtLineBegin = false;
						}
					}
					else
					{
						this.ReadChar();
						this.isAtLineBegin = false;
					}
				}
				else if (num3 != 64)
				{
					switch (num3)
					{
					case 123:
						this.isAtLineBegin = false;
						num++;
						break;
					case 125:
						this.isAtLineBegin = false;
						if (--num < 0)
						{
							this.curToken = new Token(17, base.Col - 1, base.Line);
							return;
						}
						break;
					}
				}
				else
				{
					int num5 = base.ReaderRead();
					if (num5 == -1)
					{
						this.errors.Error(base.Line, base.Col, string.Format("EOF after @", new object[0]));
					}
					else if (num5 == 34)
					{
						this.ReadVerbatimString();
					}
					this.isAtLineBegin = false;
				}
			}
			this.curToken = new Token(0, base.Col, base.Line);
		}

		private PreprocessingDirective SkipToPreProcessingDirective(bool parseIfExpression, bool parseElifExpression)
		{
			while (true)
			{
				this.PPWhitespace();
				int num = base.ReaderRead();
				if (num == -1)
				{
					break;
				}
				if (num == 35)
				{
					goto IL_4C;
				}
				base.SkipToEndOfLine();
			}
			this.errors.Error(base.Line, base.Col, string.Format("Reached EOF but expected #endif", new object[0]));
			return null;
			IL_4C:
			return this.ReadPreProcessingDirectiveInternal(parseIfExpression, parseElifExpression);
		}

		public override IDictionary<string, object> ConditionalCompilationSymbols
		{
			get
			{
				return this.conditionalCompilation.Symbols;
			}
		}

		private ConditionalCompilation conditionalCompilation = new ConditionalCompilation();

		private readonly char[] escapeSequenceBuffer = new char[12];

		private char[] identBuffer = new char[512];

		private bool isAtLineBegin = true;

		private const int MAX_IDENTIFIER_LENGTH = 512;
	}
}
