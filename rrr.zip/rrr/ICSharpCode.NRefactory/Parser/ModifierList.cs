﻿using System;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory.Parser
{
	internal class ModifierList
	{
		public void Add(Modifiers m, Location tokenLocation)
		{
			if (this.location.IsEmpty)
			{
				this.location = tokenLocation;
			}
			if ((this.cur & m) == Modifiers.None)
			{
				this.cur |= m;
			}
		}

		public void Check(Modifiers allowed)
		{
			Modifiers modifiers = this.cur & ~allowed;
		}

		public bool Contains(Modifiers m)
		{
			return (this.cur & m) != Modifiers.None;
		}

		public Location GetDeclarationLocation(Location keywordLocation)
		{
			if (this.location.IsEmpty)
			{
				return keywordLocation;
			}
			return this.location;
		}

		public bool isNone
		{
			get
			{
				return this.cur == Modifiers.None;
			}
		}

		public Modifiers Modifier
		{
			get
			{
				return this.cur;
			}
		}

		private Modifiers cur;

		private Location location = new Location(-1, -1);
	}
}
