﻿using System;

namespace ICSharpCode.NRefactory.Parser
{
	public delegate void ErrorCodeProc(int line, int col, int n);
}
