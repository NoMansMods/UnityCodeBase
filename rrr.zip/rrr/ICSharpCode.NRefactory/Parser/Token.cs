﻿using System;
using ICSharpCode.NRefactory.Parser.CSharp;
using ICSharpCode.NRefactory.Parser.VB;

namespace ICSharpCode.NRefactory.Parser
{
	public class Token
	{
		public Token(int kind) : this(kind, 0, 0)
		{
		}

		public Token(int kind, int col, int line) : this(kind, col, line, null)
		{
		}

		public Token(int kind, int col, int line, string val)
		{
			this.kind = kind;
			this.col = col;
			this.line = line;
			this.val = val;
			this.endLocation = new Location(col + (string.IsNullOrEmpty(val) ? 1 : val.Length), line);
		}

		internal Token(int kind, int x, int y, string val, object literalValue, LiteralFormat literalFormat) : this(kind, new Location(x, y), new Location(x + val.Length, y), val, literalValue, literalFormat)
		{
		}

		public Token(int kind, Location startLocation, Location endLocation, string val, object literalValue, LiteralFormat literalFormat)
		{
			this.kind = kind;
			this.col = startLocation.Column;
			this.line = startLocation.Line;
			this.endLocation = endLocation;
			this.val = val;
			this.literalValue = literalValue;
			this.literalFormat = literalFormat;
		}

		public override string ToString()
		{
			return string.Format("[C# {0}/VB {1} Location={3} EndLocation={4} val={5}]", new object[]
			{
				ICSharpCode.NRefactory.Parser.CSharp.Tokens.GetTokenString(this.kind),
				ICSharpCode.NRefactory.Parser.VB.Tokens.GetTokenString(this.kind),
				this.Location,
				this.EndLocation,
				this.val
			});
		}

		public Location EndLocation
		{
			get
			{
				return this.endLocation;
			}
		}

		public int Kind
		{
			get
			{
				return this.kind;
			}
		}

		public LiteralFormat LiteralFormat
		{
			get
			{
				return this.literalFormat;
			}
		}

		public object LiteralValue
		{
			get
			{
				return this.literalValue;
			}
		}

		public Location Location
		{
			get
			{
				return new Location(this.col, this.line);
			}
		}

		public string Value
		{
			get
			{
				return this.val;
			}
		}

		internal readonly int col;

		private readonly Location endLocation;

		internal readonly int kind;

		internal readonly int line;

		internal readonly LiteralFormat literalFormat;

		internal readonly object literalValue;

		internal Token next;

		internal readonly string val;
	}
}
