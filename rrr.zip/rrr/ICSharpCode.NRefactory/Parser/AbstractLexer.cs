﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ICSharpCode.NRefactory.Parser
{
	public abstract class AbstractLexer : ILexer, IDisposable
	{
		protected AbstractLexer(TextReader reader)
		{
			this.reader = reader;
		}

		public virtual void Dispose()
		{
			this.reader.Close();
			this.reader = null;
			this.errors = null;
			this.lastToken = (this.curToken = (this.peekToken = null));
			this.specialCommentHash = null;
			this.tagComments = null;
			this.sb = (this.originalValue = null);
		}

		protected int GetHexNumber(char digit)
		{
			if (char.IsDigit(digit))
			{
				return (int)(digit - '0');
			}
			if ('A' <= digit && digit <= 'F')
			{
				return (int)(digit - 'A' + '\n');
			}
			if ('a' <= digit && digit <= 'f')
			{
				return (int)(digit - 'a' + '\n');
			}
			this.errors.Error(this.line, this.col, string.Format("Invalid hex number '" + digit + "'", new object[0]));
			return 0;
		}

		protected static IEnumerable<string> GetSymbols(string symbols)
		{
			if (!string.IsNullOrEmpty(symbols))
			{
				try
				{
					string[] array = symbols.Split(new char[]
					{
						';',
						' ',
						'\t'
					});
					for (int i = 0; i < array.Length; i++)
					{
						string text = array[i];
						string text2 = text.Trim();
						if (text2.Length != 0)
						{
							yield return text2;
						}
					}
				}
				finally
				{
				}
			}
			yield break;
		}

		protected bool HandleLineEnd(char ch)
		{
			if (ch == '\r')
			{
				if (this.reader.Peek() == 10)
				{
					this.ReaderRead();
					return true;
				}
				this.LineBreak();
				return true;
			}
			else
			{
				if (ch == '\n')
				{
					this.LineBreak();
					return true;
				}
				return false;
			}
		}

		protected static bool IsHex(char digit)
		{
			return char.IsDigit(digit) || ('A' <= digit && digit <= 'F') || ('a' <= digit && digit <= 'f');
		}

		protected static bool IsIdentifierPart(int ch)
		{
			return ch == 95 || (ch != -1 && char.IsLetterOrDigit((char)ch));
		}

		protected void LineBreak()
		{
			this.lastLineEnd = this.curLineEnd;
			this.curLineEnd = new Location(this.col - 1, this.line);
		}

		protected abstract Token Next();

		public virtual Token NextToken()
		{
			if (this.curToken == null)
			{
				this.curToken = this.Next();
				this.specialTracker.InformToken(this.curToken.kind);
				return this.curToken;
			}
			this.lastToken = this.curToken;
			if (this.curToken.next == null)
			{
				this.curToken.next = this.Next();
				if (this.curToken.next != null)
				{
					this.specialTracker.InformToken(this.curToken.next.kind);
				}
			}
			this.curToken = this.curToken.next;
			return this.curToken;
		}

		public Token Peek()
		{
			if (this.peekToken.next == null)
			{
				this.peekToken.next = this.Next();
				this.specialTracker.InformToken(this.peekToken.next.kind);
			}
			this.peekToken = this.peekToken.next;
			return this.peekToken;
		}

		protected int ReaderPeek()
		{
			return this.reader.Peek();
		}

		protected int ReaderRead()
		{
			this.col++;
			int num = this.reader.Read();
			if (this.recordRead && num >= 0)
			{
				this.recordedText.Append((char)num);
			}
			if ((num == 13 && this.reader.Peek() != 10) || num == 10)
			{
				this.line++;
				this.col = 1;
				this.LineBreak();
			}
			return num;
		}

		protected string ReadToEndOfLine()
		{
			this.sb.Length = 0;
			int num;
			while ((num = this.reader.Read()) != -1)
			{
				char value = (char)num;
				if (num == 13)
				{
					if (this.reader.Peek() == 10)
					{
						this.reader.Read();
					}
					num = 10;
				}
				if (num == 10)
				{
					this.line++;
					this.col = 1;
					return this.sb.ToString();
				}
				this.sb.Append(value);
			}
			string text = this.sb.ToString();
			this.col += text.Length;
			return text;
		}

		public virtual void SetConditionalCompilationSymbols(string symbols)
		{
			throw new NotSupportedException();
		}

		public abstract void SkipCurrentBlock(int targetToken);

		protected void SkipToEndOfLine()
		{
			int num;
			while ((num = this.reader.Read()) != -1)
			{
				if (num == 13)
				{
					if (this.reader.Peek() == 10)
					{
						this.reader.Read();
					}
					num = 10;
				}
				if (num == 10)
				{
					this.line++;
					this.col = 1;
					return;
				}
			}
		}

		public void StartPeek()
		{
			this.peekToken = this.curToken;
		}

		protected int Col
		{
			get
			{
				return this.col;
			}
		}

		public virtual IDictionary<string, object> ConditionalCompilationSymbols
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		public Errors Errors
		{
			get
			{
				return this.errors;
			}
		}

		public bool EvaluateConditionalCompilation
		{
			get;
			set;
		}

		protected int Line
		{
			get
			{
				return this.line;
			}
		}

		public Token LookAhead
		{
			get
			{
				return this.curToken;
			}
		}

		public bool SkipAllComments
		{
			get;
			set;
		}

		public string[] SpecialCommentTags
		{
			get
			{
				return this.specialCommentTags;
			}
			set
			{
				this.specialCommentTags = value;
				this.specialCommentHash = null;
				if (this.specialCommentTags != null && this.specialCommentTags.Length > 0)
				{
					this.specialCommentHash = new Hashtable();
					string[] array = this.specialCommentTags;
					for (int i = 0; i < array.Length; i++)
					{
						string key = array[i];
						this.specialCommentHash.Add(key, null);
					}
				}
			}
		}

		public SpecialTracker SpecialTracker
		{
			get
			{
				return this.specialTracker;
			}
		}

		public List<TagComment> TagComments
		{
			get
			{
				return this.tagComments;
			}
		}

		public Token Token
		{
			get
			{
				return this.lastToken;
			}
		}

		private int col = 1;

		protected Location curLineEnd = new Location(1, 1);

		protected Token curToken;

		[CLSCompliant(false)]
		protected Errors errors = new Errors();

		protected Location lastLineEnd = new Location(1, 1);

		protected Token lastToken;

		private int line = 1;

		protected StringBuilder originalValue = new StringBuilder();

		protected Token peekToken;

		private TextReader reader;

		protected StringBuilder recordedText = new StringBuilder();

		protected bool recordRead;

		protected StringBuilder sb = new StringBuilder();

		protected Hashtable specialCommentHash;

		private string[] specialCommentTags;

		[CLSCompliant(false)]
		protected SpecialTracker specialTracker = new SpecialTracker();

		private List<TagComment> tagComments = new List<TagComment>();
	}
}
