﻿using System;

namespace ICSharpCode.NRefactory.Parser
{
	public delegate void ErrorMsgProc(int line, int col, string msg);
}
