﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ICSharpCode.NRefactory.Parser
{
	public class SpecialTracker
	{
		public void AddChar(char c)
		{
			this.sb.Append(c);
		}

		public void AddEndOfLine(Location point)
		{
			this.currentSpecials.Add(new BlankLine(point));
		}

		public void AddPreprocessingDirective(PreprocessingDirective directive)
		{
			if (directive == null)
			{
				throw new ArgumentNullException("directive");
			}
			this.currentSpecials.Add(directive);
		}

		public void AddString(string s)
		{
			this.sb.Append(s);
		}

		public void FinishComment(Location endPosition)
		{
			this.currentSpecials.Add(new Comment(this.currentCommentType, this.sb.ToString(), this.commentStartsLine, this.startPosition, endPosition));
		}

		public void InformToken(int kind)
		{
		}

		public List<ISpecial> RetrieveSpecials()
		{
			List<ISpecial> result = this.currentSpecials;
			this.currentSpecials = new List<ISpecial>();
			return result;
		}

		public void StartComment(CommentType commentType, bool commentStartsLine, Location startPosition)
		{
			this.currentCommentType = commentType;
			this.startPosition = startPosition;
			this.sb.Length = 0;
			this.commentStartsLine = commentStartsLine;
		}

		public List<ISpecial> CurrentSpecials
		{
			get
			{
				return this.currentSpecials;
			}
		}

		private bool commentStartsLine;

		private CommentType currentCommentType;

		private List<ISpecial> currentSpecials = new List<ISpecial>();

		private StringBuilder sb = new StringBuilder();

		private Location startPosition;
	}
}
