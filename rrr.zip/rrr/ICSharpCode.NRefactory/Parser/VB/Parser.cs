﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Visitors;

namespace ICSharpCode.NRefactory.Parser.VB
{
	internal sealed class Parser : AbstractParser
	{
		public Parser(ILexer lexer) : base(lexer)
		{
			this.lexer = (Lexer)lexer;
		}

		private void AccessorDecls(out PropertyGetRegion getBlock, out PropertySetRegion setBlock)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			getBlock = null;
			setBlock = null;
			while (this.la.kind == 28)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			if (this.StartOf(24))
			{
				this.GetAccessorDecl(out getBlock, list);
				if (this.StartOf(25))
				{
					list = new List<AttributeSection>();
					while (this.la.kind == 28)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list.Add(item);
					}
					this.SetAccessorDecl(out setBlock, list);
					return;
				}
			}
			else if (this.StartOf(26))
			{
				this.SetAccessorDecl(out setBlock, list);
				if (this.StartOf(27))
				{
					list = new List<AttributeSection>();
					while (this.la.kind == 28)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list.Add(item);
					}
					this.GetAccessorDecl(out getBlock, list);
					return;
				}
			}
			else
			{
				base.SynErr(251);
			}
		}

		private void AdditiveExpr(out Expression outExpr)
		{
			this.ModuloExpr(out outExpr);
			while (this.la.kind == 18 || this.la.kind == 19)
			{
				BinaryOperatorType op;
				if (this.la.kind == 19)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Add;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Subtract;
				}
				Expression right;
				this.ModuloExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void AggregateQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionFromClause fromClause = null;
			QueryExpressionAggregateClause queryExpressionAggregateClause = new QueryExpressionAggregateClause();
			queryExpressionAggregateClause.IntoVariables = new List<ExpressionRangeVariable>();
			queryExpressionAggregateClause.StartLocation = this.la.Location;
			base.Expect(45);
			this.CollectionRangeVariableDeclaration(out fromClause);
			queryExpressionAggregateClause.FromClause = fromClause;
			while (this.StartOf(31))
			{
				this.QueryOperator(queryExpressionAggregateClause.MiddleClauses);
			}
			base.Expect(130);
			this.ExpressionRangeVariableDeclarationList(queryExpressionAggregateClause.IntoVariables);
			queryExpressionAggregateClause.EndLocation = this.t.EndLocation;
			middleClauses.Add(queryExpressionAggregateClause);
		}

		private void Argument(out Expression argumentexpr)
		{
			argumentexpr = null;
			if (this.IsNamedAssign())
			{
				this.Identifier();
				string val = this.t.val;
				base.Expect(11);
				base.Expect(10);
				Expression expression;
				this.Expr(out expression);
				argumentexpr = new NamedArgumentExpression(val, expression);
				return;
			}
			if (this.StartOf(29))
			{
				this.Expr(out argumentexpr);
				return;
			}
			base.SynErr(267);
		}

		private void ArgumentList(out List<Expression> arguments)
		{
			arguments = new List<Expression>();
			Expression expression = null;
			if (this.StartOf(29))
			{
				this.Argument(out expression);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				arguments.Add(expression ?? Expression.Null);
				expression = null;
				if (this.StartOf(29))
				{
					this.Argument(out expression);
				}
				if (expression == null)
				{
					expression = Expression.Null;
				}
			}
			if (expression != null)
			{
				arguments.Add(expression);
			}
		}

		private void ArrayInitializationModifier(out List<Expression> arrayModifiers)
		{
			arrayModifiers = null;
			base.Expect(25);
			this.InitializationRankList(out arrayModifiers);
			base.Expect(26);
		}

		private void ArrayNameModifier(out ArrayList arrayModifiers)
		{
			arrayModifiers = null;
			this.ArrayTypeModifiers(out arrayModifiers);
		}

		private void ArrayTypeModifiers(out ArrayList arrayModifiers)
		{
			arrayModifiers = new ArrayList();
			int num = 0;
			while (this.IsDims())
			{
				base.Expect(25);
				if (this.la.kind == 12 || this.la.kind == 26)
				{
					this.RankList(out num);
				}
				arrayModifiers.Add(num);
				base.Expect(26);
			}
			if (arrayModifiers.Count == 0)
			{
				arrayModifiers = null;
			}
		}

		private void AssignmentOperator(out AssignmentOperatorType op)
		{
			op = AssignmentOperatorType.None;
			int kind = this.la.kind;
			if (kind == 10)
			{
				this.lexer.NextToken();
				op = AssignmentOperatorType.Assign;
				return;
			}
			switch (kind)
			{
			case 34:
				this.lexer.NextToken();
				op = AssignmentOperatorType.Add;
				return;
			case 35:
				this.lexer.NextToken();
				op = AssignmentOperatorType.Power;
				return;
			case 36:
				this.lexer.NextToken();
				op = AssignmentOperatorType.Subtract;
				return;
			case 37:
				this.lexer.NextToken();
				op = AssignmentOperatorType.Multiply;
				return;
			case 38:
				this.lexer.NextToken();
				op = AssignmentOperatorType.Divide;
				return;
			case 39:
				this.lexer.NextToken();
				op = AssignmentOperatorType.DivideInteger;
				return;
			case 40:
				this.lexer.NextToken();
				op = AssignmentOperatorType.ShiftLeft;
				return;
			case 41:
				this.lexer.NextToken();
				op = AssignmentOperatorType.ShiftRight;
				return;
			case 42:
				this.lexer.NextToken();
				op = AssignmentOperatorType.ConcatString;
				return;
			default:
				base.SynErr(256);
				return;
			}
		}

		private void Attribute(out ICSharpCode.NRefactory.Ast.Attribute attribute)
		{
			List<Expression> list = new List<Expression>();
			List<NamedArgumentExpression> list2 = new List<NamedArgumentExpression>();
			if (this.la.kind == 117)
			{
				this.lexer.NextToken();
				base.Expect(16);
			}
			string name;
			this.Qualident(out name);
			if (this.la.kind == 25)
			{
				this.AttributeArguments(list, list2);
			}
			attribute = new ICSharpCode.NRefactory.Ast.Attribute(name, list, list2);
		}

		private void AttributeArguments(List<Expression> positional, List<NamedArgumentExpression> named)
		{
			bool flag = false;
			string text = "";
			base.Expect(25);
			if (this.IsNotClosingParenthesis())
			{
				if (this.IsNamedAssign())
				{
					flag = true;
					this.IdentifierOrKeyword(out text);
					if (this.la.kind == 11)
					{
						this.lexer.NextToken();
					}
					base.Expect(10);
				}
				Expression expression;
				this.Expr(out expression);
				if (expression != null)
				{
					if (string.IsNullOrEmpty(text))
					{
						positional.Add(expression);
					}
					else
					{
						named.Add(new NamedArgumentExpression(text, expression));
						text = "";
					}
				}
				while (this.la.kind == 12)
				{
					this.lexer.NextToken();
					if (this.IsNamedAssign())
					{
						flag = true;
						this.IdentifierOrKeyword(out text);
						if (this.la.kind == 11)
						{
							this.lexer.NextToken();
						}
						base.Expect(10);
					}
					else if (this.StartOf(29))
					{
						if (flag)
						{
							this.Error("no positional argument after named argument");
						}
					}
					else
					{
						base.SynErr(269);
					}
					this.Expr(out expression);
					if (expression != null)
					{
						if (text == "")
						{
							positional.Add(expression);
						}
						else
						{
							named.Add(new NamedArgumentExpression(text, expression));
							text = "";
						}
					}
				}
			}
			base.Expect(26);
		}

		private void AttributeSection(out AttributeSection section)
		{
			string attributeTarget = "";
			List<ICSharpCode.NRefactory.Ast.Attribute> list = new List<ICSharpCode.NRefactory.Ast.Attribute>();
			base.Expect(28);
			Location location = this.t.Location;
			if (this.IsLocalAttrTarget())
			{
				if (this.la.kind == 106)
				{
					this.lexer.NextToken();
					attributeTarget = "event";
				}
				else if (this.la.kind == 180)
				{
					this.lexer.NextToken();
					attributeTarget = "return";
				}
				else
				{
					this.Identifier();
					string a = this.t.val.ToLower(CultureInfo.InvariantCulture);
					if (a != "field" || a != "method" || a != "module" || a != "param" || a != "property" || a != "type")
					{
						this.Error("attribute target specifier (event, return, field,method, module, param, property, or type) expected");
					}
					attributeTarget = this.t.val;
				}
				base.Expect(11);
			}
			ICSharpCode.NRefactory.Ast.Attribute item;
			this.Attribute(out item);
			list.Add(item);
			while (this.NotFinalComma())
			{
				base.Expect(12);
				this.Attribute(out item);
				list.Add(item);
			}
			if (this.la.kind == 12)
			{
				this.lexer.NextToken();
			}
			base.Expect(27);
			section = new AttributeSection
			{
				AttributeTarget = attributeTarget,
				Attributes = list,
				StartLocation = location,
				EndLocation = this.t.EndLocation
			};
		}

		private void Block(out Statement stmt)
		{
			BlockStatement blockStatement = new BlockStatement();
			if (this.t != null)
			{
				blockStatement.StartLocation = this.t.EndLocation;
			}
			this.compilationUnit.BlockStart(blockStatement);
			while (this.StartOf(22) || this.IsEndStmtAhead())
			{
				if (this.IsEndStmtAhead())
				{
					base.Expect(100);
					this.EndOfStmt();
					this.compilationUnit.AddChild(new EndStatement());
				}
				else
				{
					this.Statement();
					this.EndOfStmt();
				}
			}
			stmt = blockStatement;
			if (this.t != null)
			{
				blockStatement.EndLocation = this.t.EndLocation;
			}
			this.compilationUnit.BlockEnd();
		}

		private void CaseClause(out CaseLabel caseClause)
		{
			Expression label = null;
			Expression toExpression = null;
			BinaryOperatorType binaryOperatorType = BinaryOperatorType.None;
			caseClause = null;
			if (this.la.kind == 98)
			{
				this.lexer.NextToken();
				caseClause = new CaseLabel();
				return;
			}
			if (this.StartOf(43))
			{
				if (this.la.kind == 131)
				{
					this.lexer.NextToken();
				}
				int kind = this.la.kind;
				if (kind != 10)
				{
					switch (kind)
					{
					case 27:
						this.lexer.NextToken();
						binaryOperatorType = BinaryOperatorType.GreaterThan;
						break;
					case 28:
						this.lexer.NextToken();
						binaryOperatorType = BinaryOperatorType.LessThan;
						break;
					case 29:
						this.lexer.NextToken();
						binaryOperatorType = BinaryOperatorType.InEquality;
						break;
					case 30:
						this.lexer.NextToken();
						binaryOperatorType = BinaryOperatorType.GreaterThanOrEqual;
						break;
					case 31:
						this.lexer.NextToken();
						binaryOperatorType = BinaryOperatorType.LessThanOrEqual;
						break;
					default:
						base.SynErr(285);
						break;
					}
				}
				else
				{
					this.lexer.NextToken();
					binaryOperatorType = BinaryOperatorType.Equality;
				}
				this.Expr(out label);
				caseClause = new CaseLabel(binaryOperatorType, label);
				return;
			}
			if (this.StartOf(29))
			{
				this.Expr(out label);
				if (this.la.kind == 201)
				{
					this.lexer.NextToken();
					this.Expr(out toExpression);
				}
				caseClause = new CaseLabel(label, toExpression);
				return;
			}
			base.SynErr(286);
		}

		private void CaseClauses(out List<CaseLabel> caseClauses)
		{
			caseClauses = new List<CaseLabel>();
			CaseLabel caseLabel = null;
			this.CaseClause(out caseLabel);
			if (caseLabel != null)
			{
				caseClauses.Add(caseLabel);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.CaseClause(out caseLabel);
				if (caseLabel != null)
				{
					caseClauses.Add(caseLabel);
				}
			}
		}

		private void CastTarget(out TypeReference type)
		{
			type = null;
			switch (this.la.kind)
			{
			case 63:
				this.lexer.NextToken();
				type = new TypeReference("System.Boolean", true);
				return;
			case 64:
				this.lexer.NextToken();
				type = new TypeReference("System.Byte", true);
				return;
			case 65:
				this.lexer.NextToken();
				type = new TypeReference("System.Char", true);
				return;
			case 66:
				this.lexer.NextToken();
				type = new TypeReference("System.DateTime", true);
				return;
			case 67:
				this.lexer.NextToken();
				type = new TypeReference("System.Double", true);
				return;
			case 68:
				this.lexer.NextToken();
				type = new TypeReference("System.Decimal", true);
				return;
			case 70:
				this.lexer.NextToken();
				type = new TypeReference("System.Int32", true);
				return;
			case 72:
				this.lexer.NextToken();
				type = new TypeReference("System.Int64", true);
				return;
			case 73:
				this.lexer.NextToken();
				type = new TypeReference("System.Object", true);
				return;
			case 77:
				this.lexer.NextToken();
				type = new TypeReference("System.SByte", true);
				return;
			case 78:
				this.lexer.NextToken();
				type = new TypeReference("System.Int16", true);
				return;
			case 79:
				this.lexer.NextToken();
				type = new TypeReference("System.Single", true);
				return;
			case 80:
				this.lexer.NextToken();
				type = new TypeReference("System.String", true);
				return;
			case 82:
				this.lexer.NextToken();
				type = new TypeReference("System.UInt32", true);
				return;
			case 83:
				this.lexer.NextToken();
				type = new TypeReference("System.UInt64", true);
				return;
			case 84:
				this.lexer.NextToken();
				type = new TypeReference("System.UInt16", true);
				return;
			}
			base.SynErr(262);
		}

		private void CatchClauses(out List<CatchClause> catchClauses)
		{
			catchClauses = new List<CatchClause>();
			TypeReference typeReference = null;
			Statement statementBlock = null;
			Expression condition = null;
			string variableName = string.Empty;
			while (this.la.kind == 62)
			{
				this.lexer.NextToken();
				if (this.StartOf(14))
				{
					this.Identifier();
					variableName = this.t.val;
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.TypeName(out typeReference);
					}
				}
				if (this.la.kind == 214)
				{
					this.lexer.NextToken();
					this.Expr(out condition);
				}
				this.EndOfStmt();
				this.Block(out statementBlock);
				catchClauses.Add(new CatchClause(typeReference, variableName, statementBlock, condition));
			}
		}

		private void Charset(out CharsetModifier charsetModifier)
		{
			charsetModifier = CharsetModifier.None;
			if (this.la.kind != 114)
			{
				if (this.la.kind == 195)
				{
					return;
				}
				if (this.la.kind == 49)
				{
					this.lexer.NextToken();
					charsetModifier = CharsetModifier.Ansi;
					return;
				}
				if (this.la.kind == 53)
				{
					this.lexer.NextToken();
					charsetModifier = CharsetModifier.Auto;
					return;
				}
				if (this.la.kind == 208)
				{
					this.lexer.NextToken();
					charsetModifier = CharsetModifier.Unicode;
					return;
				}
				base.SynErr(248);
			}
		}

		private void ClassBaseType(out TypeReference typeRef)
		{
			typeRef = null;
			base.Expect(127);
			this.TypeName(out typeRef);
			this.EndOfStmt();
		}

		private void ClassBody(TypeDeclaration newType)
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(8))
			{
				List<AttributeSection> list = new List<AttributeSection>();
				ModifierList m = new ModifierList();
				while (this.la.kind == 28)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				while (this.StartOf(9))
				{
					this.MemberModifier(m);
				}
				this.ClassMemberDecl(m, list);
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
		}

		private void ClassMemberDecl(ModifierList m, List<AttributeSection> attributes)
		{
			this.StructureMemberDecl(m, attributes);
		}

		private void CollectionInitializer(out Expression outExpr)
		{
			Expression expression = null;
			CollectionInitializerExpression collectionInitializerExpression = new CollectionInitializerExpression();
			base.Expect(23);
			if (this.StartOf(30))
			{
				this.VariableInitializer(out expression);
				if (expression != null)
				{
					collectionInitializerExpression.CreateExpressions.Add(expression);
				}
				while (this.NotFinalComma())
				{
					base.Expect(12);
					this.VariableInitializer(out expression);
					if (expression != null)
					{
						collectionInitializerExpression.CreateExpressions.Add(expression);
					}
				}
			}
			base.Expect(24);
			outExpr = collectionInitializerExpression;
		}

		private void CollectionRangeVariableDeclaration(out QueryExpressionFromClause fromClause)
		{
			fromClause = new QueryExpressionFromClause();
			fromClause.StartLocation = this.la.Location;
			TypeReference type = null;
			Expression inExpression = null;
			this.Identifier();
			if (this.la.kind == 50)
			{
				this.lexer.NextToken();
				this.TypeName(out type);
				fromClause.Type = type;
			}
			base.Expect(125);
			this.Expr(out inExpression);
			fromClause.InExpression = inExpression;
			fromClause.EndLocation = this.t.EndLocation;
		}

		private void CollectionRangeVariableDeclarationList(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionFromClause item = null;
			this.CollectionRangeVariableDeclaration(out item);
			middleClauses.Add(item);
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.CollectionRangeVariableDeclaration(out item);
				middleClauses.Add(item);
			}
		}

		private void ComparisonExpr(out Expression outExpr)
		{
			BinaryOperatorType op = BinaryOperatorType.None;
			this.ShiftExpr(out outExpr);
			while (this.StartOf(33))
			{
				int kind = this.la.kind;
				if (kind <= 31)
				{
					if (kind != 10)
					{
						switch (kind)
						{
						case 27:
							this.lexer.NextToken();
							op = BinaryOperatorType.GreaterThan;
							break;
						case 28:
							this.lexer.NextToken();
							op = BinaryOperatorType.LessThan;
							break;
						case 29:
							this.lexer.NextToken();
							op = BinaryOperatorType.InEquality;
							break;
						case 30:
							this.lexer.NextToken();
							op = BinaryOperatorType.GreaterThanOrEqual;
							break;
						case 31:
							this.lexer.NextToken();
							op = BinaryOperatorType.LessThanOrEqual;
							break;
						}
					}
					else
					{
						this.lexer.NextToken();
						op = BinaryOperatorType.Equality;
					}
				}
				else
				{
					switch (kind)
					{
					case 131:
						this.lexer.NextToken();
						op = BinaryOperatorType.ReferenceEquality;
						break;
					case 132:
						this.lexer.NextToken();
						op = BinaryOperatorType.ReferenceInequality;
						break;
					default:
						if (kind == 136)
						{
							this.lexer.NextToken();
							op = BinaryOperatorType.Like;
						}
						break;
					}
				}
				if (this.StartOf(34))
				{
					Expression expression;
					this.ShiftExpr(out expression);
					outExpr = new BinaryOperatorExpression(outExpr, op, expression);
				}
				else if (this.la.kind == 150)
				{
					this.lexer.NextToken();
					Expression expression;
					this.ShiftExpr(out expression);
					outExpr = new BinaryOperatorExpression(outExpr, op, new UnaryOperatorExpression(expression, UnaryOperatorType.Not));
				}
				else
				{
					base.SynErr(263);
				}
			}
		}

		private void ConcatenationExpr(out Expression outExpr)
		{
			this.AdditiveExpr(out outExpr);
			while (this.la.kind == 13)
			{
				this.lexer.NextToken();
				Expression right;
				this.AdditiveExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.Concat, right);
			}
		}

		private void ConditionalExpression(out Expression expr)
		{
			ConditionalExpression conditionalExpression = new ConditionalExpression();
			BinaryOperatorExpression binaryOperatorExpression = new BinaryOperatorExpression();
			conditionalExpression.StartLocation = (binaryOperatorExpression.StartLocation = this.la.Location);
			Expression expression = null;
			Expression expression2 = null;
			Expression expression3 = null;
			base.Expect(122);
			base.Expect(25);
			this.Expr(out expression);
			base.Expect(12);
			this.Expr(out expression2);
			if (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.Expr(out expression3);
			}
			base.Expect(26);
			if (expression3 != null)
			{
				conditionalExpression.Condition = expression;
				conditionalExpression.TrueExpression = expression2;
				conditionalExpression.FalseExpression = expression3;
				conditionalExpression.EndLocation = this.t.EndLocation;
				expr = conditionalExpression;
				return;
			}
			binaryOperatorExpression.Left = expression;
			binaryOperatorExpression.Right = expression2;
			binaryOperatorExpression.Op = BinaryOperatorType.NullCoalescing;
			binaryOperatorExpression.EndLocation = this.t.EndLocation;
			expr = binaryOperatorExpression;
		}

		private void ConjunctionExpr(out Expression outExpr)
		{
			this.NotExpr(out outExpr);
			while (this.la.kind == 47 || this.la.kind == 48)
			{
				BinaryOperatorType op;
				if (this.la.kind == 47)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.BitwiseAnd;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.LogicalAnd;
				}
				Expression right;
				this.NotExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void ConstantDeclarator(List<VariableDeclaration> constantDeclaration)
		{
			Expression initializer = null;
			TypeReference typeReference = null;
			string name = string.Empty;
			this.Identifier();
			name = this.t.val;
			Location location = this.t.Location;
			if (this.la.kind == 50)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
			}
			base.Expect(10);
			this.Expr(out initializer);
			constantDeclaration.Add(new VariableDeclaration(name, initializer)
			{
				TypeReference = typeReference,
				StartLocation = location
			});
		}

		private void DisjunctionExpr(out Expression outExpr)
		{
			this.ConjunctionExpr(out outExpr);
			while (this.la.kind == 161 || this.la.kind == 163 || this.la.kind == 221)
			{
				BinaryOperatorType op;
				if (this.la.kind == 161)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.BitwiseOr;
				}
				else if (this.la.kind == 163)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.LogicalOr;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.ExclusiveOr;
				}
				Expression right;
				this.ConjunctionExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void DistinctQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionDistinctClause queryExpressionDistinctClause = new QueryExpressionDistinctClause();
			queryExpressionDistinctClause.StartLocation = this.la.Location;
			base.Expect(94);
			queryExpressionDistinctClause.EndLocation = this.t.EndLocation;
			middleClauses.Add(queryExpressionDistinctClause);
		}

		private bool DotAndIdentOrKw()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 16 && (kind == 2 || kind >= 43);
		}

		private void EmbeddedStatement(out Statement statement)
		{
			Statement statement2 = null;
			statement = null;
			Expression expression = null;
			string eventName = string.Empty;
			List<Expression> arguments = null;
			if (this.la.kind == 107)
			{
				this.lexer.NextToken();
				ExitType exitType = ExitType.None;
				int kind = this.la.kind;
				if (kind <= 171)
				{
					if (kind <= 111)
					{
						if (kind == 95)
						{
							this.lexer.NextToken();
							exitType = ExitType.Do;
							goto IL_147;
						}
						if (kind == 111)
						{
							this.lexer.NextToken();
							exitType = ExitType.For;
							goto IL_147;
						}
					}
					else
					{
						if (kind == 114)
						{
							this.lexer.NextToken();
							exitType = ExitType.Function;
							goto IL_147;
						}
						if (kind == 171)
						{
							this.lexer.NextToken();
							exitType = ExitType.Property;
							goto IL_147;
						}
					}
				}
				else if (kind <= 195)
				{
					if (kind == 182)
					{
						this.lexer.NextToken();
						exitType = ExitType.Select;
						goto IL_147;
					}
					if (kind == 195)
					{
						this.lexer.NextToken();
						exitType = ExitType.Sub;
						goto IL_147;
					}
				}
				else
				{
					if (kind == 203)
					{
						this.lexer.NextToken();
						exitType = ExitType.Try;
						goto IL_147;
					}
					if (kind == 216)
					{
						this.lexer.NextToken();
						exitType = ExitType.While;
						goto IL_147;
					}
				}
				base.SynErr(273);
				IL_147:
				statement = new ExitStatement(exitType);
				return;
			}
			if (this.la.kind == 203)
			{
				this.TryStatement(out statement);
				return;
			}
			if (this.la.kind == 76)
			{
				this.lexer.NextToken();
				ContinueType continueType = ContinueType.None;
				if (this.la.kind == 95 || this.la.kind == 111 || this.la.kind == 216)
				{
					if (this.la.kind == 95)
					{
						this.lexer.NextToken();
						continueType = ContinueType.Do;
					}
					else if (this.la.kind == 111)
					{
						this.lexer.NextToken();
						continueType = ContinueType.For;
					}
					else
					{
						this.lexer.NextToken();
						continueType = ContinueType.While;
					}
				}
				statement = new ContinueStatement(continueType);
				return;
			}
			if (this.la.kind == 200)
			{
				this.lexer.NextToken();
				if (this.StartOf(29))
				{
					this.Expr(out expression);
				}
				statement = new ThrowStatement(expression);
				return;
			}
			if (this.la.kind == 180)
			{
				this.lexer.NextToken();
				if (this.StartOf(29))
				{
					this.Expr(out expression);
				}
				statement = new ReturnStatement(expression);
				return;
			}
			if (this.la.kind == 196)
			{
				this.lexer.NextToken();
				this.Expr(out expression);
				this.EndOfStmt();
				this.Block(out statement2);
				base.Expect(100);
				base.Expect(196);
				statement = new LockStatement(expression, statement2);
				return;
			}
			if (this.la.kind == 174)
			{
				this.lexer.NextToken();
				this.Identifier();
				eventName = this.t.val;
				if (this.la.kind == 25)
				{
					this.lexer.NextToken();
					if (this.StartOf(37))
					{
						this.ArgumentList(out arguments);
					}
					base.Expect(26);
				}
				statement = new RaiseEventStatement(eventName, arguments);
				return;
			}
			if (this.la.kind == 218)
			{
				this.WithStatement(out statement);
				return;
			}
			if (this.la.kind == 43)
			{
				this.lexer.NextToken();
				Expression handlerExpression = null;
				this.Expr(out expression);
				base.Expect(12);
				this.Expr(out handlerExpression);
				statement = new AddHandlerStatement(expression, handlerExpression);
				return;
			}
			if (this.la.kind == 178)
			{
				this.lexer.NextToken();
				Expression handlerExpression2 = null;
				this.Expr(out expression);
				base.Expect(12);
				this.Expr(out handlerExpression2);
				statement = new RemoveHandlerStatement(expression, handlerExpression2);
				return;
			}
			if (this.la.kind == 216)
			{
				this.lexer.NextToken();
				this.Expr(out expression);
				this.EndOfStmt();
				this.Block(out statement2);
				base.Expect(100);
				base.Expect(216);
				statement = new DoLoopStatement(expression, statement2, ConditionType.While, ConditionPosition.Start);
				return;
			}
			if (this.la.kind == 95)
			{
				this.lexer.NextToken();
				ConditionType conditionType = ConditionType.None;
				if (this.la.kind == 209 || this.la.kind == 216)
				{
					this.WhileOrUntil(out conditionType);
					this.Expr(out expression);
					this.EndOfStmt();
					this.Block(out statement2);
					base.Expect(138);
					statement = new DoLoopStatement(expression, statement2, (conditionType == ConditionType.While) ? ConditionType.DoWhile : conditionType, ConditionPosition.Start);
					return;
				}
				if (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
					this.Block(out statement2);
					base.Expect(138);
					if (this.la.kind == 209 || this.la.kind == 216)
					{
						this.WhileOrUntil(out conditionType);
						this.Expr(out expression);
					}
					statement = new DoLoopStatement(expression, statement2, conditionType, ConditionPosition.End);
					return;
				}
				base.SynErr(274);
				return;
			}
			else if (this.la.kind == 111)
			{
				this.lexer.NextToken();
				Expression expression2 = null;
				Location location = this.t.Location;
				if (this.la.kind == 97)
				{
					this.lexer.NextToken();
					TypeReference typeReference;
					string variableName;
					this.LoopControlVariable(out typeReference, out variableName);
					base.Expect(125);
					this.Expr(out expression2);
					this.EndOfStmt();
					this.Block(out statement2);
					base.Expect(149);
					if (this.StartOf(29))
					{
						this.Expr(out expression);
					}
					statement = new ForeachStatement(typeReference, variableName, expression2, statement2, expression);
					statement.StartLocation = location;
					statement.EndLocation = this.t.EndLocation;
					return;
				}
				if (this.StartOf(38))
				{
					Expression start = null;
					Expression end = null;
					Expression step = null;
					Expression loopVariableExpression = null;
					Expression item = null;
					List<Expression> list = null;
					TypeReference typeReference;
					string variableName;
					if (this.IsLoopVariableDeclaration())
					{
						this.LoopControlVariable(out typeReference, out variableName);
					}
					else
					{
						typeReference = null;
						variableName = null;
						this.SimpleExpr(out loopVariableExpression);
					}
					base.Expect(10);
					this.Expr(out start);
					base.Expect(201);
					this.Expr(out end);
					if (this.la.kind == 190)
					{
						this.lexer.NextToken();
						this.Expr(out step);
					}
					this.EndOfStmt();
					this.Block(out statement2);
					base.Expect(149);
					if (this.StartOf(29))
					{
						this.Expr(out item);
						list = new List<Expression>();
						list.Add(item);
						while (this.la.kind == 12)
						{
							this.lexer.NextToken();
							this.Expr(out item);
							list.Add(item);
						}
					}
					statement = new ForNextStatement
					{
						TypeReference = typeReference,
						VariableName = variableName,
						LoopVariableExpression = loopVariableExpression,
						Start = start,
						End = end,
						Step = step,
						EmbeddedStatement = statement2,
						NextExpressions = list
					};
					return;
				}
				base.SynErr(275);
				return;
			}
			else
			{
				if (this.la.kind == 105)
				{
					this.lexer.NextToken();
					this.Expr(out expression);
					statement = new ErrorStatement(expression);
					return;
				}
				if (this.la.kind == 176)
				{
					this.lexer.NextToken();
					bool isPreserve = false;
					if (this.la.kind == 169)
					{
						this.lexer.NextToken();
						isPreserve = true;
					}
					this.ReDimClause(out expression);
					ReDimStatement reDimStatement = new ReDimStatement(isPreserve);
					statement = reDimStatement;
					Parser.SafeAdd<InvocationExpression>(reDimStatement, reDimStatement.ReDimClauses, expression as InvocationExpression);
					while (this.la.kind == 12)
					{
						this.lexer.NextToken();
						this.ReDimClause(out expression);
						Parser.SafeAdd<InvocationExpression>(reDimStatement, reDimStatement.ReDimClauses, expression as InvocationExpression);
					}
					return;
				}
				if (this.la.kind == 104)
				{
					this.lexer.NextToken();
					this.Expr(out expression);
					EraseStatement eraseStatement = new EraseStatement();
					if (expression != null)
					{
						Parser.SafeAdd<Expression>(eraseStatement, eraseStatement.Expressions, expression);
					}
					while (this.la.kind == 12)
					{
						this.lexer.NextToken();
						this.Expr(out expression);
						if (expression != null)
						{
							Parser.SafeAdd<Expression>(eraseStatement, eraseStatement.Expressions, expression);
						}
					}
					statement = eraseStatement;
					return;
				}
				if (this.la.kind == 191)
				{
					this.lexer.NextToken();
					statement = new StopStatement();
					return;
				}
				if (this.la.kind == 122)
				{
					base.Expect(122);
					Location location2 = this.t.Location;
					this.Expr(out expression);
					if (this.la.kind == 199)
					{
						this.lexer.NextToken();
					}
					if (this.la.kind == 1 || this.la.kind == 11)
					{
						this.EndOfStmt();
						this.Block(out statement2);
						IfElseStatement ifElseStatement = new IfElseStatement(expression, statement2);
						ifElseStatement.StartLocation = location2;
						while (this.la.kind == 99 || this.IsElseIf())
						{
							Location location3;
							if (this.IsElseIf())
							{
								base.Expect(98);
								location3 = this.t.Location;
								base.Expect(122);
							}
							else
							{
								this.lexer.NextToken();
								location3 = this.t.Location;
							}
							Expression condition = null;
							Statement embeddedStatement = null;
							this.Expr(out condition);
							if (this.la.kind == 199)
							{
								this.lexer.NextToken();
							}
							this.EndOfStmt();
							this.Block(out embeddedStatement);
							ElseIfSection elseIfSection = new ElseIfSection(condition, embeddedStatement);
							elseIfSection.StartLocation = location3;
							elseIfSection.EndLocation = this.t.Location;
							elseIfSection.Parent = ifElseStatement;
							ifElseStatement.ElseIfSections.Add(elseIfSection);
						}
						if (this.la.kind == 98)
						{
							this.lexer.NextToken();
							if (this.la.kind == 1 || this.la.kind == 11)
							{
								this.EndOfStmt();
							}
							this.Block(out statement2);
							ifElseStatement.FalseStatement.Add(statement2);
						}
						base.Expect(100);
						base.Expect(122);
						ifElseStatement.EndLocation = this.t.Location;
						statement = ifElseStatement;
						return;
					}
					if (this.StartOf(39))
					{
						IfElseStatement ifElseStatement2 = new IfElseStatement(expression);
						ifElseStatement2.StartLocation = location2;
						this.SingleLineStatementList(ifElseStatement2.TrueStatement);
						if (this.la.kind == 98)
						{
							this.lexer.NextToken();
							if (this.StartOf(39))
							{
								this.SingleLineStatementList(ifElseStatement2.FalseStatement);
							}
						}
						ifElseStatement2.EndLocation = this.t.Location;
						statement = ifElseStatement2;
						return;
					}
					base.SynErr(276);
					return;
				}
				else
				{
					if (this.la.kind == 182)
					{
						this.lexer.NextToken();
						if (this.la.kind == 61)
						{
							this.lexer.NextToken();
						}
						this.Expr(out expression);
						this.EndOfStmt();
						List<SwitchSection> list2 = new List<SwitchSection>();
						Statement statement3 = null;
						while (this.la.kind == 61)
						{
							List<CaseLabel> switchLabels = null;
							Location location4 = this.la.Location;
							this.lexer.NextToken();
							this.CaseClauses(out switchLabels);
							if (this.IsNotStatementSeparator())
							{
								this.lexer.NextToken();
							}
							this.EndOfStmt();
							SwitchSection switchSection = new SwitchSection(switchLabels);
							switchSection.StartLocation = location4;
							this.Block(out statement3);
							switchSection.Children = statement3.Children;
							switchSection.EndLocation = this.t.EndLocation;
							list2.Add(switchSection);
						}
						statement = new SwitchStatement(expression, list2);
						base.Expect(100);
						base.Expect(182);
						return;
					}
					if (this.la.kind == 157)
					{
						OnErrorStatement onErrorStatement = null;
						this.OnErrorStatement(out onErrorStatement);
						statement = onErrorStatement;
						return;
					}
					if (this.la.kind == 119)
					{
						GotoStatement gotoStatement = null;
						this.GotoStatement(out gotoStatement);
						statement = gotoStatement;
						return;
					}
					if (this.la.kind == 179)
					{
						ResumeStatement resumeStatement = null;
						this.ResumeStatement(out resumeStatement);
						statement = resumeStatement;
						return;
					}
					if (this.StartOf(38))
					{
						Expression right = null;
						bool flag = this.la.kind == 19 || this.la.kind == 18 || this.la.kind == 150 || this.la.kind == 22;
						this.SimpleExpr(out expression);
						if (this.StartOf(40))
						{
							AssignmentOperatorType op;
							this.AssignmentOperator(out op);
							this.Expr(out right);
							expression = new AssignmentExpression(expression, op, right);
						}
						else if (this.la.kind == 1 || this.la.kind == 11 || this.la.kind == 98)
						{
							if (flag)
							{
								this.Error("error in assignment.");
							}
						}
						else
						{
							base.SynErr(277);
						}
						if (expression is MemberReferenceExpression || expression is IdentifierExpression)
						{
							expression = new InvocationExpression(expression);
						}
						statement = new ExpressionStatement(expression);
						return;
					}
					if (this.la.kind == 60)
					{
						this.lexer.NextToken();
						this.SimpleExpr(out expression);
						statement = new ExpressionStatement(expression);
						return;
					}
					if (this.la.kind == 211)
					{
						this.lexer.NextToken();
						if (this.Peek(1).kind == 50)
						{
							LocalVariableDeclaration localVariableDeclaration = new LocalVariableDeclaration(Modifiers.None);
							this.VariableDeclarator(localVariableDeclaration.Variables);
							while (this.la.kind == 12)
							{
								this.lexer.NextToken();
								this.VariableDeclarator(localVariableDeclaration.Variables);
							}
							Statement embeddedStatement2;
							this.Block(out embeddedStatement2);
							statement = new UsingStatement(localVariableDeclaration, embeddedStatement2);
						}
						else if (this.StartOf(29))
						{
							this.Expr(out expression);
							Statement embeddedStatement2;
							this.Block(out embeddedStatement2);
							statement = new UsingStatement(new ExpressionStatement(expression), embeddedStatement2);
						}
						else
						{
							base.SynErr(278);
						}
						base.Expect(100);
						base.Expect(211);
						return;
					}
					if (this.StartOf(41))
					{
						this.LocalDeclarationStatement(out statement);
						return;
					}
					base.SynErr(279);
					return;
				}
			}
		}

		private void EndOfStmt()
		{
			if (this.la.kind == 1)
			{
				this.lexer.NextToken();
				return;
			}
			if (this.la.kind == 11)
			{
				this.lexer.NextToken();
				return;
			}
			base.SynErr(223);
		}

		private void EnsureIsZero(Expression expr)
		{
			if (!(expr is PrimitiveExpression) || (expr as PrimitiveExpression).StringValue != "0")
			{
				this.Error("lower bound of array must be zero");
			}
		}

		private void EnumBody(TypeDeclaration newType)
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(12))
			{
				FieldDeclaration childNode;
				this.EnumMemberDecl(out childNode);
				this.compilationUnit.AddChild(childNode);
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(100);
			base.Expect(102);
			newType.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void EnumMemberDecl(out FieldDeclaration f)
		{
			Expression initializer = null;
			List<AttributeSection> list = new List<AttributeSection>();
			AttributeSection item = null;
			while (this.la.kind == 28)
			{
				this.AttributeSection(out item);
				list.Add(item);
			}
			this.Identifier();
			f = new FieldDeclaration(list);
			VariableDeclaration variableDeclaration = new VariableDeclaration(this.t.val);
			f.Fields.Add(variableDeclaration);
			f.StartLocation = (variableDeclaration.StartLocation = this.t.Location);
			if (this.la.kind == 10)
			{
				this.lexer.NextToken();
				this.Expr(out initializer);
				variableDeclaration.Initializer = initializer;
			}
			this.EndOfStmt();
		}

		public void Error(string s)
		{
			if (this.errDist >= 2)
			{
				base.Errors.Error(this.la.line, this.la.col, s);
			}
			this.errDist = 0;
		}

		private void EventAccessorDeclaration(out EventAddRemoveRegion eventAccessorDeclaration)
		{
			Statement statement = null;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			List<AttributeSection> list2 = new List<AttributeSection>();
			eventAccessorDeclaration = null;
			while (this.la.kind == 28)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list2.Add(item);
			}
			if (this.la.kind == 43)
			{
				this.lexer.NextToken();
				if (this.la.kind == 25)
				{
					this.lexer.NextToken();
					if (this.StartOf(4))
					{
						this.FormalParameterList(list);
					}
					base.Expect(26);
				}
				base.Expect(1);
				this.Block(out statement);
				base.Expect(100);
				base.Expect(43);
				this.EndOfStmt();
				eventAccessorDeclaration = new EventAddRegion(list2);
				eventAccessorDeclaration.Block = (BlockStatement)statement;
				eventAccessorDeclaration.Parameters = list;
				return;
			}
			if (this.la.kind == 178)
			{
				this.lexer.NextToken();
				if (this.la.kind == 25)
				{
					this.lexer.NextToken();
					if (this.StartOf(4))
					{
						this.FormalParameterList(list);
					}
					base.Expect(26);
				}
				base.Expect(1);
				this.Block(out statement);
				base.Expect(100);
				base.Expect(178);
				this.EndOfStmt();
				eventAccessorDeclaration = new EventRemoveRegion(list2);
				eventAccessorDeclaration.Block = (BlockStatement)statement;
				eventAccessorDeclaration.Parameters = list;
				return;
			}
			if (this.la.kind == 174)
			{
				this.lexer.NextToken();
				if (this.la.kind == 25)
				{
					this.lexer.NextToken();
					if (this.StartOf(4))
					{
						this.FormalParameterList(list);
					}
					base.Expect(26);
				}
				base.Expect(1);
				this.Block(out statement);
				base.Expect(100);
				base.Expect(174);
				this.EndOfStmt();
				eventAccessorDeclaration = new EventRaiseRegion(list2);
				eventAccessorDeclaration.Block = (BlockStatement)statement;
				eventAccessorDeclaration.Parameters = list;
				return;
			}
			base.SynErr(252);
		}

		private void EventMemberSpecifier(out string name)
		{
			if (this.StartOf(14))
			{
				this.Identifier();
			}
			else if (this.la.kind == 144)
			{
				this.lexer.NextToken();
			}
			else if (this.la.kind == 139)
			{
				this.lexer.NextToken();
			}
			else
			{
				base.SynErr(255);
			}
			name = this.t.val;
			base.Expect(16);
			string str;
			this.IdentifierOrKeyword(out str);
			name = name + "." + str;
		}

		private void ExponentiationExpr(out Expression outExpr)
		{
			this.SimpleExpr(out outExpr);
			while (this.la.kind == 20)
			{
				this.lexer.NextToken();
				Expression right;
				this.SimpleExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.Power, right);
			}
		}

		private void Expr(out Expression expr)
		{
			expr = null;
			if (this.IsQueryExpression())
			{
				this.QueryExpr(out expr);
				return;
			}
			if (this.la.kind == 114)
			{
				this.LambdaExpr(out expr);
				return;
			}
			if (this.StartOf(21))
			{
				this.DisjunctionExpr(out expr);
				return;
			}
			base.SynErr(247);
		}

		private void ExpressionRangeVariableDeclaration(out ExpressionRangeVariable variable)
		{
			variable = new ExpressionRangeVariable();
			variable.StartLocation = this.la.Location;
			Expression expression = null;
			TypeReference type = null;
			if (this.IsIdentifiedExpressionRange())
			{
				this.Identifier();
				variable.Identifier = this.t.val;
				if (this.la.kind == 50)
				{
					this.lexer.NextToken();
					this.TypeName(out type);
					variable.Type = type;
				}
				base.Expect(10);
			}
			this.Expr(out expression);
			variable.Expression = expression;
			variable.EndLocation = this.t.EndLocation;
		}

		private void ExpressionRangeVariableDeclarationList(List<ExpressionRangeVariable> variables)
		{
			ExpressionRangeVariable item = null;
			this.ExpressionRangeVariableDeclaration(out item);
			variables.Add(item);
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.ExpressionRangeVariableDeclaration(out item);
				variables.Add(item);
			}
		}

		private void FormalParameter(out ParameterDeclarationExpression p)
		{
			List<AttributeSection> list = new List<AttributeSection>();
			TypeReference typeReference = null;
			ParamModifierList paramModifierList = new ParamModifierList(this);
			Expression defaultValue = null;
			p = null;
			ArrayList arrayList = null;
			while (this.la.kind == 28)
			{
				AttributeSection item;
				this.AttributeSection(out item);
				list.Add(item);
			}
			while (this.StartOf(35))
			{
				this.ParameterModifier(paramModifierList);
			}
			this.Identifier();
			string val = this.t.val;
			if (this.IsDims())
			{
				this.ArrayTypeModifiers(out arrayList);
			}
			if (this.la.kind == 50)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
			}
			if (typeReference != null)
			{
				if (arrayList != null)
				{
					if (typeReference.RankSpecifier != null)
					{
						this.Error("array rank only allowed one time");
					}
					else
					{
						typeReference.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
					}
				}
			}
			else
			{
				typeReference = new TypeReference("System.Object", (arrayList == null) ? null : ((int[])arrayList.ToArray(typeof(int))));
			}
			if (this.la.kind == 10)
			{
				this.lexer.NextToken();
				this.Expr(out defaultValue);
			}
			paramModifierList.Check();
			p = new ParameterDeclarationExpression(typeReference, val, paramModifierList.Modifier, defaultValue);
			p.Attributes = list;
		}

		private void FormalParameterList(List<ParameterDeclarationExpression> parameter)
		{
			ParameterDeclarationExpression parameterDeclarationExpression;
			this.FormalParameter(out parameterDeclarationExpression);
			if (parameterDeclarationExpression != null)
			{
				parameter.Add(parameterDeclarationExpression);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.FormalParameter(out parameterDeclarationExpression);
				if (parameterDeclarationExpression != null)
				{
					parameter.Add(parameterDeclarationExpression);
				}
			}
		}

		private void FromOrAggregateQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			if (this.la.kind == 113)
			{
				this.FromQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 45)
			{
				this.AggregateQueryOperator(middleClauses);
				return;
			}
			base.SynErr(264);
		}

		private void FromQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			base.Expect(113);
			this.CollectionRangeVariableDeclarationList(middleClauses);
		}

		private void GetAccessorDecl(out PropertyGetRegion getBlock, List<AttributeSection> attributes)
		{
			Statement statement = null;
			Modifiers modifier;
			this.PropertyAccessorAccessModifier(out modifier);
			base.Expect(115);
			Location location = this.t.Location;
			base.Expect(1);
			this.Block(out statement);
			getBlock = new PropertyGetRegion((BlockStatement)statement, attributes);
			base.Expect(100);
			base.Expect(115);
			getBlock.Modifier = modifier;
			getBlock.StartLocation = location;
			getBlock.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void GetTypeTypeName(out TypeReference typeref)
		{
			ArrayList arrayList = null;
			this.NonArrayTypeName(out typeref, true);
			this.ArrayTypeModifiers(out arrayList);
			if (arrayList != null && typeref != null)
			{
				typeref.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
			}
		}

		private void GlobalAttributeSection()
		{
			base.Expect(28);
			Location location = this.t.Location;
			if (this.la.kind == 52)
			{
				this.lexer.NextToken();
			}
			else if (this.la.kind == 141)
			{
				this.lexer.NextToken();
			}
			else
			{
				base.SynErr(226);
			}
			string attributeTarget = (this.t.val != null) ? this.t.val.ToLower(CultureInfo.InvariantCulture) : null;
			List<ICSharpCode.NRefactory.Ast.Attribute> list = new List<ICSharpCode.NRefactory.Ast.Attribute>();
			base.Expect(11);
			ICSharpCode.NRefactory.Ast.Attribute item;
			this.Attribute(out item);
			list.Add(item);
			while (this.NotFinalComma())
			{
				if (this.la.kind == 12)
				{
					this.lexer.NextToken();
					if (this.la.kind == 52)
					{
						this.lexer.NextToken();
					}
					else if (this.la.kind == 141)
					{
						this.lexer.NextToken();
					}
					else
					{
						base.SynErr(227);
					}
					base.Expect(11);
				}
				this.Attribute(out item);
				list.Add(item);
			}
			if (this.la.kind == 12)
			{
				this.lexer.NextToken();
			}
			base.Expect(27);
			this.EndOfStmt();
			AttributeSection childNode = new AttributeSection
			{
				AttributeTarget = attributeTarget,
				Attributes = list,
				StartLocation = location,
				EndLocation = this.t.EndLocation
			};
			this.compilationUnit.AddChild(childNode);
		}

		private void GotoStatement(out GotoStatement goToStatement)
		{
			string empty = string.Empty;
			base.Expect(119);
			this.LabelName(out empty);
			goToStatement = new GotoStatement(empty);
		}

		private void GroupByQueryOperator(out QueryExpressionGroupVBClause groupByClause)
		{
			groupByClause = new QueryExpressionGroupVBClause();
			groupByClause.StartLocation = this.la.Location;
			base.Expect(120);
			this.ExpressionRangeVariableDeclarationList(groupByClause.GroupVariables);
			base.Expect(57);
			this.ExpressionRangeVariableDeclarationList(groupByClause.ByVariables);
			base.Expect(130);
			this.ExpressionRangeVariableDeclarationList(groupByClause.IntoVariables);
			groupByClause.EndLocation = this.t.EndLocation;
		}

		private void GroupJoinQueryOperator(out QueryExpressionGroupJoinVBClause groupJoinClause)
		{
			groupJoinClause = new QueryExpressionGroupJoinVBClause();
			groupJoinClause.StartLocation = this.la.Location;
			QueryExpressionJoinVBClause joinClause = null;
			base.Expect(120);
			this.JoinQueryOperator(out joinClause);
			base.Expect(130);
			this.ExpressionRangeVariableDeclarationList(groupJoinClause.IntoVariables);
			groupJoinClause.JoinClause = joinClause;
			groupJoinClause.EndLocation = this.t.EndLocation;
		}

		private void HandlesClause(out List<string> handlesClause)
		{
			handlesClause = new List<string>();
			base.Expect(121);
			string text;
			this.EventMemberSpecifier(out text);
			if (text != null)
			{
				handlesClause.Add(text);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.EventMemberSpecifier(out text);
				if (text != null)
				{
					handlesClause.Add(text);
				}
			}
		}

		private void Identifier()
		{
			if (this.StartOf(5))
			{
				this.IdentifierForFieldDeclaration();
				return;
			}
			if (this.la.kind == 85)
			{
				this.lexer.NextToken();
				return;
			}
			base.SynErr(233);
		}

		private void IdentifierForFieldDeclaration()
		{
			int kind = this.la.kind;
			if (kind <= 120)
			{
				if (kind <= 91)
				{
					if (kind <= 57)
					{
						if (kind == 2)
						{
							this.lexer.NextToken();
							return;
						}
						switch (kind)
						{
						case 45:
							this.lexer.NextToken();
							return;
						case 49:
							this.lexer.NextToken();
							return;
						case 51:
							this.lexer.NextToken();
							return;
						case 52:
							this.lexer.NextToken();
							return;
						case 53:
							this.lexer.NextToken();
							return;
						case 54:
							this.lexer.NextToken();
							return;
						case 57:
							this.lexer.NextToken();
							return;
						}
					}
					else
					{
						if (kind == 74)
						{
							this.lexer.NextToken();
							return;
						}
						if (kind == 91)
						{
							this.lexer.NextToken();
							return;
						}
					}
				}
				else if (kind <= 103)
				{
					if (kind == 94)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 103)
					{
						this.lexer.NextToken();
						return;
					}
				}
				else
				{
					if (kind == 108)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 113)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 120)
					{
						this.lexer.NextToken();
						return;
					}
				}
			}
			else if (kind <= 162)
			{
				if (kind <= 130)
				{
					if (kind == 126)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 130)
					{
						this.lexer.NextToken();
						return;
					}
				}
				else
				{
					if (kind == 133)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 156)
					{
						this.lexer.NextToken();
						return;
					}
					if (kind == 162)
					{
						this.lexer.NextToken();
						return;
					}
				}
			}
			else if (kind <= 188)
			{
				if (kind == 169)
				{
					this.lexer.NextToken();
					return;
				}
				if (kind == 188)
				{
					this.lexer.NextToken();
					return;
				}
			}
			else
			{
				switch (kind)
				{
				case 197:
					this.lexer.NextToken();
					return;
				case 198:
					this.lexer.NextToken();
					return;
				default:
					switch (kind)
					{
					case 208:
						this.lexer.NextToken();
						return;
					case 209:
						this.lexer.NextToken();
						return;
					default:
						if (kind == 215)
						{
							this.lexer.NextToken();
							return;
						}
						break;
					}
					break;
				}
			}
			base.SynErr(249);
		}

		private void IdentifierOrKeyword(out string name)
		{
			this.lexer.NextToken();
			name = this.t.val;
		}

		private void ImplementsClause(out List<InterfaceImplementation> baseInterfaces)
		{
			baseInterfaces = new List<InterfaceImplementation>();
			TypeReference typeReference = null;
			string memberName = null;
			base.Expect(123);
			this.NonArrayTypeName(out typeReference, false);
			if (typeReference != null)
			{
				memberName = TypeReference.StripLastIdentifierFromType(ref typeReference);
			}
			baseInterfaces.Add(new InterfaceImplementation(typeReference, memberName));
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.NonArrayTypeName(out typeReference, false);
				if (typeReference != null)
				{
					memberName = TypeReference.StripLastIdentifierFromType(ref typeReference);
				}
				baseInterfaces.Add(new InterfaceImplementation(typeReference, memberName));
			}
		}

		private void ImportClause(out Using u)
		{
			string text = null;
			TypeReference typeReference = null;
			u = null;
			this.Qualident(out text);
			if (this.la.kind == 10)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
			}
			if (text != null && text.Length > 0)
			{
				if (typeReference != null)
				{
					u = new Using(text, typeReference);
					return;
				}
				u = new Using(text);
			}
		}

		private void ImportsStmt()
		{
			List<Using> list = new List<Using>();
			base.Expect(124);
			Location location = this.t.Location;
			Using @using;
			this.ImportClause(out @using);
			if (@using != null)
			{
				list.Add(@using);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.ImportClause(out @using);
				if (@using != null)
				{
					list.Add(@using);
				}
			}
			this.EndOfStmt();
			UsingDeclaration usingDeclaration = new UsingDeclaration(list);
			usingDeclaration.StartLocation = location;
			usingDeclaration.EndLocation = this.t.Location;
			this.compilationUnit.AddChild(usingDeclaration);
		}

		private void InitializationRankList(out List<Expression> rank)
		{
			rank = new List<Expression>();
			Expression expression = null;
			this.Expr(out expression);
			if (this.la.kind == 201)
			{
				this.lexer.NextToken();
				this.EnsureIsZero(expression);
				this.Expr(out expression);
			}
			if (expression != null)
			{
				rank.Add(expression);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.Expr(out expression);
				if (this.la.kind == 201)
				{
					this.lexer.NextToken();
					this.EnsureIsZero(expression);
					this.Expr(out expression);
				}
				if (expression != null)
				{
					rank.Add(expression);
				}
			}
		}

		private void IntegerDivisionExpr(out Expression outExpr)
		{
			this.MultiplicativeExpr(out outExpr);
			while (this.la.kind == 15)
			{
				this.lexer.NextToken();
				Expression right;
				this.MultiplicativeExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.DivideInteger, right);
			}
		}

		private void InterfaceBase(out List<TypeReference> bases)
		{
			bases = new List<TypeReference>();
			base.Expect(127);
			TypeReference typeReference;
			this.TypeName(out typeReference);
			if (typeReference != null)
			{
				bases.Add(typeReference);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
				if (typeReference != null)
				{
					bases.Add(typeReference);
				}
			}
			this.EndOfStmt();
		}

		private void InterfaceBody(TypeDeclaration newType)
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(13))
			{
				this.InterfaceMemberDecl();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(100);
			base.Expect(129);
			newType.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void InterfaceMemberDecl()
		{
			TypeReference typeReference = null;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			List<TemplateDefinition> templates = new List<TemplateDefinition>();
			AttributeSection attributeSection = null;
			ModifierList modifierList = new ModifierList();
			List<AttributeSection> list2 = new List<AttributeSection>();
			if (this.StartOf(19))
			{
				while (this.la.kind == 28)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list2.Add(item);
				}
				while (this.StartOf(9))
				{
					this.MemberModifier(modifierList);
				}
				if (this.la.kind == 106)
				{
					this.lexer.NextToken();
					modifierList.Check(Modifiers.New);
					Location location = this.t.Location;
					this.Identifier();
					string val = this.t.val;
					if (this.la.kind == 25)
					{
						this.lexer.NextToken();
						if (this.StartOf(4))
						{
							this.FormalParameterList(list);
						}
						base.Expect(26);
					}
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.TypeName(out typeReference);
					}
					this.EndOfStmt();
					EventDeclaration childNode = new EventDeclaration
					{
						Name = val,
						TypeReference = typeReference,
						Modifier = modifierList.Modifier,
						Parameters = list,
						Attributes = list2,
						StartLocation = location,
						EndLocation = this.t.EndLocation
					};
					this.compilationUnit.AddChild(childNode);
					return;
				}
				if (this.la.kind == 195)
				{
					this.lexer.NextToken();
					Location location2 = this.t.Location;
					modifierList.Check(Modifiers.VBInterfaceMethods);
					this.Identifier();
					string val = this.t.val;
					this.TypeParameterList(templates);
					if (this.la.kind == 25)
					{
						this.lexer.NextToken();
						if (this.StartOf(4))
						{
							this.FormalParameterList(list);
						}
						base.Expect(26);
					}
					this.EndOfStmt();
					MethodDeclaration childNode2 = new MethodDeclaration
					{
						Name = val,
						Modifier = modifierList.Modifier,
						Parameters = list,
						Attributes = list2,
						TypeReference = new TypeReference("System.Void", true),
						StartLocation = location2,
						EndLocation = this.t.EndLocation,
						Templates = templates
					};
					this.compilationUnit.AddChild(childNode2);
					return;
				}
				if (this.la.kind == 114)
				{
					this.lexer.NextToken();
					modifierList.Check(Modifiers.VBInterfaceMethods);
					Location location3 = this.t.Location;
					this.Identifier();
					string val = this.t.val;
					this.TypeParameterList(templates);
					if (this.la.kind == 25)
					{
						this.lexer.NextToken();
						if (this.StartOf(4))
						{
							this.FormalParameterList(list);
						}
						base.Expect(26);
					}
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						while (this.la.kind == 28)
						{
							this.AttributeSection(out attributeSection);
						}
						this.TypeName(out typeReference);
					}
					if (typeReference == null)
					{
						typeReference = new TypeReference("System.Object", true);
					}
					MethodDeclaration methodDeclaration = new MethodDeclaration
					{
						Name = val,
						Modifier = modifierList.Modifier,
						TypeReference = typeReference,
						Parameters = list,
						Attributes = list2
					};
					if (attributeSection != null)
					{
						attributeSection.AttributeTarget = "return";
						methodDeclaration.Attributes.Add(attributeSection);
					}
					methodDeclaration.StartLocation = location3;
					methodDeclaration.EndLocation = this.t.EndLocation;
					methodDeclaration.Templates = templates;
					this.compilationUnit.AddChild(methodDeclaration);
					this.EndOfStmt();
					return;
				}
				if (this.la.kind == 171)
				{
					this.lexer.NextToken();
					Location location4 = this.t.Location;
					modifierList.Check(Modifiers.VBInterfaceProperties);
					this.Identifier();
					string val = this.t.val;
					if (this.la.kind == 25)
					{
						this.lexer.NextToken();
						if (this.StartOf(4))
						{
							this.FormalParameterList(list);
						}
						base.Expect(26);
					}
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.TypeName(out typeReference);
					}
					if (typeReference == null)
					{
						typeReference = new TypeReference("System.Object", true);
					}
					this.EndOfStmt();
					PropertyDeclaration propertyDeclaration = new PropertyDeclaration(val, typeReference, modifierList.Modifier, list2);
					propertyDeclaration.Parameters = list;
					propertyDeclaration.EndLocation = this.t.EndLocation;
					propertyDeclaration.StartLocation = location4;
					this.compilationUnit.AddChild(propertyDeclaration);
					return;
				}
				base.SynErr(245);
				return;
			}
			else
			{
				if (this.StartOf(20))
				{
					this.NonModuleDeclaration(modifierList, list2);
					return;
				}
				base.SynErr(246);
				return;
			}
		}

		private void InvocationExpression(ref Expression pexpr)
		{
			List<Expression> arguments = null;
			base.Expect(25);
			Location location = this.t.Location;
			this.ArgumentList(out arguments);
			base.Expect(26);
			pexpr = new InvocationExpression(pexpr, arguments);
			pexpr.StartLocation = location;
			pexpr.EndLocation = this.t.Location;
		}

		private bool IsDims()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 25 && (kind == 12 || kind == 26);
		}

		private bool IsElseIf()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 98 && kind == 122;
		}

		private bool IsEndStmtAhead()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 100 && (kind == 1 || kind == 11);
		}

		private bool IsGlobalAttrTarget()
		{
			Token token = this.Peek(1);
			return this.la.kind == 28 && (string.Equals(token.val, "assembly", StringComparison.InvariantCultureIgnoreCase) || string.Equals(token.val, "module", StringComparison.InvariantCultureIgnoreCase));
		}

		private bool IsIdentifiedExpressionRange()
		{
			return this.la.kind == 50 || this.la.kind == 10;
		}

		private static bool IsIdentifierToken(Token tk)
		{
			return Tokens.IdentifierTokens[tk.kind] || tk.kind == 2;
		}

		private bool IsLabel()
		{
			return (this.la.kind == 2 || this.la.kind == 5) && this.Peek(1).kind == 11;
		}

		private bool IsLocalAttrTarget()
		{
			return false;
		}

		private bool IsLoopVariableDeclaration()
		{
			if (!Parser.IsIdentifierToken(this.la))
			{
				return false;
			}
			this.lexer.StartPeek();
			Token token = this.lexer.Peek();
			if (token.kind == 25)
			{
				do
				{
					token = this.lexer.Peek();
				}
				while (token.kind == 12);
				if (token.kind != 26)
				{
					return false;
				}
				token = this.lexer.Peek();
			}
			return token.kind == 50 || token.kind == 10;
		}

		private static bool IsMustOverride(ModifierList m)
		{
			return m.Contains(Modifiers.Dim);
		}

		private bool IsNamedAssign()
		{
			return this.Peek(1).kind == 11 && this.Peek(2).kind == 10;
		}

		private bool IsNegativeLabelName()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 119 && kind == 18;
		}

		private bool IsNotClosingParenthesis()
		{
			return this.la.kind != 26;
		}

		private bool IsNotStatementSeparator()
		{
			return this.la.kind == 11 && this.Peek(1).kind == 1;
		}

		private bool IsObjectCreation()
		{
			return this.la.kind == 50 && this.Peek(1).kind == 148;
		}

		private bool IsQueryExpression()
		{
			return (this.la.kind == 113 || this.la.kind == 45) && Parser.IsIdentifierToken(this.Peek(1));
		}

		private bool IsResumeNext()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 179 && kind == 149;
		}

		private bool IsSize()
		{
			return this.la.kind == 25;
		}

		private void JoinCondition(out QueryExpressionJoinConditionVB condition)
		{
			condition = new QueryExpressionJoinConditionVB();
			condition.StartLocation = this.la.Location;
			Expression leftSide = null;
			Expression rightSide = null;
			this.Expr(out leftSide);
			base.Expect(103);
			this.Expr(out rightSide);
			condition.LeftSide = leftSide;
			condition.RightSide = rightSide;
			condition.EndLocation = this.t.EndLocation;
		}

		private void JoinQueryOperator(out QueryExpressionJoinVBClause joinClause)
		{
			joinClause = new QueryExpressionJoinVBClause();
			joinClause.StartLocation = this.la.Location;
			QueryExpressionFromClause joinVariable = null;
			QueryExpressionJoinVBClause subJoin = null;
			QueryExpressionJoinConditionVB item = null;
			base.Expect(133);
			this.CollectionRangeVariableDeclaration(out joinVariable);
			joinClause.JoinVariable = joinVariable;
			if (this.la.kind == 133)
			{
				this.JoinQueryOperator(out subJoin);
				joinClause.SubJoin = subJoin;
			}
			base.Expect(157);
			this.JoinCondition(out item);
			Parser.SafeAdd<QueryExpressionJoinConditionVB>(joinClause, joinClause.Conditions, item);
			while (this.la.kind == 47)
			{
				this.lexer.NextToken();
				this.JoinCondition(out item);
				Parser.SafeAdd<QueryExpressionJoinConditionVB>(joinClause, joinClause.Conditions, item);
			}
			joinClause.EndLocation = this.t.EndLocation;
		}

		private void LabelName(out string name)
		{
			name = string.Empty;
			if (this.StartOf(14))
			{
				this.Identifier();
				name = this.t.val;
				return;
			}
			if (this.la.kind == 5)
			{
				this.lexer.NextToken();
				name = this.t.val;
				return;
			}
			base.SynErr(272);
		}

		private void LambdaExpr(out Expression expr)
		{
			Expression expressionBody = null;
			LambdaExpression lambdaExpression = new LambdaExpression();
			lambdaExpression.StartLocation = this.la.Location;
			base.Expect(114);
			if (this.la.kind == 25)
			{
				this.lexer.NextToken();
				if (this.StartOf(4))
				{
					this.FormalParameterList(lambdaExpression.Parameters);
				}
				base.Expect(26);
			}
			this.Expr(out expressionBody);
			lambdaExpression.ExpressionBody = expressionBody;
			lambdaExpression.EndLocation = this.t.EndLocation;
			expr = lambdaExpression;
		}

		private bool LeaveBlock()
		{
			int kind = this.Peek(1).kind;
			return Tokens.BlockSucc[this.la.kind] && (this.la.kind != 100 || kind == 1 || kind == 11);
		}

		private void LetQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionLetVBClause queryExpressionLetVBClause = new QueryExpressionLetVBClause();
			queryExpressionLetVBClause.StartLocation = this.la.Location;
			base.Expect(134);
			this.ExpressionRangeVariableDeclarationList(queryExpressionLetVBClause.Variables);
			queryExpressionLetVBClause.EndLocation = this.t.EndLocation;
			middleClauses.Add(queryExpressionLetVBClause);
		}

		private void LocalDeclarationStatement(out Statement statement)
		{
			ModifierList modifierList = new ModifierList();
			bool flag = false;
			while (this.la.kind == 75 || this.la.kind == 92 || this.la.kind == 189)
			{
				if (this.la.kind == 75)
				{
					this.lexer.NextToken();
					modifierList.Add(Modifiers.Const, this.t.Location);
				}
				else if (this.la.kind == 189)
				{
					this.lexer.NextToken();
					modifierList.Add(Modifiers.Static, this.t.Location);
				}
				else
				{
					this.lexer.NextToken();
					flag = true;
				}
			}
			if (flag && (modifierList.Modifier & Modifiers.Const) != Modifiers.None)
			{
				this.Error("Dim is not allowed on constants.");
			}
			if (modifierList.isNone && !flag)
			{
				this.Error("Const, Dim or Static expected");
			}
			LocalVariableDeclaration localVariableDeclaration = new LocalVariableDeclaration(modifierList.Modifier);
			localVariableDeclaration.StartLocation = this.t.Location;
			this.VariableDeclarator(localVariableDeclaration.Variables);
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.VariableDeclarator(localVariableDeclaration.Variables);
			}
			statement = localVariableDeclaration;
		}

		private void LoopControlVariable(out TypeReference type, out string name)
		{
			ArrayList arrayList = null;
			type = null;
			this.Qualident(out name);
			if (this.IsDims())
			{
				this.ArrayTypeModifiers(out arrayList);
			}
			if (this.la.kind == 50)
			{
				this.lexer.NextToken();
				this.TypeName(out type);
				if (name.IndexOf('.') > 0)
				{
					this.Error("No type def for 'for each' member indexer allowed.");
				}
			}
			if (type != null)
			{
				if (type.RankSpecifier != null && arrayList != null)
				{
					this.Error("array rank only allowed one time");
					return;
				}
				if (arrayList != null)
				{
					type.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
				}
			}
		}

		private void MemberInitializer(out NamedArgumentExpression memberInitializer)
		{
			memberInitializer = new NamedArgumentExpression();
			memberInitializer.StartLocation = this.la.Location;
			Expression expression = null;
			string name = null;
			base.Expect(16);
			this.IdentifierOrKeyword(out name);
			base.Expect(10);
			this.Expr(out expression);
			memberInitializer.Name = name;
			memberInitializer.Expression = expression;
			memberInitializer.EndLocation = this.t.EndLocation;
		}

		private void MemberModifier(ModifierList m)
		{
			int kind = this.la.kind;
			if (kind <= 143)
			{
				if (kind <= 92)
				{
					if (kind == 89)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Default, this.t.Location);
						return;
					}
					if (kind == 92)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Dim, this.t.Location);
						return;
					}
				}
				else
				{
					if (kind == 112)
					{
						this.lexer.NextToken();
						m.Add(Modifiers.Internal, this.t.Location);
						return;
					}
					switch (kind)
					{
					case 142:
						this.lexer.NextToken();
						m.Add(Modifiers.Dim, this.t.Location);
						return;
					case 143:
						this.lexer.NextToken();
						m.Add(Modifiers.Dim, this.t.Location);
						return;
					}
				}
			}
			else if (kind <= 175)
			{
				switch (kind)
				{
				case 152:
					this.lexer.NextToken();
					m.Add(Modifiers.Sealed, this.t.Location);
					return;
				case 153:
					this.lexer.NextToken();
					m.Add(Modifiers.Sealed, this.t.Location);
					return;
				default:
					switch (kind)
					{
					case 164:
						this.lexer.NextToken();
						m.Add(Modifiers.Overloads, this.t.Location);
						return;
					case 165:
						this.lexer.NextToken();
						m.Add(Modifiers.Virtual, this.t.Location);
						return;
					case 166:
						this.lexer.NextToken();
						m.Add(Modifiers.Override, this.t.Location);
						return;
					case 168:
						this.lexer.NextToken();
						m.Add(Modifiers.Partial, this.t.Location);
						return;
					case 170:
						this.lexer.NextToken();
						m.Add(Modifiers.Private, this.t.Location);
						return;
					case 172:
						this.lexer.NextToken();
						m.Add(Modifiers.Protected, this.t.Location);
						return;
					case 173:
						this.lexer.NextToken();
						m.Add(Modifiers.Public, this.t.Location);
						return;
					case 175:
						this.lexer.NextToken();
						m.Add(Modifiers.ReadOnly, this.t.Location);
						return;
					}
					break;
				}
			}
			else
			{
				switch (kind)
				{
				case 184:
					this.lexer.NextToken();
					m.Add(Modifiers.New, this.t.Location);
					return;
				case 185:
					this.lexer.NextToken();
					m.Add(Modifiers.Static, this.t.Location);
					return;
				default:
					switch (kind)
					{
					case 219:
						this.lexer.NextToken();
						m.Add(Modifiers.WithEvents, this.t.Location);
						return;
					case 220:
						this.lexer.NextToken();
						m.Add(Modifiers.WriteOnly, this.t.Location);
						return;
					}
					break;
				}
			}
			base.SynErr(237);
		}

		private void ModuleBody(TypeDeclaration newType)
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(8))
			{
				List<AttributeSection> list = new List<AttributeSection>();
				ModifierList m = new ModifierList();
				while (this.la.kind == 28)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				while (this.StartOf(9))
				{
					this.MemberModifier(m);
				}
				this.ClassMemberDecl(m, list);
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(100);
			base.Expect(141);
			newType.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void ModuloExpr(out Expression outExpr)
		{
			this.IntegerDivisionExpr(out outExpr);
			while (this.la.kind == 140)
			{
				this.lexer.NextToken();
				Expression right;
				this.IntegerDivisionExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, BinaryOperatorType.Modulus, right);
			}
		}

		private void MultiplicativeExpr(out Expression outExpr)
		{
			this.UnaryExpr(out outExpr);
			while (this.la.kind == 14 || this.la.kind == 22)
			{
				BinaryOperatorType op;
				if (this.la.kind == 22)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Multiply;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.Divide;
				}
				Expression right;
				this.UnaryExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void NamespaceBody()
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(1))
			{
				this.NamespaceMemberDecl();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(100);
			base.Expect(146);
			this.EndOfStmt();
		}

		private void NamespaceMemberDecl()
		{
			ModifierList m = new ModifierList();
			List<AttributeSection> list = new List<AttributeSection>();
			if (this.la.kind == 146)
			{
				this.lexer.NextToken();
				Location location = this.t.Location;
				string name;
				this.Qualident(out name);
				INode node = new NamespaceDeclaration(name);
				node.StartLocation = location;
				this.compilationUnit.AddChild(node);
				this.compilationUnit.BlockStart(node);
				this.EndOfStmt();
				this.NamespaceBody();
				node.EndLocation = this.t.Location;
				this.compilationUnit.BlockEnd();
				return;
			}
			if (this.StartOf(2))
			{
				while (this.la.kind == 28)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				while (this.StartOf(3))
				{
					this.TypeModifier(m);
				}
				this.NonModuleDeclaration(m, list);
				return;
			}
			base.SynErr(228);
		}

		private void NonArrayTypeName(out TypeReference typeref, bool canBeUnbound)
		{
			typeref = null;
			bool isGlobal = false;
			if (this.StartOf(10))
			{
				if (this.la.kind == 117)
				{
					this.lexer.NextToken();
					base.Expect(16);
					isGlobal = true;
				}
				this.QualIdentAndTypeArguments(out typeref, canBeUnbound);
				typeref.IsGlobal = isGlobal;
				while (this.la.kind == 16)
				{
					this.lexer.NextToken();
					TypeReference typeReference;
					this.QualIdentAndTypeArguments(out typeReference, canBeUnbound);
					typeref = new InnerClassTypeReference(typeref, typeReference.Type, typeReference.GenericTypes);
				}
				return;
			}
			if (this.la.kind == 154)
			{
				this.lexer.NextToken();
				typeref = new TypeReference("System.Object", true);
				if (this.la.kind == 21)
				{
					this.lexer.NextToken();
					List<TypeReference> list = new List<TypeReference>(1);
					if (typeref != null)
					{
						list.Add(typeref);
					}
					typeref = new TypeReference("System.Nullable", list)
					{
						IsKeyword = true
					};
					return;
				}
			}
			else if (this.StartOf(11))
			{
				string type;
				this.PrimitiveTypeName(out type);
				typeref = new TypeReference(type, true);
				if (this.la.kind == 21)
				{
					this.lexer.NextToken();
					List<TypeReference> list2 = new List<TypeReference>(1);
					if (typeref != null)
					{
						list2.Add(typeref);
					}
					typeref = new TypeReference("System.Nullable", list2)
					{
						IsKeyword = true
					};
					return;
				}
			}
			else
			{
				base.SynErr(236);
			}
		}

		private void NonModuleDeclaration(ModifierList m, List<AttributeSection> attributes)
		{
			TypeReference item = null;
			List<TypeReference> collection = null;
			int kind = this.la.kind;
			if (kind <= 102)
			{
				if (kind == 71)
				{
					m.Check(Modifiers.Classes);
					this.lexer.NextToken();
					TypeDeclaration typeDeclaration = new TypeDeclaration(m.Modifier, attributes);
					typeDeclaration.StartLocation = this.t.Location;
					this.compilationUnit.AddChild(typeDeclaration);
					this.compilationUnit.BlockStart(typeDeclaration);
					typeDeclaration.Type = ClassType.Class;
					this.Identifier();
					typeDeclaration.Name = this.t.val;
					this.TypeParameterList(typeDeclaration.Templates);
					this.EndOfStmt();
					typeDeclaration.BodyStartLocation = this.t.Location;
					if (this.la.kind == 127)
					{
						this.ClassBaseType(out item);
						Parser.SafeAdd<TypeReference>(typeDeclaration, typeDeclaration.BaseTypes, item);
					}
					while (this.la.kind == 123)
					{
						this.TypeImplementsClause(out collection);
						typeDeclaration.BaseTypes.AddRange(collection);
					}
					this.ClassBody(typeDeclaration);
					base.Expect(100);
					base.Expect(71);
					typeDeclaration.EndLocation = this.t.EndLocation;
					this.EndOfStmt();
					this.compilationUnit.BlockEnd();
					return;
				}
				if (kind == 90)
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBStructures);
					DelegateDeclaration delegateDeclaration = new DelegateDeclaration(m.Modifier, attributes);
					delegateDeclaration.ReturnType = new TypeReference("System.Void", true);
					delegateDeclaration.StartLocation = m.GetDeclarationLocation(this.t.Location);
					List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
					if (this.la.kind == 195)
					{
						this.lexer.NextToken();
						this.Identifier();
						delegateDeclaration.Name = this.t.val;
						this.TypeParameterList(delegateDeclaration.Templates);
						if (this.la.kind == 25)
						{
							this.lexer.NextToken();
							if (this.StartOf(4))
							{
								this.FormalParameterList(list);
							}
							base.Expect(26);
							delegateDeclaration.Parameters = list;
						}
					}
					else if (this.la.kind == 114)
					{
						this.lexer.NextToken();
						this.Identifier();
						delegateDeclaration.Name = this.t.val;
						this.TypeParameterList(delegateDeclaration.Templates);
						if (this.la.kind == 25)
						{
							this.lexer.NextToken();
							if (this.StartOf(4))
							{
								this.FormalParameterList(list);
							}
							base.Expect(26);
							delegateDeclaration.Parameters = list;
						}
						if (this.la.kind == 50)
						{
							this.lexer.NextToken();
							TypeReference returnType;
							this.TypeName(out returnType);
							delegateDeclaration.ReturnType = returnType;
						}
					}
					else
					{
						base.SynErr(231);
					}
					delegateDeclaration.EndLocation = this.t.EndLocation;
					this.EndOfStmt();
					this.compilationUnit.AddChild(delegateDeclaration);
					return;
				}
				if (kind == 102)
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBStructures);
					TypeDeclaration typeDeclaration2 = new TypeDeclaration(m.Modifier, attributes);
					typeDeclaration2.StartLocation = m.GetDeclarationLocation(this.t.Location);
					this.compilationUnit.AddChild(typeDeclaration2);
					this.compilationUnit.BlockStart(typeDeclaration2);
					typeDeclaration2.Type = ClassType.Enum;
					this.Identifier();
					typeDeclaration2.Name = this.t.val;
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.NonArrayTypeName(out item, false);
						Parser.SafeAdd<TypeReference>(typeDeclaration2, typeDeclaration2.BaseTypes, item);
					}
					this.EndOfStmt();
					typeDeclaration2.BodyStartLocation = this.t.Location;
					this.EnumBody(typeDeclaration2);
					this.compilationUnit.BlockEnd();
					return;
				}
			}
			else
			{
				if (kind == 129)
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBStructures);
					TypeDeclaration typeDeclaration3 = new TypeDeclaration(m.Modifier, attributes);
					typeDeclaration3.StartLocation = m.GetDeclarationLocation(this.t.Location);
					this.compilationUnit.AddChild(typeDeclaration3);
					this.compilationUnit.BlockStart(typeDeclaration3);
					typeDeclaration3.Type = ClassType.Interface;
					this.Identifier();
					typeDeclaration3.Name = this.t.val;
					this.TypeParameterList(typeDeclaration3.Templates);
					this.EndOfStmt();
					typeDeclaration3.BodyStartLocation = this.t.Location;
					while (this.la.kind == 127)
					{
						this.InterfaceBase(out collection);
						typeDeclaration3.BaseTypes.AddRange(collection);
					}
					this.InterfaceBody(typeDeclaration3);
					this.compilationUnit.BlockEnd();
					return;
				}
				if (kind == 141)
				{
					this.lexer.NextToken();
					m.Check(Modifiers.Visibility);
					TypeDeclaration typeDeclaration4 = new TypeDeclaration(m.Modifier, attributes);
					this.compilationUnit.AddChild(typeDeclaration4);
					this.compilationUnit.BlockStart(typeDeclaration4);
					typeDeclaration4.StartLocation = m.GetDeclarationLocation(this.t.Location);
					typeDeclaration4.Type = ClassType.Module;
					this.Identifier();
					typeDeclaration4.Name = this.t.val;
					this.EndOfStmt();
					typeDeclaration4.BodyStartLocation = this.t.Location;
					this.ModuleBody(typeDeclaration4);
					this.compilationUnit.BlockEnd();
					return;
				}
				if (kind == 194)
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBStructures);
					TypeDeclaration typeDeclaration5 = new TypeDeclaration(m.Modifier, attributes);
					this.compilationUnit.AddChild(typeDeclaration5);
					this.compilationUnit.BlockStart(typeDeclaration5);
					typeDeclaration5.StartLocation = m.GetDeclarationLocation(this.t.Location);
					typeDeclaration5.Type = ClassType.Struct;
					this.Identifier();
					typeDeclaration5.Name = this.t.val;
					this.TypeParameterList(typeDeclaration5.Templates);
					this.EndOfStmt();
					typeDeclaration5.BodyStartLocation = this.t.Location;
					while (this.la.kind == 123)
					{
						this.TypeImplementsClause(out collection);
						typeDeclaration5.BaseTypes.AddRange(collection);
					}
					this.StructureBody(typeDeclaration5);
					this.compilationUnit.BlockEnd();
					return;
				}
			}
			base.SynErr(232);
		}

		private void NormalOrReDimArgumentList(out List<Expression> arguments, out bool canBeNormal, out bool canBeRedim)
		{
			arguments = new List<Expression>();
			canBeNormal = true;
			canBeRedim = !this.IsNamedAssign();
			Expression expression = null;
			if (this.StartOf(29))
			{
				this.Argument(out expression);
				if (this.la.kind == 201)
				{
					this.lexer.NextToken();
					this.EnsureIsZero(expression);
					canBeNormal = false;
					this.Expr(out expression);
				}
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				if (expression == null)
				{
					canBeRedim = false;
				}
				arguments.Add(expression ?? Expression.Null);
				expression = null;
				canBeRedim &= !this.IsNamedAssign();
				if (this.StartOf(29))
				{
					this.Argument(out expression);
					if (this.la.kind == 201)
					{
						this.lexer.NextToken();
						this.EnsureIsZero(expression);
						canBeNormal = false;
						this.Expr(out expression);
					}
				}
				if (expression == null)
				{
					canBeRedim = false;
					expression = Expression.Null;
				}
			}
			if (expression != null)
			{
				arguments.Add(expression);
				return;
			}
			canBeRedim = false;
		}

		private void NotExpr(out Expression outExpr)
		{
			UnaryOperatorType unaryOperatorType = UnaryOperatorType.None;
			while (this.la.kind == 150)
			{
				this.lexer.NextToken();
				unaryOperatorType = UnaryOperatorType.Not;
			}
			this.ComparisonExpr(out outExpr);
			if (unaryOperatorType != UnaryOperatorType.None)
			{
				outExpr = new UnaryOperatorExpression(outExpr, unaryOperatorType);
			}
		}

		private bool NotFinalComma()
		{
			int kind = this.Peek(1).kind;
			return this.la.kind == 12 && kind != 24;
		}

		private void ObjectCreateExpression(out Expression oce)
		{
			TypeReference typeReference = null;
			Expression expression = null;
			List<Expression> list = null;
			ArrayList arrayList = null;
			oce = null;
			base.Expect(148);
			if (this.StartOf(7))
			{
				this.NonArrayTypeName(out typeReference, false);
				if (this.la.kind == 25)
				{
					this.lexer.NextToken();
					bool flag;
					bool flag2;
					this.NormalOrReDimArgumentList(out list, out flag, out flag2);
					base.Expect(26);
					if (this.la.kind == 23 || this.la.kind == 25)
					{
						if (this.la.kind == 25)
						{
							this.ArrayTypeModifiers(out arrayList);
							this.CollectionInitializer(out expression);
						}
						else
						{
							this.CollectionInitializer(out expression);
						}
					}
					if (flag2 && !flag && expression == null)
					{
						expression = new CollectionInitializerExpression();
					}
				}
			}
			if (expression == null)
			{
				oce = new ObjectCreateExpression(typeReference, list);
			}
			else
			{
				if (arrayList == null)
				{
					arrayList = new ArrayList();
				}
				arrayList.Insert(0, (list == null) ? 0 : Math.Max(list.Count - 1, 0));
				typeReference.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
				oce = new ArrayCreateExpression(typeReference, expression as CollectionInitializerExpression)
				{
					Arguments = list
				};
			}
			if (this.la.kind == 218)
			{
				NamedArgumentExpression item = null;
				this.lexer.NextToken();
				CollectionInitializerExpression collectionInitializerExpression = new CollectionInitializerExpression();
				collectionInitializerExpression.StartLocation = this.la.Location;
				base.Expect(23);
				this.MemberInitializer(out item);
				collectionInitializerExpression.CreateExpressions.Add(item);
				while (this.la.kind == 12)
				{
					this.lexer.NextToken();
					this.MemberInitializer(out item);
					collectionInitializerExpression.CreateExpressions.Add(item);
				}
				base.Expect(24);
				collectionInitializerExpression.EndLocation = this.t.Location;
				if (oce is ObjectCreateExpression)
				{
					((ObjectCreateExpression)oce).ObjectInitializer = collectionInitializerExpression;
				}
			}
		}

		private void OnErrorStatement(out OnErrorStatement stmt)
		{
			stmt = null;
			GotoStatement gotoStatement = null;
			base.Expect(157);
			base.Expect(105);
			if (this.IsNegativeLabelName())
			{
				base.Expect(119);
				base.Expect(18);
				base.Expect(5);
				long num = long.Parse(this.t.val);
				if (num != 1L)
				{
					this.Error("invalid label in on error statement.");
				}
				stmt = new OnErrorStatement(new GotoStatement((num * -1L).ToString()));
				return;
			}
			if (this.la.kind == 119)
			{
				this.GotoStatement(out gotoStatement);
				string label = gotoStatement.Label;
				try
				{
					long num2 = long.Parse(label);
					if (num2 != 0L)
					{
						this.Error("invalid label in on error statement.");
					}
				}
				catch
				{
				}
				stmt = new OnErrorStatement(gotoStatement);
				return;
			}
			if (this.la.kind == 179)
			{
				this.lexer.NextToken();
				base.Expect(149);
				stmt = new OnErrorStatement(new ResumeStatement(true));
				return;
			}
			base.SynErr(283);
		}

		private void OptionStmt()
		{
			INode node = null;
			bool optionValue = true;
			base.Expect(159);
			Location location = this.t.Location;
			if (this.la.kind == 108)
			{
				this.lexer.NextToken();
				if (this.la.kind == 156 || this.la.kind == 157)
				{
					this.OptionValue(ref optionValue);
				}
				node = new OptionDeclaration(OptionType.Explicit, optionValue);
			}
			else if (this.la.kind == 192)
			{
				this.lexer.NextToken();
				if (this.la.kind == 156 || this.la.kind == 157)
				{
					this.OptionValue(ref optionValue);
				}
				node = new OptionDeclaration(OptionType.Strict, optionValue);
			}
			else if (this.la.kind == 74)
			{
				this.lexer.NextToken();
				if (this.la.kind == 54)
				{
					this.lexer.NextToken();
					node = new OptionDeclaration(OptionType.CompareBinary, optionValue);
				}
				else if (this.la.kind == 198)
				{
					this.lexer.NextToken();
					node = new OptionDeclaration(OptionType.CompareText, optionValue);
				}
				else
				{
					base.SynErr(224);
				}
			}
			else if (this.la.kind == 126)
			{
				this.lexer.NextToken();
				if (this.la.kind == 156 || this.la.kind == 157)
				{
					this.OptionValue(ref optionValue);
				}
				node = new OptionDeclaration(OptionType.Infer, optionValue);
			}
			else
			{
				base.SynErr(225);
			}
			this.EndOfStmt();
			if (node != null)
			{
				node.StartLocation = location;
				node.EndLocation = this.t.Location;
				this.compilationUnit.AddChild(node);
			}
		}

		private void OptionValue(ref bool val)
		{
			if (this.la.kind == 157)
			{
				this.lexer.NextToken();
				val = true;
				return;
			}
			if (this.la.kind == 156)
			{
				this.lexer.NextToken();
				val = false;
				return;
			}
			base.SynErr(229);
		}

		private void OrderByQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionOrderClause queryExpressionOrderClause = new QueryExpressionOrderClause();
			queryExpressionOrderClause.StartLocation = this.la.Location;
			List<QueryExpressionOrdering> orderings = null;
			base.Expect(162);
			base.Expect(57);
			this.OrderExpressionList(out orderings);
			queryExpressionOrderClause.Orderings = orderings;
			queryExpressionOrderClause.EndLocation = this.t.EndLocation;
			middleClauses.Add(queryExpressionOrderClause);
		}

		private void OrderExpression(out QueryExpressionOrdering ordering)
		{
			ordering = new QueryExpressionOrdering();
			ordering.StartLocation = this.la.Location;
			ordering.Direction = QueryExpressionOrderingDirection.None;
			Expression criteria = null;
			this.Expr(out criteria);
			ordering.Criteria = criteria;
			if (this.la.kind == 51 || this.la.kind == 91)
			{
				if (this.la.kind == 51)
				{
					this.lexer.NextToken();
					ordering.Direction = QueryExpressionOrderingDirection.Ascending;
				}
				else
				{
					this.lexer.NextToken();
					ordering.Direction = QueryExpressionOrderingDirection.Descending;
				}
			}
			ordering.EndLocation = this.t.EndLocation;
		}

		private void OrderExpressionList(out List<QueryExpressionOrdering> orderings)
		{
			orderings = new List<QueryExpressionOrdering>();
			QueryExpressionOrdering item = null;
			this.OrderExpression(out item);
			orderings.Add(item);
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.OrderExpression(out item);
				orderings.Add(item);
			}
		}

		private void OverloadableOperator(out OverloadableOperatorType operatorType)
		{
			operatorType = OverloadableOperatorType.None;
			int kind = this.la.kind;
			if (kind <= 120)
			{
				if (kind <= 85)
				{
					if (kind <= 57)
					{
						if (kind != 2)
						{
							switch (kind)
							{
							case 10:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Equality;
								return;
							case 11:
							case 12:
							case 16:
							case 17:
							case 21:
							case 23:
							case 24:
							case 25:
							case 26:
								goto IL_3B8;
							case 13:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Concat;
								return;
							case 14:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Divide;
								return;
							case 15:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.DivideInteger;
								return;
							case 18:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Subtract;
								return;
							case 19:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Add;
								return;
							case 20:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Power;
								return;
							case 22:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.Multiply;
								return;
							case 27:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.GreaterThan;
								return;
							case 28:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.LessThan;
								return;
							case 29:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.InEquality;
								return;
							case 30:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.GreaterThanOrEqual;
								return;
							case 31:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.LessThanOrEqual;
								return;
							case 32:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.ShiftLeft;
								return;
							case 33:
								this.lexer.NextToken();
								operatorType = OverloadableOperatorType.ShiftRight;
								return;
							default:
								switch (kind)
								{
								case 45:
								case 49:
								case 51:
								case 52:
								case 53:
								case 54:
								case 57:
									break;
								case 46:
								case 48:
								case 50:
								case 55:
								case 56:
									goto IL_3B8;
								case 47:
									this.lexer.NextToken();
									operatorType = OverloadableOperatorType.BitwiseAnd;
									return;
								default:
									goto IL_3B8;
								}
								break;
							}
						}
					}
					else if (kind != 74)
					{
						if (kind == 81)
						{
							this.lexer.NextToken();
							operatorType = OverloadableOperatorType.CType;
							return;
						}
						if (kind != 85)
						{
							goto IL_3B8;
						}
					}
				}
				else if (kind <= 103)
				{
					if (kind != 91 && kind != 94 && kind != 103)
					{
						goto IL_3B8;
					}
				}
				else if (kind != 108 && kind != 113 && kind != 120)
				{
					goto IL_3B8;
				}
			}
			else if (kind <= 156)
			{
				if (kind <= 133)
				{
					if (kind != 126 && kind != 130 && kind != 133)
					{
						goto IL_3B8;
					}
				}
				else
				{
					if (kind == 136)
					{
						this.lexer.NextToken();
						operatorType = OverloadableOperatorType.Like;
						return;
					}
					if (kind == 140)
					{
						this.lexer.NextToken();
						operatorType = OverloadableOperatorType.Modulus;
						return;
					}
					if (kind != 156)
					{
						goto IL_3B8;
					}
				}
			}
			else if (kind <= 188)
			{
				switch (kind)
				{
				case 161:
					this.lexer.NextToken();
					operatorType = OverloadableOperatorType.BitwiseOr;
					return;
				case 162:
					break;
				default:
					if (kind != 169 && kind != 188)
					{
						goto IL_3B8;
					}
					break;
				}
			}
			else if (kind <= 209)
			{
				switch (kind)
				{
				case 197:
				case 198:
					break;
				default:
					switch (kind)
					{
					case 208:
					case 209:
						break;
					default:
						goto IL_3B8;
					}
					break;
				}
			}
			else if (kind != 215)
			{
				if (kind != 221)
				{
					goto IL_3B8;
				}
				this.lexer.NextToken();
				operatorType = OverloadableOperatorType.ExclusiveOr;
				return;
			}
			this.Identifier();
			string val = this.t.val;
			if (string.Equals(val, "istrue", StringComparison.InvariantCultureIgnoreCase))
			{
				operatorType = OverloadableOperatorType.IsTrue;
				return;
			}
			if (string.Equals(val, "isfalse", StringComparison.InvariantCultureIgnoreCase))
			{
				operatorType = OverloadableOperatorType.IsFalse;
				return;
			}
			this.Error("Invalid operator. Possible operators are '+', '-', 'Not', 'IsTrue', 'IsFalse'.");
			return;
			IL_3B8:
			base.SynErr(253);
		}

		private void ParameterModifier(ParamModifierList m)
		{
			if (this.la.kind == 59)
			{
				this.lexer.NextToken();
				m.Add(ParameterModifiers.In);
				return;
			}
			if (this.la.kind == 56)
			{
				this.lexer.NextToken();
				m.Add(ParameterModifiers.Ref);
				return;
			}
			if (this.la.kind == 160)
			{
				this.lexer.NextToken();
				m.Add(ParameterModifiers.Optional);
				return;
			}
			if (this.la.kind == 167)
			{
				this.lexer.NextToken();
				m.Add(ParameterModifiers.Params);
				return;
			}
			base.SynErr(270);
		}

		public override void Parse()
		{
			this.ParseRoot();
			this.compilationUnit.AcceptVisitor(new SetParentVisitor(), null);
		}

		public override BlockStatement ParseBlock()
		{
			this.lexer.NextToken();
			this.compilationUnit = new CompilationUnit();
			Location location = this.la.Location;
			Statement statement;
			this.Block(out statement);
			if (statement != null)
			{
				statement.StartLocation = location;
				if (this.t != null)
				{
					statement.EndLocation = this.t.EndLocation;
				}
				else
				{
					statement.EndLocation = this.la.Location;
				}
				statement.AcceptVisitor(new SetParentVisitor(), null);
			}
			base.Expect(0);
			return statement as BlockStatement;
		}

		public override Expression ParseExpression()
		{
			this.lexer.NextToken();
			Location location = this.la.Location;
			Expression expression;
			this.Expr(out expression);
			while (this.la.kind == 1)
			{
				this.lexer.NextToken();
			}
			if (expression != null)
			{
				expression.StartLocation = location;
				expression.EndLocation = this.t.EndLocation;
				expression.AcceptVisitor(new SetParentVisitor(), null);
			}
			base.Expect(0);
			return expression;
		}

		private void ParseRoot()
		{
			this.VBNET();
		}

		public override List<INode> ParseTypeMembers()
		{
			this.lexer.NextToken();
			this.compilationUnit = new CompilationUnit();
			TypeDeclaration typeDeclaration = new TypeDeclaration(Modifiers.None, null);
			this.compilationUnit.BlockStart(typeDeclaration);
			this.ClassBody(typeDeclaration);
			this.compilationUnit.BlockEnd();
			base.Expect(0);
			typeDeclaration.AcceptVisitor(new SetParentVisitor(), null);
			return typeDeclaration.Children;
		}

		public override TypeReference ParseTypeReference()
		{
			return null;
		}

		private void PartitionQueryOperator(out QueryExpressionPartitionVBClause partitionClause)
		{
			partitionClause = new QueryExpressionPartitionVBClause();
			partitionClause.StartLocation = this.la.Location;
			Expression expression = null;
			if (this.la.kind == 197)
			{
				this.lexer.NextToken();
				partitionClause.PartitionType = QueryExpressionPartitionType.Take;
				if (this.la.kind == 216)
				{
					this.lexer.NextToken();
					partitionClause.PartitionType = QueryExpressionPartitionType.TakeWhile;
				}
				this.Expr(out expression);
				return;
			}
			if (this.la.kind == 188)
			{
				this.lexer.NextToken();
				partitionClause.PartitionType = QueryExpressionPartitionType.Skip;
				if (this.la.kind == 216)
				{
					this.lexer.NextToken();
				}
				partitionClause.PartitionType = QueryExpressionPartitionType.SkipWhile;
				this.Expr(out expression);
				partitionClause.Expression = expression;
				partitionClause.EndLocation = this.t.EndLocation;
				return;
			}
			base.SynErr(266);
		}

		private Token Peek(int n)
		{
			this.lexer.StartPeek();
			Token result = this.la;
			while (n > 0)
			{
				result = this.lexer.Peek();
				n--;
			}
			return result;
		}

		private void PrimitiveTypeName(out string type)
		{
			type = string.Empty;
			int kind = this.la.kind;
			if (kind <= 96)
			{
				if (kind <= 58)
				{
					if (kind == 55)
					{
						this.lexer.NextToken();
						type = "System.Boolean";
						return;
					}
					if (kind == 58)
					{
						this.lexer.NextToken();
						type = "System.Byte";
						return;
					}
				}
				else
				{
					if (kind == 69)
					{
						this.lexer.NextToken();
						type = "System.Char";
						return;
					}
					switch (kind)
					{
					case 86:
						this.lexer.NextToken();
						type = "System.DateTime";
						return;
					case 87:
						this.lexer.NextToken();
						type = "System.Decimal";
						return;
					default:
						if (kind == 96)
						{
							this.lexer.NextToken();
							type = "System.Double";
							return;
						}
						break;
					}
				}
			}
			else if (kind <= 181)
			{
				if (kind == 128)
				{
					this.lexer.NextToken();
					type = "System.Int32";
					return;
				}
				if (kind == 137)
				{
					this.lexer.NextToken();
					type = "System.Int64";
					return;
				}
				if (kind == 181)
				{
					this.lexer.NextToken();
					type = "System.SByte";
					return;
				}
			}
			else
			{
				switch (kind)
				{
				case 186:
					this.lexer.NextToken();
					type = "System.Int16";
					return;
				case 187:
					this.lexer.NextToken();
					type = "System.Single";
					return;
				default:
					if (kind == 193)
					{
						this.lexer.NextToken();
						type = "System.String";
						return;
					}
					switch (kind)
					{
					case 206:
						this.lexer.NextToken();
						type = "System.UInt32";
						return;
					case 207:
						this.lexer.NextToken();
						type = "System.UInt64";
						return;
					case 210:
						this.lexer.NextToken();
						type = "System.UInt16";
						return;
					}
					break;
				}
			}
			base.SynErr(261);
		}

		private void PropertyAccessorAccessModifier(out Modifiers m)
		{
			m = Modifiers.None;
			while (this.StartOf(28))
			{
				if (this.la.kind == 173)
				{
					this.lexer.NextToken();
					m |= Modifiers.Public;
				}
				else if (this.la.kind == 172)
				{
					this.lexer.NextToken();
					m |= Modifiers.Protected;
				}
				else if (this.la.kind == 112)
				{
					this.lexer.NextToken();
					m |= Modifiers.Internal;
				}
				else
				{
					this.lexer.NextToken();
					m |= Modifiers.Private;
				}
			}
		}

		private void Qualident(out string qualident)
		{
			this.qualidentBuilder.Length = 0;
			this.Identifier();
			this.qualidentBuilder.Append(this.t.val);
			while (this.DotAndIdentOrKw())
			{
				base.Expect(16);
				string value;
				this.IdentifierOrKeyword(out value);
				this.qualidentBuilder.Append('.');
				this.qualidentBuilder.Append(value);
			}
			qualident = this.qualidentBuilder.ToString();
		}

		private void QualIdentAndTypeArguments(out TypeReference typeref, bool canBeUnbound)
		{
			typeref = null;
			string type;
			this.Qualident(out type);
			typeref = new TypeReference(type);
			if (this.la.kind == 25 && this.Peek(1).kind == 155)
			{
				this.lexer.NextToken();
				base.Expect(155);
				if (canBeUnbound && (this.la.kind == 26 || this.la.kind == 12))
				{
					typeref.GenericTypes.Add(NullTypeReference.Instance);
					while (this.la.kind == 12)
					{
						this.lexer.NextToken();
						typeref.GenericTypes.Add(NullTypeReference.Instance);
					}
				}
				else if (this.StartOf(7))
				{
					this.TypeArgumentList(typeref.GenericTypes);
				}
				else
				{
					base.SynErr(268);
				}
				base.Expect(26);
			}
		}

		private void QueryExpr(out Expression expr)
		{
			QueryExpression queryExpression = new QueryExpression();
			queryExpression.StartLocation = this.la.Location;
			List<QueryExpressionClause> middleClauses = new List<QueryExpressionClause>();
			expr = queryExpression;
			this.FromOrAggregateQueryOperator(middleClauses);
			while (this.StartOf(31))
			{
				this.QueryOperator(middleClauses);
			}
			queryExpression.EndLocation = this.t.EndLocation;
		}

		private void QueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionJoinVBClause item = null;
			QueryExpressionGroupVBClause item2 = null;
			QueryExpressionPartitionVBClause queryExpressionPartitionVBClause = null;
			QueryExpressionGroupJoinVBClause item3 = null;
			if (this.la.kind == 113)
			{
				this.FromQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 45)
			{
				this.AggregateQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 182)
			{
				this.SelectQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 94)
			{
				this.DistinctQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 215)
			{
				this.WhereQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 162)
			{
				this.OrderByQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 188 || this.la.kind == 197)
			{
				this.PartitionQueryOperator(out queryExpressionPartitionVBClause);
				return;
			}
			if (this.la.kind == 134)
			{
				this.LetQueryOperator(middleClauses);
				return;
			}
			if (this.la.kind == 133)
			{
				this.JoinQueryOperator(out item);
				middleClauses.Add(item);
				return;
			}
			if (this.la.kind == 120 && this.Peek(1).kind == 133)
			{
				this.GroupJoinQueryOperator(out item3);
				middleClauses.Add(item3);
				return;
			}
			if (this.la.kind == 120)
			{
				this.GroupByQueryOperator(out item2);
				middleClauses.Add(item2);
				return;
			}
			base.SynErr(265);
		}

		private void RankList(out int i)
		{
			i = 0;
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				i++;
			}
		}

		private void ReDimClause(out Expression expr)
		{
			this.SimpleNonInvocationExpression(out expr);
			this.ReDimClauseInternal(ref expr);
		}

		private void ReDimClauseInternal(ref Expression expr)
		{
			while (this.la.kind == 16 || (this.la.kind == 25 && this.Peek(1).kind == 155))
			{
				if (this.la.kind == 16)
				{
					this.lexer.NextToken();
					string memberName;
					this.IdentifierOrKeyword(out memberName);
					expr = new MemberReferenceExpression(expr, memberName);
				}
				else
				{
					this.InvocationExpression(ref expr);
				}
			}
			base.Expect(25);
			List<Expression> arguments;
			bool flag;
			bool flag2;
			this.NormalOrReDimArgumentList(out arguments, out flag, out flag2);
			base.Expect(26);
			expr = new InvocationExpression(expr, arguments);
			if ((!flag2 || (flag && (this.la.kind == 16 || this.la.kind == 25))) && base.Errors.Count == 0)
			{
				this.ReDimClauseInternal(ref expr);
			}
		}

		private void ResumeStatement(out ResumeStatement resumeStatement)
		{
			resumeStatement = null;
			string empty = string.Empty;
			if (this.IsResumeNext())
			{
				base.Expect(179);
				base.Expect(149);
				resumeStatement = new ResumeStatement(true);
				return;
			}
			if (this.la.kind == 179)
			{
				this.lexer.NextToken();
				if (this.StartOf(42))
				{
					this.LabelName(out empty);
				}
				resumeStatement = new ResumeStatement(empty);
				return;
			}
			base.SynErr(284);
		}

		private static void SafeAdd<T>(INode parent, List<T> list, T item) where T : class, INode
		{
			if (item != null)
			{
				list.Add(item);
				item.Parent = parent;
			}
		}

		private void SelectQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionSelectVBClause queryExpressionSelectVBClause = new QueryExpressionSelectVBClause();
			queryExpressionSelectVBClause.StartLocation = this.la.Location;
			base.Expect(182);
			this.ExpressionRangeVariableDeclarationList(queryExpressionSelectVBClause.Variables);
			queryExpressionSelectVBClause.EndLocation = this.t.Location;
			middleClauses.Add(queryExpressionSelectVBClause);
		}

		private void SetAccessorDecl(out PropertySetRegion setBlock, List<AttributeSection> attributes)
		{
			Statement statement = null;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			Modifiers modifier;
			this.PropertyAccessorAccessModifier(out modifier);
			base.Expect(183);
			Location location = this.t.Location;
			if (this.la.kind == 25)
			{
				this.lexer.NextToken();
				if (this.StartOf(4))
				{
					this.FormalParameterList(list);
				}
				base.Expect(26);
			}
			base.Expect(1);
			this.Block(out statement);
			setBlock = new PropertySetRegion((BlockStatement)statement, attributes);
			setBlock.Modifier = modifier;
			setBlock.Parameters = list;
			base.Expect(100);
			base.Expect(183);
			setBlock.StartLocation = location;
			setBlock.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void ShiftExpr(out Expression outExpr)
		{
			this.ConcatenationExpr(out outExpr);
			while (this.la.kind == 32 || this.la.kind == 33)
			{
				BinaryOperatorType op;
				if (this.la.kind == 32)
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.ShiftLeft;
				}
				else
				{
					this.lexer.NextToken();
					op = BinaryOperatorType.ShiftRight;
				}
				Expression right;
				this.ConcatenationExpr(out right);
				outExpr = new BinaryOperatorExpression(outExpr, op, right);
			}
		}

		private void SimpleExpr(out Expression pexpr)
		{
			this.SimpleNonInvocationExpression(out pexpr);
			while (this.la.kind == 16 || this.la.kind == 17 || this.la.kind == 25)
			{
				if (this.la.kind == 16)
				{
					this.lexer.NextToken();
					string text;
					this.IdentifierOrKeyword(out text);
					pexpr = new MemberReferenceExpression(pexpr, text);
					if (this.la.kind == 25 && this.Peek(1).kind == 155)
					{
						this.lexer.NextToken();
						base.Expect(155);
						this.TypeArgumentList(((MemberReferenceExpression)pexpr).TypeArguments);
						base.Expect(26);
					}
				}
				else if (this.la.kind == 17)
				{
					this.lexer.NextToken();
					string text;
					this.IdentifierOrKeyword(out text);
					pexpr = new BinaryOperatorExpression(pexpr, BinaryOperatorType.DictionaryAccess, new PrimitiveExpression(text, text));
				}
				else
				{
					this.InvocationExpression(ref pexpr);
				}
			}
		}

		private void SimpleNonInvocationExpression(out Expression pexpr)
		{
			TypeReference typeReference = null;
			string empty = string.Empty;
			pexpr = null;
			if (this.StartOf(32))
			{
				int kind = this.la.kind;
				Expression expression;
				if (kind <= 133)
				{
					if (kind <= 109)
					{
						if (kind <= 96)
						{
							switch (kind)
							{
							case 2:
								break;
							case 3:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 4:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 5:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 6:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 7:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 8:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							case 9:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(this.t.literalValue, this.t.val)
								{
									LiteralFormat = this.t.literalFormat
								};
								return;
							default:
								switch (kind)
								{
								case 25:
									this.lexer.NextToken();
									this.Expr(out expression);
									base.Expect(26);
									pexpr = new ParenthesizedExpression(expression);
									return;
								case 26:
								case 27:
								case 28:
								case 29:
								case 30:
								case 31:
								case 32:
								case 33:
								case 34:
								case 35:
								case 36:
								case 37:
								case 38:
								case 39:
								case 40:
								case 41:
								case 42:
								case 43:
								case 46:
								case 47:
								case 48:
								case 50:
								case 56:
								case 59:
								case 60:
								case 61:
								case 62:
								case 71:
								case 75:
								case 76:
								case 88:
								case 89:
								case 90:
								case 92:
								case 95:
									return;
								case 44:
									this.lexer.NextToken();
									this.Expr(out expression);
									pexpr = new AddressOfExpression(expression);
									return;
								case 45:
								case 49:
								case 51:
								case 52:
								case 53:
								case 54:
								case 57:
								case 74:
								case 85:
								case 91:
								case 94:
									break;
								case 55:
								case 58:
								case 69:
								case 86:
								case 87:
								case 96:
									goto IL_608;
								case 63:
								case 64:
								case 65:
								case 66:
								case 67:
								case 68:
								case 70:
								case 72:
								case 73:
								case 77:
								case 78:
								case 79:
								case 80:
								case 82:
								case 83:
								case 84:
									this.CastTarget(out typeReference);
									base.Expect(25);
									this.Expr(out expression);
									base.Expect(26);
									pexpr = new CastExpression(typeReference, expression, CastType.PrimitiveConversion);
									return;
								case 81:
								case 93:
									goto IL_740;
								default:
									return;
								}
								break;
							}
						}
						else if (kind != 103)
						{
							switch (kind)
							{
							case 108:
								break;
							case 109:
								this.lexer.NextToken();
								pexpr = new PrimitiveExpression(false, "false");
								return;
							default:
								return;
							}
						}
					}
					else if (kind <= 122)
					{
						switch (kind)
						{
						case 113:
							break;
						case 114:
						case 115:
							return;
						case 116:
							this.lexer.NextToken();
							base.Expect(25);
							this.GetTypeTypeName(out typeReference);
							base.Expect(26);
							pexpr = new TypeOfExpression(typeReference);
							return;
						case 117:
							this.lexer.NextToken();
							base.Expect(16);
							this.Identifier();
							typeReference = new TypeReference(this.t.val ?? "");
							typeReference.IsGlobal = true;
							pexpr = new TypeReferenceExpression(typeReference);
							return;
						default:
							switch (kind)
							{
							case 120:
								break;
							case 121:
								return;
							case 122:
								this.ConditionalExpression(out pexpr);
								return;
							default:
								return;
							}
							break;
						}
					}
					else
					{
						switch (kind)
						{
						case 126:
						case 130:
							break;
						case 127:
						case 129:
							return;
						case 128:
							goto IL_608;
						default:
							if (kind != 133)
							{
								return;
							}
							break;
						}
					}
				}
				else if (kind <= 156)
				{
					if (kind <= 148)
					{
						switch (kind)
						{
						case 137:
							goto IL_608;
						case 138:
							return;
						case 139:
							this.lexer.NextToken();
							pexpr = new ThisReferenceExpression();
							return;
						default:
							switch (kind)
							{
							case 144:
							case 145:
							{
								Expression targetObject = null;
								if (this.la.kind == 144)
								{
									this.lexer.NextToken();
									targetObject = new BaseReferenceExpression();
								}
								else if (this.la.kind == 145)
								{
									this.lexer.NextToken();
									targetObject = new ClassReferenceExpression();
								}
								else
								{
									base.SynErr(258);
								}
								base.Expect(16);
								this.IdentifierOrKeyword(out empty);
								pexpr = new MemberReferenceExpression(targetObject, empty);
								return;
							}
							case 146:
							case 147:
								return;
							case 148:
								this.ObjectCreateExpression(out expression);
								pexpr = expression;
								return;
							default:
								return;
							}
							break;
						}
					}
					else
					{
						if (kind == 151)
						{
							this.lexer.NextToken();
							pexpr = new PrimitiveExpression(null, "null");
							return;
						}
						switch (kind)
						{
						case 154:
							goto IL_608;
						case 155:
							return;
						case 156:
							break;
						default:
							return;
						}
					}
				}
				else if (kind <= 169)
				{
					if (kind != 162 && kind != 169)
					{
						return;
					}
				}
				else
				{
					if (kind == 181)
					{
						goto IL_608;
					}
					switch (kind)
					{
					case 186:
					case 187:
					case 193:
					case 206:
					case 207:
					case 210:
						goto IL_608;
					case 188:
					case 197:
					case 198:
					case 208:
					case 209:
						break;
					case 189:
					case 190:
					case 191:
					case 192:
					case 194:
					case 195:
					case 196:
					case 199:
					case 200:
					case 201:
					case 203:
						return;
					case 202:
						this.lexer.NextToken();
						pexpr = new PrimitiveExpression(true, "true");
						return;
					case 204:
						goto IL_740;
					case 205:
						this.lexer.NextToken();
						this.SimpleExpr(out expression);
						base.Expect(131);
						this.TypeName(out typeReference);
						pexpr = new TypeOfIsExpression(expression, typeReference);
						return;
					default:
						if (kind != 215)
						{
							return;
						}
						break;
					}
				}
				this.Identifier();
				pexpr = new IdentifierExpression(this.t.val);
				pexpr.StartLocation = this.t.Location;
				pexpr.EndLocation = this.t.EndLocation;
				if (this.la.kind == 25 && this.Peek(1).kind == 155)
				{
					this.lexer.NextToken();
					base.Expect(155);
					this.TypeArgumentList(((IdentifierExpression)pexpr).TypeArguments);
					base.Expect(26);
					return;
				}
				return;
				IL_608:
				string type = string.Empty;
				if (this.StartOf(11))
				{
					this.PrimitiveTypeName(out type);
				}
				else if (this.la.kind == 154)
				{
					this.lexer.NextToken();
					type = "System.Object";
				}
				else
				{
					base.SynErr(257);
				}
				pexpr = new TypeReferenceExpression(new TypeReference(type, true));
				return;
				IL_740:
				CastType castType = CastType.Cast;
				if (this.la.kind == 93)
				{
					this.lexer.NextToken();
				}
				else if (this.la.kind == 81)
				{
					this.lexer.NextToken();
					castType = CastType.Conversion;
				}
				else if (this.la.kind == 204)
				{
					this.lexer.NextToken();
					castType = CastType.TryCast;
				}
				else
				{
					base.SynErr(259);
				}
				base.Expect(25);
				this.Expr(out expression);
				base.Expect(12);
				this.TypeName(out typeReference);
				base.Expect(26);
				pexpr = new CastExpression(typeReference, expression, castType);
				return;
			}
			if (this.la.kind == 16)
			{
				this.lexer.NextToken();
				this.IdentifierOrKeyword(out empty);
				pexpr = new MemberReferenceExpression(null, empty);
				return;
			}
			base.SynErr(260);
		}

		private void SingleLineStatementList(List<Statement> list)
		{
			Statement statement = null;
			if (this.la.kind == 100)
			{
				this.lexer.NextToken();
				statement = new EndStatement();
			}
			else if (this.StartOf(36))
			{
				this.EmbeddedStatement(out statement);
			}
			else
			{
				base.SynErr(281);
			}
			if (statement != null)
			{
				list.Add(statement);
			}
			while (this.la.kind == 11)
			{
				this.lexer.NextToken();
				while (this.la.kind == 11)
				{
					this.lexer.NextToken();
				}
				if (this.la.kind == 100)
				{
					this.lexer.NextToken();
					statement = new EndStatement();
				}
				else if (this.StartOf(36))
				{
					this.EmbeddedStatement(out statement);
				}
				else
				{
					base.SynErr(282);
				}
				if (statement != null)
				{
					list.Add(statement);
				}
			}
		}

		private bool StartOf(int s)
		{
			return Parser.set[s, this.lexer.LookAhead.kind];
		}

		private void Statement()
		{
			Statement statement = null;
			Location location = this.la.Location;
			string empty = string.Empty;
			if (this.la.kind != 1 && this.la.kind != 11)
			{
				if (this.IsLabel())
				{
					this.LabelName(out empty);
					this.compilationUnit.AddChild(new LabelStatement(this.t.val));
					base.Expect(11);
					this.Statement();
				}
				else if (this.StartOf(36))
				{
					this.EmbeddedStatement(out statement);
					this.compilationUnit.AddChild(statement);
				}
				else
				{
					base.SynErr(271);
				}
			}
			if (statement != null)
			{
				statement.StartLocation = location;
				statement.EndLocation = this.t.Location;
			}
		}

		private void StructureBody(TypeDeclaration newType)
		{
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.StartOf(8))
			{
				List<AttributeSection> list = new List<AttributeSection>();
				ModifierList m = new ModifierList();
				while (this.la.kind == 28)
				{
					AttributeSection item;
					this.AttributeSection(out item);
					list.Add(item);
				}
				while (this.StartOf(9))
				{
					this.MemberModifier(m);
				}
				this.StructureMemberDecl(m, list);
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(100);
			base.Expect(194);
			newType.EndLocation = this.t.EndLocation;
			this.EndOfStmt();
		}

		private void StructureMemberDecl(ModifierList m, List<AttributeSection> attributes)
		{
			TypeReference typeReference = null;
			List<ParameterDeclarationExpression> list = new List<ParameterDeclarationExpression>();
			Statement statement = null;
			List<VariableDeclaration> list2 = new List<VariableDeclaration>();
			List<TemplateDefinition> templates = new List<TemplateDefinition>();
			int kind = this.la.kind;
			if (kind > 130)
			{
				if (kind <= 162)
				{
					if (kind <= 141)
					{
						if (kind == 133)
						{
							goto IL_CA2;
						}
						if (kind != 141)
						{
							goto IL_1434;
						}
						goto IL_237;
					}
					else if (kind != 147)
					{
						switch (kind)
						{
						case 156:
							goto IL_CA2;
						case 157:
							goto IL_1434;
						case 158:
							break;
						default:
							if (kind != 162)
							{
								goto IL_1434;
							}
							goto IL_CA2;
						}
					}
				}
				else if (kind <= 188)
				{
					switch (kind)
					{
					case 169:
						goto IL_CA2;
					case 170:
						goto IL_1434;
					case 171:
					{
						this.lexer.NextToken();
						m.Check(Modifiers.VBProperties);
						Location location = this.t.Location;
						List<InterfaceImplementation> interfaceImplementations = null;
						this.Identifier();
						string val = this.t.val;
						if (this.la.kind == 25)
						{
							this.lexer.NextToken();
							if (this.StartOf(4))
							{
								this.FormalParameterList(list);
							}
							base.Expect(26);
						}
						if (this.la.kind == 50)
						{
							this.lexer.NextToken();
							this.TypeName(out typeReference);
						}
						if (typeReference == null)
						{
							typeReference = new TypeReference("System.Object", true);
						}
						if (this.la.kind == 123)
						{
							this.ImplementsClause(out interfaceImplementations);
						}
						this.EndOfStmt();
						if (Parser.IsMustOverride(m))
						{
							PropertyDeclaration propertyDeclaration = new PropertyDeclaration(val, typeReference, m.Modifier, attributes);
							propertyDeclaration.StartLocation = m.GetDeclarationLocation(location);
							propertyDeclaration.EndLocation = this.t.Location;
							propertyDeclaration.TypeReference = typeReference;
							propertyDeclaration.InterfaceImplementations = interfaceImplementations;
							propertyDeclaration.Parameters = list;
							this.compilationUnit.AddChild(propertyDeclaration);
							return;
						}
						if (this.StartOf(17))
						{
							PropertyDeclaration propertyDeclaration2 = new PropertyDeclaration(val, typeReference, m.Modifier, attributes);
							propertyDeclaration2.StartLocation = m.GetDeclarationLocation(location);
							propertyDeclaration2.EndLocation = this.t.Location;
							propertyDeclaration2.BodyStart = this.t.Location;
							propertyDeclaration2.TypeReference = typeReference;
							propertyDeclaration2.InterfaceImplementations = interfaceImplementations;
							propertyDeclaration2.Parameters = list;
							PropertyGetRegion getRegion;
							PropertySetRegion setRegion;
							this.AccessorDecls(out getRegion, out setRegion);
							base.Expect(100);
							base.Expect(171);
							this.EndOfStmt();
							propertyDeclaration2.GetRegion = getRegion;
							propertyDeclaration2.SetRegion = setRegion;
							propertyDeclaration2.BodyEnd = this.t.EndLocation;
							this.compilationUnit.AddChild(propertyDeclaration2);
							return;
						}
						base.SynErr(243);
						return;
					}
					default:
						if (kind != 188)
						{
							goto IL_1434;
						}
						goto IL_CA2;
					}
				}
				else
				{
					switch (kind)
					{
					case 194:
						goto IL_237;
					case 195:
					{
						this.lexer.NextToken();
						Location location2 = this.t.Location;
						if (this.StartOf(14))
						{
							string name = string.Empty;
							List<string> handlesClause = null;
							List<InterfaceImplementation> interfaceImplementations2 = null;
							this.Identifier();
							name = this.t.val;
							m.Check(Modifiers.VBMethods);
							this.TypeParameterList(templates);
							if (this.la.kind == 25)
							{
								this.lexer.NextToken();
								if (this.StartOf(4))
								{
									this.FormalParameterList(list);
								}
								base.Expect(26);
							}
							if (this.la.kind == 121 || this.la.kind == 123)
							{
								if (this.la.kind == 123)
								{
									this.ImplementsClause(out interfaceImplementations2);
								}
								else
								{
									this.HandlesClause(out handlesClause);
								}
							}
							Location endLocation = this.t.EndLocation;
							if (Parser.IsMustOverride(m))
							{
								this.EndOfStmt();
								MethodDeclaration methodDeclaration = new MethodDeclaration
								{
									Name = name,
									Modifier = m.Modifier,
									Parameters = list,
									Attributes = attributes,
									StartLocation = m.GetDeclarationLocation(location2),
									EndLocation = endLocation,
									TypeReference = new TypeReference("System.Void", true),
									Templates = templates,
									HandlesClause = handlesClause,
									InterfaceImplementations = interfaceImplementations2
								};
								this.compilationUnit.AddChild(methodDeclaration);
								return;
							}
							if (this.la.kind == 1)
							{
								this.lexer.NextToken();
								MethodDeclaration methodDeclaration = new MethodDeclaration
								{
									Name = name,
									Modifier = m.Modifier,
									Parameters = list,
									Attributes = attributes,
									StartLocation = m.GetDeclarationLocation(location2),
									EndLocation = endLocation,
									TypeReference = new TypeReference("System.Void", true),
									Templates = templates,
									HandlesClause = handlesClause,
									InterfaceImplementations = interfaceImplementations2
								};
								this.compilationUnit.AddChild(methodDeclaration);
								if (base.ParseMethodBodies)
								{
									this.Block(out statement);
									base.Expect(100);
									base.Expect(195);
								}
								else
								{
									this.lexer.SkipCurrentBlock(195);
									statement = new BlockStatement();
								}
								methodDeclaration.Body = (BlockStatement)statement;
								methodDeclaration.Body.EndLocation = this.t.EndLocation;
								this.EndOfStmt();
								return;
							}
							base.SynErr(238);
							return;
						}
						else
						{
							if (this.la.kind == 148)
							{
								this.lexer.NextToken();
								if (this.la.kind == 25)
								{
									this.lexer.NextToken();
									if (this.StartOf(4))
									{
										this.FormalParameterList(list);
									}
									base.Expect(26);
								}
								m.Check(Modifiers.Constructors);
								Location endLocation2 = this.t.EndLocation;
								base.Expect(1);
								if (base.ParseMethodBodies)
								{
									this.Block(out statement);
									base.Expect(100);
									base.Expect(195);
								}
								else
								{
									this.lexer.SkipCurrentBlock(195);
									statement = new BlockStatement();
								}
								Location endLocation3 = this.t.EndLocation;
								this.EndOfStmt();
								ConstructorDeclaration constructorDeclaration = new ConstructorDeclaration("New", m.Modifier, list, attributes);
								constructorDeclaration.StartLocation = m.GetDeclarationLocation(location2);
								constructorDeclaration.EndLocation = endLocation2;
								constructorDeclaration.Body = (BlockStatement)statement;
								constructorDeclaration.Body.EndLocation = endLocation3;
								this.compilationUnit.AddChild(constructorDeclaration);
								return;
							}
							base.SynErr(239);
							return;
						}
						break;
					}
					case 196:
						goto IL_1434;
					case 197:
					case 198:
						goto IL_CA2;
					default:
						switch (kind)
						{
						case 208:
						case 209:
							goto IL_CA2;
						default:
							switch (kind)
							{
							case 215:
								goto IL_CA2;
							case 216:
								goto IL_1434;
							case 217:
								break;
							default:
								goto IL_1434;
							}
							break;
						}
						break;
					}
				}
				ConversionType conversionType = ConversionType.None;
				if (this.la.kind == 147 || this.la.kind == 217)
				{
					if (this.la.kind == 217)
					{
						this.lexer.NextToken();
						conversionType = ConversionType.Implicit;
					}
					else
					{
						this.lexer.NextToken();
						conversionType = ConversionType.Explicit;
					}
				}
				base.Expect(158);
				m.Check(Modifiers.VBOperators);
				Location location3 = this.t.Location;
				TypeReference instance = NullTypeReference.Instance;
				TypeReference instance2 = NullTypeReference.Instance;
				List<ParameterDeclarationExpression> list3 = new List<ParameterDeclarationExpression>();
				List<AttributeSection> list4 = new List<AttributeSection>();
				OverloadableOperatorType overloadableOperator;
				this.OverloadableOperator(out overloadableOperator);
				base.Expect(25);
				if (this.la.kind == 59)
				{
					this.lexer.NextToken();
				}
				this.Identifier();
				string val2 = this.t.val;
				if (this.la.kind == 50)
				{
					this.lexer.NextToken();
					this.TypeName(out instance2);
				}
				list3.Add(new ParameterDeclarationExpression(instance2, val2, ParameterModifiers.In));
				while (this.la.kind == 12)
				{
					this.lexer.NextToken();
					if (this.la.kind == 59)
					{
						this.lexer.NextToken();
					}
					this.Identifier();
					val2 = this.t.val;
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.TypeName(out instance2);
					}
					list3.Add(new ParameterDeclarationExpression(instance2, val2, ParameterModifiers.In));
				}
				base.Expect(26);
				Location endLocation4 = this.t.EndLocation;
				if (this.la.kind == 50)
				{
					this.lexer.NextToken();
					while (this.la.kind == 28)
					{
						AttributeSection item;
						this.AttributeSection(out item);
						list4.Add(item);
					}
					this.TypeName(out instance);
					endLocation4 = this.t.EndLocation;
				}
				base.Expect(1);
				this.Block(out statement);
				base.Expect(100);
				base.Expect(158);
				this.EndOfStmt();
				OperatorDeclaration operatorDeclaration = new OperatorDeclaration
				{
					Modifier = m.Modifier,
					Attributes = attributes,
					Parameters = list3,
					TypeReference = instance,
					OverloadableOperator = overloadableOperator,
					ConversionType = conversionType,
					ReturnTypeAttributes = list4,
					Body = (BlockStatement)statement,
					StartLocation = m.GetDeclarationLocation(location3),
					EndLocation = endLocation4
				};
				operatorDeclaration.Body.StartLocation = location3;
				operatorDeclaration.Body.EndLocation = this.t.Location;
				this.compilationUnit.AddChild(operatorDeclaration);
				return;
			}
			if (kind <= 91)
			{
				if (kind <= 57)
				{
					if (kind == 2)
					{
						goto IL_CA2;
					}
					switch (kind)
					{
					case 45:
					case 49:
					case 51:
					case 52:
					case 53:
					case 54:
					case 57:
						goto IL_CA2;
					case 46:
					case 47:
					case 48:
					case 50:
					case 55:
					case 56:
						goto IL_1434;
					default:
						goto IL_1434;
					}
				}
				else
				{
					switch (kind)
					{
					case 71:
						break;
					case 72:
					case 73:
						goto IL_1434;
					case 74:
						goto IL_CA2;
					case 75:
					{
						m.Check(Modifiers.Fields);
						this.lexer.NextToken();
						m.Add(Modifiers.Const, this.t.Location);
						FieldDeclaration fieldDeclaration = new FieldDeclaration(attributes, typeReference, m.Modifier);
						fieldDeclaration.StartLocation = m.GetDeclarationLocation(this.t.Location);
						List<VariableDeclaration> list5 = new List<VariableDeclaration>();
						this.ConstantDeclarator(list5);
						while (this.la.kind == 12)
						{
							this.lexer.NextToken();
							this.ConstantDeclarator(list5);
						}
						fieldDeclaration.Fields = list5;
						fieldDeclaration.EndLocation = this.t.Location;
						this.EndOfStmt();
						fieldDeclaration.EndLocation = this.t.EndLocation;
						this.compilationUnit.AddChild(fieldDeclaration);
						return;
					}
					default:
						switch (kind)
						{
						case 85:
						{
							this.lexer.NextToken();
							Location location4 = this.t.Location;
							base.Expect(106);
							m.Check(Modifiers.VBExternalMethods);
							EventAddRegion eventAddRegion = null;
							EventRemoveRegion eventRemoveRegion = null;
							EventRaiseRegion eventRaiseRegion = null;
							List<InterfaceImplementation> list6 = null;
							this.Identifier();
							string val3 = this.t.val;
							base.Expect(50);
							this.TypeName(out typeReference);
							if (this.la.kind == 123)
							{
								this.ImplementsClause(out list6);
							}
							this.EndOfStmt();
							while (this.StartOf(18))
							{
								EventAddRemoveRegion eventAddRemoveRegion;
								this.EventAccessorDeclaration(out eventAddRemoveRegion);
								if (eventAddRemoveRegion is EventAddRegion)
								{
									eventAddRegion = (EventAddRegion)eventAddRemoveRegion;
								}
								else if (eventAddRemoveRegion is EventRemoveRegion)
								{
									eventRemoveRegion = (EventRemoveRegion)eventAddRemoveRegion;
								}
								else if (eventAddRemoveRegion is EventRaiseRegion)
								{
									eventRaiseRegion = (EventRaiseRegion)eventAddRemoveRegion;
								}
							}
							base.Expect(100);
							base.Expect(106);
							this.EndOfStmt();
							if (eventAddRegion == null)
							{
								this.Error("Need to provide AddHandler accessor.");
							}
							if (eventRemoveRegion == null)
							{
								this.Error("Need to provide RemoveHandler accessor.");
							}
							if (eventRaiseRegion == null)
							{
								this.Error("Need to provide RaiseEvent accessor.");
							}
							EventDeclaration childNode = new EventDeclaration
							{
								TypeReference = typeReference,
								Name = val3,
								Modifier = m.Modifier,
								Attributes = attributes,
								StartLocation = m.GetDeclarationLocation(location4),
								EndLocation = this.t.EndLocation,
								AddRegion = eventAddRegion,
								RemoveRegion = eventRemoveRegion,
								RaiseRegion = eventRaiseRegion
							};
							this.compilationUnit.AddChild(childNode);
							return;
						}
						case 86:
						case 87:
						case 89:
							goto IL_1434;
						case 88:
						{
							this.lexer.NextToken();
							m.Check(Modifiers.VBExternalMethods);
							Location location5 = this.t.Location;
							CharsetModifier charset = CharsetModifier.None;
							string library = string.Empty;
							string alias = null;
							string name2 = string.Empty;
							if (this.StartOf(15))
							{
								this.Charset(out charset);
							}
							if (this.la.kind == 195)
							{
								this.lexer.NextToken();
								this.Identifier();
								name2 = this.t.val;
								base.Expect(135);
								base.Expect(3);
								library = (this.t.literalValue as string);
								if (this.la.kind == 46)
								{
									this.lexer.NextToken();
									base.Expect(3);
									alias = (this.t.literalValue as string);
								}
								if (this.la.kind == 25)
								{
									this.lexer.NextToken();
									if (this.StartOf(4))
									{
										this.FormalParameterList(list);
									}
									base.Expect(26);
								}
								this.EndOfStmt();
								DeclareDeclaration declareDeclaration = new DeclareDeclaration(name2, m.Modifier, null, list, attributes, library, alias, charset);
								declareDeclaration.StartLocation = m.GetDeclarationLocation(location5);
								declareDeclaration.EndLocation = this.t.EndLocation;
								this.compilationUnit.AddChild(declareDeclaration);
								return;
							}
							if (this.la.kind == 114)
							{
								this.lexer.NextToken();
								this.Identifier();
								name2 = this.t.val;
								base.Expect(135);
								base.Expect(3);
								library = (this.t.literalValue as string);
								if (this.la.kind == 46)
								{
									this.lexer.NextToken();
									base.Expect(3);
									alias = (this.t.literalValue as string);
								}
								if (this.la.kind == 25)
								{
									this.lexer.NextToken();
									if (this.StartOf(4))
									{
										this.FormalParameterList(list);
									}
									base.Expect(26);
								}
								if (this.la.kind == 50)
								{
									this.lexer.NextToken();
									this.TypeName(out typeReference);
								}
								this.EndOfStmt();
								DeclareDeclaration declareDeclaration2 = new DeclareDeclaration(name2, m.Modifier, typeReference, list, attributes, library, alias, charset);
								declareDeclaration2.StartLocation = m.GetDeclarationLocation(location5);
								declareDeclaration2.EndLocation = this.t.EndLocation;
								this.compilationUnit.AddChild(declareDeclaration2);
								return;
							}
							base.SynErr(241);
							return;
						}
						case 90:
							break;
						case 91:
							goto IL_CA2;
						default:
							goto IL_1434;
						}
						break;
					}
				}
			}
			else if (kind <= 108)
			{
				if (kind == 94)
				{
					goto IL_CA2;
				}
				switch (kind)
				{
				case 102:
					break;
				case 103:
				case 108:
					goto IL_CA2;
				case 104:
				case 105:
				case 107:
					goto IL_1434;
				case 106:
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBExternalMethods);
					Location location6 = this.t.Location;
					string name3 = string.Empty;
					List<InterfaceImplementation> interfaceImplementations3 = null;
					this.Identifier();
					name3 = this.t.val;
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						this.TypeName(out typeReference);
					}
					else if (this.StartOf(16))
					{
						if (this.la.kind == 25)
						{
							this.lexer.NextToken();
							if (this.StartOf(4))
							{
								this.FormalParameterList(list);
							}
							base.Expect(26);
						}
					}
					else
					{
						base.SynErr(242);
					}
					if (this.la.kind == 123)
					{
						this.ImplementsClause(out interfaceImplementations3);
					}
					EventDeclaration childNode2 = new EventDeclaration
					{
						Name = name3,
						TypeReference = typeReference,
						Modifier = m.Modifier,
						Parameters = list,
						Attributes = attributes,
						InterfaceImplementations = interfaceImplementations3,
						StartLocation = m.GetDeclarationLocation(location6),
						EndLocation = this.t.EndLocation
					};
					this.compilationUnit.AddChild(childNode2);
					this.EndOfStmt();
					return;
				}
				default:
					goto IL_1434;
				}
			}
			else
			{
				switch (kind)
				{
				case 113:
					goto IL_CA2;
				case 114:
				{
					this.lexer.NextToken();
					m.Check(Modifiers.VBMethods);
					string name4 = string.Empty;
					Location location7 = this.t.Location;
					List<string> handlesClause2 = null;
					List<InterfaceImplementation> interfaceImplementations4 = null;
					AttributeSection attributeSection = null;
					this.Identifier();
					name4 = this.t.val;
					this.TypeParameterList(templates);
					if (this.la.kind == 25)
					{
						this.lexer.NextToken();
						if (this.StartOf(4))
						{
							this.FormalParameterList(list);
						}
						base.Expect(26);
					}
					if (this.la.kind == 50)
					{
						this.lexer.NextToken();
						while (this.la.kind == 28)
						{
							this.AttributeSection(out attributeSection);
						}
						this.TypeName(out typeReference);
					}
					if (typeReference == null)
					{
						typeReference = new TypeReference("System.Object", true);
					}
					if (this.la.kind == 121 || this.la.kind == 123)
					{
						if (this.la.kind == 123)
						{
							this.ImplementsClause(out interfaceImplementations4);
						}
						else
						{
							this.HandlesClause(out handlesClause2);
						}
					}
					Location endLocation5 = this.t.EndLocation;
					if (Parser.IsMustOverride(m))
					{
						this.EndOfStmt();
						MethodDeclaration methodDeclaration2 = new MethodDeclaration
						{
							Name = name4,
							Modifier = m.Modifier,
							TypeReference = typeReference,
							Parameters = list,
							Attributes = attributes,
							StartLocation = m.GetDeclarationLocation(location7),
							EndLocation = endLocation5,
							HandlesClause = handlesClause2,
							Templates = templates,
							InterfaceImplementations = interfaceImplementations4
						};
						if (attributeSection != null)
						{
							attributeSection.AttributeTarget = "return";
							methodDeclaration2.Attributes.Add(attributeSection);
						}
						this.compilationUnit.AddChild(methodDeclaration2);
						return;
					}
					if (this.la.kind == 1)
					{
						this.lexer.NextToken();
						MethodDeclaration methodDeclaration2 = new MethodDeclaration
						{
							Name = name4,
							Modifier = m.Modifier,
							TypeReference = typeReference,
							Parameters = list,
							Attributes = attributes,
							StartLocation = m.GetDeclarationLocation(location7),
							EndLocation = endLocation5,
							Templates = templates,
							HandlesClause = handlesClause2,
							InterfaceImplementations = interfaceImplementations4
						};
						if (attributeSection != null)
						{
							attributeSection.AttributeTarget = "return";
							methodDeclaration2.Attributes.Add(attributeSection);
						}
						this.compilationUnit.AddChild(methodDeclaration2);
						if (base.ParseMethodBodies)
						{
							this.Block(out statement);
							base.Expect(100);
							base.Expect(114);
						}
						else
						{
							this.lexer.SkipCurrentBlock(114);
							statement = new BlockStatement();
						}
						methodDeclaration2.Body = (BlockStatement)statement;
						methodDeclaration2.Body.StartLocation = methodDeclaration2.EndLocation;
						methodDeclaration2.Body.EndLocation = this.t.EndLocation;
						this.EndOfStmt();
						return;
					}
					base.SynErr(240);
					return;
				}
				default:
					if (kind == 120)
					{
						goto IL_CA2;
					}
					switch (kind)
					{
					case 126:
					case 130:
						goto IL_CA2;
					case 127:
					case 128:
						goto IL_1434;
					case 129:
						break;
					default:
						goto IL_1434;
					}
					break;
				}
			}
			IL_237:
			this.NonModuleDeclaration(m, attributes);
			return;
			IL_CA2:
			m.Check(Modifiers.Fields);
			FieldDeclaration fieldDeclaration2 = new FieldDeclaration(attributes, null, m.Modifier);
			this.IdentifierForFieldDeclaration();
			string val4 = this.t.val;
			fieldDeclaration2.StartLocation = m.GetDeclarationLocation(this.t.Location);
			this.VariableDeclaratorPartAfterIdentifier(list2, val4);
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.VariableDeclarator(list2);
			}
			this.EndOfStmt();
			fieldDeclaration2.EndLocation = this.t.EndLocation;
			fieldDeclaration2.Fields = list2;
			this.compilationUnit.AddChild(fieldDeclaration2);
			return;
			IL_1434:
			base.SynErr(244);
		}

		protected override void SynErr(int line, int col, int errorNumber)
		{
			string msg;
			switch (errorNumber)
			{
			case 0:
				msg = "EOF expected";
				break;
			case 1:
				msg = "EOL expected";
				break;
			case 2:
				msg = "ident expected";
				break;
			case 3:
				msg = "LiteralString expected";
				break;
			case 4:
				msg = "LiteralCharacter expected";
				break;
			case 5:
				msg = "LiteralInteger expected";
				break;
			case 6:
				msg = "LiteralDouble expected";
				break;
			case 7:
				msg = "LiteralSingle expected";
				break;
			case 8:
				msg = "LiteralDecimal expected";
				break;
			case 9:
				msg = "LiteralDate expected";
				break;
			case 10:
				msg = "\"=\" expected";
				break;
			case 11:
				msg = "\":\" expected";
				break;
			case 12:
				msg = "\",\" expected";
				break;
			case 13:
				msg = "\"&\" expected";
				break;
			case 14:
				msg = "\"/\" expected";
				break;
			case 15:
				msg = "\"\\\\\" expected";
				break;
			case 16:
				msg = "\".\" expected";
				break;
			case 17:
				msg = "\"!\" expected";
				break;
			case 18:
				msg = "\"-\" expected";
				break;
			case 19:
				msg = "\"+\" expected";
				break;
			case 20:
				msg = "\"^\" expected";
				break;
			case 21:
				msg = "\"?\" expected";
				break;
			case 22:
				msg = "\"*\" expected";
				break;
			case 23:
				msg = "\"{\" expected";
				break;
			case 24:
				msg = "\"}\" expected";
				break;
			case 25:
				msg = "\"(\" expected";
				break;
			case 26:
				msg = "\")\" expected";
				break;
			case 27:
				msg = "\">\" expected";
				break;
			case 28:
				msg = "\"<\" expected";
				break;
			case 29:
				msg = "\"<>\" expected";
				break;
			case 30:
				msg = "\">=\" expected";
				break;
			case 31:
				msg = "\"<=\" expected";
				break;
			case 32:
				msg = "\"<<\" expected";
				break;
			case 33:
				msg = "\">>\" expected";
				break;
			case 34:
				msg = "\"+=\" expected";
				break;
			case 35:
				msg = "\"^=\" expected";
				break;
			case 36:
				msg = "\"-=\" expected";
				break;
			case 37:
				msg = "\"*=\" expected";
				break;
			case 38:
				msg = "\"/=\" expected";
				break;
			case 39:
				msg = "\"\\\\=\" expected";
				break;
			case 40:
				msg = "\"<<=\" expected";
				break;
			case 41:
				msg = "\">>=\" expected";
				break;
			case 42:
				msg = "\"&=\" expected";
				break;
			case 43:
				msg = "\"AddHandler\" expected";
				break;
			case 44:
				msg = "\"AddressOf\" expected";
				break;
			case 45:
				msg = "\"Aggregate\" expected";
				break;
			case 46:
				msg = "\"Alias\" expected";
				break;
			case 47:
				msg = "\"And\" expected";
				break;
			case 48:
				msg = "\"AndAlso\" expected";
				break;
			case 49:
				msg = "\"Ansi\" expected";
				break;
			case 50:
				msg = "\"As\" expected";
				break;
			case 51:
				msg = "\"Ascending\" expected";
				break;
			case 52:
				msg = "\"Assembly\" expected";
				break;
			case 53:
				msg = "\"Auto\" expected";
				break;
			case 54:
				msg = "\"Binary\" expected";
				break;
			case 55:
				msg = "\"Boolean\" expected";
				break;
			case 56:
				msg = "\"ByRef\" expected";
				break;
			case 57:
				msg = "\"By\" expected";
				break;
			case 58:
				msg = "\"Byte\" expected";
				break;
			case 59:
				msg = "\"ByVal\" expected";
				break;
			case 60:
				msg = "\"Call\" expected";
				break;
			case 61:
				msg = "\"Case\" expected";
				break;
			case 62:
				msg = "\"Catch\" expected";
				break;
			case 63:
				msg = "\"CBool\" expected";
				break;
			case 64:
				msg = "\"CByte\" expected";
				break;
			case 65:
				msg = "\"CChar\" expected";
				break;
			case 66:
				msg = "\"CDate\" expected";
				break;
			case 67:
				msg = "\"CDbl\" expected";
				break;
			case 68:
				msg = "\"CDec\" expected";
				break;
			case 69:
				msg = "\"Char\" expected";
				break;
			case 70:
				msg = "\"CInt\" expected";
				break;
			case 71:
				msg = "\"Class\" expected";
				break;
			case 72:
				msg = "\"CLng\" expected";
				break;
			case 73:
				msg = "\"CObj\" expected";
				break;
			case 74:
				msg = "\"Compare\" expected";
				break;
			case 75:
				msg = "\"Const\" expected";
				break;
			case 76:
				msg = "\"Continue\" expected";
				break;
			case 77:
				msg = "\"CSByte\" expected";
				break;
			case 78:
				msg = "\"CShort\" expected";
				break;
			case 79:
				msg = "\"CSng\" expected";
				break;
			case 80:
				msg = "\"CStr\" expected";
				break;
			case 81:
				msg = "\"CType\" expected";
				break;
			case 82:
				msg = "\"CUInt\" expected";
				break;
			case 83:
				msg = "\"CULng\" expected";
				break;
			case 84:
				msg = "\"CUShort\" expected";
				break;
			case 85:
				msg = "\"Custom\" expected";
				break;
			case 86:
				msg = "\"Date\" expected";
				break;
			case 87:
				msg = "\"Decimal\" expected";
				break;
			case 88:
				msg = "\"Declare\" expected";
				break;
			case 89:
				msg = "\"Default\" expected";
				break;
			case 90:
				msg = "\"Delegate\" expected";
				break;
			case 91:
				msg = "\"Descending\" expected";
				break;
			case 92:
				msg = "\"Dim\" expected";
				break;
			case 93:
				msg = "\"DirectCast\" expected";
				break;
			case 94:
				msg = "\"Distinct\" expected";
				break;
			case 95:
				msg = "\"Do\" expected";
				break;
			case 96:
				msg = "\"Double\" expected";
				break;
			case 97:
				msg = "\"Each\" expected";
				break;
			case 98:
				msg = "\"Else\" expected";
				break;
			case 99:
				msg = "\"ElseIf\" expected";
				break;
			case 100:
				msg = "\"End\" expected";
				break;
			case 101:
				msg = "\"EndIf\" expected";
				break;
			case 102:
				msg = "\"Enum\" expected";
				break;
			case 103:
				msg = "\"Equals\" expected";
				break;
			case 104:
				msg = "\"Erase\" expected";
				break;
			case 105:
				msg = "\"Error\" expected";
				break;
			case 106:
				msg = "\"Event\" expected";
				break;
			case 107:
				msg = "\"Exit\" expected";
				break;
			case 108:
				msg = "\"Explicit\" expected";
				break;
			case 109:
				msg = "\"False\" expected";
				break;
			case 110:
				msg = "\"Finally\" expected";
				break;
			case 111:
				msg = "\"For\" expected";
				break;
			case 112:
				msg = "\"Friend\" expected";
				break;
			case 113:
				msg = "\"From\" expected";
				break;
			case 114:
				msg = "\"Function\" expected";
				break;
			case 115:
				msg = "\"Get\" expected";
				break;
			case 116:
				msg = "\"GetType\" expected";
				break;
			case 117:
				msg = "\"Global\" expected";
				break;
			case 118:
				msg = "\"GoSub\" expected";
				break;
			case 119:
				msg = "\"GoTo\" expected";
				break;
			case 120:
				msg = "\"Group\" expected";
				break;
			case 121:
				msg = "\"Handles\" expected";
				break;
			case 122:
				msg = "\"If\" expected";
				break;
			case 123:
				msg = "\"Implements\" expected";
				break;
			case 124:
				msg = "\"Imports\" expected";
				break;
			case 125:
				msg = "\"In\" expected";
				break;
			case 126:
				msg = "\"Infer\" expected";
				break;
			case 127:
				msg = "\"Inherits\" expected";
				break;
			case 128:
				msg = "\"Integer\" expected";
				break;
			case 129:
				msg = "\"Interface\" expected";
				break;
			case 130:
				msg = "\"Into\" expected";
				break;
			case 131:
				msg = "\"Is\" expected";
				break;
			case 132:
				msg = "\"IsNot\" expected";
				break;
			case 133:
				msg = "\"Join\" expected";
				break;
			case 134:
				msg = "\"Let\" expected";
				break;
			case 135:
				msg = "\"Lib\" expected";
				break;
			case 136:
				msg = "\"Like\" expected";
				break;
			case 137:
				msg = "\"Long\" expected";
				break;
			case 138:
				msg = "\"Loop\" expected";
				break;
			case 139:
				msg = "\"Me\" expected";
				break;
			case 140:
				msg = "\"Mod\" expected";
				break;
			case 141:
				msg = "\"Module\" expected";
				break;
			case 142:
				msg = "\"MustInherit\" expected";
				break;
			case 143:
				msg = "\"MustOverride\" expected";
				break;
			case 144:
				msg = "\"MyBase\" expected";
				break;
			case 145:
				msg = "\"MyClass\" expected";
				break;
			case 146:
				msg = "\"Namespace\" expected";
				break;
			case 147:
				msg = "\"Narrowing\" expected";
				break;
			case 148:
				msg = "\"New\" expected";
				break;
			case 149:
				msg = "\"Next\" expected";
				break;
			case 150:
				msg = "\"Not\" expected";
				break;
			case 151:
				msg = "\"Nothing\" expected";
				break;
			case 152:
				msg = "\"NotInheritable\" expected";
				break;
			case 153:
				msg = "\"NotOverridable\" expected";
				break;
			case 154:
				msg = "\"Object\" expected";
				break;
			case 155:
				msg = "\"Of\" expected";
				break;
			case 156:
				msg = "\"Off\" expected";
				break;
			case 157:
				msg = "\"On\" expected";
				break;
			case 158:
				msg = "\"Operator\" expected";
				break;
			case 159:
				msg = "\"Option\" expected";
				break;
			case 160:
				msg = "\"Optional\" expected";
				break;
			case 161:
				msg = "\"Or\" expected";
				break;
			case 162:
				msg = "\"Order\" expected";
				break;
			case 163:
				msg = "\"OrElse\" expected";
				break;
			case 164:
				msg = "\"Overloads\" expected";
				break;
			case 165:
				msg = "\"Overridable\" expected";
				break;
			case 166:
				msg = "\"Overrides\" expected";
				break;
			case 167:
				msg = "\"ParamArray\" expected";
				break;
			case 168:
				msg = "\"Partial\" expected";
				break;
			case 169:
				msg = "\"Preserve\" expected";
				break;
			case 170:
				msg = "\"Private\" expected";
				break;
			case 171:
				msg = "\"Property\" expected";
				break;
			case 172:
				msg = "\"Protected\" expected";
				break;
			case 173:
				msg = "\"Public\" expected";
				break;
			case 174:
				msg = "\"RaiseEvent\" expected";
				break;
			case 175:
				msg = "\"ReadOnly\" expected";
				break;
			case 176:
				msg = "\"ReDim\" expected";
				break;
			case 177:
				msg = "\"Rem\" expected";
				break;
			case 178:
				msg = "\"RemoveHandler\" expected";
				break;
			case 179:
				msg = "\"Resume\" expected";
				break;
			case 180:
				msg = "\"Return\" expected";
				break;
			case 181:
				msg = "\"SByte\" expected";
				break;
			case 182:
				msg = "\"Select\" expected";
				break;
			case 183:
				msg = "\"Set\" expected";
				break;
			case 184:
				msg = "\"Shadows\" expected";
				break;
			case 185:
				msg = "\"Shared\" expected";
				break;
			case 186:
				msg = "\"Short\" expected";
				break;
			case 187:
				msg = "\"Single\" expected";
				break;
			case 188:
				msg = "\"Skip\" expected";
				break;
			case 189:
				msg = "\"Static\" expected";
				break;
			case 190:
				msg = "\"Step\" expected";
				break;
			case 191:
				msg = "\"Stop\" expected";
				break;
			case 192:
				msg = "\"Strict\" expected";
				break;
			case 193:
				msg = "\"String\" expected";
				break;
			case 194:
				msg = "\"Structure\" expected";
				break;
			case 195:
				msg = "\"Sub\" expected";
				break;
			case 196:
				msg = "\"SyncLock\" expected";
				break;
			case 197:
				msg = "\"Take\" expected";
				break;
			case 198:
				msg = "\"Text\" expected";
				break;
			case 199:
				msg = "\"Then\" expected";
				break;
			case 200:
				msg = "\"Throw\" expected";
				break;
			case 201:
				msg = "\"To\" expected";
				break;
			case 202:
				msg = "\"True\" expected";
				break;
			case 203:
				msg = "\"Try\" expected";
				break;
			case 204:
				msg = "\"TryCast\" expected";
				break;
			case 205:
				msg = "\"TypeOf\" expected";
				break;
			case 206:
				msg = "\"UInteger\" expected";
				break;
			case 207:
				msg = "\"ULong\" expected";
				break;
			case 208:
				msg = "\"Unicode\" expected";
				break;
			case 209:
				msg = "\"Until\" expected";
				break;
			case 210:
				msg = "\"UShort\" expected";
				break;
			case 211:
				msg = "\"Using\" expected";
				break;
			case 212:
				msg = "\"Variant\" expected";
				break;
			case 213:
				msg = "\"Wend\" expected";
				break;
			case 214:
				msg = "\"When\" expected";
				break;
			case 215:
				msg = "\"Where\" expected";
				break;
			case 216:
				msg = "\"While\" expected";
				break;
			case 217:
				msg = "\"Widening\" expected";
				break;
			case 218:
				msg = "\"With\" expected";
				break;
			case 219:
				msg = "\"WithEvents\" expected";
				break;
			case 220:
				msg = "\"WriteOnly\" expected";
				break;
			case 221:
				msg = "\"Xor\" expected";
				break;
			case 222:
				msg = "??? expected";
				break;
			case 223:
				msg = "invalid EndOfStmt";
				break;
			case 224:
				msg = "invalid OptionStmt";
				break;
			case 225:
				msg = "invalid OptionStmt";
				break;
			case 226:
				msg = "invalid GlobalAttributeSection";
				break;
			case 227:
				msg = "invalid GlobalAttributeSection";
				break;
			case 228:
				msg = "invalid NamespaceMemberDecl";
				break;
			case 229:
				msg = "invalid OptionValue";
				break;
			case 230:
				msg = "invalid TypeModifier";
				break;
			case 231:
				msg = "invalid NonModuleDeclaration";
				break;
			case 232:
				msg = "invalid NonModuleDeclaration";
				break;
			case 233:
				msg = "invalid Identifier";
				break;
			case 234:
				msg = "invalid TypeParameterConstraints";
				break;
			case 235:
				msg = "invalid TypeParameterConstraint";
				break;
			case 236:
				msg = "invalid NonArrayTypeName";
				break;
			case 237:
				msg = "invalid MemberModifier";
				break;
			case 238:
				msg = "invalid StructureMemberDecl";
				break;
			case 239:
				msg = "invalid StructureMemberDecl";
				break;
			case 240:
				msg = "invalid StructureMemberDecl";
				break;
			case 241:
				msg = "invalid StructureMemberDecl";
				break;
			case 242:
				msg = "invalid StructureMemberDecl";
				break;
			case 243:
				msg = "invalid StructureMemberDecl";
				break;
			case 244:
				msg = "invalid StructureMemberDecl";
				break;
			case 245:
				msg = "invalid InterfaceMemberDecl";
				break;
			case 246:
				msg = "invalid InterfaceMemberDecl";
				break;
			case 247:
				msg = "invalid Expr";
				break;
			case 248:
				msg = "invalid Charset";
				break;
			case 249:
				msg = "invalid IdentifierForFieldDeclaration";
				break;
			case 250:
				msg = "invalid VariableDeclaratorPartAfterIdentifier";
				break;
			case 251:
				msg = "invalid AccessorDecls";
				break;
			case 252:
				msg = "invalid EventAccessorDeclaration";
				break;
			case 253:
				msg = "invalid OverloadableOperator";
				break;
			case 254:
				msg = "invalid VariableInitializer";
				break;
			case 255:
				msg = "invalid EventMemberSpecifier";
				break;
			case 256:
				msg = "invalid AssignmentOperator";
				break;
			case 257:
				msg = "invalid SimpleNonInvocationExpression";
				break;
			case 258:
				msg = "invalid SimpleNonInvocationExpression";
				break;
			case 259:
				msg = "invalid SimpleNonInvocationExpression";
				break;
			case 260:
				msg = "invalid SimpleNonInvocationExpression";
				break;
			case 261:
				msg = "invalid PrimitiveTypeName";
				break;
			case 262:
				msg = "invalid CastTarget";
				break;
			case 263:
				msg = "invalid ComparisonExpr";
				break;
			case 264:
				msg = "invalid FromOrAggregateQueryOperator";
				break;
			case 265:
				msg = "invalid QueryOperator";
				break;
			case 266:
				msg = "invalid PartitionQueryOperator";
				break;
			case 267:
				msg = "invalid Argument";
				break;
			case 268:
				msg = "invalid QualIdentAndTypeArguments";
				break;
			case 269:
				msg = "invalid AttributeArguments";
				break;
			case 270:
				msg = "invalid ParameterModifier";
				break;
			case 271:
				msg = "invalid Statement";
				break;
			case 272:
				msg = "invalid LabelName";
				break;
			case 273:
				msg = "invalid EmbeddedStatement";
				break;
			case 274:
				msg = "invalid EmbeddedStatement";
				break;
			case 275:
				msg = "invalid EmbeddedStatement";
				break;
			case 276:
				msg = "invalid EmbeddedStatement";
				break;
			case 277:
				msg = "invalid EmbeddedStatement";
				break;
			case 278:
				msg = "invalid EmbeddedStatement";
				break;
			case 279:
				msg = "invalid EmbeddedStatement";
				break;
			case 280:
				msg = "invalid WhileOrUntil";
				break;
			case 281:
				msg = "invalid SingleLineStatementList";
				break;
			case 282:
				msg = "invalid SingleLineStatementList";
				break;
			case 283:
				msg = "invalid OnErrorStatement";
				break;
			case 284:
				msg = "invalid ResumeStatement";
				break;
			case 285:
				msg = "invalid CaseClause";
				break;
			case 286:
				msg = "invalid CaseClause";
				break;
			default:
				msg = "error " + errorNumber;
				break;
			}
			base.Errors.Error(line, col, msg);
		}

		private void TryStatement(out Statement tryStatement)
		{
			Statement statementBlock = null;
			Statement finallyBlock = null;
			List<CatchClause> catchClauses = null;
			base.Expect(203);
			this.EndOfStmt();
			this.Block(out statementBlock);
			if (this.la.kind == 62 || this.la.kind == 100 || this.la.kind == 110)
			{
				this.CatchClauses(out catchClauses);
			}
			if (this.la.kind == 110)
			{
				this.lexer.NextToken();
				this.EndOfStmt();
				this.Block(out finallyBlock);
			}
			base.Expect(100);
			base.Expect(203);
			tryStatement = new TryCatchStatement(statementBlock, catchClauses, finallyBlock);
		}

		private void TypeArgumentList(List<TypeReference> typeArguments)
		{
			TypeReference typeReference;
			this.TypeName(out typeReference);
			if (typeReference != null)
			{
				typeArguments.Add(typeReference);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
				if (typeReference != null)
				{
					typeArguments.Add(typeReference);
				}
			}
		}

		private void TypeImplementsClause(out List<TypeReference> baseInterfaces)
		{
			baseInterfaces = new List<TypeReference>();
			TypeReference typeReference = null;
			base.Expect(123);
			this.TypeName(out typeReference);
			if (typeReference != null)
			{
				baseInterfaces.Add(typeReference);
			}
			while (this.la.kind == 12)
			{
				this.lexer.NextToken();
				this.TypeName(out typeReference);
				if (typeReference != null)
				{
					baseInterfaces.Add(typeReference);
				}
			}
			this.EndOfStmt();
		}

		private void TypeModifier(ModifierList m)
		{
			int kind = this.la.kind;
			if (kind <= 142)
			{
				if (kind == 112)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Internal, this.t.Location);
					return;
				}
				if (kind == 142)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Dim, this.t.Location);
					return;
				}
			}
			else
			{
				if (kind == 152)
				{
					this.lexer.NextToken();
					m.Add(Modifiers.Sealed, this.t.Location);
					return;
				}
				switch (kind)
				{
				case 168:
					this.lexer.NextToken();
					m.Add(Modifiers.Partial, this.t.Location);
					return;
				case 169:
				case 171:
					break;
				case 170:
					this.lexer.NextToken();
					m.Add(Modifiers.Private, this.t.Location);
					return;
				case 172:
					this.lexer.NextToken();
					m.Add(Modifiers.Protected, this.t.Location);
					return;
				case 173:
					this.lexer.NextToken();
					m.Add(Modifiers.Public, this.t.Location);
					return;
				default:
					switch (kind)
					{
					case 184:
						this.lexer.NextToken();
						m.Add(Modifiers.New, this.t.Location);
						return;
					case 185:
						this.lexer.NextToken();
						m.Add(Modifiers.Static, this.t.Location);
						return;
					}
					break;
				}
			}
			base.SynErr(230);
		}

		private void TypeName(out TypeReference typeref)
		{
			ArrayList arrayList = null;
			this.NonArrayTypeName(out typeref, false);
			this.ArrayTypeModifiers(out arrayList);
			if (arrayList != null && typeref != null)
			{
				typeref.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
			}
		}

		private void TypeParameter(out TemplateDefinition template)
		{
			this.Identifier();
			template = new TemplateDefinition(this.t.val, null);
			if (this.la.kind == 50)
			{
				this.TypeParameterConstraints(template);
			}
		}

		private void TypeParameterConstraint(out TypeReference constraint)
		{
			constraint = null;
			if (this.la.kind == 71)
			{
				this.lexer.NextToken();
				constraint = TypeReference.ClassConstraint;
				return;
			}
			if (this.la.kind == 194)
			{
				this.lexer.NextToken();
				constraint = TypeReference.StructConstraint;
				return;
			}
			if (this.la.kind == 148)
			{
				this.lexer.NextToken();
				constraint = TypeReference.NewConstraint;
				return;
			}
			if (this.StartOf(7))
			{
				this.TypeName(out constraint);
				return;
			}
			base.SynErr(235);
		}

		private void TypeParameterConstraints(TemplateDefinition template)
		{
			base.Expect(50);
			if (this.la.kind == 23)
			{
				this.lexer.NextToken();
				TypeReference typeReference;
				this.TypeParameterConstraint(out typeReference);
				if (typeReference != null)
				{
					template.Bases.Add(typeReference);
				}
				while (this.la.kind == 12)
				{
					this.lexer.NextToken();
					this.TypeParameterConstraint(out typeReference);
					if (typeReference != null)
					{
						template.Bases.Add(typeReference);
					}
				}
				base.Expect(24);
				return;
			}
			if (this.StartOf(6))
			{
				TypeReference typeReference;
				this.TypeParameterConstraint(out typeReference);
				if (typeReference != null)
				{
					template.Bases.Add(typeReference);
					return;
				}
			}
			else
			{
				base.SynErr(234);
			}
		}

		private void TypeParameterList(List<TemplateDefinition> templates)
		{
			if (this.la.kind == 25 && this.Peek(1).kind == 155)
			{
				this.lexer.NextToken();
				base.Expect(155);
				TemplateDefinition templateDefinition;
				this.TypeParameter(out templateDefinition);
				if (templateDefinition != null)
				{
					templates.Add(templateDefinition);
				}
				while (this.la.kind == 12)
				{
					this.lexer.NextToken();
					this.TypeParameter(out templateDefinition);
					if (templateDefinition != null)
					{
						templates.Add(templateDefinition);
					}
				}
				base.Expect(26);
			}
		}

		private void UnaryExpr(out Expression uExpr)
		{
			UnaryOperatorType op = UnaryOperatorType.None;
			bool flag = false;
			while (this.la.kind == 18 || this.la.kind == 19 || this.la.kind == 22)
			{
				if (this.la.kind == 19)
				{
					this.lexer.NextToken();
					op = UnaryOperatorType.Plus;
					flag = true;
				}
				else if (this.la.kind == 18)
				{
					this.lexer.NextToken();
					op = UnaryOperatorType.Minus;
					flag = true;
				}
				else
				{
					this.lexer.NextToken();
					op = UnaryOperatorType.Dereference;
					flag = true;
				}
			}
			Expression expression;
			this.ExponentiationExpr(out expression);
			if (flag)
			{
				uExpr = new UnaryOperatorExpression(expression, op);
				return;
			}
			uExpr = expression;
		}

		private void VariableDeclarator(List<VariableDeclaration> fieldDeclaration)
		{
			this.Identifier();
			string val = this.t.val;
			this.VariableDeclaratorPartAfterIdentifier(fieldDeclaration, val);
		}

		private void VariableDeclaratorPartAfterIdentifier(List<VariableDeclaration> fieldDeclaration, string name)
		{
			Expression expression = null;
			TypeReference typeReference = null;
			ArrayList arrayList = null;
			List<Expression> list = null;
			Location location = this.t.Location;
			if (this.IsSize() && !this.IsDims())
			{
				this.ArrayInitializationModifier(out list);
			}
			if (this.IsDims())
			{
				this.ArrayNameModifier(out arrayList);
			}
			if (this.IsObjectCreation())
			{
				base.Expect(50);
				this.ObjectCreateExpression(out expression);
				if (expression is ObjectCreateExpression)
				{
					typeReference = ((ObjectCreateExpression)expression).CreateType.Clone();
				}
				else
				{
					typeReference = ((ArrayCreateExpression)expression).CreateType.Clone();
				}
			}
			else if (this.StartOf(23))
			{
				if (this.la.kind == 50)
				{
					this.lexer.NextToken();
					this.TypeName(out typeReference);
					if (typeReference != null)
					{
						for (int i = fieldDeclaration.Count - 1; i >= 0; i--)
						{
							VariableDeclaration variableDeclaration = fieldDeclaration[i];
							if (variableDeclaration.TypeReference.Type.Length > 0)
							{
								break;
							}
							TypeReference typeReference2 = typeReference.Clone();
							typeReference2.RankSpecifier = variableDeclaration.TypeReference.RankSpecifier;
							variableDeclaration.TypeReference = typeReference2;
						}
					}
				}
				if (typeReference == null && (list != null || arrayList != null))
				{
					typeReference = new TypeReference("");
				}
				if (list != null)
				{
					if (typeReference.RankSpecifier != null)
					{
						this.Error("array rank only allowed one time");
					}
					else
					{
						if (arrayList == null)
						{
							typeReference.RankSpecifier = new int[]
							{
								list.Count - 1
							};
						}
						else
						{
							arrayList.Insert(0, list.Count - 1);
							typeReference.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
						}
						expression = new ArrayCreateExpression(typeReference.Clone(), list);
					}
				}
				else if (arrayList != null)
				{
					if (typeReference.RankSpecifier != null)
					{
						this.Error("array rank only allowed one time");
					}
					else
					{
						typeReference.RankSpecifier = (int[])arrayList.ToArray(typeof(int));
					}
				}
				if (this.la.kind == 10)
				{
					this.lexer.NextToken();
					this.VariableInitializer(out expression);
				}
			}
			else
			{
				base.SynErr(250);
			}
			fieldDeclaration.Add(new VariableDeclaration(name, expression, typeReference)
			{
				StartLocation = location,
				EndLocation = this.t.Location
			});
		}

		private void VariableInitializer(out Expression initializerExpression)
		{
			initializerExpression = null;
			if (this.StartOf(29))
			{
				this.Expr(out initializerExpression);
				return;
			}
			if (this.la.kind == 23)
			{
				this.CollectionInitializer(out initializerExpression);
				return;
			}
			base.SynErr(254);
		}

		private void VBNET()
		{
			this.lexer.NextToken();
			this.compilationUnit = new CompilationUnit();
			while (this.la.kind == 1 || this.la.kind == 11)
			{
				this.EndOfStmt();
			}
			while (this.la.kind == 159)
			{
				this.OptionStmt();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			while (this.la.kind == 124)
			{
				this.ImportsStmt();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			while (this.IsGlobalAttrTarget())
			{
				this.GlobalAttributeSection();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			while (this.StartOf(1))
			{
				this.NamespaceMemberDecl();
				while (this.la.kind == 1 || this.la.kind == 11)
				{
					this.EndOfStmt();
				}
			}
			base.Expect(0);
		}

		private void WhereQueryOperator(List<QueryExpressionClause> middleClauses)
		{
			QueryExpressionWhereClause queryExpressionWhereClause = new QueryExpressionWhereClause();
			queryExpressionWhereClause.StartLocation = this.la.Location;
			Expression condition = null;
			base.Expect(215);
			this.Expr(out condition);
			queryExpressionWhereClause.Condition = condition;
			queryExpressionWhereClause.EndLocation = this.t.EndLocation;
			middleClauses.Add(queryExpressionWhereClause);
		}

		private void WhileOrUntil(out ConditionType conditionType)
		{
			conditionType = ConditionType.None;
			if (this.la.kind == 216)
			{
				this.lexer.NextToken();
				conditionType = ConditionType.While;
				return;
			}
			if (this.la.kind == 209)
			{
				this.lexer.NextToken();
				conditionType = ConditionType.Until;
				return;
			}
			base.SynErr(280);
		}

		private void WithStatement(out Statement withStatement)
		{
			Statement statement = null;
			Expression expression = null;
			base.Expect(218);
			Location location = this.t.Location;
			this.Expr(out expression);
			this.EndOfStmt();
			withStatement = new WithStatement(expression);
			withStatement.StartLocation = location;
			this.Block(out statement);
			((WithStatement)withStatement).Body = (BlockStatement)statement;
			base.Expect(100);
			base.Expect(218);
			withStatement.EndLocation = this.t.Location;
		}

		private bool WriteFullTypeName(StringBuilder b, Expression expr)
		{
			MemberReferenceExpression memberReferenceExpression = expr as MemberReferenceExpression;
			if (memberReferenceExpression != null)
			{
				bool result = this.WriteFullTypeName(b, memberReferenceExpression.TargetObject);
				if (b.Length > 0)
				{
					b.Append('.');
				}
				b.Append(memberReferenceExpression.MemberName);
				return result;
			}
			if (expr is IdentifierExpression)
			{
				b.Append(((IdentifierExpression)expr).Identifier);
				return true;
			}
			return false;
		}

		private Token la
		{
			[DebuggerStepThrough]
			get
			{
				return this.lexer.LookAhead;
			}
		}

		private Token t
		{
			[DebuggerStepThrough]
			get
			{
				return this.lexer.Token;
			}
		}

		private Lexer lexer;

		private const int maxT = 222;

		private StringBuilder qualidentBuilder = new StringBuilder();

		private static bool[,] set = new bool[,]
		{
			{
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				false,
				false,
				true,
				true,
				true,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				true,
				true,
				true,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				true,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			},
			{
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				true,
				true,
				true,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				true,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			}
		};

		private const bool T = true;

		private const bool x = false;
	}
}
