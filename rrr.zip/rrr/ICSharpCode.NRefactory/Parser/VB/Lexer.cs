﻿using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace ICSharpCode.NRefactory.Parser.VB
{
	internal sealed class Lexer : AbstractLexer
	{
		public Lexer(TextReader reader) : base(reader)
		{
		}

		protected override Token Next()
		{
			if (this.misreadExclamationMarkAsTypeCharacter)
			{
				this.misreadExclamationMarkAsTypeCharacter = false;
				return new Token(17, base.Col - 1, base.Line);
			}
			Location location;
			char c;
			int col;
			int line;
			string text;
			int token;
			int col2;
			int line2;
			Token token2;
			while (true)
			{
				location = new Location(base.Col, base.Line);
				int num = base.ReaderRead();
				if (num == -1)
				{
					break;
				}
				c = (char)num;
				if (char.IsWhiteSpace(c))
				{
					if (base.HandleLineEnd(c))
					{
						if (!this.lineEnd)
						{
							goto IL_74;
						}
						this.specialTracker.AddEndOfLine(location);
					}
				}
				else if (c == '_')
				{
					if (base.ReaderPeek() == -1)
					{
						goto Block_7;
					}
					if (!char.IsWhiteSpace((char)base.ReaderPeek()))
					{
						goto Block_8;
					}
					c = (char)base.ReaderRead();
					bool flag = this.lineEnd;
					this.lineEnd = false;
					while (char.IsWhiteSpace(c))
					{
						if (base.HandleLineEnd(c))
						{
							this.lineEnd = true;
							break;
						}
						if (base.ReaderPeek() == -1)
						{
							goto IL_155;
						}
						c = (char)base.ReaderRead();
					}
					if (!this.lineEnd)
					{
						this.errors.Error(base.Line, base.Col, string.Format("Return expected", new object[0]));
					}
					this.lineEnd = flag;
				}
				else if (c == '#')
				{
					while (char.IsWhiteSpace((char)base.ReaderPeek()))
					{
						base.ReaderRead();
					}
					if (char.IsDigit((char)base.ReaderPeek()))
					{
						goto Block_14;
					}
					this.ReadPreprocessorDirective();
				}
				else
				{
					if (c == '[')
					{
						goto Block_16;
					}
					if (char.IsLetter(c))
					{
						col = base.Col - 1;
						line = base.Line;
						char c2;
						text = this.ReadIdent(c, out c2);
						if (c2 != '\0')
						{
							goto IL_426;
						}
						token = Keywords.GetToken(text);
						if (token < 0)
						{
							goto IL_426;
						}
						if (token != 177)
						{
							goto IL_411;
						}
						this.ReadComment();
						if (!this.lineEnd)
						{
							goto Block_25;
						}
					}
					else
					{
						if (char.IsDigit(c))
						{
							goto Block_26;
						}
						if (c == '&')
						{
							goto Block_27;
						}
						if (c == '\'' || c == '‘' || c == '’')
						{
							col2 = base.Col - 1;
							line2 = base.Line;
							this.ReadComment();
							if (!this.lineEnd)
							{
								goto Block_32;
							}
						}
						else
						{
							if (c == '"')
							{
								goto Block_33;
							}
							token2 = this.ReadOperator(c);
							if (token2 != null)
							{
								goto Block_38;
							}
							this.errors.Error(base.Line, base.Col, string.Format("Unknown char({0}) which can't be read", c));
						}
					}
				}
			}
			return new Token(0);
			IL_74:
			this.lineEnd = true;
			return new Token(1, location, new Location(base.Col, base.Line), null, null, LiteralFormat.None);
			Block_7:
			this.errors.Error(base.Line, base.Col, string.Format("No EOF expected after _", new object[0]));
			return new Token(0);
			Block_8:
			int col3 = base.Col - 1;
			int line3 = base.Line;
			string val = this.ReadIdent('_');
			this.lineEnd = false;
			return new Token(2, col3, line3, val);
			IL_155:
			this.errors.Error(base.Line, base.Col, string.Format("No EOF expected after _", new object[0]));
			return new Token(0);
			Block_14:
			int x = base.Col - 1;
			int line4 = base.Line;
			string text2 = this.ReadDate();
			DateTime dateTime = new DateTime(1, 1, 1, 0, 0, 0);
			try
			{
				dateTime = DateTime.Parse(text2, CultureInfo.InvariantCulture, DateTimeStyles.NoCurrentDateDefault);
			}
			catch (Exception arg)
			{
				this.errors.Error(base.Line, base.Col, string.Format("Invalid date time {0}", arg));
			}
			return new Token(9, x, line4, text2, dateTime, LiteralFormat.DateTimeLiteral);
			Block_16:
			this.lineEnd = false;
			if (base.ReaderPeek() == -1)
			{
				this.errors.Error(base.Line, base.Col, string.Format("Identifier expected", new object[0]));
			}
			c = (char)base.ReaderRead();
			if (c == ']' || char.IsWhiteSpace(c))
			{
				this.errors.Error(base.Line, base.Col, string.Format("Identifier expected", new object[0]));
			}
			int col4 = base.Col - 1;
			int line5 = base.Line;
			string val2 = this.ReadIdent(c);
			if (base.ReaderPeek() == -1)
			{
				this.errors.Error(base.Line, base.Col, string.Format("']' expected", new object[0]));
			}
			c = (char)base.ReaderRead();
			if (c != ']')
			{
				this.errors.Error(base.Line, base.Col, string.Format("']' expected", new object[0]));
			}
			return new Token(2, col4, line5, val2);
			Block_25:
			this.lineEnd = true;
			return new Token(1, base.Col, base.Line, "\n");
			IL_411:
			this.lineEnd = false;
			return new Token(token, col, line, text);
			IL_426:
			this.lineEnd = false;
			return new Token(2, col, line, text);
			Block_26:
			this.lineEnd = false;
			return this.ReadDigit(c, base.Col - 1);
			Block_27:
			this.lineEnd = false;
			if (base.ReaderPeek() == -1)
			{
				return this.ReadOperator('&');
			}
			c = (char)base.ReaderPeek();
			if (char.ToUpper(c, CultureInfo.InvariantCulture) == 'H' || char.ToUpper(c, CultureInfo.InvariantCulture) == 'O')
			{
				return this.ReadDigit('&', base.Col - 1);
			}
			return this.ReadOperator('&');
			Block_32:
			this.lineEnd = true;
			return new Token(1, col2, line2, "\n");
			Block_33:
			this.lineEnd = false;
			int x2 = base.Col - 1;
			int line6 = base.Line;
			string text3 = this.ReadString();
			if (base.ReaderPeek() != -1 && (base.ReaderPeek() == 67 || base.ReaderPeek() == 99))
			{
				base.ReaderRead();
				if (text3.Length != 1)
				{
					this.errors.Error(base.Line, base.Col, string.Format("Chars can only have Length 1 ", new object[0]));
				}
				if (text3.Length == 0)
				{
					text3 = "\0";
				}
				return new Token(4, x2, line6, '"' + text3 + "\"C", text3[0], LiteralFormat.CharLiteral);
			}
			return new Token(3, x2, line6, '"' + text3 + '"', text3, LiteralFormat.StringLiteral);
			Block_38:
			this.lineEnd = false;
			return token2;
		}

		public override Token NextToken()
		{
			if (this.curToken == null)
			{
				this.curToken = this.Next();
				this.specialTracker.InformToken(this.curToken.kind);
				return this.curToken;
			}
			this.lastToken = this.curToken;
			if (this.curToken.next == null)
			{
				this.curToken.next = this.Next();
				this.specialTracker.InformToken(this.curToken.next.kind);
			}
			this.curToken = this.curToken.next;
			if (this.curToken.kind == 0 && this.lastToken.kind != 1)
			{
				this.curToken = new Token(1, this.curToken.col, this.curToken.line, "\n");
				this.specialTracker.InformToken(this.curToken.kind);
				this.curToken.next = new Token(0, this.curToken.col, this.curToken.line, "\n");
				this.specialTracker.InformToken(this.curToken.next.kind);
			}
			return this.curToken;
		}

		private char PeekUpperChar()
		{
			return char.ToUpper((char)base.ReaderPeek(), CultureInfo.InvariantCulture);
		}

		private void ReadComment()
		{
			Location startPosition = new Location(base.Col, base.Line);
			this.sb.Length = 0;
			StringBuilder stringBuilder = (this.specialCommentHash != null) ? new StringBuilder() : null;
			int num = 2;
			int num2;
			while ((num2 = base.ReaderRead()) != -1)
			{
				char c = (char)num2;
				if (base.HandleLineEnd(c))
				{
					break;
				}
				this.sb.Append(c);
				if (num > 0)
				{
					if (c == '\'' || c == '‘' || c == '’')
					{
						if (--num == 0)
						{
							this.specialTracker.StartComment(CommentType.Documentation, this.isAtLineBegin, startPosition);
							this.sb.Length = 0;
						}
					}
					else
					{
						this.specialTracker.StartComment(CommentType.SingleLine, this.isAtLineBegin, startPosition);
						num = 0;
					}
				}
				if (this.specialCommentHash != null)
				{
					if (char.IsLetter(c))
					{
						stringBuilder.Append(c);
					}
					else
					{
						string text = stringBuilder.ToString();
						stringBuilder.Length = 0;
						if (this.specialCommentHash.ContainsKey(text))
						{
							Location startPosition2 = new Location(base.Col, base.Line);
							string text2 = c + base.ReadToEndOfLine();
							base.TagComments.Add(new TagComment(text, text2, this.isAtLineBegin, startPosition2, new Location(base.Col, base.Line)));
							this.sb.Append(text2);
							break;
						}
					}
				}
			}
			if (num > 0)
			{
				this.specialTracker.StartComment(CommentType.SingleLine, this.isAtLineBegin, startPosition);
			}
			this.specialTracker.AddString(this.sb.ToString());
			this.specialTracker.FinishComment(new Location(base.Col, base.Line));
		}

		private string ReadDate()
		{
			char c = '\0';
			this.sb.Length = 0;
			int num;
			while ((num = base.ReaderRead()) != -1)
			{
				c = (char)num;
				if (c == '#')
				{
					break;
				}
				if (c == '\n')
				{
					this.errors.Error(base.Line, base.Col, string.Format("No return allowed inside Date literal", new object[0]));
				}
				else
				{
					this.sb.Append(c);
				}
			}
			if (c != '#')
			{
				this.errors.Error(base.Line, base.Col, string.Format("End of File reached before Date literal terminated", new object[0]));
			}
			return this.sb.ToString();
		}

		private Token ReadDigit(char ch, int x)
		{
			this.sb.Length = 0;
			this.sb.Append(ch);
			int line = base.Line;
			string text = "";
			if (ch != '&')
			{
				text += ch;
			}
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			bool flag5 = false;
			if (base.ReaderPeek() == -1)
			{
				if (ch == '&')
				{
					this.errors.Error(base.Line, base.Col, string.Format("digit expected", new object[0]));
				}
				return new Token(5, x, line, this.sb.ToString(), (int)(ch - '0'), LiteralFormat.DecimalNumber);
			}
			if (ch == '.')
			{
				if (char.IsDigit((char)base.ReaderPeek()))
				{
					flag4 = true;
					if (flag || flag2)
					{
						this.errors.Error(base.Line, base.Col, string.Format("No hexadecimal or oktadecimal floating point values allowed", new object[0]));
					}
					while (base.ReaderPeek() != -1)
					{
						if (!char.IsDigit((char)base.ReaderPeek()))
						{
							break;
						}
						text += (char)base.ReaderRead();
					}
				}
			}
			else if (ch == '&' && this.PeekUpperChar() == 'H')
			{
				this.sb.Append((char)base.ReaderRead());
				while (base.ReaderPeek() != -1 && "0123456789ABCDEF".IndexOf(this.PeekUpperChar()) != -1)
				{
					ch = (char)base.ReaderRead();
					this.sb.Append(ch);
					text += char.ToUpper(ch, CultureInfo.InvariantCulture);
				}
				flag = true;
			}
			else if (base.ReaderPeek() != -1 && ch == '&' && this.PeekUpperChar() == 'O')
			{
				this.sb.Append((char)base.ReaderRead());
				while (base.ReaderPeek() != -1 && "01234567".IndexOf(this.PeekUpperChar()) != -1)
				{
					ch = (char)base.ReaderRead();
					this.sb.Append(ch);
					text += char.ToUpper(ch, CultureInfo.InvariantCulture);
				}
				flag2 = true;
			}
			else
			{
				while (base.ReaderPeek() != -1 && char.IsDigit((char)base.ReaderPeek()))
				{
					ch = (char)base.ReaderRead();
					text += ch;
					this.sb.Append(ch);
				}
			}
			if (text.Length == 0)
			{
				this.errors.Error(base.Line, base.Col, string.Format("digit expected", new object[0]));
				return new Token(5, x, line, this.sb.ToString(), 0, LiteralFormat.DecimalNumber);
			}
			if ((base.ReaderPeek() != -1 && "%&SILU".IndexOf(this.PeekUpperChar()) != -1) || flag || flag2)
			{
				bool flag6 = false;
				if (base.ReaderPeek() != -1)
				{
					ch = (char)base.ReaderPeek();
					this.sb.Append(ch);
					ch = char.ToUpper(ch, CultureInfo.InvariantCulture);
					flag6 = (ch == 'U');
					if (flag6)
					{
						base.ReaderRead();
						ch = (char)base.ReaderPeek();
						this.sb.Append(ch);
						ch = char.ToUpper(ch, CultureInfo.InvariantCulture);
						if (ch != 'I' && ch != 'L' && ch != 'S')
						{
							this.errors.Error(base.Line, base.Col, "Invalid type character: U" + ch);
						}
					}
				}
				try
				{
					if (flag2)
					{
						base.ReaderRead();
						ulong num = 0uL;
						for (int i = 0; i < text.Length; i++)
						{
							num = num * 8uL + (ulong)text[i] - 48uL;
						}
						if (ch == 'S')
						{
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), (ushort)num, LiteralFormat.OctalNumber);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), (short)num, LiteralFormat.OctalNumber);
							return result;
						}
						else if (ch == '%' || ch == 'I')
						{
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), (uint)num, LiteralFormat.OctalNumber);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), (int)num, LiteralFormat.OctalNumber);
							return result;
						}
						else if (ch == '&' || ch == 'L')
						{
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), num, LiteralFormat.OctalNumber);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), (long)num, LiteralFormat.OctalNumber);
							return result;
						}
						else
						{
							Token result;
							if (num > (ulong)-1)
							{
								result = new Token(5, x, line, this.sb.ToString(), (long)num, LiteralFormat.OctalNumber);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), (int)num, LiteralFormat.OctalNumber);
							return result;
						}
					}
					else
					{
						LiteralFormat literalFormat = flag ? LiteralFormat.HexadecimalNumber : LiteralFormat.DecimalNumber;
						if (ch == 'S')
						{
							base.ReaderRead();
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), ushort.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), short.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
							return result;
						}
						else if (ch == '%' || ch == 'I')
						{
							base.ReaderRead();
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), uint.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), int.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
							return result;
						}
						else if (ch == '&' || ch == 'L')
						{
							base.ReaderRead();
							Token result;
							if (flag6)
							{
								result = new Token(5, x, line, this.sb.ToString(), ulong.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), long.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), literalFormat);
							return result;
						}
						else if (flag)
						{
							ulong num2 = ulong.Parse(text, NumberStyles.HexNumber);
							Token result;
							if (num2 > (ulong)-1)
							{
								result = new Token(5, x, line, this.sb.ToString(), (long)num2, literalFormat);
								return result;
							}
							result = new Token(5, x, line, this.sb.ToString(), (int)num2, literalFormat);
							return result;
						}
					}
				}
				catch (OverflowException ex)
				{
					this.errors.Error(base.Line, base.Col, ex.Message);
					Token result = new Token(5, x, line, this.sb.ToString(), 0, LiteralFormat.None);
					return result;
				}
			}
			Token next = null;
			if (!flag4 && base.ReaderPeek() == 46)
			{
				base.ReaderRead();
				if (base.ReaderPeek() != -1 && char.IsDigit((char)base.ReaderPeek()))
				{
					flag4 = true;
					if (flag || flag2)
					{
						this.errors.Error(base.Line, base.Col, string.Format("No hexadecimal or oktadecimal floating point values allowed", new object[0]));
					}
					text += '.';
					while (base.ReaderPeek() != -1)
					{
						if (!char.IsDigit((char)base.ReaderPeek()))
						{
							break;
						}
						text += (char)base.ReaderRead();
					}
				}
				else
				{
					next = new Token(16, base.Col - 1, base.Line);
				}
			}
			if (base.ReaderPeek() != -1 && this.PeekUpperChar() == 'E')
			{
				flag4 = true;
				text += (char)base.ReaderRead();
				if (base.ReaderPeek() != -1 && (base.ReaderPeek() == 45 || base.ReaderPeek() == 43))
				{
					text += (char)base.ReaderRead();
				}
				while (base.ReaderPeek() != -1 && char.IsDigit((char)base.ReaderPeek()))
				{
					text += (char)base.ReaderRead();
				}
			}
			if (base.ReaderPeek() != -1)
			{
				char c = this.PeekUpperChar();
				if (c <= '@')
				{
					switch (c)
					{
					case '!':
						goto IL_8A3;
					case '"':
						goto IL_8AD;
					case '#':
						break;
					default:
						if (c != '@')
						{
							goto IL_8AD;
						}
						goto IL_897;
					}
				}
				else
				{
					switch (c)
					{
					case 'D':
						goto IL_897;
					case 'E':
						goto IL_8AD;
					case 'F':
						goto IL_8A3;
					default:
						if (c != 'R')
						{
							goto IL_8AD;
						}
						break;
					}
				}
				base.ReaderRead();
				flag4 = true;
				goto IL_8AD;
				IL_897:
				base.ReaderRead();
				flag5 = true;
				goto IL_8AD;
				IL_8A3:
				base.ReaderRead();
				flag3 = true;
			}
			try
			{
				IL_8AD:
				if (flag3)
				{
					Token result = new Token(7, x, line, this.sb.ToString(), float.Parse(text, CultureInfo.InvariantCulture), LiteralFormat.DecimalNumber);
					return result;
				}
				if (flag5)
				{
					Token result = new Token(8, x, line, this.sb.ToString(), decimal.Parse(text, NumberStyles.Any, CultureInfo.InvariantCulture), LiteralFormat.DecimalNumber);
					return result;
				}
				if (flag4)
				{
					Token result = new Token(6, x, line, this.sb.ToString(), double.Parse(text, CultureInfo.InvariantCulture), LiteralFormat.DecimalNumber);
					return result;
				}
			}
			catch (FormatException)
			{
				this.errors.Error(base.Line, base.Col, string.Format("{0} is not a parseable number", text));
				if (flag3)
				{
					Token result = new Token(7, x, line, this.sb.ToString(), 0f, LiteralFormat.DecimalNumber);
					return result;
				}
				if (flag5)
				{
					Token result = new Token(8, x, line, this.sb.ToString(), 0m, LiteralFormat.DecimalNumber);
					return result;
				}
				if (flag4)
				{
					Token result = new Token(6, x, line, this.sb.ToString(), 0.0, LiteralFormat.DecimalNumber);
					return result;
				}
			}
			Token token;
			try
			{
				token = new Token(5, x, line, this.sb.ToString(), int.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), flag ? LiteralFormat.HexadecimalNumber : LiteralFormat.DecimalNumber);
			}
			catch (Exception)
			{
				try
				{
					token = new Token(5, x, line, this.sb.ToString(), long.Parse(text, flag ? NumberStyles.HexNumber : NumberStyles.Number), flag ? LiteralFormat.HexadecimalNumber : LiteralFormat.DecimalNumber);
				}
				catch (FormatException)
				{
					this.errors.Error(base.Line, base.Col, string.Format("{0} is not a parseable number", text));
					token = new Token(5, x, line, this.sb.ToString(), 0, LiteralFormat.DecimalNumber);
				}
				catch (OverflowException)
				{
					this.errors.Error(base.Line, base.Col, string.Format("{0} is too long for a integer literal", text));
					token = new Token(5, x, line, this.sb.ToString(), 0, LiteralFormat.DecimalNumber);
				}
			}
			token.next = next;
			return token;
		}

		private string ReadIdent(char ch)
		{
			char c;
			return this.ReadIdent(ch, out c);
		}

		private string ReadIdent(char ch, out char typeCharacter)
		{
			typeCharacter = '\0';
			this.sb.Length = 0;
			this.sb.Append(ch);
			int num;
			while ((num = base.ReaderPeek()) != -1 && (char.IsLetterOrDigit(ch = (char)num) || ch == '_'))
			{
				base.ReaderRead();
				this.sb.Append(ch.ToString());
			}
			if (num == -1)
			{
				return this.sb.ToString();
			}
			if ("%&@!#$".IndexOf((char)num) != -1)
			{
				typeCharacter = (char)num;
				base.ReaderRead();
				if (typeCharacter == '!')
				{
					num = base.ReaderPeek();
					if (num != -1 && (num == 95 || num == 91 || char.IsLetter((char)num)))
					{
						this.misreadExclamationMarkAsTypeCharacter = true;
					}
				}
			}
			return this.sb.ToString();
		}

		private Token ReadOperator(char ch)
		{
			int col = base.Col - 1;
			int line = base.Line;
			if (ch <= '?')
			{
				switch (ch)
				{
				case '!':
					return new Token(17, col, line);
				case '"':
				case '#':
				case '$':
				case '%':
				case '\'':
					break;
				case '&':
				{
					int num = base.ReaderPeek();
					if (num == 61)
					{
						base.ReaderRead();
						return new Token(42, col, line);
					}
					return new Token(13, col, line);
				}
				case '(':
					return new Token(25, col, line);
				case ')':
					return new Token(26, col, line);
				case '*':
				{
					int num2 = base.ReaderPeek();
					if (num2 == 61)
					{
						base.ReaderRead();
						return new Token(37, col, line);
					}
					return new Token(22, col, line, "*");
				}
				case '+':
				{
					int num3 = base.ReaderPeek();
					if (num3 == 61)
					{
						base.ReaderRead();
						return new Token(34, col, line);
					}
					return new Token(19, col, line);
				}
				case ',':
					return new Token(12, col, line);
				case '-':
				{
					int num4 = base.ReaderPeek();
					if (num4 == 61)
					{
						base.ReaderRead();
						return new Token(36, col, line);
					}
					return new Token(18, col, line);
				}
				case '.':
				{
					int num5 = base.ReaderPeek();
					if (num5 > 0 && char.IsDigit((char)num5))
					{
						return this.ReadDigit('.', base.Col);
					}
					return new Token(16, col, line);
				}
				case '/':
				{
					int num6 = base.ReaderPeek();
					if (num6 == 61)
					{
						base.ReaderRead();
						return new Token(38, col, line);
					}
					return new Token(14, col, line);
				}
				default:
					switch (ch)
					{
					case ':':
						return new Token(11, col, line);
					case '<':
						switch (base.ReaderPeek())
						{
						case 60:
						{
							base.ReaderRead();
							int num7 = base.ReaderPeek();
							if (num7 == 61)
							{
								base.ReaderRead();
								return new Token(40, col, line);
							}
							return new Token(32, col, line);
						}
						case 61:
							base.ReaderRead();
							return new Token(31, col, line);
						case 62:
							base.ReaderRead();
							return new Token(29, col, line);
						default:
							return new Token(28, col, line);
						}
						break;
					case '=':
						return new Token(10, col, line);
					case '>':
						switch (base.ReaderPeek())
						{
						case 61:
							base.ReaderRead();
							return new Token(30, col, line);
						case 62:
							base.ReaderRead();
							if (base.ReaderPeek() != -1)
							{
								int num8 = base.ReaderPeek();
								if (num8 == 61)
								{
									base.ReaderRead();
									return new Token(41, col, line);
								}
							}
							return new Token(33, col, line);
						default:
							return new Token(27, col, line);
						}
						break;
					case '?':
						return new Token(21, col, line);
					}
					break;
				}
			}
			else
			{
				switch (ch)
				{
				case '\\':
				{
					int num9 = base.ReaderPeek();
					if (num9 == 61)
					{
						base.ReaderRead();
						return new Token(39, col, line);
					}
					return new Token(15, col, line);
				}
				case ']':
					break;
				case '^':
				{
					int num10 = base.ReaderPeek();
					if (num10 == 61)
					{
						base.ReaderRead();
						return new Token(35, col, line);
					}
					return new Token(20, col, line);
				}
				default:
					switch (ch)
					{
					case '{':
						return new Token(23, col, line);
					case '}':
						return new Token(24, col, line);
					}
					break;
				}
			}
			return null;
		}

		private void ReadPreprocessorDirective()
		{
			Location start = new Location(base.Col - 1, base.Line);
			string text = this.ReadIdent('#');
			string text2 = base.ReadToEndOfLine();
			this.specialTracker.AddPreprocessingDirective(new PreprocessingDirective(text, text2.Trim(), start, new Location(start.Column + text.Length + text2.Length, start.Line)));
		}

		private string ReadString()
		{
			char c = '\0';
			this.sb.Length = 0;
			int num;
			while ((num = base.ReaderRead()) != -1)
			{
				c = (char)num;
				if (c == '"')
				{
					if (base.ReaderPeek() == -1 || base.ReaderPeek() != 34)
					{
						break;
					}
					this.sb.Append('"');
					base.ReaderRead();
				}
				else if (c == '\n')
				{
					this.errors.Error(base.Line, base.Col, string.Format("No return allowed inside String literal", new object[0]));
				}
				else
				{
					this.sb.Append(c);
				}
			}
			if (c != '"')
			{
				this.errors.Error(base.Line, base.Col, string.Format("End of File reached before String terminated ", new object[0]));
			}
			return this.sb.ToString();
		}

		public override void SkipCurrentBlock(int targetToken)
		{
			int num = -1;
			int kind = this.lastToken.kind;
			while (kind != 0 && (num != 100 || kind != targetToken))
			{
				num = kind;
				this.NextToken();
				kind = this.lastToken.kind;
			}
		}

		private bool isAtLineBegin;

		private bool lineEnd = true;

		private bool misreadExclamationMarkAsTypeCharacter;
	}
}
