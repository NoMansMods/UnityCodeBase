﻿using System;
using System.Collections.Generic;

namespace ICSharpCode.NRefactory.Parser
{
	public interface ILexer : IDisposable
	{
		Token NextToken();

		Token Peek();

		void SetConditionalCompilationSymbols(string symbols);

		void SkipCurrentBlock(int targetToken);

		void StartPeek();

		IDictionary<string, object> ConditionalCompilationSymbols
		{
			get;
		}

		Errors Errors
		{
			get;
		}

		bool EvaluateConditionalCompilation
		{
			get;
			set;
		}

		Token LookAhead
		{
			get;
		}

		bool SkipAllComments
		{
			get;
			set;
		}

		string[] SpecialCommentTags
		{
			get;
			set;
		}

		SpecialTracker SpecialTracker
		{
			get;
		}

		List<TagComment> TagComments
		{
			get;
		}

		Token Token
		{
			get;
		}
	}
}
