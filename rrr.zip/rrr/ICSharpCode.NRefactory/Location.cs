﻿using System;

namespace ICSharpCode.NRefactory
{
	public struct Location : IComparable<Location>, IEquatable<Location>
	{
		public Location(int column, int line)
		{
			this.x = column;
			this.y = line;
		}

		public int CompareTo(Location other)
		{
			if (this == other)
			{
				return 0;
			}
			if (this < other)
			{
				return -1;
			}
			return 1;
		}

		public override bool Equals(object obj)
		{
			return obj is Location && (Location)obj == this;
		}

		public bool Equals(Location other)
		{
			return this == other;
		}

		public override int GetHashCode()
		{
			return 87 * this.x.GetHashCode() ^ this.y.GetHashCode();
		}

		public static bool operator ==(Location a, Location b)
		{
			return a.x == b.x && a.y == b.y;
		}

		public static bool operator >(Location a, Location b)
		{
			return a.y > b.y || (a.y == b.y && a.x > b.x);
		}

		public static bool operator >=(Location a, Location b)
		{
			return !(a < b);
		}

		public static bool operator !=(Location a, Location b)
		{
			return a.x != b.x || a.y != b.y;
		}

		public static bool operator <(Location a, Location b)
		{
			return a.y < b.y || (a.y == b.y && a.x < b.x);
		}

		public static bool operator <=(Location a, Location b)
		{
			return !(a > b);
		}

		public override string ToString()
		{
			return string.Format("(Line {1}, Col {0})", this.x, this.y);
		}

		public int Column
		{
			get
			{
				return this.x;
			}
			set
			{
				this.x = value;
			}
		}

		public bool IsEmpty
		{
			get
			{
				return this.x <= 0 && this.y <= 0;
			}
		}

		public int Line
		{
			get
			{
				return this.y;
			}
			set
			{
				this.y = value;
			}
		}

		public int X
		{
			get
			{
				return this.x;
			}
			set
			{
				this.x = value;
			}
		}

		public int Y
		{
			get
			{
				return this.y;
			}
			set
			{
				this.y = value;
			}
		}

		public static readonly Location Empty = new Location(-1, -1);

		private int x;

		private int y;
	}
}
