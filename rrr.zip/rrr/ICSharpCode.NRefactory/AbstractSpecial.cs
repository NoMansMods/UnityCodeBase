﻿using System;

namespace ICSharpCode.NRefactory
{
	public abstract class AbstractSpecial : ISpecial
	{
		protected AbstractSpecial(Location position)
		{
			this.StartPosition = position;
			this.EndPosition = position;
		}

		protected AbstractSpecial(Location startPosition, Location endPosition)
		{
			this.StartPosition = startPosition;
			this.EndPosition = endPosition;
		}

		public abstract object AcceptVisitor(ISpecialVisitor visitor, object data);

		public override string ToString()
		{
			return string.Format("[{0}: Start = {1}, End = {2}]", base.GetType().Name, this.StartPosition, this.EndPosition);
		}

		public Location EndPosition
		{
			get;
			set;
		}

		public Location StartPosition
		{
			get;
			set;
		}
	}
}
