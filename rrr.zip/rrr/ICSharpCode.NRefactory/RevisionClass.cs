﻿using System;

internal static class RevisionClass
{
	public const string Build = "1";

	public const string FullVersion = "3.2.1.6466";

	public const string MainVersion = "3.2";

	public const string Major = "3";

	public const string Minor = "2";

	public const string Revision = "6466";
}
