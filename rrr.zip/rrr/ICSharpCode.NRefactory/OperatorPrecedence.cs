﻿using System;
using System.Collections.Generic;
using ICSharpCode.NRefactory.Ast;

namespace ICSharpCode.NRefactory
{
	internal static class OperatorPrecedence
	{
		public static int ComparePrecedenceCSharp(BinaryOperatorType op1, BinaryOperatorType op2)
		{
			int operatorPrecedence = OperatorPrecedence.GetOperatorPrecedence(OperatorPrecedence.csharpDict, op1);
			int operatorPrecedence2 = OperatorPrecedence.GetOperatorPrecedence(OperatorPrecedence.csharpDict, op2);
			return operatorPrecedence.CompareTo(operatorPrecedence2);
		}

		public static int ComparePrecedenceVB(BinaryOperatorType op1, BinaryOperatorType op2)
		{
			int operatorPrecedence = OperatorPrecedence.GetOperatorPrecedence(OperatorPrecedence.vbDict, op1);
			int operatorPrecedence2 = OperatorPrecedence.GetOperatorPrecedence(OperatorPrecedence.vbDict, op2);
			return operatorPrecedence.CompareTo(operatorPrecedence2);
		}

		private static int GetOperatorPrecedence(Dictionary<BinaryOperatorType, int> dict, BinaryOperatorType op)
		{
			int result;
			dict.TryGetValue(op, out result);
			return result;
		}

		private static Dictionary<BinaryOperatorType, int> MakePrecedenceTable(params BinaryOperatorType[][] input)
		{
			Dictionary<BinaryOperatorType, int> dictionary = new Dictionary<BinaryOperatorType, int>();
			for (int i = 0; i < input.Length; i++)
			{
				BinaryOperatorType[] array = input[i];
				for (int j = 0; j < array.Length; j++)
				{
					BinaryOperatorType key = array[j];
					dictionary.Add(key, input.Length - i);
				}
			}
			return dictionary;
		}

		private static readonly Dictionary<BinaryOperatorType, int> csharpDict = OperatorPrecedence.MakePrecedenceTable(new BinaryOperatorType[][]
		{
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Multiply,
				BinaryOperatorType.Divide,
				BinaryOperatorType.Modulus
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Add,
				BinaryOperatorType.Subtract
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.ShiftLeft,
				BinaryOperatorType.ShiftRight
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.LessThan,
				BinaryOperatorType.LessThanOrEqual,
				BinaryOperatorType.GreaterThan,
				BinaryOperatorType.GreaterThanOrEqual
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Equality,
				BinaryOperatorType.InEquality
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.BitwiseAnd
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.ExclusiveOr
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.BitwiseOr
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.LogicalAnd,
				BinaryOperatorType.LogicalOr
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.NullCoalescing
			}
		});

		private static readonly Dictionary<BinaryOperatorType, int> vbDict = OperatorPrecedence.MakePrecedenceTable(new BinaryOperatorType[][]
		{
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Power
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Multiply,
				BinaryOperatorType.Divide
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.DivideInteger
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Modulus
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Add,
				BinaryOperatorType.Subtract
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Concat
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.ShiftLeft,
				BinaryOperatorType.ShiftRight
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.Equality,
				BinaryOperatorType.InEquality,
				BinaryOperatorType.LessThan,
				BinaryOperatorType.LessThanOrEqual,
				BinaryOperatorType.GreaterThan,
				BinaryOperatorType.GreaterThanOrEqual,
				BinaryOperatorType.ReferenceEquality,
				BinaryOperatorType.ReferenceInequality,
				BinaryOperatorType.Like
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.LogicalAnd,
				BinaryOperatorType.BitwiseAnd
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.LogicalOr,
				BinaryOperatorType.BitwiseOr
			},
			new BinaryOperatorType[]
			{
				BinaryOperatorType.ExclusiveOr
			}
		});
	}
}
