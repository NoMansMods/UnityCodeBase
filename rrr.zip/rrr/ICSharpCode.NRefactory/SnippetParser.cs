﻿using System;
using System.Collections.Generic;
using System.IO;
using ICSharpCode.NRefactory.Ast;
using ICSharpCode.NRefactory.Parser;

namespace ICSharpCode.NRefactory
{
	public class SnippetParser
	{
		public SnippetParser(SupportedLanguage language)
		{
			this.language = language;
		}

		public INode Parse(string code)
		{
			IParser parser = ParserFactory.CreateParser(this.language, new StringReader(code));
			parser.Parse();
			this.Errors = parser.Errors;
			this.Specials = parser.Lexer.SpecialTracker.RetrieveSpecials();
			this.SnippetType = SnippetType.CompilationUnit;
			INode node = parser.CompilationUnit;
			if (this.Errors.Count > 0)
			{
				if (this.language == SupportedLanguage.CSharp)
				{
					parser = ParserFactory.CreateParser(this.language, new StringReader(code + ";"));
				}
				else
				{
					parser = ParserFactory.CreateParser(this.language, new StringReader(code));
				}
				Expression expression = parser.ParseExpression();
				if (expression != null && parser.Errors.Count < this.Errors.Count)
				{
					this.Errors = parser.Errors;
					this.Specials = parser.Lexer.SpecialTracker.RetrieveSpecials();
					this.SnippetType = SnippetType.Expression;
					node = expression;
				}
			}
			if (this.Errors.Count > 0)
			{
				parser = ParserFactory.CreateParser(this.language, new StringReader(code));
				BlockStatement blockStatement = parser.ParseBlock();
				if (blockStatement != null && parser.Errors.Count < this.Errors.Count)
				{
					this.Errors = parser.Errors;
					this.Specials = parser.Lexer.SpecialTracker.RetrieveSpecials();
					this.SnippetType = SnippetType.Statements;
					node = blockStatement;
				}
			}
			if (this.Errors.Count > 0)
			{
				parser = ParserFactory.CreateParser(this.language, new StringReader(code));
				List<INode> list = parser.ParseTypeMembers();
				if (list != null && list.Count > 0 && parser.Errors.Count < this.Errors.Count)
				{
					this.Errors = parser.Errors;
					this.Specials = parser.Lexer.SpecialTracker.RetrieveSpecials();
					this.SnippetType = SnippetType.TypeMembers;
					node = new SnippetParser.NodeListNode(list);
					node.StartLocation = list[0].StartLocation;
					node.EndLocation = list[list.Count - 1].EndLocation;
				}
			}
			return node;
		}

		public Errors Errors
		{
			get;
			private set;
		}

		public SnippetType SnippetType
		{
			get;
			private set;
		}

		public List<ISpecial> Specials
		{
			get;
			private set;
		}

		private readonly SupportedLanguage language;

		private sealed class NodeListNode : INode
		{
			public NodeListNode(List<INode> nodes)
			{
				this.nodes = nodes;
			}

			public object AcceptChildren(IAstVisitor visitor, object data)
			{
				foreach (INode current in this.nodes)
				{
					current.AcceptVisitor(visitor, data);
				}
				return null;
			}

			public object AcceptVisitor(IAstVisitor visitor, object data)
			{
				return this.AcceptChildren(visitor, data);
			}

			public List<INode> Children
			{
				get
				{
					return this.nodes;
				}
			}

			public Location EndLocation
			{
				get;
				set;
			}

			public INode Parent
			{
				get
				{
					return null;
				}
				set
				{
					throw new NotSupportedException();
				}
			}

			public Location StartLocation
			{
				get;
				set;
			}

			public object UserData
			{
				get;
				set;
			}

			private List<INode> nodes;
		}
	}
}
