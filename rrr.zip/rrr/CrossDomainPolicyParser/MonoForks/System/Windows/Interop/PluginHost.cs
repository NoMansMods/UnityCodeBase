﻿using System;
using UnityEngine;

namespace MonoForks.System.Windows.Interop
{
	public class PluginHost
	{
		private static string GetRoot(Uri uri)
		{
			if ((uri.Scheme == "http" && uri.Port == 80) || (uri.Scheme == "https" && uri.Port == 443) || uri.Port == -1)
			{
				return string.Format("{0}://{1}", uri.Scheme, uri.DnsSafeHost);
			}
			return string.Format("{0}://{1}:{2}", uri.Scheme, uri.DnsSafeHost, uri.Port);
		}

		public static Uri RootUri
		{
			get
			{
				return new Uri(PluginHost.GetRoot(PluginHost.SourceUri));
			}
		}

		public static Uri SourceUri
		{
			get
			{
				return new Uri(UnityCrossDomainHelper.GetWebSecurityHostUri());
			}
		}
	}
}
