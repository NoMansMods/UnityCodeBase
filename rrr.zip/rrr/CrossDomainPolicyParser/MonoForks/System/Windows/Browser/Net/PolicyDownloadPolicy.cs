﻿using System;
using MonoForks.System.Net;

namespace MonoForks.System.Windows.Browser.Net
{
	internal sealed class PolicyDownloadPolicy : ICrossDomainPolicy
	{
		public bool IsAllowed(WebRequest request)
		{
			return PolicyDownloadPolicy.IsLocalPathPolicy(request.RequestUri);
		}

		public static bool IsLocalPathPolicy(Uri uri)
		{
			string localPath = uri.LocalPath;
			return string.CompareOrdinal(localPath, "/clientaccesspolicy.xml") == 0 || string.CompareOrdinal(localPath, "/crossdomain.xml") == 0;
		}
	}
}
