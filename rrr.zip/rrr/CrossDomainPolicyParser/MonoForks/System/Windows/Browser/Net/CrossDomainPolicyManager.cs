﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security;
using MonoForks.System.Windows.Interop;

namespace MonoForks.System.Windows.Browser.Net
{
	internal static class CrossDomainPolicyManager
	{
		private static void AddPolicy(Uri responseUri, ICrossDomainPolicy policy)
		{
			string root = CrossDomainPolicyManager.GetRoot(responseUri);
			try
			{
				CrossDomainPolicyManager.policies.Add(root, policy);
			}
			catch (ArgumentException)
			{
			}
		}

		public static ICrossDomainPolicy BuildFlashPolicy(bool statuscodeOK, Uri uri, Stream responsestream, Dictionary<string, string> responseheaders)
		{
			ICrossDomainPolicy crossDomainPolicy = null;
			if (statuscodeOK)
			{
				try
				{
					crossDomainPolicy = FlashCrossDomainPolicy.FromStream(responsestream);
				}
				catch (Exception ex)
				{
					Log.Msg(string.Format("BuildFlashPolicy caught an exception while parsing {0}: {1}", uri, ex.Message));
					throw;
				}
				if (crossDomainPolicy != null)
				{
					Log.Msg("crossdomain.xml was succesfully parsed");
					string text = null;
					responseheaders.TryGetValue("X-Permitted-Cross-Domain-Policies", out text);
					if (!string.IsNullOrEmpty(text))
					{
						(crossDomainPolicy as FlashCrossDomainPolicy).SiteControl = text;
					}
				}
			}
			if (crossDomainPolicy == null)
			{
				crossDomainPolicy = CrossDomainPolicyManager.no_access_policy;
			}
			CrossDomainPolicyManager.AddPolicy(uri, crossDomainPolicy);
			return crossDomainPolicy;
		}

		public static bool CheckSocketEndPoint(string connecting_to_ip, int port)
		{
			return CrossDomainPolicyManager.CheckSocketEndPoint(connecting_to_ip, port, 843);
		}

		public static bool CheckSocketEndPoint(string connecting_to_ip, int port, int policyport)
		{
			FlashCrossDomainPolicy flashCrossDomainPolicy = CrossDomainPolicyManager.FlashCrossDomainPolicyFor(connecting_to_ip, policyport, 3000);
			return flashCrossDomainPolicy.IsSocketConnectionAllowed(port);
		}

		public static void ClearCache()
		{
			CrossDomainPolicyManager.policies.Clear();
		}

		public static FlashCrossDomainPolicy FlashCrossDomainPolicyFor(string connecting_to_ip, int policyport, int timeout)
		{
			FlashCrossDomainPolicy result;
			if (CrossDomainPolicyManager.SocketPoliciesByIp.TryGetValue(connecting_to_ip, out result))
			{
				Log.Msg(string.Format("Policy for host {0} found in the cache.", connecting_to_ip));
				return result;
			}
			FlashCrossDomainPolicy result2;
			try
			{
				FlashCrossDomainPolicy flashCrossDomainPolicy = CrossDomainPolicyManager.RetrieveFlashCrossDomainPolicyFrom(connecting_to_ip, policyport, timeout);
				flashCrossDomainPolicy.PolicyPort = policyport;
				CrossDomainPolicyManager.SocketPoliciesByIp.Add(connecting_to_ip, flashCrossDomainPolicy);
				result2 = flashCrossDomainPolicy;
			}
			catch (Exception arg)
			{
				Log.Msg(string.Format("{0} caught an exception while checking endpoint {1}: {2}", typeof(CrossDomainPolicyManager).Name, connecting_to_ip, arg));
				result2 = FlashCrossDomainPolicy.DenyPolicy;
			}
			return result2;
		}

		public static ICrossDomainPolicy GetCachedWebPolicy(Uri uri)
		{
			if (SiteOfOriginPolicy.HasSameOrigin(uri, PluginHost.SourceUri))
			{
				return CrossDomainPolicyManager.site_of_origin_policy;
			}
			string text = string.Empty;
			if (!uri.IsDefaultPort)
			{
				text = ":" + uri.Port;
			}
			if (uri.ToString() == string.Concat(new string[]
			{
				uri.Scheme,
				"://",
				uri.Host,
				text,
				"/crossdomain.xml"
			}))
			{
				return CrossDomainPolicyManager.PolicyDownloadPolicy;
			}
			string root = CrossDomainPolicyManager.GetRoot(uri);
			ICrossDomainPolicy result = null;
			CrossDomainPolicyManager.policies.TryGetValue(root, out result);
			return result;
		}

		public static Uri GetFlashPolicyUri(Uri uri)
		{
			return new Uri(CrossDomainPolicyManager.GetRootUri(uri), "/crossdomain.xml");
		}

		public static string GetRoot(Uri uri)
		{
			if ((uri.Scheme == "http" && uri.Port == 80) || (uri.Scheme == "https" && uri.Port == 443) || uri.Port == -1)
			{
				return string.Format("{0}://{1}/", uri.Scheme, uri.DnsSafeHost);
			}
			return string.Format("{0}://{1}:{2}/", uri.Scheme, uri.DnsSafeHost, uri.Port);
		}

		private static Uri GetRootUri(Uri uri)
		{
			return new Uri(CrossDomainPolicyManager.GetRoot(uri));
		}

		public static Uri GetSilverlightPolicyUri(Uri uri)
		{
			return new Uri(CrossDomainPolicyManager.GetRootUri(uri), "/clientaccesspolicy.xml");
		}

		[SecuritySafeCritical]
		private static FlashCrossDomainPolicy RetrieveFlashCrossDomainPolicyFrom(string host, int port, int timeout)
		{
			Type type = Type.GetType("System.Net.Sockets.SocketPolicyClient, System");
			Stream stream = (Stream)type.InvokeMember("GetPolicyStreamForIP", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, null, new object[]
			{
				host,
				port,
				timeout
			});
			if (stream == null)
			{
				throw new Exception("got back null stream from getpolicystream");
			}
			return FlashCrossDomainPolicy.FromStream(stream);
		}

		public const string ClientAccessPolicyFile = "/clientaccesspolicy.xml";

		public const string CrossDomainFile = "/crossdomain.xml";

		private static ICrossDomainPolicy no_access_policy = new NoAccessPolicy();

		private static Dictionary<string, ICrossDomainPolicy> policies = new Dictionary<string, ICrossDomainPolicy>();

		internal static ICrossDomainPolicy PolicyDownloadPolicy = new PolicyDownloadPolicy();

		private const int PolicyPort = 843;

		private static ICrossDomainPolicy site_of_origin_policy = new SiteOfOriginPolicy();

		private static readonly Dictionary<string, FlashCrossDomainPolicy> SocketPoliciesByIp = new Dictionary<string, FlashCrossDomainPolicy>();

		private const int Timeout = 10000;
	}
}
