﻿using System;
using System.Collections.Generic;
using MonoForks.System.Net;
using MonoForks.System.Windows.Interop;

namespace MonoForks.System.Windows.Browser.Net
{
	internal abstract class BaseDomainPolicy : ICrossDomainPolicy
	{
		public bool IsAllowed(WebRequest request)
		{
			Dictionary<string, string>.KeyCollection keys = request.Headers.Keys;
			string[] array = new string[keys.Count];
			keys.CopyTo(array, 0);
			return this.IsAllowed(request.RequestUri, array);
		}

		public abstract bool IsAllowed(Uri uri, params string[] headerKeys);

		public static string ApplicationRoot
		{
			get
			{
				if (BaseDomainPolicy.root == null)
				{
					BaseDomainPolicy.root = CrossDomainPolicyManager.GetRoot(BaseDomainPolicy.ApplicationUri);
				}
				return BaseDomainPolicy.root;
			}
		}

		public static Uri ApplicationUri
		{
			get
			{
				return PluginHost.RootUri;
			}
		}

		private static string root;

		public class Headers
		{
			public bool IsAllowed(string[] headers)
			{
				if (this.AllowAllHeaders)
				{
					return true;
				}
				if (headers == null || headers.Length == 0)
				{
					return true;
				}
				for (int i = 0; i < headers.Length; i++)
				{
					string y = headers[i];
					bool flag = false;
					foreach (string current in this.list)
					{
						if (BaseDomainPolicy.Headers.pc.Equals(current, y))
						{
							flag = true;
						}
					}
					if (!flag)
					{
						return false;
					}
				}
				return true;
			}

			public void SetHeaders(string raw)
			{
				if (raw == "*")
				{
					this.AllowAllHeaders = true;
					this.list = null;
				}
				else if (raw != null)
				{
					string[] array = raw.Split(new char[]
					{
						','
					});
					this.list = new List<string>(array.Length + 1);
					this.list.Add("Content-Type");
					for (int i = 0; i < array.Length; i++)
					{
						string text = array[i].Trim();
						if (!string.IsNullOrEmpty(text))
						{
							this.list.Add(text);
						}
					}
				}
				else
				{
					this.AllowAllHeaders = false;
					this.list = new List<string>(1);
					this.list.Add("Content-Type");
				}
			}

			public bool AllowAllHeaders
			{
				get;
				private set;
			}

			private List<string> list;

			private static BaseDomainPolicy.Headers.PrefixComparer pc = new BaseDomainPolicy.Headers.PrefixComparer();

			private class PrefixComparer : IEqualityComparer<string>
			{
				public bool Equals(string x, string y)
				{
					int num = x.Length - 1;
					if (x.Length > 0 && x[num] == '*')
					{
						return string.Compare(x, 0, y, 0, num, StringComparison.OrdinalIgnoreCase) == 0;
					}
					return string.Compare(x, y, StringComparison.OrdinalIgnoreCase) == 0;
				}

				public int GetHashCode(string obj)
				{
					return (obj != null) ? obj.GetHashCode() : 0;
				}
			}
		}
	}
}
