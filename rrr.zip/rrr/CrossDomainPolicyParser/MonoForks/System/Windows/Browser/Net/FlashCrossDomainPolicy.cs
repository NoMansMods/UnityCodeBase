﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using MonoForks.Mono.Xml;

namespace MonoForks.System.Windows.Browser.Net
{
	internal class FlashCrossDomainPolicy : BaseDomainPolicy
	{
		public FlashCrossDomainPolicy()
		{
			this.AllowedAccesses = new List<FlashCrossDomainPolicy.AllowAccessFrom>();
			this.AllowedHttpRequestHeaders = new List<FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom>();
			this.PolicyPort = 843;
		}

		public static FlashCrossDomainPolicy FromStream(Stream originalStream)
		{
			Log.Msg("received policy");
			MemoryStream memoryStream = FlashCrossDomainPolicy.StripTrailing0(originalStream);
			if (memoryStream.Length == 0L)
			{
				throw new ArgumentException("Policy can't be constructed from empty stream.");
			}
			FlashCrossDomainPolicy flashCrossDomainPolicy = new FlashCrossDomainPolicy();
			FlashCrossDomainPolicy.Handler handler = new FlashCrossDomainPolicy.Handler(flashCrossDomainPolicy);
			FlashCrossDomainPolicy.Reader reader = new FlashCrossDomainPolicy.Reader(memoryStream);
			MiniParser miniParser = new MiniParser();
			miniParser.Parse(reader, handler);
			if (flashCrossDomainPolicy.AllowedHttpRequestHeaders.Count == 0)
			{
				FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom allowHttpRequestHeadersFrom = new FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom
				{
					Domain = "*",
					Secure = true
				};
				allowHttpRequestHeadersFrom.Headers.SetHeaders(null);
				flashCrossDomainPolicy.AllowedHttpRequestHeaders.Add(allowHttpRequestHeadersFrom);
			}
			Log.Msg("done parsing policy");
			return flashCrossDomainPolicy;
		}

		public override bool IsAllowed(Uri uri, string[] headerKeys)
		{
			string siteControl = this.SiteControl;
			if (siteControl != null)
			{
				if (FlashCrossDomainPolicy.<>f__switch$map0 == null)
				{
					FlashCrossDomainPolicy.<>f__switch$map0 = new Dictionary<string, int>(3)
					{
						{
							"all",
							0
						},
						{
							"master-only",
							0
						},
						{
							"by-ftp-filename",
							0
						}
					};
				}
				int num;
				if (FlashCrossDomainPolicy.<>f__switch$map0.TryGetValue(siteControl, out num))
				{
					if (num == 0)
					{
						bool flag = false;
						if (this.AllowedAccesses.Count > 0)
						{
							foreach (FlashCrossDomainPolicy.AllowAccessFrom current in this.AllowedAccesses)
							{
								if (current.IsAllowed(uri, headerKeys))
								{
									flag = true;
								}
							}
						}
						if (!flag)
						{
							Log.Msg("Rejected because there was no AllowedAcces entry in the crossdomain file allowing this request.");
							return false;
						}
						if (this.AllowedHttpRequestHeaders.Count > 0)
						{
							foreach (FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom current2 in this.AllowedHttpRequestHeaders)
							{
								if (current2.IsRejected(uri, headerKeys))
								{
									return false;
								}
							}
							return true;
						}
						return true;
					}
				}
			}
			Log.Msg("rejected because SiteControl does not have a valid value");
			return false;
		}

		public bool IsSocketConnectionAllowed(int port)
		{
			foreach (FlashCrossDomainPolicy.AllowAccessFrom current in this.AllowedAccesses)
			{
				if (current.IsSocketConnectionAllowed(port, this.PolicyPort))
				{
					return true;
				}
			}
			return false;
		}

		public static bool ReadBooleanAttribute(MiniParser.IAttrList attrs, string attribute)
		{
			string value = attrs.GetValue(attribute);
			if (value != null)
			{
				if (FlashCrossDomainPolicy.<>f__switch$map1 == null)
				{
					FlashCrossDomainPolicy.<>f__switch$map1 = new Dictionary<string, int>(2)
					{
						{
							"true",
							0
						},
						{
							"false",
							1
						}
					};
				}
				int num;
				if (FlashCrossDomainPolicy.<>f__switch$map1.TryGetValue(value, out num))
				{
					if (num == 0)
					{
						return true;
					}
					if (num == 1)
					{
						return false;
					}
				}
				throw new Exception("Invalid boolean attribute: " + attribute);
			}
			return true;
		}

		private static MemoryStream StripTrailing0(Stream stream)
		{
			MemoryStream memoryStream = new MemoryStream();
			while (true)
			{
				int num = stream.ReadByte();
				if (num == 0 || num == -1)
				{
					break;
				}
				memoryStream.WriteByte((byte)num);
			}
			memoryStream.Seek(0L, SeekOrigin.Begin);
			return memoryStream;
		}

		public List<FlashCrossDomainPolicy.AllowAccessFrom> AllowedAccesses
		{
			get;
			private set;
		}

		public List<FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom> AllowedHttpRequestHeaders
		{
			get;
			private set;
		}

		public int PolicyPort
		{
			get;
			set;
		}

		public string SiteControl
		{
			get
			{
				return (!string.IsNullOrEmpty(this.site_control)) ? this.site_control : "all";
			}
			set
			{
				this.site_control = value;
			}
		}

		public static FlashCrossDomainPolicy DenyPolicy = new FlashCrossDomainPolicy();

		private string site_control;

		public class AllowAccessFrom
		{
			public AllowAccessFrom()
			{
				this.Secure = true;
			}

			private bool CheckDomain(Uri uri)
			{
				Log.Msg("Checking request-host: " + uri.Host + " against valid domain: " + this.Domain);
				if (this.Domain == "*")
				{
					return true;
				}
				if (BaseDomainPolicy.ApplicationUri.Host == this.Domain)
				{
					return true;
				}
				if (this.Domain[0] != '*')
				{
					return false;
				}
				string value = this.Domain.Substring(1, this.Domain.Length - 1);
				return uri.Host.EndsWith(value);
			}

			public bool IsAllowed(Uri uri, string[] headerKeys)
			{
				Log.Msg("Checking if " + uri + " is a valid domain");
				if (!this.CheckDomain(uri))
				{
					return false;
				}
				if (!this.AllowAnyPort && this.ToPorts != null && Array.IndexOf<int>(this.ToPorts, uri.Port) < 0)
				{
					Log.Msg("requested port: " + uri.Port + " is not allowed by specified portrange");
					return false;
				}
				if (!this.Secure)
				{
					return true;
				}
				if (BaseDomainPolicy.ApplicationUri.Scheme == Uri.UriSchemeHttps)
				{
					return uri.Scheme == Uri.UriSchemeHttps;
				}
				Log.Msg("All requirements met, the request is approved");
				return true;
			}

			public bool IsSocketConnectionAllowed(int port, int policyport)
			{
				if (policyport > 1024 && port < 1024)
				{
					return false;
				}
				bool flag = false;
				if (this.AllowAnyPort)
				{
					flag = true;
				}
				if (this.ToPorts != null)
				{
					int[] toPorts = this.ToPorts;
					for (int i = 0; i < toPorts.Length; i++)
					{
						int num = toPorts[i];
						if (num == port)
						{
							flag = true;
						}
					}
					if (!flag)
					{
						return false;
					}
				}
				return this.Domain == "*";
			}

			public bool AllowAnyPort
			{
				get;
				set;
			}

			public string Domain
			{
				get;
				set;
			}

			public bool Secure
			{
				get;
				set;
			}

			public int[] ToPorts
			{
				get;
				set;
			}
		}

		public class AllowHttpRequestHeadersFrom
		{
			public AllowHttpRequestHeadersFrom()
			{
				this.Headers = new BaseDomainPolicy.Headers();
			}

			public bool IsRejected(Uri uri, string[] headerKeys)
			{
				return !this.Headers.IsAllowed(headerKeys) && (!this.Secure || !(BaseDomainPolicy.ApplicationUri.Scheme == Uri.UriSchemeHttps) || uri.Scheme == Uri.UriSchemeHttps);
			}

			public bool AllowAllHeaders
			{
				get;
				set;
			}

			public string Domain
			{
				get;
				set;
			}

			public BaseDomainPolicy.Headers Headers
			{
				get;
				private set;
			}

			public bool Secure
			{
				get;
				set;
			}
		}

		private class Handler : MiniParser.IHandler
		{
			public Handler(FlashCrossDomainPolicy cdp)
			{
				this.cdp = cdp;
			}

			public void OnChars(string ch)
			{
			}

			public void OnEndElement(string name)
			{
				this.stack.Pop();
				this.current = ((this.stack.Count <= 0) ? null : ((string)this.stack.Peek()));
			}

			public void OnEndParsing(MiniParser parser)
			{
			}

			public void OnStartElement(string name, MiniParser.IAttrList attrs)
			{
				Log.Msg("Parsing: " + name);
				if (this.current == null)
				{
					if (name != "cross-domain-policy")
					{
						throw new Exception("Expected root element to be <cross-domain-policy>. found " + name + " instead");
					}
				}
				else
				{
					if (!(this.current == "cross-domain-policy"))
					{
						throw new Exception("Invalid element " + name);
					}
					switch (name)
					{
					case "site-control":
						this.cdp.SiteControl = attrs.GetValue("permitted-cross-domain-policies");
						break;
					case "allow-access-from":
					{
						FlashCrossDomainPolicy.AllowAccessFrom allowAccessFrom = new FlashCrossDomainPolicy.AllowAccessFrom
						{
							Domain = attrs.GetValue("domain"),
							Secure = FlashCrossDomainPolicy.ReadBooleanAttribute(attrs, "secure")
						};
						string value = attrs.GetValue("to-ports");
						if (value == "*")
						{
							allowAccessFrom.AllowAnyPort = true;
						}
						else if (value != null)
						{
							ArrayList arrayList = new ArrayList();
							string[] array = value.Split(new char[]
							{
								','
							});
							string[] array2 = array;
							for (int i = 0; i < array2.Length; i++)
							{
								string text = array2[i];
								int num5;
								if (text.Contains("-"))
								{
									string[] array3 = text.Split(new char[]
									{
										'-'
									});
									if (array3.Length == 2)
									{
										int num2;
										if (int.TryParse(array3[0], out num2))
										{
											int num3;
											if (int.TryParse(array3[1], out num3))
											{
												for (int num4 = num2; num4 != num3; num4++)
												{
													arrayList.Add(num4);
												}
											}
										}
									}
								}
								else if (int.TryParse(text, out num5))
								{
									arrayList.Add(num5);
								}
							}
							allowAccessFrom.ToPorts = (int[])arrayList.ToArray(typeof(int));
						}
						this.cdp.AllowedAccesses.Add(allowAccessFrom);
						break;
					}
					case "allow-http-request-headers-from":
					{
						FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom allowHttpRequestHeadersFrom = new FlashCrossDomainPolicy.AllowHttpRequestHeadersFrom
						{
							Domain = attrs.GetValue("domain"),
							Secure = FlashCrossDomainPolicy.ReadBooleanAttribute(attrs, "secure")
						};
						allowHttpRequestHeadersFrom.Headers.SetHeaders(attrs.GetValue("headers"));
						this.cdp.AllowedHttpRequestHeaders.Add(allowHttpRequestHeadersFrom);
						break;
					}
					}
				}
				this.stack.Push(name);
				this.current = name;
				Log.Msg(name);
				int length = attrs.Length;
				for (int j = 0; j < length; j++)
				{
					Log.Msg("  " + attrs.GetName(j) + ": " + attrs.GetValue(j));
				}
			}

			public void OnStartParsing(MiniParser parser)
			{
			}

			private FlashCrossDomainPolicy cdp;

			private string current;

			private Stack stack = new Stack();
		}

		private class Reader : MiniParser.IReader
		{
			public Reader(Stream stream)
			{
				this.stream = stream;
			}

			public int Read()
			{
				return this.stream.ReadByte();
			}

			private Stream stream;
		}
	}
}
