﻿using System;

namespace MonoForks.System
{
	public enum UriHostNameType
	{
		Unknown,
		Basic,
		Dns,
		IPv4,
		IPv6
	}
}
