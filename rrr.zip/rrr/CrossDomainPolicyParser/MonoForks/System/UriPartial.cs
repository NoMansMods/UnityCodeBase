﻿using System;

namespace MonoForks.System
{
	public enum UriPartial
	{
		Scheme,
		Authority,
		Path
	}
}
