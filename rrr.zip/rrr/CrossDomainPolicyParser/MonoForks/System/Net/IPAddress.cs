﻿using System;
using System.Globalization;
using MonoForks.System.Net.Sockets;

namespace MonoForks.System.Net
{
	[Serializable]
	public class IPAddress
	{
		public IPAddress(long addr)
		{
			this.m_Address = addr;
			this.m_Family = AddressFamily.InterNetwork;
		}

		public IPAddress(byte[] address)
		{
			if (address == null)
			{
				throw new ArgumentNullException("address");
			}
			int num = address.Length;
			if (num != 16)
			{
				throw new ArgumentException("address");
			}
			if (num == 16)
			{
				this.m_Numbers = new ushort[8];
				Buffer.BlockCopy(address, 0, this.m_Numbers, 0, 16);
				this.m_Family = AddressFamily.InterNetworkV6;
				this.m_ScopeId = 0L;
			}
			else
			{
				this.m_Address = (long)((ulong)((ulong)address[3] << 24) + (ulong)((long)((long)address[2] << 16)) + (ulong)((long)((long)address[1] << 8)) + (ulong)((long)address[0]));
				this.m_Family = AddressFamily.InterNetwork;
			}
		}

		public IPAddress(byte[] address, long scopeId)
		{
			if (address == null)
			{
				throw new ArgumentNullException("address");
			}
			if (address.Length != 16)
			{
				throw new ArgumentException("address");
			}
			this.m_Numbers = new ushort[8];
			Buffer.BlockCopy(address, 0, this.m_Numbers, 0, 16);
			this.m_Family = AddressFamily.InterNetworkV6;
			this.m_ScopeId = scopeId;
		}

		internal IPAddress(ushort[] address, long scopeId)
		{
			this.m_Numbers = address;
			for (int i = 0; i < 8; i++)
			{
				this.m_Numbers[i] = (ushort)IPAddress.HostToNetworkOrder((short)this.m_Numbers[i]);
			}
			this.m_Family = AddressFamily.InterNetworkV6;
			this.m_ScopeId = scopeId;
		}

		public override bool Equals(object other)
		{
			if (!(other is IPAddress))
			{
				return false;
			}
			IPAddress iPAddress = other as IPAddress;
			if (this.AddressFamily != iPAddress.AddressFamily)
			{
				return false;
			}
			if (this.AddressFamily == AddressFamily.InterNetwork)
			{
				return this.m_Address == iPAddress.m_Address;
			}
			ushort[] numbers = iPAddress.m_Numbers;
			for (int i = 0; i < 8; i++)
			{
				if (this.m_Numbers[i] != numbers[i])
				{
					return false;
				}
			}
			return true;
		}

		public byte[] GetAddressBytes()
		{
			if (this.m_Family == AddressFamily.InterNetworkV6)
			{
				byte[] array = new byte[16];
				Buffer.BlockCopy(this.m_Numbers, 0, array, 0, 16);
				return array;
			}
			return new byte[]
			{
				(byte)(this.m_Address & 255L),
				(byte)(this.m_Address >> 8 & 255L),
				(byte)(this.m_Address >> 16 & 255L),
				(byte)(this.m_Address >> 24)
			};
		}

		public override int GetHashCode()
		{
			if (this.m_Family == AddressFamily.InterNetwork)
			{
				return (int)this.m_Address;
			}
			return IPAddress.Hash(((int)this.m_Numbers[0] << 16) + (int)this.m_Numbers[1], ((int)this.m_Numbers[2] << 16) + (int)this.m_Numbers[3], ((int)this.m_Numbers[4] << 16) + (int)this.m_Numbers[5], ((int)this.m_Numbers[6] << 16) + (int)this.m_Numbers[7]);
		}

		private static int Hash(int i, int j, int k, int l)
		{
			return i ^ (j << 13 | j >> 19) ^ (k << 26 | k >> 6) ^ (l << 7 | l >> 25);
		}

		public static short HostToNetworkOrder(short host)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return host;
			}
			return IPAddress.SwapShort(host);
		}

		public static int HostToNetworkOrder(int host)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return host;
			}
			return IPAddress.SwapInt(host);
		}

		public static long HostToNetworkOrder(long host)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return host;
			}
			return IPAddress.SwapLong(host);
		}

		public static bool IsLoopback(IPAddress addr)
		{
			if (addr.m_Family == AddressFamily.InterNetwork)
			{
				return (addr.m_Address & 255L) == 127L;
			}
			for (int i = 0; i < 6; i++)
			{
				if (addr.m_Numbers[i] != 0)
				{
					return false;
				}
			}
			return IPAddress.NetworkToHostOrder((short)addr.m_Numbers[7]) == 1;
		}

		public static short NetworkToHostOrder(short network)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return network;
			}
			return IPAddress.SwapShort(network);
		}

		public static int NetworkToHostOrder(int network)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return network;
			}
			return IPAddress.SwapInt(network);
		}

		public static long NetworkToHostOrder(long network)
		{
			if (!BitConverter.IsLittleEndian)
			{
				return network;
			}
			return IPAddress.SwapLong(network);
		}

		public static IPAddress Parse(string ipString)
		{
			IPAddress result;
			if (IPAddress.TryParse(ipString, out result))
			{
				return result;
			}
			throw new FormatException("An invalid IP address was specified.");
		}

		private static IPAddress ParseIPV4(string ip)
		{
			int num = ip.IndexOf(' ');
			if (num != -1)
			{
				ip = ip.Substring(0, num);
			}
			if (ip.Length == 0 || ip[ip.Length - 1] == '.')
			{
				return null;
			}
			string[] array = ip.Split(new char[]
			{
				'.'
			});
			if (array.Length > 4)
			{
				return null;
			}
			IPAddress result;
			try
			{
				long num2 = 0L;
				for (int i = 0; i < array.Length; i++)
				{
					string text = array[i];
					long num3;
					if (3 <= text.Length && text.Length <= 4 && text[0] == '0' && (text[1] == 'x' || text[1] == 'X'))
					{
						if (text.Length == 3)
						{
							num3 = (long)((byte)Uri.FromHex(text[2]));
						}
						else
						{
							num3 = (long)((byte)(Uri.FromHex(text[2]) << 4 | Uri.FromHex(text[3])));
						}
					}
					else
					{
						if (text.Length == 0)
						{
							result = null;
							return result;
						}
						if (text[0] == '0')
						{
							num3 = 0L;
							for (int j = 1; j < text.Length; j++)
							{
								if ('0' > text[j] || text[j] > '7')
								{
									result = null;
									return result;
								}
								num3 = (num3 << 3) + (long)text[j] - 48L;
							}
						}
						else
						{
							num3 = long.Parse(text, NumberStyles.None);
						}
					}
					if (i == array.Length - 1)
					{
						i = 3;
					}
					else if (num3 > 255L)
					{
						result = null;
						return result;
					}
					int num4 = 0;
					while (num3 > 0L)
					{
						num2 |= (num3 & 255L) << (i - num4 << 3);
						num4++;
						num3 /= 256L;
					}
				}
				result = new IPAddress(num2);
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		private static IPAddress ParseIPV6(string ip)
		{
			IPv6Address pv6Address;
			if (IPv6Address.TryParse(ip, out pv6Address))
			{
				return new IPAddress(pv6Address.Address, pv6Address.ScopeId);
			}
			return null;
		}

		private static int SwapInt(int number)
		{
			return (number >> 24 & 255) | (number >> 8 & 65280) | (number << 8 & 16711680) | number << 24;
		}

		private static long SwapLong(long number)
		{
			return (number >> 56 & 255L) | (number >> 40 & 65280L) | (number >> 24 & 16711680L) | (number >> 8 & (long)((ulong)-16777216)) | (number << 8 & 1095216660480L) | (number << 24 & 280375465082880L) | (number << 40 & 71776119061217280L) | number << 56;
		}

		private static short SwapShort(short number)
		{
			return (short)((number >> 8 & 255) | ((int)number << 8 & 65280));
		}

		public override string ToString()
		{
			if (this.m_Family == AddressFamily.InterNetwork)
			{
				return IPAddress.ToString(this.m_Address);
			}
			ushort[] array = this.m_Numbers.Clone() as ushort[];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = (ushort)IPAddress.NetworkToHostOrder((short)array[i]);
			}
			return new IPv6Address(array)
			{
				ScopeId = this.ScopeId
			}.ToString();
		}

		private static string ToString(long addr)
		{
			return string.Concat(new string[]
			{
				(addr & 255L).ToString(),
				".",
				(addr >> 8 & 255L).ToString(),
				".",
				(addr >> 16 & 255L).ToString(),
				".",
				(addr >> 24 & 255L).ToString()
			});
		}

		internal static bool TryParse(string ipString, out IPAddress address)
		{
			if (ipString == null)
			{
				throw new ArgumentNullException("ipString");
			}
			IPAddress iPAddress;
			address = (iPAddress = IPAddress.ParseIPV4(ipString));
			if (iPAddress == null)
			{
				address = (iPAddress = IPAddress.ParseIPV6(ipString));
				if (iPAddress == null)
				{
					return false;
				}
			}
			return true;
		}

		[Obsolete("This property is obsolete. Use GetAddressBytes.")]
		public long Address
		{
			get
			{
				if (this.m_Family != AddressFamily.InterNetwork)
				{
					throw new Exception("The attempted operation is not supported for the type of object referenced");
				}
				return this.m_Address;
			}
			set
			{
				if (this.m_Family != AddressFamily.InterNetwork)
				{
					throw new Exception("The attempted operation is not supported for the type of object referenced");
				}
				this.m_Address = value;
			}
		}

		public AddressFamily AddressFamily
		{
			get
			{
				return this.m_Family;
			}
		}

		internal long InternalIPv4Address
		{
			get
			{
				return this.m_Address;
			}
		}

		public long ScopeId
		{
			get
			{
				if (this.m_Family != AddressFamily.InterNetworkV6)
				{
					throw new Exception("The attempted operation is not supported for the type of object referenced");
				}
				return this.m_ScopeId;
			}
			set
			{
				if (this.m_Family != AddressFamily.InterNetworkV6)
				{
					throw new Exception("The attempted operation is not supported for the type of object referenced");
				}
				this.m_ScopeId = value;
			}
		}

		public static readonly IPAddress Any = new IPAddress(0L);

		public static readonly IPAddress Broadcast = IPAddress.Parse("255.255.255.255");

		public static readonly IPAddress IPv6Any = IPAddress.ParseIPV6("::");

		public static readonly IPAddress IPv6Loopback = IPAddress.ParseIPV6("::1");

		public static readonly IPAddress IPv6None = IPAddress.ParseIPV6("::");

		public static readonly IPAddress Loopback = IPAddress.Parse("127.0.0.1");

		private long m_Address;

		private AddressFamily m_Family;

		private int m_HashCode;

		private ushort[] m_Numbers;

		private long m_ScopeId;

		public static readonly IPAddress None = IPAddress.Parse("255.255.255.255");
	}
}
