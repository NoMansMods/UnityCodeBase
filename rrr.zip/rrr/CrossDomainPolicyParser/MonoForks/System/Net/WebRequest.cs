﻿using System;
using System.Collections.Generic;

namespace MonoForks.System.Net
{
	internal class WebRequest
	{
		public WebRequest(Uri requesturi, Dictionary<string, string> headers)
		{
			this.RequestUri = requesturi;
			this.Headers = headers;
		}

		public Dictionary<string, string> Headers
		{
			get;
			set;
		}

		public Uri RequestUri
		{
			get;
			set;
		}
	}
}
