﻿using System;

namespace MonoForks.System
{
	internal enum UriKind
	{
		RelativeOrAbsolute,
		Absolute,
		Relative
	}
}
