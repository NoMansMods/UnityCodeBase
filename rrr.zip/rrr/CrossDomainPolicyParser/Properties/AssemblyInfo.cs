﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2010")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("CrossDomainPolicyParser")]
[assembly: AssemblyTitle("CrossDomainPolicyParser")]
[assembly: AssemblyTrademark("")]
[assembly: InternalsVisibleTo("CrossDomainPolicyParserTests")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
[assembly: Guid("f17522fc-5e6b-43ea-baf9-8af61d9740f0")]
