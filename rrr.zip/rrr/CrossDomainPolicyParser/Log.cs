﻿using System;

internal class Log
{
	public static void Msg(string msg)
	{
		if (Log.logger != null)
		{
			Log.logger(msg);
		}
	}

	public static void SetLog(Log.LogDelegate ld)
	{
		Log.logger = ld;
	}

	private static Log.LogDelegate logger;

	public delegate void LogDelegate(string msg);
}
