﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security;
using CrossDomainPolicyParser;
using MonoForks.Mono.Xml;
using MonoForks.System;
using MonoForks.System.Net;
using MonoForks.System.Windows.Browser.Net;

namespace UnityEngine
{
	public class UnityCrossDomainHelper
	{
		public static bool CheckSocketEndPoint(string connecting_to_ip, int port)
		{
			Log.Msg(string.Concat(new object[]
			{
				"CheckSocketEndpoint called for ",
				connecting_to_ip,
				" with port: ",
				port
			}));
			if (!Application.webSecurityEnabled)
			{
				return true;
			}
			bool flag = CrossDomainPolicyManager.CheckSocketEndPoint(connecting_to_ip, port);
			Log.Msg("CheckSocketENdpoint returns :" + flag);
			return flag;
		}

		public static void ClearCache()
		{
			UnityCrossDomainHelper.wwwPolicyProvider.ClearCache();
			CrossDomainPolicyManager.ClearCache();
		}

		private static string DefaultGetWebSecurityHostUri()
		{
			return Application.webSecurityHostUrl;
		}

		public static UnityCrossDomainHelper.SecurityPolicy GetSecurityPolicy(string requesturi_string)
		{
			return UnityCrossDomainHelper.GetSecurityPolicy(requesturi_string, UnityCrossDomainHelper.wwwPolicyProvider);
		}

		private static UnityCrossDomainHelper.SecurityPolicy GetSecurityPolicy(string requesturi_string, UnityCrossDomainHelper.IPolicyProvider policyProvider)
		{
			Uri uri = UriTools.MakeUri(Application.webSecurityHostUrl, requesturi_string);
			if (uri.Scheme == "file")
			{
				if (Application.isEditor)
				{
					return UnityCrossDomainHelper.SecurityPolicy.AllowAccess;
				}
				Uri uri2 = new Uri(Application.webSecurityHostUrl);
				if (Application.isWebPlayer && uri2.Scheme == "file")
				{
					return UnityCrossDomainHelper.SecurityPolicy.AllowAccess;
				}
				return UnityCrossDomainHelper.SecurityPolicy.DenyAccess;
			}
			else
			{
				ICrossDomainPolicy cachedWebPolicy = CrossDomainPolicyManager.GetCachedWebPolicy(uri);
				if (cachedWebPolicy != null)
				{
					WebRequest request = new WebRequest(uri, new Dictionary<string, string>());
					return (!cachedWebPolicy.IsAllowed(request)) ? UnityCrossDomainHelper.SecurityPolicy.DenyAccess : UnityCrossDomainHelper.SecurityPolicy.AllowAccess;
				}
				if (UnityCrossDomainHelper.ShouldEnableLogging())
				{
					Log.SetLog(new Log.LogDelegate(Console.WriteLine));
				}
				Log.Msg("Determining crossdomain.xml location for request: " + uri);
				Uri flashPolicyUri = CrossDomainPolicyManager.GetFlashPolicyUri(uri);
				try
				{
					Stream policy = policyProvider.GetPolicy(flashPolicyUri.ToString());
					if (policy == null)
					{
						UnityCrossDomainHelper.SecurityPolicy result = UnityCrossDomainHelper.SecurityPolicy.DontKnowYet;
						return result;
					}
					CrossDomainPolicyManager.BuildFlashPolicy(true, flashPolicyUri, policy, new Dictionary<string, string>());
				}
				catch (InvalidOperationException)
				{
					UnityCrossDomainHelper.SecurityPolicy result = UnityCrossDomainHelper.SecurityPolicy.DenyAccess;
					return result;
				}
				catch (MiniParser.XMLError xMLError)
				{
					Debug.Log(string.Format("Error reading crossdomain policy: {0}", xMLError.Message));
					UnityCrossDomainHelper.SecurityPolicy result = UnityCrossDomainHelper.SecurityPolicy.DenyAccess;
					return result;
				}
				return UnityCrossDomainHelper.GetSecurityPolicy(requesturi_string, policyProvider);
			}
		}

		public static bool GetSecurityPolicyForDotNetWebRequest(string requesturi_string, MethodInfo policyProvidingMethod)
		{
			UnityCrossDomainHelper.WebRequestPolicyProvider policyProvider = new UnityCrossDomainHelper.WebRequestPolicyProvider(policyProvidingMethod);
			return UnityCrossDomainHelper.GetSecurityPolicy(requesturi_string, policyProvider) == UnityCrossDomainHelper.SecurityPolicy.AllowAccess;
		}

		public static string GetWebSecurityHostUri()
		{
			return UnityCrossDomainHelper.getWebSecurityHostUriDelegate();
		}

		public static bool PrefetchSocketPolicy(string ip, int policyport, int timeout)
		{
			if (!Application.webSecurityEnabled)
			{
				return false;
			}
			FlashCrossDomainPolicy flashCrossDomainPolicy = CrossDomainPolicyManager.FlashCrossDomainPolicyFor(ip, policyport, timeout);
			return flashCrossDomainPolicy != FlashCrossDomainPolicy.DenyPolicy;
		}

		internal static void SetWebSecurityHostUriDelegate(UnityCrossDomainHelper.GetWebSecurityHostUriDelegate d)
		{
			UnityCrossDomainHelper.getWebSecurityHostUriDelegate = d;
		}

		[SecuritySafeCritical]
		private static bool ShouldEnableLogging()
		{
			return Environment.GetEnvironmentVariable("ENABLE_CROSSDOMAIN_LOGGING") == "1";
		}

		private static UnityCrossDomainHelper.GetWebSecurityHostUriDelegate getWebSecurityHostUriDelegate = new UnityCrossDomainHelper.GetWebSecurityHostUriDelegate(UnityCrossDomainHelper.DefaultGetWebSecurityHostUri);

		private static UnityCrossDomainHelper.WWWPolicyProvider wwwPolicyProvider = new UnityCrossDomainHelper.WWWPolicyProvider();

		public delegate string GetWebSecurityHostUriDelegate();

		private interface IPolicyProvider
		{
			Stream GetPolicy(string url);
		}

		public enum SecurityPolicy
		{
			DontKnowYet,
			AllowAccess,
			DenyAccess
		}

		private class WebRequestPolicyProvider : UnityCrossDomainHelper.IPolicyProvider
		{
			public WebRequestPolicyProvider(MethodInfo mi)
			{
				this.methodinfo = mi;
			}

			[SecuritySafeCritical]
			public Stream GetPolicy(string policy_url)
			{
				string text = Environment.GetEnvironmentVariable("UNITY_PROXYSERVER");
				if (string.IsNullOrEmpty(text))
				{
					text = null;
				}
				object obj = this.methodinfo.Invoke(null, new object[]
				{
					policy_url,
					text
				});
				return (Stream)obj;
			}

			private MethodInfo methodinfo;
		}

		private class WWWPolicyProvider : UnityCrossDomainHelper.IPolicyProvider
		{
			public void ClearCache()
			{
				this.policyDownloads.Clear();
			}

			public Stream GetPolicy(string policyurl)
			{
				WWW wWW = null;
				this.policyDownloads.TryGetValue(policyurl, out wWW);
				if (wWW != null)
				{
					if (!wWW.isDone)
					{
						return null;
					}
					bool flag = wWW.error == null;
					if (!flag)
					{
						throw new InvalidOperationException("Unable to download policy");
					}
					if (flag)
					{
						Log.Msg("Download had OK statuscode");
						Log.Msg("Received the following crossdomain.xml");
						Log.Msg("----------");
						Log.Msg(wWW.text);
						Log.Msg("----------");
						return new MemoryStream(wWW.bytes);
					}
				}
				WWW value = new WWW(policyurl);
				this.policyDownloads.Add(policyurl, value);
				return null;
			}

			private Dictionary<string, WWW> policyDownloads = new Dictionary<string, WWW>();
		}
	}
}
