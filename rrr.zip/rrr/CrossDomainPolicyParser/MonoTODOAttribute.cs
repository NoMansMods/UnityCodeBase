﻿using System;

internal class MonoTODOAttribute : Attribute
{
	public MonoTODOAttribute(string s)
	{
	}
}
