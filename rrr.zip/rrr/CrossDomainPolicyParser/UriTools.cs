﻿using System;
using MonoForks.System;

namespace CrossDomainPolicyParser
{
	internal class UriTools
	{
		private static string GetBaseUrl(string url)
		{
			return url.Substring(0, url.LastIndexOf('/'));
		}

		public static Uri MakeUri(string gameurl, string url)
		{
			if (!url.ToLower().StartsWith("http://") && !url.ToLower().StartsWith("https://") && !url.ToLower().StartsWith("file://"))
			{
				url = UriTools.GetBaseUrl(gameurl) + "/" + url;
			}
			Log.Msg("About to parse url: " + url);
			return new Uri(url);
		}
	}
}
