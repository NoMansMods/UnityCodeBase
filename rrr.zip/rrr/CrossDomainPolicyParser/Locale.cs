﻿using System;

internal static class Locale
{
	public static string GetText(string s)
	{
		return s;
	}
}
