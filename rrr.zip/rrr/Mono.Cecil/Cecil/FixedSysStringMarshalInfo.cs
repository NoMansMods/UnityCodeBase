﻿using System;

namespace Mono.Cecil
{
	public sealed class FixedSysStringMarshalInfo : MarshalInfo
	{
		public FixedSysStringMarshalInfo() : base(NativeType.FixedSysString)
		{
			this.size = -1;
		}

		public int Size
		{
			get
			{
				return this.size;
			}
			set
			{
				this.size = value;
			}
		}

		internal int size;
	}
}
