﻿using System;
using Mono.Cecil.Metadata;

namespace Mono.Cecil
{
	internal sealed class FieldTable : MetadataTable<Row<FieldAttributes, uint, uint>>
	{
		public override void Write(TableHeapBuffer buffer)
		{
			for (int i = 0; i < this.length; i++)
			{
				buffer.WriteUInt16((ushort)this.rows[i].Col1);
				buffer.WriteString(this.rows[i].Col2);
				buffer.WriteBlob(this.rows[i].Col3);
			}
		}
	}
}
