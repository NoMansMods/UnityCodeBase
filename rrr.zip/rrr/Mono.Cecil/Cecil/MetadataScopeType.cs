﻿using System;

namespace Mono.Cecil
{
	public enum MetadataScopeType
	{
		AssemblyNameReference,
		ModuleReference,
		ModuleDefinition
	}
}
