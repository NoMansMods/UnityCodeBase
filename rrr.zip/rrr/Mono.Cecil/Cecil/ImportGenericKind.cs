﻿using System;

namespace Mono.Cecil
{
	internal enum ImportGenericKind
	{
		Definition,
		Open
	}
}
