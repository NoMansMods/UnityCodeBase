﻿using System;

namespace Mono.Cecil
{
	public sealed class CustomMarshalInfo : MarshalInfo
	{
		public CustomMarshalInfo() : base(NativeType.CustomMarshaler)
		{
		}

		public string Cookie
		{
			get
			{
				return this.cookie;
			}
			set
			{
				this.cookie = value;
			}
		}

		public Guid Guid
		{
			get
			{
				return this.guid;
			}
			set
			{
				this.guid = value;
			}
		}

		public TypeReference ManagedType
		{
			get
			{
				return this.managed_type;
			}
			set
			{
				this.managed_type = value;
			}
		}

		public string UnmanagedType
		{
			get
			{
				return this.unmanaged_type;
			}
			set
			{
				this.unmanaged_type = value;
			}
		}

		internal string cookie;

		internal Guid guid;

		internal TypeReference managed_type;

		internal string unmanaged_type;
	}
}
