﻿using System;

namespace Mono.Cecil
{
	internal enum FileAttributes : uint
	{
		ContainsMetaData,
		ContainsNoMetaData
	}
}
