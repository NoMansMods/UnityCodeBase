﻿using System;
using Mono.Cecil.Metadata;

namespace Mono.Cecil
{
	internal abstract class MetadataTable
	{
		public abstract void Sort();

		public abstract void Write(TableHeapBuffer buffer);

		public bool IsLarge
		{
			get
			{
				return this.Length > 65535;
			}
		}

		public abstract int Length
		{
			get;
		}
	}
}
