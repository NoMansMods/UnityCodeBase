﻿using System;

namespace Mono.Cecil
{
	public class ModuleReference : IMetadataScope, IMetadataTokenProvider
	{
		internal ModuleReference()
		{
			this.token = new MetadataToken(TokenType.ModuleRef);
		}

		public ModuleReference(string name) : this()
		{
			this.name = name;
		}

		public override string ToString()
		{
			return this.name;
		}

		public virtual MetadataScopeType MetadataScopeType
		{
			get
			{
				return MetadataScopeType.ModuleReference;
			}
		}

		public MetadataToken MetadataToken
		{
			get
			{
				return this.token;
			}
			set
			{
				this.token = value;
			}
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}

		private string name;

		internal MetadataToken token;
	}
}
