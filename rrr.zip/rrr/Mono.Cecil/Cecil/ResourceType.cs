﻿using System;

namespace Mono.Cecil
{
	public enum ResourceType
	{
		Linked,
		Embedded,
		AssemblyLinked
	}
}
