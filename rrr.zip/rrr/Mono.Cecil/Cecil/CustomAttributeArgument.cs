﻿using System;

namespace Mono.Cecil
{
	public struct CustomAttributeArgument
	{
		public CustomAttributeArgument(TypeReference type, object value)
		{
			Mixin.CheckType(type);
			this.type = type;
			this.value = value;
		}

		public TypeReference Type
		{
			get
			{
				return this.type;
			}
		}

		public object Value
		{
			get
			{
				return this.value;
			}
		}

		private readonly TypeReference type;

		private readonly object value;
	}
}
