﻿using System;

namespace Mono.Cecil
{
	public sealed class AssemblyNameDefinition : AssemblyNameReference
	{
		internal AssemblyNameDefinition()
		{
			this.token = new MetadataToken(TokenType.Assembly, 1);
		}

		public AssemblyNameDefinition(string name, Version version) : base(name, version)
		{
			this.token = new MetadataToken(TokenType.Assembly, 1);
		}

		public override byte[] Hash
		{
			get
			{
				return Empty<byte>.Array;
			}
		}
	}
}
