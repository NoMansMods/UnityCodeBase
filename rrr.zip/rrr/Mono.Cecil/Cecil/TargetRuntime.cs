﻿using System;

namespace Mono.Cecil
{
	public enum TargetRuntime
	{
		Net_1_0,
		Net_1_1,
		Net_2_0,
		Net_4_0
	}
}
