﻿using System;

namespace Mono.Cecil
{
	public enum ReadingMode
	{
		Immediate = 1,
		Deferred
	}
}
