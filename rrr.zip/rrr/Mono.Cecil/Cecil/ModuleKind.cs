﻿using System;

namespace Mono.Cecil
{
	public enum ModuleKind
	{
		Dll,
		Console,
		Windows,
		NetModule
	}
}
