﻿using System;

namespace Mono.Cecil
{
	public abstract class Resource
	{
		internal Resource(string name, ManifestResourceAttributes attributes)
		{
			this.name = name;
			this.attributes = (uint)attributes;
		}

		public ManifestResourceAttributes Attributes
		{
			get
			{
				return (ManifestResourceAttributes)this.attributes;
			}
			set
			{
				this.attributes = (uint)value;
			}
		}

		public bool IsPrivate
		{
			get
			{
				return this.attributes.GetMaskedAttributes(7u, 2u);
			}
			set
			{
				this.attributes = this.attributes.SetMaskedAttributes(7u, 2u, value);
			}
		}

		public bool IsPublic
		{
			get
			{
				return this.attributes.GetMaskedAttributes(7u, 1u);
			}
			set
			{
				this.attributes = this.attributes.SetMaskedAttributes(7u, 1u, value);
			}
		}

		public string Name
		{
			get
			{
				return this.name;
			}
			set
			{
				this.name = value;
			}
		}

		public abstract ResourceType ResourceType
		{
			get;
		}

		private uint attributes;

		private string name;
	}
}
