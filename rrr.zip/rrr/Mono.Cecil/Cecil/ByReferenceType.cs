﻿using System;
using Mono.Cecil.Metadata;

namespace Mono.Cecil
{
	public sealed class ByReferenceType : TypeSpecification
	{
		public ByReferenceType(TypeReference type) : base(type)
		{
			Mixin.CheckType(type);
			this.etype = Mono.Cecil.Metadata.ElementType.ByRef;
		}

		public override string FullName
		{
			get
			{
				return base.FullName + "&";
			}
		}

		public override bool IsByReference
		{
			get
			{
				return true;
			}
		}

		public override bool IsValueType
		{
			get
			{
				return false;
			}
			set
			{
				throw new InvalidOperationException();
			}
		}

		public override string Name
		{
			get
			{
				return base.Name + "&";
			}
		}
	}
}
