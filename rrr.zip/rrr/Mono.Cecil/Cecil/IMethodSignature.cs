﻿using System;
using Mono.Collections.Generic;

namespace Mono.Cecil
{
	public interface IMethodSignature : IMetadataTokenProvider
	{
		MethodCallingConvention CallingConvention
		{
			get;
			set;
		}

		bool ExplicitThis
		{
			get;
			set;
		}

		bool HasParameters
		{
			get;
		}

		bool HasThis
		{
			get;
			set;
		}

		MethodReturnType MethodReturnType
		{
			get;
		}

		Collection<ParameterDefinition> Parameters
		{
			get;
		}

		TypeReference ReturnType
		{
			get;
			set;
		}
	}
}
