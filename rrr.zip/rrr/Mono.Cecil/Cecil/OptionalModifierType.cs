﻿using System;
using Mono.Cecil.Metadata;

namespace Mono.Cecil
{
	public sealed class OptionalModifierType : TypeSpecification, IModifierType
	{
		public OptionalModifierType(TypeReference modifierType, TypeReference type) : base(type)
		{
			Mixin.CheckModifier(modifierType, type);
			this.modifier_type = modifierType;
			this.etype = Mono.Cecil.Metadata.ElementType.CModOpt;
		}

		public override bool ContainsGenericParameter
		{
			get
			{
				return this.modifier_type.ContainsGenericParameter || base.ContainsGenericParameter;
			}
		}

		public override string FullName
		{
			get
			{
				return base.FullName + this.Suffix;
			}
		}

		public override bool IsOptionalModifier
		{
			get
			{
				return true;
			}
		}

		public override bool IsValueType
		{
			get
			{
				return false;
			}
			set
			{
				throw new InvalidOperationException();
			}
		}

		public TypeReference ModifierType
		{
			get
			{
				return this.modifier_type;
			}
			set
			{
				this.modifier_type = value;
			}
		}

		public override string Name
		{
			get
			{
				return base.Name + this.Suffix;
			}
		}

		private string Suffix
		{
			get
			{
				return " modopt(" + this.modifier_type + ")";
			}
		}

		private TypeReference modifier_type;
	}
}
