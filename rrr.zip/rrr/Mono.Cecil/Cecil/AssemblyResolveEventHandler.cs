﻿using System;

namespace Mono.Cecil
{
	public delegate AssemblyDefinition AssemblyResolveEventHandler(object sender, AssemblyNameReference reference);
}
