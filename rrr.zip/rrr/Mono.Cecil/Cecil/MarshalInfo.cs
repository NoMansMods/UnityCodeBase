﻿using System;

namespace Mono.Cecil
{
	public class MarshalInfo
	{
		public MarshalInfo(NativeType native)
		{
			this.native = native;
		}

		public NativeType NativeType
		{
			get
			{
				return this.native;
			}
			set
			{
				this.native = value;
			}
		}

		internal NativeType native;
	}
}
