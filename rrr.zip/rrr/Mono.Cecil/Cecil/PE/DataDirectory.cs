﻿using System;

namespace Mono.Cecil.PE
{
	internal struct DataDirectory
	{
		public DataDirectory(uint rva, uint size)
		{
			this.VirtualAddress = rva;
			this.Size = size;
		}

		public bool IsZero
		{
			get
			{
				return this.VirtualAddress == 0u && this.Size == 0u;
			}
		}

		public readonly uint VirtualAddress;

		public readonly uint Size;
	}
}
