﻿using System;

namespace Mono.Cecil.PE
{
	internal sealed class Section
	{
		public byte[] Data;

		public string Name;

		public uint PointerToRawData;

		public uint SizeOfRawData;

		public uint VirtualAddress;

		public uint VirtualSize;
	}
}
