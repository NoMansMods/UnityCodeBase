﻿using System;

namespace Mono.Cecil
{
	public sealed class AssemblyResolveEventArgs : EventArgs
	{
		public AssemblyResolveEventArgs(AssemblyNameReference reference)
		{
			this.reference = reference;
		}

		public AssemblyNameReference AssemblyReference
		{
			get
			{
				return this.reference;
			}
		}

		private readonly AssemblyNameReference reference;
	}
}
