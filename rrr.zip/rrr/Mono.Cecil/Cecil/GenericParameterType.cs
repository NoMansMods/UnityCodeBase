﻿using System;

namespace Mono.Cecil
{
	public enum GenericParameterType
	{
		Type,
		Method
	}
}
