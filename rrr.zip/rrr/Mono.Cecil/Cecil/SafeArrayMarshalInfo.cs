﻿using System;

namespace Mono.Cecil
{
	public sealed class SafeArrayMarshalInfo : MarshalInfo
	{
		public SafeArrayMarshalInfo() : base(NativeType.SafeArray)
		{
			this.element_type = VariantType.None;
		}

		public VariantType ElementType
		{
			get
			{
				return this.element_type;
			}
			set
			{
				this.element_type = value;
			}
		}

		internal VariantType element_type;
	}
}
