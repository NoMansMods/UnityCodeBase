﻿using System;
using Mono.Cecil.PE;
using Mono.Collections.Generic;

namespace Mono.Cecil
{
	internal sealed class ImmediateModuleReader : ModuleReader
	{
		public ImmediateModuleReader(Image image) : base(image, ReadingMode.Immediate)
		{
		}

		private static void Read(object collection)
		{
		}

		private static void ReadCustomAttributes(ICustomAttributeProvider provider)
		{
			if (!provider.HasCustomAttributes)
			{
				return;
			}
			Collection<CustomAttribute> customAttributes = provider.CustomAttributes;
			for (int i = 0; i < customAttributes.Count; i++)
			{
				CustomAttribute customAttribute = customAttributes[i];
				ImmediateModuleReader.Read(customAttribute.ConstructorArguments);
			}
		}

		private static void ReadEvents(TypeDefinition type)
		{
			Collection<EventDefinition> events = type.Events;
			for (int i = 0; i < events.Count; i++)
			{
				EventDefinition eventDefinition = events[i];
				ImmediateModuleReader.Read(eventDefinition.AddMethod);
				ImmediateModuleReader.ReadCustomAttributes(eventDefinition);
			}
		}

		private static void ReadFields(TypeDefinition type)
		{
			Collection<FieldDefinition> fields = type.Fields;
			for (int i = 0; i < fields.Count; i++)
			{
				FieldDefinition fieldDefinition = fields[i];
				if (fieldDefinition.HasConstant)
				{
					ImmediateModuleReader.Read(fieldDefinition.Constant);
				}
				if (fieldDefinition.HasLayoutInfo)
				{
					ImmediateModuleReader.Read(fieldDefinition.Offset);
				}
				if (fieldDefinition.RVA > 0)
				{
					ImmediateModuleReader.Read(fieldDefinition.InitialValue);
				}
				if (fieldDefinition.HasMarshalInfo)
				{
					ImmediateModuleReader.Read(fieldDefinition.MarshalInfo);
				}
				ImmediateModuleReader.ReadCustomAttributes(fieldDefinition);
			}
		}

		private static void ReadGenericParameters(IGenericParameterProvider provider)
		{
			if (!provider.HasGenericParameters)
			{
				return;
			}
			Collection<GenericParameter> genericParameters = provider.GenericParameters;
			for (int i = 0; i < genericParameters.Count; i++)
			{
				GenericParameter genericParameter = genericParameters[i];
				if (genericParameter.HasConstraints)
				{
					ImmediateModuleReader.Read(genericParameter.Constraints);
				}
				ImmediateModuleReader.ReadCustomAttributes(genericParameter);
			}
		}

		private static void ReadMethods(TypeDefinition type)
		{
			Collection<MethodDefinition> methods = type.Methods;
			for (int i = 0; i < methods.Count; i++)
			{
				MethodDefinition methodDefinition = methods[i];
				ImmediateModuleReader.ReadGenericParameters(methodDefinition);
				if (methodDefinition.HasParameters)
				{
					ImmediateModuleReader.ReadParameters(methodDefinition);
				}
				if (methodDefinition.HasOverrides)
				{
					ImmediateModuleReader.Read(methodDefinition.Overrides);
				}
				if (methodDefinition.IsPInvokeImpl)
				{
					ImmediateModuleReader.Read(methodDefinition.PInvokeInfo);
				}
				ImmediateModuleReader.ReadSecurityDeclarations(methodDefinition);
				ImmediateModuleReader.ReadCustomAttributes(methodDefinition);
				MethodReturnType methodReturnType = methodDefinition.MethodReturnType;
				if (methodReturnType.HasConstant)
				{
					ImmediateModuleReader.Read(methodReturnType.Constant);
				}
				if (methodReturnType.HasMarshalInfo)
				{
					ImmediateModuleReader.Read(methodReturnType.MarshalInfo);
				}
				ImmediateModuleReader.ReadCustomAttributes(methodReturnType);
			}
		}

		protected override void ReadModule()
		{
			this.module.Read<ModuleDefinition, ModuleDefinition>(this.module, delegate(ModuleDefinition module, MetadataReader reader)
			{
				base.ReadModuleManifest(reader);
				ImmediateModuleReader.ReadModule(module);
				return module;
			});
		}

		public static void ReadModule(ModuleDefinition module)
		{
			if (module.HasAssemblyReferences)
			{
				ImmediateModuleReader.Read(module.AssemblyReferences);
			}
			if (module.HasResources)
			{
				ImmediateModuleReader.Read(module.Resources);
			}
			if (module.HasModuleReferences)
			{
				ImmediateModuleReader.Read(module.ModuleReferences);
			}
			if (module.HasTypes)
			{
				ImmediateModuleReader.ReadTypes(module.Types);
			}
			if (module.HasExportedTypes)
			{
				ImmediateModuleReader.Read(module.ExportedTypes);
			}
			if (module.HasCustomAttributes)
			{
				ImmediateModuleReader.Read(module.CustomAttributes);
			}
			AssemblyDefinition assembly = module.Assembly;
			if (assembly == null)
			{
				return;
			}
			if (assembly.HasCustomAttributes)
			{
				ImmediateModuleReader.ReadCustomAttributes(assembly);
			}
			if (assembly.HasSecurityDeclarations)
			{
				ImmediateModuleReader.Read(assembly.SecurityDeclarations);
			}
		}

		private static void ReadParameters(MethodDefinition method)
		{
			Collection<ParameterDefinition> parameters = method.Parameters;
			for (int i = 0; i < parameters.Count; i++)
			{
				ParameterDefinition parameterDefinition = parameters[i];
				if (parameterDefinition.HasConstant)
				{
					ImmediateModuleReader.Read(parameterDefinition.Constant);
				}
				if (parameterDefinition.HasMarshalInfo)
				{
					ImmediateModuleReader.Read(parameterDefinition.MarshalInfo);
				}
				ImmediateModuleReader.ReadCustomAttributes(parameterDefinition);
			}
		}

		private static void ReadProperties(TypeDefinition type)
		{
			Collection<PropertyDefinition> properties = type.Properties;
			for (int i = 0; i < properties.Count; i++)
			{
				PropertyDefinition propertyDefinition = properties[i];
				ImmediateModuleReader.Read(propertyDefinition.GetMethod);
				if (propertyDefinition.HasConstant)
				{
					ImmediateModuleReader.Read(propertyDefinition.Constant);
				}
				ImmediateModuleReader.ReadCustomAttributes(propertyDefinition);
			}
		}

		private static void ReadSecurityDeclarations(ISecurityDeclarationProvider provider)
		{
			if (!provider.HasSecurityDeclarations)
			{
				return;
			}
			Collection<SecurityDeclaration> securityDeclarations = provider.SecurityDeclarations;
			for (int i = 0; i < securityDeclarations.Count; i++)
			{
				SecurityDeclaration securityDeclaration = securityDeclarations[i];
				ImmediateModuleReader.Read(securityDeclaration.SecurityAttributes);
			}
		}

		private static void ReadType(TypeDefinition type)
		{
			ImmediateModuleReader.ReadGenericParameters(type);
			if (type.HasInterfaces)
			{
				ImmediateModuleReader.Read(type.Interfaces);
			}
			if (type.HasNestedTypes)
			{
				ImmediateModuleReader.ReadTypes(type.NestedTypes);
			}
			if (type.HasLayoutInfo)
			{
				ImmediateModuleReader.Read(type.ClassSize);
			}
			if (type.HasFields)
			{
				ImmediateModuleReader.ReadFields(type);
			}
			if (type.HasMethods)
			{
				ImmediateModuleReader.ReadMethods(type);
			}
			if (type.HasProperties)
			{
				ImmediateModuleReader.ReadProperties(type);
			}
			if (type.HasEvents)
			{
				ImmediateModuleReader.ReadEvents(type);
			}
			ImmediateModuleReader.ReadSecurityDeclarations(type);
			ImmediateModuleReader.ReadCustomAttributes(type);
		}

		private static void ReadTypes(Collection<TypeDefinition> types)
		{
			for (int i = 0; i < types.Count; i++)
			{
				ImmediateModuleReader.ReadType(types[i]);
			}
		}
	}
}
