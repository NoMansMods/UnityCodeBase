﻿using System;

namespace Mono.Cecil
{
	public enum AssemblyHashAlgorithm : uint
	{
		None,
		Reserved = 32771u,
		SHA1
	}
}
