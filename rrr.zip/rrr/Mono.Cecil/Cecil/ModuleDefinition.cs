﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using Mono.Cecil.Cil;
using Mono.Cecil.Metadata;
using Mono.Cecil.PE;
using Mono.Collections.Generic;

namespace Mono.Cecil
{
	public sealed class ModuleDefinition : ModuleReference, ICustomAttributeProvider, IMetadataTokenProvider
	{
		internal ModuleDefinition()
		{
			this.MetadataSystem = new MetadataSystem();
			this.token = new MetadataToken(TokenType.Module, 1);
		}

		internal ModuleDefinition(Image image) : this()
		{
			this.Image = image;
			this.kind = image.Kind;
			this.RuntimeVersion = image.RuntimeVersion;
			this.architecture = image.Architecture;
			this.attributes = image.Attributes;
			this.characteristics = image.Characteristics;
			this.fq_name = image.FileName;
			this.reader = new MetadataReader(this);
		}

		private static void CheckContext(IGenericParameterProvider context, ModuleDefinition module)
		{
			if (context == null)
			{
				return;
			}
			if (context.Module != module)
			{
				throw new ArgumentException();
			}
		}

		private static void CheckField(object field)
		{
			if (field == null)
			{
				throw new ArgumentNullException("field");
			}
		}

		private static void CheckFullName(string fullName)
		{
			if (fullName == null)
			{
				throw new ArgumentNullException("fullName");
			}
			if (fullName.Length == 0)
			{
				throw new ArgumentException();
			}
		}

		private static void CheckMethod(object method)
		{
			if (method == null)
			{
				throw new ArgumentNullException("method");
			}
		}

		private static void CheckStream(object stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
		}

		private static void CheckType(object type)
		{
			if (type == null)
			{
				throw new ArgumentNullException("type");
			}
		}

		private static AssemblyNameDefinition CreateAssemblyName(string name)
		{
			if (name.EndsWith(".dll") || name.EndsWith(".exe"))
			{
				name = name.Substring(0, name.Length - 4);
			}
			return new AssemblyNameDefinition(name, new Version(0, 0, 0, 0));
		}

		public static ModuleDefinition CreateModule(string name, ModuleKind kind)
		{
			return ModuleDefinition.CreateModule(name, new ModuleParameters
			{
				Kind = kind
			});
		}

		public static ModuleDefinition CreateModule(string name, ModuleParameters parameters)
		{
			Mixin.CheckName(name);
			Mixin.CheckParameters(parameters);
			ModuleDefinition moduleDefinition = new ModuleDefinition
			{
				Name = name,
				kind = parameters.Kind,
				Runtime = parameters.Runtime,
				architecture = parameters.Architecture,
				mvid = Guid.NewGuid(),
				Attributes = ModuleAttributes.ILOnly,
				Characteristics = (ModuleCharacteristics.DynamicBase | ModuleCharacteristics.NoSEH | ModuleCharacteristics.NXCompat | ModuleCharacteristics.TerminalServerAware)
			};
			if (parameters.AssemblyResolver != null)
			{
				moduleDefinition.assembly_resolver = parameters.AssemblyResolver;
			}
			if (parameters.MetadataResolver != null)
			{
				moduleDefinition.metadata_resolver = parameters.MetadataResolver;
			}
			if (parameters.Kind != ModuleKind.NetModule)
			{
				AssemblyDefinition assemblyDefinition = new AssemblyDefinition();
				moduleDefinition.assembly = assemblyDefinition;
				moduleDefinition.assembly.Name = ModuleDefinition.CreateAssemblyName(name);
				assemblyDefinition.main_module = moduleDefinition;
			}
			moduleDefinition.Types.Add(new TypeDefinition(string.Empty, "<Module>", TypeAttributes.NotPublic));
			return moduleDefinition;
		}

		private static ImportGenericContext GenericContextFor(IGenericParameterProvider context)
		{
			if (context == null)
			{
				return default(ImportGenericContext);
			}
			return new ImportGenericContext(context);
		}

		public ImageDebugDirectory GetDebugHeader(out byte[] header)
		{
			if (!this.HasDebugHeader)
			{
				throw new InvalidOperationException();
			}
			return this.Image.GetDebugHeader(out header);
		}

		private static Stream GetFileStream(string fileName, FileMode mode, FileAccess access, FileShare share)
		{
			if (fileName == null)
			{
				throw new ArgumentNullException("fileName");
			}
			if (fileName.Length == 0)
			{
				throw new ArgumentException();
			}
			return new FileStream(fileName, mode, access, share);
		}

		public IEnumerable<MemberReference> GetMemberReferences()
		{
			if (!this.HasImage)
			{
				return Empty<MemberReference>.Array;
			}
			return this.Read<ModuleDefinition, IEnumerable<MemberReference>>(this, (ModuleDefinition _, MetadataReader reader) => reader.GetMemberReferences());
		}

		private TypeDefinition GetNestedType(string fullname)
		{
			string[] array = fullname.Split(new char[]
			{
				'/'
			});
			TypeDefinition typeDefinition = this.GetType(array[0]);
			if (typeDefinition == null)
			{
				return null;
			}
			for (int i = 1; i < array.Length; i++)
			{
				TypeDefinition nestedType = typeDefinition.GetNestedType(array[i]);
				if (nestedType == null)
				{
					return null;
				}
				typeDefinition = nestedType;
			}
			return typeDefinition;
		}

		public TypeDefinition GetType(string fullName)
		{
			ModuleDefinition.CheckFullName(fullName);
			int num = fullName.IndexOf('/');
			if (num > 0)
			{
				return this.GetNestedType(fullName);
			}
			return ((TypeDefinitionCollection)this.Types).GetType(fullName);
		}

		public TypeReference GetType(string fullName, bool runtimeName)
		{
			if (!runtimeName)
			{
				return this.GetType(fullName);
			}
			return TypeParser.ParseType(this, fullName);
		}

		public TypeDefinition GetType(string @namespace, string name)
		{
			Mixin.CheckName(name);
			return ((TypeDefinitionCollection)this.Types).GetType(@namespace ?? string.Empty, name);
		}

		private TypeReference GetTypeReference(string scope, string fullname)
		{
			return this.Read<Row<string, string>, TypeReference>(new Row<string, string>(scope, fullname), (Row<string, string> row, MetadataReader reader) => reader.GetTypeReference(row.Col1, row.Col2));
		}

		public IEnumerable<TypeReference> GetTypeReferences()
		{
			if (!this.HasImage)
			{
				return Empty<TypeReference>.Array;
			}
			return this.Read<ModuleDefinition, IEnumerable<TypeReference>>(this, (ModuleDefinition _, MetadataReader reader) => reader.GetTypeReferences());
		}

		public IEnumerable<TypeDefinition> GetTypes()
		{
			return ModuleDefinition.GetTypes(this.Types);
		}

		private static IEnumerable<TypeDefinition> GetTypes(Collection<TypeDefinition> types)
		{
			for (int i = 0; i < types.Count; i++)
			{
				TypeDefinition typeDefinition = types[i];
				yield return typeDefinition;
				if (typeDefinition.HasNestedTypes)
				{
					foreach (TypeDefinition current in ModuleDefinition.GetTypes(typeDefinition.NestedTypes))
					{
						yield return current;
					}
				}
			}
			yield break;
		}

		public bool HasTypeReference(string fullName)
		{
			return this.HasTypeReference(string.Empty, fullName);
		}

		public bool HasTypeReference(string scope, string fullName)
		{
			ModuleDefinition.CheckFullName(fullName);
			return this.HasImage && this.GetTypeReference(scope, fullName) != null;
		}

		public TypeReference Import(Type type)
		{
			return this.Import(type, null);
		}

		public FieldReference Import(FieldInfo field)
		{
			return this.Import(field, null);
		}

		public MethodReference Import(MethodBase method)
		{
			ModuleDefinition.CheckMethod(method);
			return this.MetadataImporter.ImportMethod(method, default(ImportGenericContext), ImportGenericKind.Definition);
		}

		public TypeReference Import(TypeReference type)
		{
			ModuleDefinition.CheckType(type);
			if (type.Module == this)
			{
				return type;
			}
			return this.MetadataImporter.ImportType(type, default(ImportGenericContext));
		}

		public FieldReference Import(FieldReference field)
		{
			ModuleDefinition.CheckField(field);
			if (field.Module == this)
			{
				return field;
			}
			return this.MetadataImporter.ImportField(field, default(ImportGenericContext));
		}

		public MethodReference Import(MethodReference method)
		{
			return this.Import(method, null);
		}

		public TypeReference Import(Type type, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckType(type);
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportType(type, ModuleDefinition.GenericContextFor(context), (context != null) ? ImportGenericKind.Open : ImportGenericKind.Definition);
		}

		public FieldReference Import(FieldInfo field, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckField(field);
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportField(field, ModuleDefinition.GenericContextFor(context));
		}

		public MethodReference Import(MethodBase method, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckMethod(method);
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportMethod(method, ModuleDefinition.GenericContextFor(context), (context != null) ? ImportGenericKind.Open : ImportGenericKind.Definition);
		}

		public TypeReference Import(TypeReference type, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckType(type);
			if (type.Module == this)
			{
				return type;
			}
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportType(type, ModuleDefinition.GenericContextFor(context));
		}

		public FieldReference Import(FieldReference field, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckField(field);
			if (field.Module == this)
			{
				return field;
			}
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportField(field, ModuleDefinition.GenericContextFor(context));
		}

		public MethodReference Import(MethodReference method, IGenericParameterProvider context)
		{
			ModuleDefinition.CheckMethod(method);
			if (method.Module == this)
			{
				return method;
			}
			ModuleDefinition.CheckContext(context, this);
			return this.MetadataImporter.ImportMethod(method, ModuleDefinition.GenericContextFor(context));
		}

		public IMetadataTokenProvider LookupToken(int token)
		{
			return this.LookupToken(new MetadataToken((uint)token));
		}

		public IMetadataTokenProvider LookupToken(MetadataToken token)
		{
			return this.Read<MetadataToken, IMetadataTokenProvider>(token, (MetadataToken t, MetadataReader reader) => reader.LookupToken(t));
		}

		private void ProcessDebugHeader()
		{
			if (!this.HasDebugHeader)
			{
				return;
			}
			byte[] header;
			ImageDebugDirectory debugHeader = this.GetDebugHeader(out header);
			if (!this.symbol_reader.ProcessDebugHeader(debugHeader, header))
			{
				throw new InvalidOperationException();
			}
		}

		internal TRet Read<TItem, TRet>(TItem item, Func<TItem, MetadataReader, TRet> read)
		{
			TRet result;
			lock (this.module_lock)
			{
				int position = this.reader.position;
				IGenericContext context = this.reader.context;
				TRet tRet = read(item, this.reader);
				this.reader.position = position;
				this.reader.context = context;
				result = tRet;
			}
			return result;
		}

		internal TRet Read<TItem, TRet>(ref TRet variable, TItem item, Func<TItem, MetadataReader, TRet> read) where TRet : class
		{
			TRet result;
			lock (this.module_lock)
			{
				if (variable != null)
				{
					result = variable;
				}
				else
				{
					int position = this.reader.position;
					IGenericContext context = this.reader.context;
					TRet tRet = read(item, this.reader);
					this.reader.position = position;
					this.reader.context = context;
					result = (variable = tRet);
				}
			}
			return result;
		}

		public static ModuleDefinition ReadModule(string fileName)
		{
			return ModuleDefinition.ReadModule(fileName, new ReaderParameters(ReadingMode.Deferred));
		}

		public static ModuleDefinition ReadModule(Stream stream)
		{
			return ModuleDefinition.ReadModule(stream, new ReaderParameters(ReadingMode.Deferred));
		}

		public static ModuleDefinition ReadModule(string fileName, ReaderParameters parameters)
		{
			ModuleDefinition result;
			using (Stream fileStream = ModuleDefinition.GetFileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				result = ModuleDefinition.ReadModule(fileStream, parameters);
			}
			return result;
		}

		public static ModuleDefinition ReadModule(Stream stream, ReaderParameters parameters)
		{
			ModuleDefinition.CheckStream(stream);
			if (!stream.CanRead || !stream.CanSeek)
			{
				throw new ArgumentException();
			}
			Mixin.CheckParameters(parameters);
			return ModuleReader.CreateModuleFrom(ImageReader.ReadImageFrom(stream), parameters);
		}

		public void ReadSymbols()
		{
			if (string.IsNullOrEmpty(this.fq_name))
			{
				throw new InvalidOperationException();
			}
			ISymbolReaderProvider platformReaderProvider = SymbolProvider.GetPlatformReaderProvider();
			if (platformReaderProvider == null)
			{
				throw new InvalidOperationException();
			}
			this.ReadSymbols(platformReaderProvider.GetSymbolReader(this, this.fq_name));
		}

		public void ReadSymbols(ISymbolReader reader)
		{
			if (reader == null)
			{
				throw new ArgumentNullException("reader");
			}
			this.symbol_reader = reader;
			this.ProcessDebugHeader();
		}

		internal FieldDefinition Resolve(FieldReference field)
		{
			return this.MetadataResolver.Resolve(field);
		}

		internal MethodDefinition Resolve(MethodReference method)
		{
			return this.MetadataResolver.Resolve(method);
		}

		internal TypeDefinition Resolve(TypeReference type)
		{
			return this.MetadataResolver.Resolve(type);
		}

		public bool TryGetTypeReference(string fullName, out TypeReference type)
		{
			return this.TryGetTypeReference(string.Empty, fullName, out type);
		}

		public bool TryGetTypeReference(string scope, string fullName, out TypeReference type)
		{
			ModuleDefinition.CheckFullName(fullName);
			if (!this.HasImage)
			{
				type = null;
				return false;
			}
			TypeReference typeReference;
			type = (typeReference = this.GetTypeReference(scope, fullName));
			return typeReference != null;
		}

		public void Write(string fileName)
		{
			this.Write(fileName, new WriterParameters());
		}

		public void Write(Stream stream)
		{
			this.Write(stream, new WriterParameters());
		}

		public void Write(string fileName, WriterParameters parameters)
		{
			using (Stream fileStream = ModuleDefinition.GetFileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
			{
				this.Write(fileStream, parameters);
			}
		}

		public void Write(Stream stream, WriterParameters parameters)
		{
			ModuleDefinition.CheckStream(stream);
			if (!stream.CanWrite || !stream.CanSeek)
			{
				throw new ArgumentException();
			}
			Mixin.CheckParameters(parameters);
			ModuleWriter.WriteModuleTo(this, stream, parameters);
		}

		public TargetArchitecture Architecture
		{
			get
			{
				return this.architecture;
			}
			set
			{
				this.architecture = value;
			}
		}

		public AssemblyDefinition Assembly
		{
			get
			{
				return this.assembly;
			}
		}

		public Collection<AssemblyNameReference> AssemblyReferences
		{
			get
			{
				if (this.references != null)
				{
					return this.references;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, Collection<AssemblyNameReference>>(ref this.references, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadAssemblyReferences());
				}
				return this.references = new Collection<AssemblyNameReference>();
			}
		}

		public IAssemblyResolver AssemblyResolver
		{
			get
			{
				if (this.assembly_resolver == null)
				{
					Interlocked.CompareExchange<IAssemblyResolver>(ref this.assembly_resolver, new DefaultAssemblyResolver(), null);
				}
				return this.assembly_resolver;
			}
		}

		public ModuleAttributes Attributes
		{
			get
			{
				return this.attributes;
			}
			set
			{
				this.attributes = value;
			}
		}

		public ModuleCharacteristics Characteristics
		{
			get
			{
				return this.characteristics;
			}
			set
			{
				this.characteristics = value;
			}
		}

		public Collection<CustomAttribute> CustomAttributes
		{
			get
			{
				return this.custom_attributes ?? this.GetCustomAttributes(ref this.custom_attributes, this);
			}
		}

		public MethodDefinition EntryPoint
		{
			get
			{
				if (this.entry_point != null)
				{
					return this.entry_point;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, MethodDefinition>(ref this.entry_point, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadEntryPoint());
				}
				return this.entry_point = null;
			}
			set
			{
				this.entry_point = value;
			}
		}

		public Collection<ExportedType> ExportedTypes
		{
			get
			{
				if (this.exported_types != null)
				{
					return this.exported_types;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, Collection<ExportedType>>(ref this.exported_types, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadExportedTypes());
				}
				return this.exported_types = new Collection<ExportedType>();
			}
		}

		public string FullyQualifiedName
		{
			get
			{
				return this.fq_name;
			}
		}

		public bool HasAssemblyReferences
		{
			get
			{
				if (this.references != null)
				{
					return this.references.Count > 0;
				}
				return this.HasImage && this.Image.HasTable(Table.AssemblyRef);
			}
		}

		public bool HasCustomAttributes
		{
			get
			{
				if (this.custom_attributes != null)
				{
					return this.custom_attributes.Count > 0;
				}
				return this.GetHasCustomAttributes(this);
			}
		}

		public bool HasDebugHeader
		{
			get
			{
				return this.Image != null && !this.Image.Debug.IsZero;
			}
		}

		public bool HasExportedTypes
		{
			get
			{
				if (this.exported_types != null)
				{
					return this.exported_types.Count > 0;
				}
				return this.HasImage && this.Image.HasTable(Table.ExportedType);
			}
		}

		internal bool HasImage
		{
			get
			{
				return this.Image != null;
			}
		}

		public bool HasModuleReferences
		{
			get
			{
				if (this.modules != null)
				{
					return this.modules.Count > 0;
				}
				return this.HasImage && this.Image.HasTable(Table.ModuleRef);
			}
		}

		public bool HasResources
		{
			get
			{
				if (this.resources != null)
				{
					return this.resources.Count > 0;
				}
				if (!this.HasImage)
				{
					return false;
				}
				if (!this.Image.HasTable(Table.ManifestResource))
				{
					return this.Read<ModuleDefinition, bool>(this, (ModuleDefinition _, MetadataReader reader) => reader.HasFileResource());
				}
				return true;
			}
		}

		public bool HasSymbols
		{
			get
			{
				return this.symbol_reader != null;
			}
		}

		public bool HasTypes
		{
			get
			{
				if (this.types != null)
				{
					return this.types.Count > 0;
				}
				return this.HasImage && this.Image.HasTable(Table.TypeDef);
			}
		}

		public bool IsMain
		{
			get
			{
				return this.kind != ModuleKind.NetModule;
			}
		}

		public ModuleKind Kind
		{
			get
			{
				return this.kind;
			}
			set
			{
				this.kind = value;
			}
		}

		internal MetadataImporter MetadataImporter
		{
			get
			{
				if (this.importer == null)
				{
					Interlocked.CompareExchange<MetadataImporter>(ref this.importer, new MetadataImporter(this), null);
				}
				return this.importer;
			}
		}

		public IMetadataResolver MetadataResolver
		{
			get
			{
				if (this.metadata_resolver == null)
				{
					Interlocked.CompareExchange<IMetadataResolver>(ref this.metadata_resolver, new MetadataResolver(this.AssemblyResolver), null);
				}
				return this.metadata_resolver;
			}
		}

		public override MetadataScopeType MetadataScopeType
		{
			get
			{
				return MetadataScopeType.ModuleDefinition;
			}
		}

		public Collection<ModuleReference> ModuleReferences
		{
			get
			{
				if (this.modules != null)
				{
					return this.modules;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, Collection<ModuleReference>>(ref this.modules, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadModuleReferences());
				}
				return this.modules = new Collection<ModuleReference>();
			}
		}

		public Guid Mvid
		{
			get
			{
				return this.mvid;
			}
			set
			{
				this.mvid = value;
			}
		}

		public Collection<Resource> Resources
		{
			get
			{
				if (this.resources != null)
				{
					return this.resources;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, Collection<Resource>>(ref this.resources, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadResources());
				}
				return this.resources = new Collection<Resource>();
			}
		}

		public TargetRuntime Runtime
		{
			get
			{
				return this.runtime;
			}
			set
			{
				this.runtime = value;
				this.runtime_version = this.runtime.RuntimeVersionString();
			}
		}

		public string RuntimeVersion
		{
			get
			{
				return this.runtime_version;
			}
			set
			{
				this.runtime_version = value;
				this.runtime = this.runtime_version.ParseRuntime();
			}
		}

		public ISymbolReader SymbolReader
		{
			get
			{
				return this.symbol_reader;
			}
		}

		internal object SyncRoot
		{
			get
			{
				return this.module_lock;
			}
		}

		public Collection<TypeDefinition> Types
		{
			get
			{
				if (this.types != null)
				{
					return this.types;
				}
				if (this.HasImage)
				{
					return this.Read<ModuleDefinition, TypeDefinitionCollection>(ref this.types, this, (ModuleDefinition _, MetadataReader reader) => reader.ReadTypes());
				}
				return this.types = new TypeDefinitionCollection(this);
			}
		}

		public TypeSystem TypeSystem
		{
			get
			{
				if (this.type_system == null)
				{
					Interlocked.CompareExchange<TypeSystem>(ref this.type_system, TypeSystem.CreateTypeSystem(this), null);
				}
				return this.type_system;
			}
		}

		private TargetArchitecture architecture;

		internal AssemblyDefinition assembly;

		internal IAssemblyResolver assembly_resolver;

		private ModuleAttributes attributes;

		private ModuleCharacteristics characteristics;

		private Collection<CustomAttribute> custom_attributes;

		private MethodDefinition entry_point;

		private Collection<ExportedType> exported_types;

		private readonly string fq_name;

		internal Image Image;

		private MetadataImporter importer;

		internal ModuleKind kind;

		internal MetadataSystem MetadataSystem;

		internal IMetadataResolver metadata_resolver;

		private Collection<ModuleReference> modules;

		private readonly object module_lock = new object();

		private Guid mvid;

		private readonly MetadataReader reader;

		internal ReadingMode ReadingMode;

		private Collection<AssemblyNameReference> references;

		private Collection<Resource> resources;

		private TargetRuntime runtime;

		internal string runtime_version;

		internal ISymbolReaderProvider SymbolReaderProvider;

		internal ISymbolReader symbol_reader;

		private TypeDefinitionCollection types;

		internal TypeSystem type_system;
	}
}
