﻿using System;
using Mono.Cecil.PE;

namespace Mono.Cecil.Metadata
{
	internal abstract class Heap
	{
		protected Heap(Section section, uint offset, uint size)
		{
			this.Section = section;
			this.Offset = offset;
			this.Size = size;
		}

		public int IndexSize;

		public readonly uint Offset;

		public readonly Section Section;

		public readonly uint Size;
	}
}
