﻿using System;
using Mono.Cecil.PE;

namespace Mono.Cecil.Metadata
{
	internal sealed class BlobHeap : Heap
	{
		public BlobHeap(Section section, uint start, uint size) : base(section, start, size)
		{
		}

		public byte[] Read(uint index)
		{
			if (index == 0u || index > this.Size - 1u)
			{
				return Empty<byte>.Array;
			}
			byte[] data = this.Section.Data;
			int srcOffset = (int)(index + this.Offset);
			int num = (int)data.ReadCompressedUInt32(ref srcOffset);
			byte[] array = new byte[num];
			Buffer.BlockCopy(data, srcOffset, array, 0, num);
			return array;
		}
	}
}
