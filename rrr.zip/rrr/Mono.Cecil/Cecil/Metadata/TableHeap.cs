﻿using System;
using Mono.Cecil.PE;

namespace Mono.Cecil.Metadata
{
	internal sealed class TableHeap : Heap
	{
		public TableHeap(Section section, uint start, uint size) : base(section, start, size)
		{
		}

		public bool HasTable(Table table)
		{
			return (this.Valid & 1L << (int)table) != 0L;
		}

		public TableInformation this[Table table]
		{
			get
			{
				return this.Tables[(int)table];
			}
		}

		public long Sorted;

		public const int TableCount = 45;

		public readonly TableInformation[] Tables = new TableInformation[45];

		public long Valid;
	}
}
