﻿using System;
using Mono.Cecil.PE;

namespace Mono.Cecil.Metadata
{
	internal abstract class HeapBuffer : ByteBuffer
	{
		protected HeapBuffer(int length) : base(length)
		{
		}

		public abstract bool IsEmpty
		{
			get;
		}

		public bool IsLarge
		{
			get
			{
				return this.length > 65535;
			}
		}
	}
}
