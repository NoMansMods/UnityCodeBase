﻿using System;
using System.IO;
using System.Runtime.Serialization;

namespace Mono.Cecil
{
	[Serializable]
	public class AssemblyResolutionException : FileNotFoundException
	{
		public AssemblyResolutionException(AssemblyNameReference reference) : base(string.Format("Failed to resolve assembly: '{0}'", reference))
		{
			this.reference = reference;
		}

		protected AssemblyResolutionException(SerializationInfo info, StreamingContext context) : base(info, context)
		{
		}

		public AssemblyNameReference AssemblyReference
		{
			get
			{
				return this.reference;
			}
		}

		private readonly AssemblyNameReference reference;
	}
}
