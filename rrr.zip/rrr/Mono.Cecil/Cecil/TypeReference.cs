﻿using System;
using Mono.Cecil.Metadata;
using Mono.Collections.Generic;

namespace Mono.Cecil
{
	public class TypeReference : MemberReference, IGenericParameterProvider, IMetadataTokenProvider, IGenericContext
	{
		protected TypeReference(string @namespace, string name) : base(name)
		{
			this.@namespace = (@namespace ?? string.Empty);
			this.token = new MetadataToken(TokenType.TypeRef, 0);
		}

		public TypeReference(string @namespace, string name, ModuleDefinition module, IMetadataScope scope) : this(@namespace, name)
		{
			this.module = module;
			this.scope = scope;
		}

		public TypeReference(string @namespace, string name, ModuleDefinition module, IMetadataScope scope, bool valueType) : this(@namespace, name, module, scope)
		{
			this.value_type = valueType;
		}

		public virtual TypeReference GetElementType()
		{
			return this;
		}

		public virtual TypeDefinition Resolve()
		{
			ModuleDefinition moduleDefinition = this.Module;
			if (moduleDefinition == null)
			{
				throw new NotSupportedException();
			}
			return moduleDefinition.Resolve(this);
		}

		public override TypeReference DeclaringType
		{
			get
			{
				return base.DeclaringType;
			}
			set
			{
				base.DeclaringType = value;
				this.fullname = null;
			}
		}

		public override string FullName
		{
			get
			{
				if (this.fullname != null)
				{
					return this.fullname;
				}
				this.fullname = this.TypeFullName();
				if (this.IsNested)
				{
					this.fullname = this.DeclaringType.FullName + "/" + this.fullname;
				}
				return this.fullname;
			}
		}

		public virtual Collection<GenericParameter> GenericParameters
		{
			get
			{
				if (this.generic_parameters != null)
				{
					return this.generic_parameters;
				}
				return this.generic_parameters = new GenericParameterCollection(this);
			}
		}

		public virtual bool HasGenericParameters
		{
			get
			{
				return !this.generic_parameters.IsNullOrEmpty<GenericParameter>();
			}
		}

		public virtual bool IsArray
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsByReference
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsFunctionPointer
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsGenericInstance
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsGenericParameter
		{
			get
			{
				return false;
			}
		}

		public bool IsNested
		{
			get
			{
				return this.DeclaringType != null;
			}
		}

		public virtual bool IsOptionalModifier
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsPinned
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsPointer
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsPrimitive
		{
			get
			{
				return this.etype.IsPrimitive();
			}
		}

		public virtual bool IsRequiredModifier
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsSentinel
		{
			get
			{
				return false;
			}
		}

		public virtual bool IsValueType
		{
			get
			{
				return this.value_type;
			}
			set
			{
				this.value_type = value;
			}
		}

		public virtual MetadataType MetadataType
		{
			get
			{
				ElementType elementType = this.etype;
				if (elementType != ElementType.None)
				{
					return (MetadataType)this.etype;
				}
				if (!this.IsValueType)
				{
					return MetadataType.Class;
				}
				return MetadataType.ValueType;
			}
		}

		public override ModuleDefinition Module
		{
			get
			{
				if (this.module != null)
				{
					return this.module;
				}
				TypeReference declaringType = this.DeclaringType;
				if (declaringType != null)
				{
					return declaringType.Module;
				}
				return null;
			}
		}

		IGenericParameterProvider IGenericContext.Method
		{
			get
			{
				return null;
			}
		}

		IGenericParameterProvider IGenericContext.Type
		{
			get
			{
				return this;
			}
		}

		GenericParameterType IGenericParameterProvider.GenericParameterType
		{
			get
			{
				return GenericParameterType.Type;
			}
		}

		public override string Name
		{
			get
			{
				return base.Name;
			}
			set
			{
				base.Name = value;
				this.fullname = null;
			}
		}

		public virtual string Namespace
		{
			get
			{
				return this.@namespace;
			}
			set
			{
				this.@namespace = value;
				this.fullname = null;
			}
		}

		public virtual IMetadataScope Scope
		{
			get
			{
				TypeReference declaringType = this.DeclaringType;
				if (declaringType != null)
				{
					return declaringType.Scope;
				}
				return this.scope;
			}
			set
			{
				TypeReference declaringType = this.DeclaringType;
				if (declaringType != null)
				{
					declaringType.Scope = value;
					return;
				}
				this.scope = value;
			}
		}

		internal ElementType etype;

		private string fullname;

		protected Collection<GenericParameter> generic_parameters;

		internal ModuleDefinition module;

		private string @namespace;

		internal IMetadataScope scope;

		private bool value_type;
	}
}
