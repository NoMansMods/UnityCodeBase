﻿using System;

namespace Mono.Cecil
{
	public enum TargetArchitecture
	{
		I386,
		AMD64,
		IA64,
		ARMv7
	}
}
