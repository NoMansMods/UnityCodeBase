﻿using System;

namespace Mono.Cecil
{
	public sealed class LinkedResource : Resource
	{
		public LinkedResource(string name, ManifestResourceAttributes flags) : base(name, flags)
		{
		}

		public LinkedResource(string name, ManifestResourceAttributes flags, string file) : base(name, flags)
		{
			this.file = file;
		}

		public string File
		{
			get
			{
				return this.file;
			}
			set
			{
				this.file = value;
			}
		}

		public byte[] Hash
		{
			get
			{
				return this.hash;
			}
		}

		public override ResourceType ResourceType
		{
			get
			{
				return ResourceType.Linked;
			}
		}

		private string file;

		internal byte[] hash;
	}
}
