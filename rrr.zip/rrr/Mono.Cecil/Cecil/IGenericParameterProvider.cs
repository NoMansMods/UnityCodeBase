﻿using System;
using Mono.Collections.Generic;

namespace Mono.Cecil
{
	public interface IGenericParameterProvider : IMetadataTokenProvider
	{
		Collection<GenericParameter> GenericParameters
		{
			get;
		}

		GenericParameterType GenericParameterType
		{
			get;
		}

		bool HasGenericParameters
		{
			get;
		}

		bool IsDefinition
		{
			get;
		}

		ModuleDefinition Module
		{
			get;
		}
	}
}
