﻿using System;

namespace Mono.Cecil.Cil
{
	public enum OpCodeType
	{
		Annotation,
		Macro,
		Nternal,
		Objmodel,
		Prefix,
		Primitive
	}
}
