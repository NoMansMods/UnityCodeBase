﻿using System;
using System.Threading;
using Mono.Collections.Generic;

namespace Mono.Cecil.Cil
{
	public sealed class MethodBody : IVariableDefinitionProvider
	{
		public MethodBody(MethodDefinition method)
		{
			this.method = method;
		}

		private static ParameterDefinition CreateThisParameter(MethodDefinition method)
		{
			TypeDefinition declaringType = method.DeclaringType;
			TypeReference parameterType = (declaringType.IsValueType || declaringType.IsPrimitive) ? new PointerType(declaringType) : declaringType;
			return new ParameterDefinition(parameterType, method);
		}

		public ILProcessor GetILProcessor()
		{
			return new ILProcessor(this);
		}

		public int CodeSize
		{
			get
			{
				return this.code_size;
			}
		}

		public Collection<ExceptionHandler> ExceptionHandlers
		{
			get
			{
				Collection<ExceptionHandler> arg_18_0;
				if ((arg_18_0 = this.exceptions) == null)
				{
					arg_18_0 = (this.exceptions = new Collection<ExceptionHandler>());
				}
				return arg_18_0;
			}
		}

		public bool HasExceptionHandlers
		{
			get
			{
				return !this.exceptions.IsNullOrEmpty<ExceptionHandler>();
			}
		}

		public bool HasVariables
		{
			get
			{
				return !this.variables.IsNullOrEmpty<VariableDefinition>();
			}
		}

		public bool InitLocals
		{
			get
			{
				return this.init_locals;
			}
			set
			{
				this.init_locals = value;
			}
		}

		public Collection<Instruction> Instructions
		{
			get
			{
				Collection<Instruction> arg_18_0;
				if ((arg_18_0 = this.instructions) == null)
				{
					arg_18_0 = (this.instructions = new InstructionCollection());
				}
				return arg_18_0;
			}
		}

		public MetadataToken LocalVarToken
		{
			get
			{
				return this.local_var_token;
			}
			set
			{
				this.local_var_token = value;
			}
		}

		public int MaxStackSize
		{
			get
			{
				return this.max_stack_size;
			}
			set
			{
				this.max_stack_size = value;
			}
		}

		public MethodDefinition Method
		{
			get
			{
				return this.method;
			}
		}

		public Scope Scope
		{
			get
			{
				return this.scope;
			}
			set
			{
				this.scope = value;
			}
		}

		public ParameterDefinition ThisParameter
		{
			get
			{
				if (this.method == null || this.method.DeclaringType == null)
				{
					throw new NotSupportedException();
				}
				if (!this.method.HasThis)
				{
					return null;
				}
				if (this.this_parameter == null)
				{
					Interlocked.CompareExchange<ParameterDefinition>(ref this.this_parameter, MethodBody.CreateThisParameter(this.method), null);
				}
				return this.this_parameter;
			}
		}

		public Collection<VariableDefinition> Variables
		{
			get
			{
				Collection<VariableDefinition> arg_18_0;
				if ((arg_18_0 = this.variables) == null)
				{
					arg_18_0 = (this.variables = new VariableDefinitionCollection());
				}
				return arg_18_0;
			}
		}

		internal int code_size;

		internal Collection<ExceptionHandler> exceptions;

		internal bool init_locals;

		internal Collection<Instruction> instructions;

		internal MetadataToken local_var_token;

		internal int max_stack_size;

		internal readonly MethodDefinition method;

		private Scope scope;

		internal ParameterDefinition this_parameter;

		internal Collection<VariableDefinition> variables;
	}
}
