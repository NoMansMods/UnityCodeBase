﻿using System;

namespace Mono.Cecil.Cil
{
	public enum DocumentType
	{
		Other,
		Text
	}
}
