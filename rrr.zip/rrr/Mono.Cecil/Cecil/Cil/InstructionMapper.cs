﻿using System;

namespace Mono.Cecil.Cil
{
	public delegate Instruction InstructionMapper(int offset);
}
