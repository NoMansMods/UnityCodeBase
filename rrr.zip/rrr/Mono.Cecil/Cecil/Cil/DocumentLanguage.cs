﻿using System;

namespace Mono.Cecil.Cil
{
	public enum DocumentLanguage
	{
		Other,
		C,
		Cpp,
		CSharp,
		Basic,
		Java,
		Cobol,
		Pascal,
		Cil,
		JScript,
		Smc,
		MCpp,
		FSharp
	}
}
