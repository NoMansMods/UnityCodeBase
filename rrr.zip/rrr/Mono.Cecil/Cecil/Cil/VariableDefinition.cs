﻿using System;

namespace Mono.Cecil.Cil
{
	public sealed class VariableDefinition : VariableReference
	{
		public VariableDefinition(TypeReference variableType) : base(variableType)
		{
		}

		public VariableDefinition(string name, TypeReference variableType) : base(name, variableType)
		{
		}

		public override VariableDefinition Resolve()
		{
			return this;
		}

		public bool IsPinned
		{
			get
			{
				return this.variable_type.IsPinned;
			}
		}
	}
}
