﻿using System;
using Mono.Collections.Generic;

namespace Mono.Cecil.Cil
{
	public sealed class Scope : IVariableDefinitionProvider
	{
		public Instruction End
		{
			get
			{
				return this.end;
			}
			set
			{
				this.end = value;
			}
		}

		public bool HasScopes
		{
			get
			{
				return !this.scopes.IsNullOrEmpty<Scope>();
			}
		}

		public bool HasVariables
		{
			get
			{
				return !this.variables.IsNullOrEmpty<VariableDefinition>();
			}
		}

		public Collection<Scope> Scopes
		{
			get
			{
				if (this.scopes == null)
				{
					this.scopes = new Collection<Scope>();
				}
				return this.scopes;
			}
		}

		public Instruction Start
		{
			get
			{
				return this.start;
			}
			set
			{
				this.start = value;
			}
		}

		public Collection<VariableDefinition> Variables
		{
			get
			{
				if (this.variables == null)
				{
					this.variables = new Collection<VariableDefinition>();
				}
				return this.variables;
			}
		}

		private Instruction end;

		private Collection<Scope> scopes;

		private Instruction start;

		private Collection<VariableDefinition> variables;
	}
}
