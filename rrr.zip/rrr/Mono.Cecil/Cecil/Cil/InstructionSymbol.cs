﻿using System;

namespace Mono.Cecil.Cil
{
	public struct InstructionSymbol
	{
		public InstructionSymbol(int offset, SequencePoint sequencePoint)
		{
			this.Offset = offset;
			this.SequencePoint = sequencePoint;
		}

		public readonly int Offset;

		public readonly SequencePoint SequencePoint;
	}
}
