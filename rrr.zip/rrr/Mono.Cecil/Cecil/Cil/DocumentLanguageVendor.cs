﻿using System;

namespace Mono.Cecil.Cil
{
	public enum DocumentLanguageVendor
	{
		Other,
		Microsoft
	}
}
