﻿using System;

namespace Mono.Cecil.Cil
{
	public enum DocumentHashAlgorithm
	{
		None,
		MD5,
		SHA1
	}
}
